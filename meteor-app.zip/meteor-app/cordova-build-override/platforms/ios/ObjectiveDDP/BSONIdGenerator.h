#import <Foundation/Foundation.h>

@interface BSONIdGenerator : NSObject
+ (NSString *)generate;
@end
