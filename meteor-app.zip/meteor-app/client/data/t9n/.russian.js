/**
 * Created by douson on 13.07.15.
 */

var ru;

    ru = {
        getAllUsers:         'Все пользователи системы',
        getContactUsers:     'Найденные контакты',
        status:              'Статус',
        active:              'Активные',
        inactive:            'Завершенные',
        views:               'Просмотров',
        left:                'Осталось',
        //home:
        headliner:           'Мгновенное объявление, основанное на положении.',//wtf??
        distance:             'Дистанция',
        mile:                 'миля',
        miles:                 'миль',
        ft:                 'футов'
    };

T9n.map('ru', ru);