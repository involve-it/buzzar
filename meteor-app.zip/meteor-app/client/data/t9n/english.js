/**
 * Created by douson on 13.07.15.
 */

var en;

en = {
  getAllUsers: 'Get all system users',
  getContactUsers: 'Contacts found',
  status: 'Status',
  active: 'Active',
  inactive: 'Inactive',
  views: 'Views',
  left: 'Left',
  //sitewise:
  siteTitleElement: 'instant post, bound to location',
  // home page:
  headliner: 'instant post, bound to location',
  distance: 'Distance',
  mile: 'ml',
  miles: 'ml',
  ft: 'ft'
};

T9n.map('en', en);