/**
 * Created by Ashot on 9/6/15.
 */

Template.checkInBtn.events({
  'click .js-checkin-btn': function(e,v){
    //debugger;
  }
})