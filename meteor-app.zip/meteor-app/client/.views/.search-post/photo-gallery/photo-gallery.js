/**
 * Created by douson on 21.08.15.
 */

Template.photoGallery.helpers({
    getPhotoGallery: function() {
        return false;
    }
});