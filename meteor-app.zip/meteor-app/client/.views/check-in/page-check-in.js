/**
 * Created by Ashot on 9/6/15.
 */
/*if (Meteor.isClient) {
  debugger;
  angular.module('socially',['angular-meteor']);
}*/

function onReady() {
}
Template.pageCheckIn.rendered = function(){
}
Template.pageCheckIn.helpers({});