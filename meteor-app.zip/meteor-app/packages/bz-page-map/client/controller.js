/**
 * Created by Ashot on 9/19/15.
 */
//bz.help.makeNamespace('bz.runtime.newPost.location');
