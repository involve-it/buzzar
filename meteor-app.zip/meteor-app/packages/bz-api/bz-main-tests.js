// Write your tests here!
// Here is an example.

Tinytest.add('example-main-pass', function (test) {
  test.equal(true, true);
  //test.equal(false, true);
});

Tinytest.add('example-main-fail', function (test) {
  test.equal(true, false);
  //test.equal(false, true);
});

// need velocity for this:
/*describe('sanjo:jasmine on client', function () {
  it('works', function () {
    expect(it).toBeDefined();
  })
})*/
