/**
 * Created by Ashot on 9/26/15.
 */
Meteor.subscribe('bz.reviews.all');

imagesArrayGlobal = [];