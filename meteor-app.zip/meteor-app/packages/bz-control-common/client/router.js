/**
 * Created by Ashot on 9/25/15.
 */
/*
 Router.onBeforeAction(function(){
 loadFilePicker('ALnxiQfmTvCYXXHc2Xlb2z');
 this.next();
 //can leave out key if its in settings
 },{only:['settings.edit']});*/