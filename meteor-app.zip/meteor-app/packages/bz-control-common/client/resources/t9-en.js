/**
 * Created by douson on 13.07.15.
 */

var en;

en = {
  searchLocationText: 'Place name or address'
};

T9n.map('en', en);