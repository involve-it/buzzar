/**
 * Created by Ashot on 9/27/15.
 */
//comments = new Meteor.Pagination('bz.reviews');