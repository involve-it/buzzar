/**
 * Created by ashot on 8/20/15.
 */
var isOn = false;
Template.bzPageChats.events({

});

Template.bzPageChats.rendered = function () {
  
  //$('select').foundationSelect();
  //$(document).foundation();

};




