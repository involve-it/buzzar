/**
 * Created by ashot on 8/25/15.
 */
Template.postsPageDetails.onCreated(function(){
});
Template.postsPageDetails.helpers({
});
