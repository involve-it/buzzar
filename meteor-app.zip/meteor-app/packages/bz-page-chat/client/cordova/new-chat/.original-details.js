Template.postsNewOriginalDetails.create = function(){
}