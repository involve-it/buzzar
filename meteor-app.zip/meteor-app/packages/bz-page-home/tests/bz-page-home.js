// Write your tests here!
// Here is an example.
Tinytest.add('MeteorFile - read', function (test) {
  test.equal(true, true);
});
