// Write your tests here!
// Here is an example.
Tinytest.add('example-main-test', function (test) {
  test.equal(true, true);
});
