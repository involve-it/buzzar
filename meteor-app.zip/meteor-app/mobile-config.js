/**
 * Created by yvdorofeev on 10/8/15.
 */
App.accessRule('*');