(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/01_inits/01_init.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/12/15.                                                                                       // 2
 */                                                                                                                   // 3
var global;                                                                                                           // 4
if(Meteor.isClient){                                                                                                  // 5
  global = typeof window !== 'undefined' && window !== null ? window : {};                                            // 6
} else if (Meteor.isServer) {                                                                                         // 7
  global = typeof GLOBAL !== 'undefined' && GLOBAL !== null ? GLOBAL : {};                                            // 8
}                                                                                                                     // 9
global.bz = {}                                                                                                        // 10
global.bz.cols = {}                                                                                                   // 11
global.bz.runtime = {}                                                                                                // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/01_inits/02_helpers.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/20/15.                                                                                       // 2
 */                                                                                                                   // 3
var Helpers = {}                                                                                                      // 4
/**                                                                                                                   // 5
 * This function is for constructing namespace objects from a string, attaching it to a global window object.         // 6
 * If some objects already exist, it will extend them. Dependant on the underscore.js library.                        // 7
 * this can span multiple lines.                                                                                      // 8
 *                                                                                                                    // 9
 * @method makeNamespace                                                                                              // 10
 * @param {Object} initialObject - main config object, containing:                                                    // 11
 *	- path: names of objects in the chain, delimited by '.'                                                            // 12
 *	- object: the object that will be placed into the namespace end.                                                   // 13
 *	  if object is not provided, just create the namespace, if it does not exist yet.                                  // 14
 *	OR initialObject can be a string, in which case consider it as a new namespace,                                    // 15
 *	  and the second parameter is the original object (or non-defined).                                                // 16
 * @return {Object} final object assigned to the namespace.                                                           // 17
 */                                                                                                                   // 18
Helpers.makeNamespace = function (initialObject) {                                                                    // 19
  if (initialObject && typeof initialObject === 'string') {                                                           // 20
    initialObject = {                                                                                                 // 21
      path: initialObject,                                                                                            // 22
      object: arguments[1]                                                                                            // 23
    }                                                                                                                 // 24
  };                                                                                                                  // 25
  var buildFromName, first, foreverFirst, global, l1, l2, namespace, retObj, sc, subPaths;                            // 26
  if(Meteor.isClient){                                                                                                // 27
    global = typeof window !== 'undefined' && window !== null ? window : {};                                          // 28
  } else if (Meteor.isServer) {                                                                                       // 29
    global = typeof GLOBAL !== 'undefined' && GLOBAL !== null ? GLOBAL : {};                                          // 30
  }                                                                                                                   // 31
                                                                                                                      // 32
  if (typeof global === 'string') {                                                                                   // 33
    global = eval(global);                                                                                            // 34
  }                                                                                                                   // 35
  subPaths = initialObject.path.split('.').reverse();                                                                 // 36
  foreverFirst = subPaths[0];                                                                                         // 37
  first = subPaths.pop();                                                                                             // 38
  namespace = global[first] = typeof global[first] !== 'undefined' && global[first] || {};                            // 39
  if (subPaths.length === 0) {                                                                                        // 40
    if (typeof global[first] !== 'undefined' && global[first]) {                                                      // 41
      _.extend(global[first], initialObject);                                                                         // 42
    } else {                                                                                                          // 43
      global[first] = initialObject.object;                                                                           // 44
    }                                                                                                                 // 45
    return namespace;                                                                                                 // 46
  }                                                                                                                   // 47
  retObj = null;                                                                                                      // 48
  l1 = l2 = subPaths.length;                                                                                          // 49
  buildFromName = function (paths, ns) {                                                                              // 50
    var retns;                                                                                                        // 51
    if (paths.length <= 0) {                                                                                          // 52
      return ns;                                                                                                      // 53
    }                                                                                                                 // 54
    first = subPaths.pop();                                                                                           // 55
    retns = typeof ns[first] !== 'undefined' && ns[first] || {};                                                      // 56
    ns[first] = buildFromName(paths, retns);                                                                          // 57
    if (l1 === l2) {                                                                                                  // 58
      if (typeof initialObject.object !== 'undefined') {                                                              // 59
        if (!_.isObject(initialObject.object)) {                                                                      // 60
          ns[foreverFirst] = initialObject.object;                                                                    // 61
        } else {                                                                                                      // 62
          ns[foreverFirst] = _.extend(ns[foreverFirst], initialObject.object);                                        // 63
        }                                                                                                             // 64
      }                                                                                                               // 65
      retObj = _.extend(ns[foreverFirst] != null ? ns[foreverFirst] : ns[foreverFirst] = {}, retObj != null ? retObj : retObj = {});
    }                                                                                                                 // 67
    l1 = l1 - 1;                                                                                                      // 68
    return ns;                                                                                                        // 69
  };                                                                                                                  // 70
  namespace = buildFromName(subPaths, namespace);                                                                     // 71
  return retObj;                                                                                                      // 72
};                                                                                                                    // 73
/**                                                                                                                   // 74
 * This function is for checking namespace existence from a string. Convenience method to replace tedious existence checks.
 * If global namespace object exists, it will return true, otherwise - false. Dependant on the underscore.js library. // 76
 * @method checkNamespace                                                                                             // 77
 * @param {string} namespace - namespace to verify.                                                                   // 78
 * @returns {bool} value showing if the namespace exists.                                                             // 79
 * @example if (bz && bz.lat && bz.lat.lon && bz.lat.lon[0] && bz.lat.lon[0].a ) can be replaced with one call "checkNamespace('bz.lat.lon[0].a')
 *                                                                                                                    // 81
 */                                                                                                                   // 82
Helpers.checkNamespace = function(namespace){                                                                         // 83
                                                                                                                      // 84
}                                                                                                                     // 85
/**                                                                                                                   // 86
 * This function is for wrapping custom function for safe code execution                                              // 87
 * If exception of any kind is thrown, it will either be thrown                                                       // 88
 *	or will be logged (if ReferenceError , that stops execution of consequent code in the script).                     // 89
 *                                                                                                                    // 90
 * @method MakeGlobalNamespaceAndObject                                                                               // 91
 * @param {Function} functionWithCode - function object, containing code to execute                                   // 92
 * @param [1..n] - any parameters, that should be passed into the function                                            // 93
 * @returns {Object} object, that is returned by functionWithCode / error.                                            // 94
 */                                                                                                                   // 95
Helpers.safeCode = function (functionWithCode) {                                                                      // 96
  var ret = undefined;                                                                                                // 97
  if (functionWithCode && typeof functionWithCode === 'function') {                                                   // 98
                                                                                                                      // 99
    try {                                                                                                             // 100
      ret = functionWithCode.apply(functionWithCode, Array.prototype.slice.call(arguments, 1));                       // 101
    } catch (ex) {                                                                                                    // 102
      ret = ex;                                                                                                       // 103
      bz.help.logError(ex);                                                                                           // 104
    }                                                                                                                 // 105
  }                                                                                                                   // 106
  return ret;                                                                                                         // 107
}                                                                                                                     // 108
Helpers.logError = function (exObject, message, logToRollbar) {                                                       // 109
  // check if first argument is of Error type:                                                                        // 110
  if (typeof exObject === 'object' && exObject instanceof Error) {                                                    // 111
                                                                                                                      // 112
  } else if (typeof exObject === 'string' && exObject !== '') {                                                       // 113
    message = exObject;                                                                                               // 114
                                                                                                                      // 115
    exObject = new Error(message);                                                                                    // 116
    if (typeof message === 'boolean') {                                                                               // 117
      logToRollbar = message;                                                                                         // 118
    }                                                                                                                 // 119
  }                                                                                                                   // 120
  if (bz && bz.config && bz.config.env) {                                                                             // 121
    if (bz.config.env === 'dev') {                                                                                    // 122
      if (console) {                                                                                                  // 123
        if (console.error) {                                                                                          // 124
          console.error(exObject);                                                                                    // 125
        } else if (console.log) {                                                                                     // 126
          console.log(message);                                                                                       // 127
        }                                                                                                             // 128
      }                                                                                                               // 129
      // log to rollbar if developer explicetely asked for this:                                                      // 130
      logToRollbar && typeof Rollbar !== 'undefined' && Rollbar.error(message, exObject);                             // 131
    } else if (bz.config.env === 'prod') {                                                                            // 132
      // do rollbar:                                                                                                  // 133
      // send to roolbar, if needed (see this api: https://rollbar.com/docs/notifier/rollbar.js/):                    // 134
      if (logToRollbar !== false) {// don't log to rollbar if developer explicetely asked for this:                   // 135
        typeof Rollbar !== 'undefined' && Rollbar.error(message, exObject);                                           // 136
      }                                                                                                               // 137
    }                                                                                                                 // 138
  }                                                                                                                   // 139
}                                                                                                                     // 140
Helpers.log = function (text){                                                                                        // 141
  if (bz.config.env === 'dev' && console && console.log) {                                                            // 142
                                                                                                                      // 143
  }                                                                                                                   // 144
}                                                                                                                     // 145
Helpers.collectionExists = function(name) {                                                                           // 146
  return Meteor.connection._mongo_livedata_collections[name] !== null && Meteor.connection._mongo_livedata_collections[name] !== undefined;
}                                                                                                                     // 148
Helpers.makeNamespace({                                                                                               // 149
  path: 'bz.help',                                                                                                    // 150
  object: Helpers                                                                                                     // 151
});                                                                                                                   // 152
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/01_inits/03_extends.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/20/15.                                                                                       // 2
 */                                                                                                                   // 3
  // extend standard and vendor objects:                                                                              // 4
(function () {                                                                                                        // 5
  //create new String.prototype method that will convert string to 'Capitalized' (first letter of each word capital): // 6
  if (String && String.prototype && !String.prototype.toCapitalCase) {                                                // 7
    String.prototype.toCapitalCase = function () {                                                                    // 8
      return this.replace(/(?:^|\s)\S/g, function(a) { return a.toUpperCase(); });                                    // 9
    }                                                                                                                 // 10
    //create new String.prototype method that will convert string to 'Capitalized' (first letter capital):            // 11
    if (String && String.prototype && !String.prototype.toCapitalFirst) {                                             // 12
      String.prototype.toCapitalFirst = function () {                                                                 // 13
        return this.charAt(0).toUpperCase() + this.slice(1);                                                          // 14
      }                                                                                                               // 15
    }                                                                                                                 // 16
  }                                                                                                                   // 17
})();                                                                                                                 // 18
bz.help.safeCode(function(){                                                                                          // 19
  if (Number.prototype.toRadians === undefined) {                                                                     // 20
    Number.prototype.toRadians = function() { return this * Math.PI / 180; };                                         // 21
  }                                                                                                                   // 22
                                                                                                                      // 23
                                                                                                                      // 24
  /** Extend Number object with method to convert radians to numeric (signed) degrees */                              // 25
  if (Number.prototype.toDegrees === undefined) {                                                                     // 26
    Number.prototype.toDegrees = function() { return this * 180 / Math.PI; };                                         // 27
  }                                                                                                                   // 28
  // UNDERSCORE:                                                                                                      // 29
  if(_ && !_.guid) {                                                                                                  // 30
    _.guid = function () {                                                                                            // 31
      function s4() {                                                                                                 // 32
        return Math.floor((1 + Math.random()) * 0x10000)                                                              // 33
            .toString(16)                                                                                             // 34
            .substring(1);                                                                                            // 35
      }                                                                                                               // 36
      return s4() + s4() + '-' + s4() + '-' + s4() + '-' +                                                            // 37
          s4() + '-' + s4() + s4() + s4();                                                                            // 38
    }                                                                                                                 // 39
  }                                                                                                                   // 40
  if(_ && !_.param) {                                                                                                 // 41
    _.param = function(parameters){                                                                                   // 42
      return _.map(_.keys(parameters), function(item){                                                                // 43
        return item + '=' + parameters[item];                                                                         // 44
      }).join('&');                                                                                                   // 45
    }                                                                                                                 // 46
  }                                                                                                                   // 47
});                                                                                                                   // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/02_business/posts.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by yvdorofeev on 10/22/15.                                                                                 // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
var helperFunctions = {                                                                                               // 5
  hasLivePresence: function () {                                                                                      // 6
    var loc = null;                                                                                                   // 7
    if (this.presences && Object.keys(this.presences).length > 0) {                                                   // 8
      _.each(this.presences, function (e, i) {                                                                        // 9
        if (i !== bz.const.locations.type.DYNAMIC && !loc) {                                                          // 10
          loc = _.find(this.details.locations, function (location) {                                                  // 11
            return location._id === i;                                                                                // 12
          });                                                                                                         // 13
        }                                                                                                             // 14
        if (i === bz.const.locations.type.DYNAMIC) {                                                                  // 15
          loc = _.find(this.details.locations, function (location) {                                                  // 16
            return location.placeType === bz.const.locations.type.DYNAMIC;                                            // 17
          });                                                                                                         // 18
        }                                                                                                             // 19
      }, this);                                                                                                       // 20
    }                                                                                                                 // 21
    return loc;                                                                                                       // 22
  }                                                                                                                   // 23
};                                                                                                                    // 24
                                                                                                                      // 25
bz.help.makeNamespace('bz.help.posts', helperFunctions);                                                              // 26
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/client/lib/01_inits/accounts.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by douson on 08.07.15.                                                                                     // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
Meteor.startup(function () {                                                                                          // 5
  AccountsEntry.config({                                                                                              // 6
    logo: 'img/logo.png',                  // if set displays logo above sign-in options                              // 7
    privacyUrl: '/privacy-policy',     // if set adds link to privacy policy and 'you agree to ...' on sign-up page   // 8
    termsUrl: '/terms-of-use',         // if set adds link to terms  'you agree to ...' on sign-up page               // 9
    homeRoute: 'entrySignIn',                    // mandatory - path to redirect to after sign-out                    // 10
    dashboardRoute: '/',      // mandatory - path to redirect to after successful sign-in                             // 11
    profileRoute: 'profile/',                                                                                         // 12
    //passwordSignupFields: 'EMAIL_ONLY',                                                                             // 13
    passwordSignupFields: 'USERNAME_AND_OPTIONAL_EMAIL',                                                              // 14
    showSignupCode: false,                                                                                            // 15
    showOtherLoginServices: false,      // Set to false to hide oauth login buttons on the signin/signup pages. Useful if you are using something like accounts-meld or want to oauth for api access
    fluidLayout: false,               // Set to true to use bootstrap3 container-fluid and row-fluid classes.         // 17
    useContainer: true,               // Set to false to use an unstyled "accounts-entry-container" class instead of a bootstrap3 "container" or "container-fluid" class.
    signInAfterRegistration: true,    // Set to false to avoid prevent users being automatically signed up upon sign-up e.g. to wait until their email has been verified.
    emailVerificationPendingRoute: '/verification-pending', // The route to which users should be directed after sign-up. Only relevant if signInAfterRegistration is false.
    showSpinner: true,                // Show the spinner when the client is talking to the server (spin.js)          // 21
    spinnerOptions: {color: "#000", top: "80%"} // options as per [spin.js](http://fgnass.github.io/spin.js/)         // 22
                                                                                                                      // 23
  });                                                                                                                 // 24
});                                                                                                                   // 25
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/client/lib/01_inits/location.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by syurdor on 8/26/2015.                                                                                   // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
var Location = {                                                                                                      // 5
    processCurrentLocation: function(){                                                                               // 6
        //report location only if logged in                                                                           // 7
        if (Meteor.userId()) {                                                                                        // 8
            navigator.geolocation.getCurrentPosition(function (position) {                                            // 9
                var currentLocation = Session.get('currentLocation');                                                 // 10
                //TODO: remove 'true'                                                                                 // 11
                if (true || !currentLocation || currentLocation.accuracy != position.coords.accuracy || currentLocation.latitude != position.coords.latitude || currentLocation.longitude != position.coords.longitude) {
                    Session.set('currentLocation', {                                                                  // 13
                        latitude: position.coords.latitude,                                                           // 14
                        longitude: position.coords.longitude,                                                         // 15
                        accuracy: position.coords.accuracy                                                            // 16
                    });                                                                                               // 17
                    /*Meteor.call('getNearbyPosts', Meteor.userId(), position.coords.latitude, position.coords.longitude, function(err, result){
                     //update ui                                                                                      // 19
                     console.log(result);                                                                             // 20
                     });*/                                                                                            // 21
                    //37.314008, -121.791756                                                                          // 22
                    Meteor.call('reportLocation', {                                                                   // 23
                        userId: Meteor.userId(),                                                                      // 24
                        lat: position.coords.latitude,                                                                // 25
                        lng: position.coords.longitude,                                                               // 26
                        sessionId: Meteor.connection._lastSessionId                                                   // 27
                    }, function (err, posts) {                                                                        // 28
                    });                                                                                               // 29
                }                                                                                                     // 30
            });                                                                                                       // 31
        }                                                                                                             // 32
    },                                                                                                                // 33
    logOut: function(){                                                                                               // 34
        if (Meteor.userId()){                                                                                         // 35
            Meteor.call('logOut', Meteor.userId());                                                                   // 36
        }                                                                                                             // 37
    }                                                                                                                 // 38
};                                                                                                                    // 39
                                                                                                                      // 40
bz.help.makeNamespace('bz.help.location', Location);                                                                  // 41
                                                                                                                      // 42
Meteor.startup(function(){                                                                                            // 43
    bz.help.location.processCurrentLocation();                                                                        // 44
    document.addEventListener('resume', bz.help.location.processCurrentLocation, false);                              // 45
});                                                                                                                   // 46
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/client/lib/01_inits/fb.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by root on 9/1/15.                                                                                         // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
if(false && Meteor.isClient) {                                                                                        // 5
  window.fbAsyncInit = function() {                                                                                   // 6
    FB.init({                                                                                                         // 7
      appId      : '1025008177543236',                                                                                // 8
      status     : true,                                                                                              // 9
      xfbml      : true,                                                                                              // 10
      version    : 'v2.4'                                                                                             // 11
    });                                                                                                               // 12
  };                                                                                                                  // 13
}                                                                                                                     // 14
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/client/lib/01_inits/maps.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by root on 9/5/15.                                                                                         // 2
 */                                                                                                                   // 3
/*if (Meteor.isClient) {                                                                                              // 4
 Meteor.startup(function() {                                                                                          // 5
 GoogleMaps.load();                                                                                                   // 6
 });                                                                                                                  // 7
 }*/                                                                                                                  // 8
var Maps = {                                                                                                          // 9
  initLocation: function () {                                                                                         // 10
    bz.help.makeNamespace('bz.runtime.maps');                                                                         // 11
    this.getCurrentLocation(function (loc) {                                                                          // 12
      //Session.set('bz.api.loc', loc);                                                                               // 13
    });                                                                                                               // 14
    //}                                                                                                               // 15
  },                                                                                                                  // 16
  getCurrentLocation: function (callback) {                                                                           // 17
    var args = Array.prototype.slice.apply(arguments).slice(1);                                                       // 18
    var that = this;                                                                                                  // 19
    /*var loc = {  //  49 Geary Street, San Francisco, CA                                                             // 20
      lat: 37.787923,                                                                                                 // 21
      lng: -122.404342                                                                                                // 22
    };*/                                                                                                              // 23
                                                                                                                      // 24
    /*var loc = {                                                                                                     // 25
      lat: 37.3213,                                                                                                   // 26
      lng: -121.81649                                                                                                 // 27
    };                                                                                                                // 28
    args.unshift(loc)                                                                                                 // 29
    callback.apply(that, args);                                                                                       // 30
    return;*/                                                                                                         // 31
    navigator.geolocation.getCurrentPosition(function (a) {                                                           // 32
     //bz.runtime.maps.currentGeoposition = a;                                                                        // 33
     var loc = {                                                                                                      // 34
      lat: a.coords.latitude,                                                                                         // 35
      lng: a.coords.longitude                                                                                         // 36
     };                                                                                                               // 37
     console.log(a);                                                                                                  // 38
     //bz.runtime.maps.loc = loc;                                                                                     // 39
     args.unshift(loc);                                                                                               // 40
     Session.set('bz.api.maps.recentLoc', loc);                                                                       // 41
     callback.apply(that, args);                                                                                      // 42
    });                                                                                                               // 43
  },                                                                                                                  // 44
  initPlacesCollection: function () {                                                                                 // 45
    if (!bz.runtime.maps.places && !bz.help.collectionExists('maps.places')) {                                        // 46
                                                                                                                      // 47
      var placesCol = new Meteor.Collection("maps.places"); // client-side only.                                      // 48
      bz.help.makeNamespace('bz.runtime.maps.places', placesCol);                                                     // 49
    }                                                                                                                 // 50
  },                                                                                                                  // 51
  googleMapsLoad: function () {      // need run after doc.ready                                                      // 52
    if (!GoogleMaps.loaded()) {                                                                                       // 53
                                                                                                                      // 54
      GoogleMaps.load({                                                                                               // 55
        //key: bz.config.mapsKey,                                                                                     // 56
        libraries: 'places'  // also accepts an array if you need more than one                                       // 57
      });                                                                                                             // 58
                                                                                                                      // 59
    }                                                                                                                 // 60
  },                                                                                                                  // 61
  initGeocoding: function(){                                                                                          // 62
    geocoder = new google.maps.Geocoder();                                                                            // 63
  },                                                                                                                  // 64
  getCoordsFromAddress: function(address){                                                                            // 65
    var ret = $.Deferred(), coords;                                                                                   // 66
      if(geocoder) {                                                                                                  // 67
        geocoder.geocode({                                                                                            // 68
          'address': address                                                                                          // 69
        }, function (results, status) {                                                                               // 70
          if (status == google.maps.GeocoderStatus.OK) {                                                              // 71
            if (results.length > 1) {                                                                                 // 72
              bz.help.logError('more than 1 result in geocoding!');                                                   // 73
            }                                                                                                         // 74
            googleCoordsToNormalCoords(results[0].geometry.location);                                                 // 75
                                                                                                                      // 76
            ret.resolve(coords);                                                                                      // 77
          } else {                                                                                                    // 78
            ret.resolve(undefined);                                                                                   // 79
            bz.help.logError("bz.api.maps: Geocode was not successful for the following reason: " + status);          // 80
          }                                                                                                           // 81
        });                                                                                                           // 82
      } else {                                                                                                        // 83
        ret.reject();                                                                                                 // 84
      }                                                                                                               // 85
    return ret;                                                                                                       // 86
  },                                                                                                                  // 87
  getAddressFromCoords: function(coords){                                                                             // 88
    var ret = $.Deferred(), address;                                                                                  // 89
    if (geocoder){                                                                                                    // 90
      var latLng = {lat: parseFloat(coords.lat), lng: parseFloat(coords.lng)};                                        // 91
      geocoder.geocode({                                                                                              // 92
        'location': latLng                                                                                            // 93
      }, function(results, status){                                                                                   // 94
        if (status == google.maps.GeocoderStatus.OK && results[1]) {                                                  // 95
          address = results[1].formatted_address;                                                                     // 96
          ret.resolve(address);                                                                                       // 97
        } else {                                                                                                      // 98
          ret.resolve(undefined);                                                                                     // 99
          bz.help.logError("bz.api.maps: ReverseGeocode was not successful for the following reason: " + status);     // 100
        }                                                                                                             // 101
      });                                                                                                             // 102
    } else {                                                                                                          // 103
      ret.reject();                                                                                                   // 104
    }                                                                                                                 // 105
    return ret;                                                                                                       // 106
  }                                                                                                                   // 107
};                                                                                                                    // 108
                                                                                                                      // 109
googleCoordsToNormalCoords = function (googleCoords){                                                                 // 110
  var coords;                                                                                                         // 111
  if(Number.parseFloat(googleCoords.J)){ // stupid ..                                                                 // 112
    coords = {                                                                                                        // 113
      lat: googleCoords.J,                                                                                            // 114
      lng: googleCoords.M                                                                                             // 115
    }                                                                                                                 // 116
  } else if (typeof googleCoords.lat === 'function' && Number.parseFloat(googleCoords.lat())) { // .. google          // 117
    coords = {                                                                                                        // 118
      lat: googleCoords.lat(),                                                                                        // 119
      lng: googleCoords.lng()                                                                                         // 120
    }                                                                                                                 // 121
  }                                                                                                                   // 122
  return coords;                                                                                                      // 123
}                                                                                                                     // 124
                                                                                                                      // 125
bz.help.makeNamespace('bz.help.maps', Maps);                                                                          // 126
bz.help.maps.googleCoordsToNormalCoords = googleCoordsToNormalCoords;                                                 // 127
                                                                                                                      // 128
                                                                                                                      // 129
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/client/lib/01_inits/t9.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by douson on 08.07.15.                                                                                     // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      // 6
/*                                                                                                                    // 7
*Необходимо определить язык устройства и подставить значение для локализации                                          // 8
*/                                                                                                                    // 9
                                                                                                                      // 10
T9n.setLanguage("en");                                                                                                // 11
                                                                                                                      // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/client/lib/01_inits/template-helpers.js                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/31/15.                                                                                       // 2
 */                                                                                                                   // 3
var EARTH_RAD = T9n.getLanguage() === 'en'? 3959 : 6371e3; // radius of Earth, miles/meters                           // 4
// see this: http://www.movable-type.co.uk/scripts/latlong.html                                                       // 5
Template.registerHelper('isDevEnv', function (postIn) {                                                               // 6
  return bz.config.env === 'dev';                                                                                     // 7
});                                                                                                                   // 8
Template.registerHelper('getDistanceToPost', function (postIn) {                                                      // 9
  var ret, post = postIn || this,                                                                                     // 10
      x, y, xcur, ycur, curLoc, dist;                                                                                 // 11
  if (post.details && post.details.locations && post.details.locations[0] && post.details.locations[0].coords) {      // 12
    x = post.details.locations[0].coords.lat;                                                                         // 13
    y = post.details.locations[0].coords.lng;                                                                         // 14
    if (curLoc = Session.get('currentLocation')) {                                                                    // 15
      xcur = curLoc.latitude;                                                                                         // 16
      ycur = curLoc.longitude;                                                                                        // 17
                                                                                                                      // 18
                                                                                                                      // 19
      var R = EARTH_RAD;                                                                                              // 20
      var φ1 = xcur.toRadians(),  λ1 = ycur.toRadians();                                                              // 21
      var φ2 = x.toRadians(), λ2 = y.toRadians();                                                                     // 22
      var Δφ = φ2 - φ1;                                                                                               // 23
      var Δλ = λ2 - λ1;                                                                                               // 24
                                                                                                                      // 25
      var a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +                                                                       // 26
          Math.cos(φ1) * Math.cos(φ2) *                                                                               // 27
          Math.sin(Δλ/2) * Math.sin(Δλ/2);                                                                            // 28
      var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));                                                           // 29
      var d = R * c;                                                                                                  // 30
                                                                                                                      // 31
      ret = Math.round(d);                                                                                            // 32
      //ret = Math.sqrt(Math.pow((xcur - x), 2) + Math.pow((ycur - y), 2));                                           // 33
    }                                                                                                                 // 34
    /*                                                                                                                // 35
     latitude: position.coords.latitude,                                                                              // 36
     longitude: position.coords.longitude,                                                                            // 37
     accuracy: position.coords.accuracy*/                                                                             // 38
    /*navigator.geolocation.getCurrentPosition(function (a) {                                                         // 39
     //bz.runtime.maps.currentGeoposition = a;                                                                        // 40
     bz.runtime.maps.loc = {                                                                                          // 41
     lat: a.coords.latitude,                                                                                          // 42
     lng: a.coords.longitude                                                                                          // 43
     };                                                                                                               // 44
     Session.set('loc', bz.runtime.maps.loc);                                                                         // 45
     });*/                                                                                                            // 46
  }                                                                                                                   // 47
  return ret;                                                                                                         // 48
});                                                                                                                   // 49
Template.registerHelper('getFormattedTs', function (ts) {                                                             // 50
                                                                                                                      // 51
  return moment(ts).fromNow();                                                                                        // 52
  //return '';                                                                                                        // 53
});                                                                                                                   // 54
                                                                                                                      // 55
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/client/lib/rates/jquery.raty.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/*!                                                                                                                   // 1
 * jQuery Raty - A Star Rating Plugin                                                                                 // 2
 *                                                                                                                    // 3
 * The MIT License                                                                                                    // 4
 *                                                                                                                    // 5
 * @author  : Washington Botelho                                                                                      // 6
 * @doc     : http://wbotelhos.com/raty                                                                               // 7
 * @version : 2.7.0                                                                                                   // 8
 *                                                                                                                    // 9
 */                                                                                                                   // 10
                                                                                                                      // 11
;                                                                                                                     // 12
(function($) {                                                                                                        // 13
  'use strict';                                                                                                       // 14
                                                                                                                      // 15
  var methods = {                                                                                                     // 16
    init: function(options) {                                                                                         // 17
      return this.each(function() {                                                                                   // 18
        this.self = $(this);                                                                                          // 19
                                                                                                                      // 20
        methods.destroy.call(this.self);                                                                              // 21
                                                                                                                      // 22
        this.opt = $.extend(true, {}, $.fn.raty.defaults, options);                                                   // 23
                                                                                                                      // 24
        methods._adjustCallback.call(this);                                                                           // 25
        methods._adjustNumber.call(this);                                                                             // 26
        methods._adjustHints.call(this);                                                                              // 27
                                                                                                                      // 28
        this.opt.score = methods._adjustedScore.call(this, this.opt.score);                                           // 29
                                                                                                                      // 30
        if (this.opt.starType !== 'img') {                                                                            // 31
          methods._adjustStarType.call(this);                                                                         // 32
        }                                                                                                             // 33
                                                                                                                      // 34
        methods._adjustPath.call(this);                                                                               // 35
        methods._createStars.call(this);                                                                              // 36
                                                                                                                      // 37
        if (this.opt.cancel) {                                                                                        // 38
          methods._createCancel.call(this);                                                                           // 39
        }                                                                                                             // 40
                                                                                                                      // 41
        if (this.opt.precision) {                                                                                     // 42
          methods._adjustPrecision.call(this);                                                                        // 43
        }                                                                                                             // 44
                                                                                                                      // 45
        methods._createScore.call(this);                                                                              // 46
        methods._apply.call(this, this.opt.score);                                                                    // 47
        methods._setTitle.call(this, this.opt.score);                                                                 // 48
        methods._target.call(this, this.opt.score);                                                                   // 49
                                                                                                                      // 50
        if (this.opt.readOnly) {                                                                                      // 51
          methods._lock.call(this);                                                                                   // 52
        } else {                                                                                                      // 53
          this.style.cursor = 'pointer';                                                                              // 54
                                                                                                                      // 55
          methods._binds.call(this);                                                                                  // 56
        }                                                                                                             // 57
      });                                                                                                             // 58
    },                                                                                                                // 59
                                                                                                                      // 60
    _adjustCallback: function() {                                                                                     // 61
      var options = ['number', 'readOnly', 'score', 'scoreName', 'target'];                                           // 62
                                                                                                                      // 63
      for (var i = 0; i < options.length; i++) {                                                                      // 64
        if (typeof this.opt[options[i]] === 'function') {                                                             // 65
          this.opt[options[i]] = this.opt[options[i]].call(this);                                                     // 66
        }                                                                                                             // 67
      }                                                                                                               // 68
    },                                                                                                                // 69
                                                                                                                      // 70
    _adjustedScore: function(score) {                                                                                 // 71
      if (!score) {                                                                                                   // 72
        return score;                                                                                                 // 73
      }                                                                                                               // 74
                                                                                                                      // 75
      return methods._between(score, 0, this.opt.number);                                                             // 76
    },                                                                                                                // 77
                                                                                                                      // 78
    _adjustHints: function() {                                                                                        // 79
      if (!this.opt.hints) {                                                                                          // 80
        this.opt.hints = [];                                                                                          // 81
      }                                                                                                               // 82
                                                                                                                      // 83
      if (!this.opt.halfShow && !this.opt.half) {                                                                     // 84
        return;                                                                                                       // 85
      }                                                                                                               // 86
                                                                                                                      // 87
      var steps = this.opt.precision ? 10 : 2;                                                                        // 88
                                                                                                                      // 89
      for (var i = 0; i < this.opt.number; i++) {                                                                     // 90
        var group = this.opt.hints[i];                                                                                // 91
                                                                                                                      // 92
        if (Object.prototype.toString.call(group) !== '[object Array]') {                                             // 93
          group = [group];                                                                                            // 94
        }                                                                                                             // 95
                                                                                                                      // 96
        this.opt.hints[i] = [];                                                                                       // 97
                                                                                                                      // 98
        for (var j = 0; j < steps; j++) {                                                                             // 99
          var                                                                                                         // 100
            hint = group[j],                                                                                          // 101
            last = group[group.length - 1];                                                                           // 102
                                                                                                                      // 103
          if (last === undefined) {                                                                                   // 104
            last = null;                                                                                              // 105
          }                                                                                                           // 106
                                                                                                                      // 107
          this.opt.hints[i][j] = hint === undefined ? last : hint;                                                    // 108
        }                                                                                                             // 109
      }                                                                                                               // 110
    },                                                                                                                // 111
                                                                                                                      // 112
    _adjustNumber: function() {                                                                                       // 113
      this.opt.number = methods._between(this.opt.number, 1, this.opt.numberMax);                                     // 114
    },                                                                                                                // 115
                                                                                                                      // 116
    _adjustPath: function() {                                                                                         // 117
      this.opt.path = this.opt.path || '';                                                                            // 118
                                                                                                                      // 119
      if (this.opt.path && this.opt.path.charAt(this.opt.path.length - 1) !== '/') {                                  // 120
        this.opt.path += '/';                                                                                         // 121
      }                                                                                                               // 122
    },                                                                                                                // 123
                                                                                                                      // 124
    _adjustPrecision: function() {                                                                                    // 125
      this.opt.half = true;                                                                                           // 126
    },                                                                                                                // 127
                                                                                                                      // 128
    _adjustStarType: function() {                                                                                     // 129
      var replaces = ['cancelOff', 'cancelOn', 'starHalf', 'starOff', 'starOn'];                                      // 130
                                                                                                                      // 131
      this.opt.path = '';                                                                                             // 132
                                                                                                                      // 133
      for (var i = 0; i < replaces.length; i++) {                                                                     // 134
        this.opt[replaces[i]] = this.opt[replaces[i]].replace('.', '-');                                              // 135
      }                                                                                                               // 136
    },                                                                                                                // 137
                                                                                                                      // 138
    _apply: function(score) {                                                                                         // 139
      methods._fill.call(this, score);                                                                                // 140
                                                                                                                      // 141
      if (score) {                                                                                                    // 142
        if (score > 0) {                                                                                              // 143
          this.score.val(score);                                                                                      // 144
        }                                                                                                             // 145
                                                                                                                      // 146
        methods._roundStars.call(this, score);                                                                        // 147
      }                                                                                                               // 148
    },                                                                                                                // 149
                                                                                                                      // 150
    _between: function(value, min, max) {                                                                             // 151
      return Math.min(Math.max(parseFloat(value), min), max);                                                         // 152
    },                                                                                                                // 153
                                                                                                                      // 154
    _binds: function() {                                                                                              // 155
      if (this.cancel) {                                                                                              // 156
        methods._bindOverCancel.call(this);                                                                           // 157
        methods._bindClickCancel.call(this);                                                                          // 158
        methods._bindOutCancel.call(this);                                                                            // 159
      }                                                                                                               // 160
                                                                                                                      // 161
      methods._bindOver.call(this);                                                                                   // 162
      methods._bindClick.call(this);                                                                                  // 163
      methods._bindOut.call(this);                                                                                    // 164
    },                                                                                                                // 165
                                                                                                                      // 166
    _bindClick: function() {                                                                                          // 167
      var that = this;                                                                                                // 168
                                                                                                                      // 169
      that.stars.on('click.raty', function(evt) {                                                                     // 170
        var                                                                                                           // 171
          execute = true,                                                                                             // 172
          score   = (that.opt.half || that.opt.precision) ? that.self.data('score') : (this.alt || $(this).data('alt'));
                                                                                                                      // 174
        if (that.opt.click) {                                                                                         // 175
          execute = that.opt.click.call(that, +score, evt);                                                           // 176
        }                                                                                                             // 177
                                                                                                                      // 178
        if (execute || execute === undefined) {                                                                       // 179
          if (that.opt.half && !that.opt.precision) {                                                                 // 180
            score = methods._roundHalfScore.call(that, score);                                                        // 181
          }                                                                                                           // 182
                                                                                                                      // 183
          methods._apply.call(that, score);                                                                           // 184
        }                                                                                                             // 185
      });                                                                                                             // 186
    },                                                                                                                // 187
                                                                                                                      // 188
    _bindClickCancel: function() {                                                                                    // 189
      var that = this;                                                                                                // 190
                                                                                                                      // 191
      that.cancel.on('click.raty', function(evt) {                                                                    // 192
        that.score.removeAttr('value');                                                                               // 193
                                                                                                                      // 194
        if (that.opt.click) {                                                                                         // 195
          that.opt.click.call(that, null, evt);                                                                       // 196
        }                                                                                                             // 197
      });                                                                                                             // 198
    },                                                                                                                // 199
                                                                                                                      // 200
    _bindOut: function() {                                                                                            // 201
      var that = this;                                                                                                // 202
                                                                                                                      // 203
      that.self.on('mouseleave.raty', function(evt) {                                                                 // 204
        var score = +that.score.val() || undefined;                                                                   // 205
                                                                                                                      // 206
        methods._apply.call(that, score);                                                                             // 207
        methods._target.call(that, score, evt);                                                                       // 208
        methods._resetTitle.call(that);                                                                               // 209
                                                                                                                      // 210
        if (that.opt.mouseout) {                                                                                      // 211
          that.opt.mouseout.call(that, score, evt);                                                                   // 212
        }                                                                                                             // 213
      });                                                                                                             // 214
    },                                                                                                                // 215
                                                                                                                      // 216
    _bindOutCancel: function() {                                                                                      // 217
      var that = this;                                                                                                // 218
                                                                                                                      // 219
      that.cancel.on('mouseleave.raty', function(evt) {                                                               // 220
        var icon = that.opt.cancelOff;                                                                                // 221
                                                                                                                      // 222
        if (that.opt.starType !== 'img') {                                                                            // 223
          icon = that.opt.cancelClass + ' ' + icon;                                                                   // 224
        }                                                                                                             // 225
                                                                                                                      // 226
        methods._setIcon.call(that, this, icon);                                                                      // 227
                                                                                                                      // 228
        if (that.opt.mouseout) {                                                                                      // 229
          var score = +that.score.val() || undefined;                                                                 // 230
                                                                                                                      // 231
          that.opt.mouseout.call(that, score, evt);                                                                   // 232
        }                                                                                                             // 233
      });                                                                                                             // 234
    },                                                                                                                // 235
                                                                                                                      // 236
    _bindOver: function() {                                                                                           // 237
      var that   = this,                                                                                              // 238
          action = that.opt.half ? 'mousemove.raty' : 'mouseover.raty';                                               // 239
                                                                                                                      // 240
      that.stars.on(action, function(evt) {                                                                           // 241
        var score = methods._getScoreByPosition.call(that, evt, this);                                                // 242
                                                                                                                      // 243
        methods._fill.call(that, score);                                                                              // 244
                                                                                                                      // 245
        if (that.opt.half) {                                                                                          // 246
          methods._roundStars.call(that, score, evt);                                                                 // 247
          methods._setTitle.call(that, score, evt);                                                                   // 248
                                                                                                                      // 249
          that.self.data('score', score);                                                                             // 250
        }                                                                                                             // 251
                                                                                                                      // 252
        methods._target.call(that, score, evt);                                                                       // 253
                                                                                                                      // 254
        if (that.opt.mouseover) {                                                                                     // 255
          that.opt.mouseover.call(that, score, evt);                                                                  // 256
        }                                                                                                             // 257
      });                                                                                                             // 258
    },                                                                                                                // 259
                                                                                                                      // 260
    _bindOverCancel: function() {                                                                                     // 261
      var that = this;                                                                                                // 262
                                                                                                                      // 263
      that.cancel.on('mouseover.raty', function(evt) {                                                                // 264
        var                                                                                                           // 265
          starOff = that.opt.path + that.opt.starOff,                                                                 // 266
          icon    = that.opt.cancelOn;                                                                                // 267
                                                                                                                      // 268
        if (that.opt.starType === 'img') {                                                                            // 269
          that.stars.attr('src', starOff);                                                                            // 270
        } else {                                                                                                      // 271
          icon = that.opt.cancelClass + ' ' + icon;                                                                   // 272
                                                                                                                      // 273
          that.stars.attr('class', starOff);                                                                          // 274
        }                                                                                                             // 275
                                                                                                                      // 276
        methods._setIcon.call(that, this, icon);                                                                      // 277
        methods._target.call(that, null, evt);                                                                        // 278
                                                                                                                      // 279
        if (that.opt.mouseover) {                                                                                     // 280
          that.opt.mouseover.call(that, null);                                                                        // 281
        }                                                                                                             // 282
      });                                                                                                             // 283
    },                                                                                                                // 284
                                                                                                                      // 285
    _buildScoreField: function() {                                                                                    // 286
      return $('<input />', { name: this.opt.scoreName, type: 'hidden' }).appendTo(this);                             // 287
    },                                                                                                                // 288
                                                                                                                      // 289
    _createCancel: function() {                                                                                       // 290
      var icon   = this.opt.path + this.opt.cancelOff,                                                                // 291
          cancel = $('<' + this.opt.starType + ' />', { title: this.opt.cancelHint, 'class': this.opt.cancelClass }); // 292
                                                                                                                      // 293
      if (this.opt.starType === 'img') {                                                                              // 294
        cancel.attr({ src: icon, alt: 'x' });                                                                         // 295
      } else {                                                                                                        // 296
        // TODO: use $.data                                                                                           // 297
        cancel.attr('data-alt', 'x').addClass(icon);                                                                  // 298
      }                                                                                                               // 299
                                                                                                                      // 300
      if (this.opt.cancelPlace === 'left') {                                                                          // 301
        this.self.prepend('&#160;').prepend(cancel);                                                                  // 302
      } else {                                                                                                        // 303
        this.self.append('&#160;').append(cancel);                                                                    // 304
      }                                                                                                               // 305
                                                                                                                      // 306
      this.cancel = cancel;                                                                                           // 307
    },                                                                                                                // 308
                                                                                                                      // 309
    _createScore: function() {                                                                                        // 310
      var score = $(this.opt.targetScore);                                                                            // 311
                                                                                                                      // 312
      this.score = score.length ? score : methods._buildScoreField.call(this);                                        // 313
    },                                                                                                                // 314
                                                                                                                      // 315
    _createStars: function() {                                                                                        // 316
      for (var i = 1; i <= this.opt.number; i++) {                                                                    // 317
        var                                                                                                           // 318
          name  = methods._nameForIndex.call(this, i),                                                                // 319
          attrs = { alt: i, src: this.opt.path + this.opt[name] };                                                    // 320
                                                                                                                      // 321
        if (this.opt.starType !== 'img') {                                                                            // 322
          attrs = { 'data-alt': i, 'class': attrs.src }; // TODO: use $.data.                                         // 323
        }                                                                                                             // 324
                                                                                                                      // 325
        attrs.title = methods._getHint.call(this, i);                                                                 // 326
                                                                                                                      // 327
        $('<' + this.opt.starType + ' />', attrs).appendTo(this);                                                     // 328
                                                                                                                      // 329
        if (this.opt.space) {                                                                                         // 330
          this.self.append(i < this.opt.number ? '&#160;' : '');                                                      // 331
        }                                                                                                             // 332
      }                                                                                                               // 333
                                                                                                                      // 334
      this.stars = this.self.children(this.opt.starType);                                                             // 335
    },                                                                                                                // 336
                                                                                                                      // 337
    _error: function(message) {                                                                                       // 338
      $(this).text(message);                                                                                          // 339
                                                                                                                      // 340
      $.error(message);                                                                                               // 341
    },                                                                                                                // 342
                                                                                                                      // 343
    _fill: function(score) {                                                                                          // 344
      var hash = 0;                                                                                                   // 345
                                                                                                                      // 346
      for (var i = 1; i <= this.stars.length; i++) {                                                                  // 347
        var                                                                                                           // 348
          icon,                                                                                                       // 349
          star   = this.stars[i - 1],                                                                                 // 350
          turnOn = methods._turnOn.call(this, i, score);                                                              // 351
                                                                                                                      // 352
        if (this.opt.iconRange && this.opt.iconRange.length > hash) {                                                 // 353
          var irange = this.opt.iconRange[hash];                                                                      // 354
                                                                                                                      // 355
          icon = methods._getRangeIcon.call(this, irange, turnOn);                                                    // 356
                                                                                                                      // 357
          if (i <= irange.range) {                                                                                    // 358
            methods._setIcon.call(this, star, icon);                                                                  // 359
          }                                                                                                           // 360
                                                                                                                      // 361
          if (i === irange.range) {                                                                                   // 362
            hash++;                                                                                                   // 363
          }                                                                                                           // 364
        } else {                                                                                                      // 365
          icon = this.opt[turnOn ? 'starOn' : 'starOff'];                                                             // 366
                                                                                                                      // 367
          methods._setIcon.call(this, star, icon);                                                                    // 368
        }                                                                                                             // 369
      }                                                                                                               // 370
    },                                                                                                                // 371
                                                                                                                      // 372
    _getFirstDecimal: function(number) {                                                                              // 373
      var                                                                                                             // 374
        decimal = number.toString().split('.')[1],                                                                    // 375
        result  = 0;                                                                                                  // 376
                                                                                                                      // 377
      if (decimal) {                                                                                                  // 378
        result = parseInt(decimal.charAt(0), 10);                                                                     // 379
                                                                                                                      // 380
        if (decimal.slice(1, 5) === '9999') {                                                                         // 381
          result++;                                                                                                   // 382
        }                                                                                                             // 383
      }                                                                                                               // 384
                                                                                                                      // 385
      return result;                                                                                                  // 386
    },                                                                                                                // 387
                                                                                                                      // 388
    _getRangeIcon: function(irange, turnOn) {                                                                         // 389
      return turnOn ? irange.on || this.opt.starOn : irange.off || this.opt.starOff;                                  // 390
    },                                                                                                                // 391
                                                                                                                      // 392
    _getScoreByPosition: function(evt, icon) {                                                                        // 393
      var score = parseInt(icon.alt || icon.getAttribute('data-alt'), 10);                                            // 394
                                                                                                                      // 395
      if (this.opt.half) {                                                                                            // 396
        var                                                                                                           // 397
          size    = methods._getWidth.call(this),                                                                     // 398
          percent = parseFloat((evt.pageX - $(icon).offset().left) / size);                                           // 399
                                                                                                                      // 400
        score = score - 1 + percent;                                                                                  // 401
      }                                                                                                               // 402
                                                                                                                      // 403
      return score;                                                                                                   // 404
    },                                                                                                                // 405
                                                                                                                      // 406
    _getHint: function(score, evt) {                                                                                  // 407
      if (score !== 0 && !score) {                                                                                    // 408
        return this.opt.noRatedMsg;                                                                                   // 409
      }                                                                                                               // 410
                                                                                                                      // 411
      var                                                                                                             // 412
        decimal = methods._getFirstDecimal.call(this, score),                                                         // 413
        integer = Math.ceil(score),                                                                                   // 414
        group   = this.opt.hints[(integer || 1) - 1],                                                                 // 415
        hint    = group,                                                                                              // 416
        set     = !evt || this.move;                                                                                  // 417
                                                                                                                      // 418
      if (this.opt.precision) {                                                                                       // 419
        if (set) {                                                                                                    // 420
          decimal = decimal === 0 ? 9 : decimal - 1;                                                                  // 421
        }                                                                                                             // 422
                                                                                                                      // 423
        hint = group[decimal];                                                                                        // 424
      } else if (this.opt.halfShow || this.opt.half) {                                                                // 425
        decimal = set && decimal === 0 ? 1 : decimal > 5 ? 1 : 0;                                                     // 426
                                                                                                                      // 427
        hint = group[decimal];                                                                                        // 428
      }                                                                                                               // 429
                                                                                                                      // 430
      return hint === '' ? '' : hint || score;                                                                        // 431
    },                                                                                                                // 432
                                                                                                                      // 433
    _getWidth: function() {                                                                                           // 434
      var width = this.stars[0].width || parseFloat(this.stars.eq(0).css('font-size'));                               // 435
                                                                                                                      // 436
      if (!width) {                                                                                                   // 437
        methods._error.call(this, 'Could not get the icon width!');                                                   // 438
      }                                                                                                               // 439
                                                                                                                      // 440
      return width;                                                                                                   // 441
    },                                                                                                                // 442
                                                                                                                      // 443
    _lock: function() {                                                                                               // 444
      var hint = methods._getHint.call(this, this.score.val());                                                       // 445
                                                                                                                      // 446
      this.style.cursor = '';                                                                                         // 447
      this.title        = hint;                                                                                       // 448
                                                                                                                      // 449
      this.score.prop('readonly', true);                                                                              // 450
      this.stars.prop('title', hint);                                                                                 // 451
                                                                                                                      // 452
      if (this.cancel) {                                                                                              // 453
        this.cancel.hide();                                                                                           // 454
      }                                                                                                               // 455
                                                                                                                      // 456
      this.self.data('readonly', true);                                                                               // 457
    },                                                                                                                // 458
                                                                                                                      // 459
    _nameForIndex: function(i) {                                                                                      // 460
      return this.opt.score && this.opt.score >= i ? 'starOn' : 'starOff';                                            // 461
    },                                                                                                                // 462
                                                                                                                      // 463
    _resetTitle: function(star) {                                                                                     // 464
      for (var i = 0; i < this.opt.number; i++) {                                                                     // 465
        this.stars[i].title = methods._getHint.call(this, i + 1);                                                     // 466
      }                                                                                                               // 467
    },                                                                                                                // 468
                                                                                                                      // 469
     _roundHalfScore: function(score) {                                                                               // 470
      var integer = parseInt(score, 10),                                                                              // 471
          decimal = methods._getFirstDecimal.call(this, score);                                                       // 472
                                                                                                                      // 473
      if (decimal !== 0) {                                                                                            // 474
        decimal = decimal > 5 ? 1 : 0.5;                                                                              // 475
      }                                                                                                               // 476
                                                                                                                      // 477
      return integer + decimal;                                                                                       // 478
    },                                                                                                                // 479
                                                                                                                      // 480
    _roundStars: function(score, evt) {                                                                               // 481
      var                                                                                                             // 482
        decimal = (score % 1).toFixed(2),                                                                             // 483
        name    ;                                                                                                     // 484
                                                                                                                      // 485
      if (evt || this.move) {                                                                                         // 486
        name = decimal > 0.5 ? 'starOn' : 'starHalf';                                                                 // 487
      } else if (decimal > this.opt.round.down) {               // Up:   [x.76 .. x.99]                               // 488
        name = 'starOn';                                                                                              // 489
                                                                                                                      // 490
        if (this.opt.halfShow && decimal < this.opt.round.up) { // Half: [x.26 .. x.75]                               // 491
          name = 'starHalf';                                                                                          // 492
        } else if (decimal < this.opt.round.full) {             // Down: [x.00 .. x.5]                                // 493
          name = 'starOff';                                                                                           // 494
        }                                                                                                             // 495
      }                                                                                                               // 496
                                                                                                                      // 497
      if (name) {                                                                                                     // 498
        var                                                                                                           // 499
          icon = this.opt[name],                                                                                      // 500
          star = this.stars[Math.ceil(score) - 1];                                                                    // 501
                                                                                                                      // 502
        methods._setIcon.call(this, star, icon);                                                                      // 503
      }                                                         // Full down: [x.00 .. x.25]                          // 504
    },                                                                                                                // 505
                                                                                                                      // 506
    _setIcon: function(star, icon) {                                                                                  // 507
      star[this.opt.starType === 'img' ? 'src' : 'className'] = this.opt.path + icon;                                 // 508
    },                                                                                                                // 509
                                                                                                                      // 510
    _setTarget: function(target, score) {                                                                             // 511
      if (score) {                                                                                                    // 512
        score = this.opt.targetFormat.toString().replace('{score}', score);                                           // 513
      }                                                                                                               // 514
                                                                                                                      // 515
      if (target.is(':input')) {                                                                                      // 516
        target.val(score);                                                                                            // 517
      } else {                                                                                                        // 518
        target.html(score);                                                                                           // 519
      }                                                                                                               // 520
    },                                                                                                                // 521
                                                                                                                      // 522
    _setTitle: function(score, evt) {                                                                                 // 523
      if (score) {                                                                                                    // 524
        var                                                                                                           // 525
          integer = parseInt(Math.ceil(score), 10),                                                                   // 526
          star    = this.stars[integer - 1];                                                                          // 527
                                                                                                                      // 528
        star.title = methods._getHint.call(this, score, evt);                                                         // 529
      }                                                                                                               // 530
    },                                                                                                                // 531
                                                                                                                      // 532
    _target: function(score, evt) {                                                                                   // 533
      if (this.opt.target) {                                                                                          // 534
        var target = $(this.opt.target);                                                                              // 535
                                                                                                                      // 536
        if (!target.length) {                                                                                         // 537
          methods._error.call(this, 'Target selector invalid or missing!');                                           // 538
        }                                                                                                             // 539
                                                                                                                      // 540
        var mouseover = evt && evt.type === 'mouseover';                                                              // 541
                                                                                                                      // 542
        if (score === undefined) {                                                                                    // 543
          score = this.opt.targetText;                                                                                // 544
        } else if (score === null) {                                                                                  // 545
          score = mouseover ? this.opt.cancelHint : this.opt.targetText;                                              // 546
        } else {                                                                                                      // 547
          if (this.opt.targetType === 'hint') {                                                                       // 548
            score = methods._getHint.call(this, score, evt);                                                          // 549
          } else if (this.opt.precision) {                                                                            // 550
            score = parseFloat(score).toFixed(1);                                                                     // 551
          }                                                                                                           // 552
                                                                                                                      // 553
          var mousemove = evt && evt.type === 'mousemove';                                                            // 554
                                                                                                                      // 555
          if (!mouseover && !mousemove && !this.opt.targetKeep) {                                                     // 556
            score = this.opt.targetText;                                                                              // 557
          }                                                                                                           // 558
        }                                                                                                             // 559
                                                                                                                      // 560
        methods._setTarget.call(this, target, score);                                                                 // 561
      }                                                                                                               // 562
    },                                                                                                                // 563
                                                                                                                      // 564
    _turnOn: function(i, score) {                                                                                     // 565
      return this.opt.single ? (i === score) : (i <= score);                                                          // 566
    },                                                                                                                // 567
                                                                                                                      // 568
    _unlock: function() {                                                                                             // 569
      this.style.cursor = 'pointer';                                                                                  // 570
      this.removeAttribute('title');                                                                                  // 571
                                                                                                                      // 572
      this.score.removeAttr('readonly');                                                                              // 573
                                                                                                                      // 574
      this.self.data('readonly', false);                                                                              // 575
                                                                                                                      // 576
      for (var i = 0; i < this.opt.number; i++) {                                                                     // 577
        this.stars[i].title = methods._getHint.call(this, i + 1);                                                     // 578
      }                                                                                                               // 579
                                                                                                                      // 580
      if (this.cancel) {                                                                                              // 581
        this.cancel.css('display', '');                                                                               // 582
      }                                                                                                               // 583
    },                                                                                                                // 584
                                                                                                                      // 585
    cancel: function(click) {                                                                                         // 586
      return this.each(function() {                                                                                   // 587
        var self = $(this);                                                                                           // 588
                                                                                                                      // 589
        if (self.data('readonly') !== true) {                                                                         // 590
          methods[click ? 'click' : 'score'].call(self, null);                                                        // 591
                                                                                                                      // 592
          this.score.removeAttr('value');                                                                             // 593
        }                                                                                                             // 594
      });                                                                                                             // 595
    },                                                                                                                // 596
                                                                                                                      // 597
    click: function(score) {                                                                                          // 598
      return this.each(function() {                                                                                   // 599
        if ($(this).data('readonly') !== true) {                                                                      // 600
          score = methods._adjustedScore.call(this, score);                                                           // 601
                                                                                                                      // 602
          methods._apply.call(this, score);                                                                           // 603
                                                                                                                      // 604
          if (this.opt.click) {                                                                                       // 605
            this.opt.click.call(this, score, $.Event('click'));                                                       // 606
          }                                                                                                           // 607
                                                                                                                      // 608
          methods._target.call(this, score);                                                                          // 609
        }                                                                                                             // 610
      });                                                                                                             // 611
    },                                                                                                                // 612
                                                                                                                      // 613
    destroy: function() {                                                                                             // 614
      return this.each(function() {                                                                                   // 615
        var self = $(this),                                                                                           // 616
            raw  = self.data('raw');                                                                                  // 617
                                                                                                                      // 618
        if (raw) {                                                                                                    // 619
          self.off('.raty').empty().css({ cursor: raw.style.cursor }).removeData('readonly');                         // 620
        } else {                                                                                                      // 621
          self.data('raw', self.clone()[0]);                                                                          // 622
        }                                                                                                             // 623
      });                                                                                                             // 624
    },                                                                                                                // 625
                                                                                                                      // 626
    getScore: function() {                                                                                            // 627
      var score = [],                                                                                                 // 628
          value ;                                                                                                     // 629
                                                                                                                      // 630
      this.each(function() {                                                                                          // 631
        value = this.score.val();                                                                                     // 632
                                                                                                                      // 633
        score.push(value ? +value : undefined);                                                                       // 634
      });                                                                                                             // 635
                                                                                                                      // 636
      return (score.length > 1) ? score : score[0];                                                                   // 637
    },                                                                                                                // 638
                                                                                                                      // 639
    move: function(score) {                                                                                           // 640
      return this.each(function() {                                                                                   // 641
        var                                                                                                           // 642
          integer  = parseInt(score, 10),                                                                             // 643
          decimal  = methods._getFirstDecimal.call(this, score);                                                      // 644
                                                                                                                      // 645
        if (integer >= this.opt.number) {                                                                             // 646
          integer = this.opt.number - 1;                                                                              // 647
          decimal = 10;                                                                                               // 648
        }                                                                                                             // 649
                                                                                                                      // 650
        var                                                                                                           // 651
          width   = methods._getWidth.call(this),                                                                     // 652
          steps   = width / 10,                                                                                       // 653
          star    = $(this.stars[integer]),                                                                           // 654
          percent = star.offset().left + steps * decimal,                                                             // 655
          evt     = $.Event('mousemove', { pageX: percent });                                                         // 656
                                                                                                                      // 657
        this.move = true;                                                                                             // 658
                                                                                                                      // 659
        star.trigger(evt);                                                                                            // 660
                                                                                                                      // 661
        this.move = false;                                                                                            // 662
      });                                                                                                             // 663
    },                                                                                                                // 664
                                                                                                                      // 665
    readOnly: function(readonly) {                                                                                    // 666
      return this.each(function() {                                                                                   // 667
        var self = $(this);                                                                                           // 668
                                                                                                                      // 669
        if (self.data('readonly') !== readonly) {                                                                     // 670
          if (readonly) {                                                                                             // 671
            self.off('.raty').children('img').off('.raty');                                                           // 672
                                                                                                                      // 673
            methods._lock.call(this);                                                                                 // 674
          } else {                                                                                                    // 675
            methods._binds.call(this);                                                                                // 676
            methods._unlock.call(this);                                                                               // 677
          }                                                                                                           // 678
                                                                                                                      // 679
          self.data('readonly', readonly);                                                                            // 680
        }                                                                                                             // 681
      });                                                                                                             // 682
    },                                                                                                                // 683
                                                                                                                      // 684
    reload: function() {                                                                                              // 685
      return methods.set.call(this, {});                                                                              // 686
    },                                                                                                                // 687
                                                                                                                      // 688
    score: function() {                                                                                               // 689
      var self = $(this);                                                                                             // 690
                                                                                                                      // 691
      return arguments.length ? methods.setScore.apply(self, arguments) : methods.getScore.call(self);                // 692
    },                                                                                                                // 693
                                                                                                                      // 694
    set: function(options) {                                                                                          // 695
      return this.each(function() {                                                                                   // 696
        $(this).raty($.extend({}, this.opt, options));                                                                // 697
      });                                                                                                             // 698
    },                                                                                                                // 699
                                                                                                                      // 700
    setScore: function(score) {                                                                                       // 701
      return this.each(function() {                                                                                   // 702
        if ($(this).data('readonly') !== true) {                                                                      // 703
          score = methods._adjustedScore.call(this, score);                                                           // 704
                                                                                                                      // 705
          methods._apply.call(this, score);                                                                           // 706
          methods._target.call(this, score);                                                                          // 707
        }                                                                                                             // 708
      });                                                                                                             // 709
    }                                                                                                                 // 710
  };                                                                                                                  // 711
                                                                                                                      // 712
  $.fn.raty = function(method) {                                                                                      // 713
    if (methods[method]) {                                                                                            // 714
      return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));                                   // 715
    } else if (typeof method === 'object' || !method) {                                                               // 716
      return methods.init.apply(this, arguments);                                                                     // 717
    } else {                                                                                                          // 718
      $.error('Method ' + method + ' does not exist!');                                                               // 719
    }                                                                                                                 // 720
  };                                                                                                                  // 721
                                                                                                                      // 722
  $.fn.raty.defaults = {                                                                                              // 723
    cancel       : false,                                                                                             // 724
    cancelClass  : 'raty-cancel',                                                                                     // 725
    cancelHint   : 'Cancel this rating!',                                                                             // 726
    cancelOff    : 'cancel-off.png',                                                                                  // 727
    cancelOn     : 'cancel-on.png',                                                                                   // 728
    cancelPlace  : 'left',                                                                                            // 729
    click        : undefined,                                                                                         // 730
    half         : false,                                                                                             // 731
    halfShow     : true,                                                                                              // 732
    hints        : ['bad', 'poor', 'regular', 'good', 'gorgeous'],                                                    // 733
    iconRange    : undefined,                                                                                         // 734
    mouseout     : undefined,                                                                                         // 735
    mouseover    : undefined,                                                                                         // 736
    noRatedMsg   : 'Not rated yet!',                                                                                  // 737
    number       : 5,                                                                                                 // 738
    numberMax    : 20,                                                                                                // 739
    path         : undefined,                                                                                         // 740
    precision    : false,                                                                                             // 741
    readOnly     : false,                                                                                             // 742
    round        : { down: 0.25, full: 0.6, up: 0.76 },                                                               // 743
    score        : undefined,                                                                                         // 744
    scoreName    : 'score',                                                                                           // 745
    single       : false,                                                                                             // 746
    space        : true,                                                                                              // 747
    starHalf     : 'star-half.png',                                                                                   // 748
    starOff      : 'star-off.png',                                                                                    // 749
    starOn       : 'star-on.png',                                                                                     // 750
    starType     : 'img',                                                                                             // 751
    target       : undefined,                                                                                         // 752
    targetFormat : '{score}',                                                                                         // 753
    targetKeep   : false,                                                                                             // 754
    targetScore  : undefined,                                                                                         // 755
    targetText   : '',                                                                                                // 756
    targetType   : 'hint'                                                                                             // 757
  };                                                                                                                  // 758
                                                                                                                      // 759
})(jQuery);                                                                                                           // 760
                                                                                                                      // 761
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
