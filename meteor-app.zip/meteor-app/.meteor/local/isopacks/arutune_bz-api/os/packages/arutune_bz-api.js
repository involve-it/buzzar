(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/01_inits/01_init.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/12/15.                                                                                       // 2
 */                                                                                                                   // 3
var global;                                                                                                           // 4
if(Meteor.isClient){                                                                                                  // 5
  global = typeof window !== 'undefined' && window !== null ? window : {};                                            // 6
} else if (Meteor.isServer) {                                                                                         // 7
  global = typeof GLOBAL !== 'undefined' && GLOBAL !== null ? GLOBAL : {};                                            // 8
}                                                                                                                     // 9
global.bz = {}                                                                                                        // 10
global.bz.cols = {}                                                                                                   // 11
global.bz.runtime = {}                                                                                                // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/01_inits/02_helpers.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/20/15.                                                                                       // 2
 */                                                                                                                   // 3
var Helpers = {}                                                                                                      // 4
/**                                                                                                                   // 5
 * This function is for constructing namespace objects from a string, attaching it to a global window object.         // 6
 * If some objects already exist, it will extend them. Dependant on the underscore.js library.                        // 7
 * this can span multiple lines.                                                                                      // 8
 *                                                                                                                    // 9
 * @method makeNamespace                                                                                              // 10
 * @param {Object} initialObject - main config object, containing:                                                    // 11
 *	- path: names of objects in the chain, delimited by '.'                                                            // 12
 *	- object: the object that will be placed into the namespace end.                                                   // 13
 *	  if object is not provided, just create the namespace, if it does not exist yet.                                  // 14
 *	OR initialObject can be a string, in which case consider it as a new namespace,                                    // 15
 *	  and the second parameter is the original object (or non-defined).                                                // 16
 * @return {Object} final object assigned to the namespace.                                                           // 17
 */                                                                                                                   // 18
Helpers.makeNamespace = function (initialObject) {                                                                    // 19
  if (initialObject && typeof initialObject === 'string') {                                                           // 20
    initialObject = {                                                                                                 // 21
      path: initialObject,                                                                                            // 22
      object: arguments[1]                                                                                            // 23
    }                                                                                                                 // 24
  };                                                                                                                  // 25
  var buildFromName, first, foreverFirst, global, l1, l2, namespace, retObj, sc, subPaths;                            // 26
  if(Meteor.isClient){                                                                                                // 27
    global = typeof window !== 'undefined' && window !== null ? window : {};                                          // 28
  } else if (Meteor.isServer) {                                                                                       // 29
    global = typeof GLOBAL !== 'undefined' && GLOBAL !== null ? GLOBAL : {};                                          // 30
  }                                                                                                                   // 31
                                                                                                                      // 32
  if (typeof global === 'string') {                                                                                   // 33
    global = eval(global);                                                                                            // 34
  }                                                                                                                   // 35
  subPaths = initialObject.path.split('.').reverse();                                                                 // 36
  foreverFirst = subPaths[0];                                                                                         // 37
  first = subPaths.pop();                                                                                             // 38
  namespace = global[first] = typeof global[first] !== 'undefined' && global[first] || {};                            // 39
  if (subPaths.length === 0) {                                                                                        // 40
    if (typeof global[first] !== 'undefined' && global[first]) {                                                      // 41
      _.extend(global[first], initialObject);                                                                         // 42
    } else {                                                                                                          // 43
      global[first] = initialObject.object;                                                                           // 44
    }                                                                                                                 // 45
    return namespace;                                                                                                 // 46
  }                                                                                                                   // 47
  retObj = null;                                                                                                      // 48
  l1 = l2 = subPaths.length;                                                                                          // 49
  buildFromName = function (paths, ns) {                                                                              // 50
    var retns;                                                                                                        // 51
    if (paths.length <= 0) {                                                                                          // 52
      return ns;                                                                                                      // 53
    }                                                                                                                 // 54
    first = subPaths.pop();                                                                                           // 55
    retns = typeof ns[first] !== 'undefined' && ns[first] || {};                                                      // 56
    ns[first] = buildFromName(paths, retns);                                                                          // 57
    if (l1 === l2) {                                                                                                  // 58
      if (typeof initialObject.object !== 'undefined') {                                                              // 59
        if (!_.isObject(initialObject.object)) {                                                                      // 60
          ns[foreverFirst] = initialObject.object;                                                                    // 61
        } else {                                                                                                      // 62
          ns[foreverFirst] = _.extend(ns[foreverFirst], initialObject.object);                                        // 63
        }                                                                                                             // 64
      }                                                                                                               // 65
      retObj = _.extend(ns[foreverFirst] != null ? ns[foreverFirst] : ns[foreverFirst] = {}, retObj != null ? retObj : retObj = {});
    }                                                                                                                 // 67
    l1 = l1 - 1;                                                                                                      // 68
    return ns;                                                                                                        // 69
  };                                                                                                                  // 70
  namespace = buildFromName(subPaths, namespace);                                                                     // 71
  return retObj;                                                                                                      // 72
};                                                                                                                    // 73
/**                                                                                                                   // 74
 * This function is for checking namespace existence from a string. Convenience method to replace tedious existence checks.
 * If global namespace object exists, it will return true, otherwise - false. Dependant on the underscore.js library. // 76
 * @method checkNamespace                                                                                             // 77
 * @param {string} namespace - namespace to verify.                                                                   // 78
 * @returns {bool} value showing if the namespace exists.                                                             // 79
 * @example if (bz && bz.lat && bz.lat.lon && bz.lat.lon[0] && bz.lat.lon[0].a ) can be replaced with one call "checkNamespace('bz.lat.lon[0].a')
 *                                                                                                                    // 81
 */                                                                                                                   // 82
Helpers.checkNamespace = function(namespace){                                                                         // 83
                                                                                                                      // 84
}                                                                                                                     // 85
/**                                                                                                                   // 86
 * This function is for wrapping custom function for safe code execution                                              // 87
 * If exception of any kind is thrown, it will either be thrown                                                       // 88
 *	or will be logged (if ReferenceError , that stops execution of consequent code in the script).                     // 89
 *                                                                                                                    // 90
 * @method MakeGlobalNamespaceAndObject                                                                               // 91
 * @param {Function} functionWithCode - function object, containing code to execute                                   // 92
 * @param [1..n] - any parameters, that should be passed into the function                                            // 93
 * @returns {Object} object, that is returned by functionWithCode / error.                                            // 94
 */                                                                                                                   // 95
Helpers.safeCode = function (functionWithCode) {                                                                      // 96
  var ret = undefined;                                                                                                // 97
  if (functionWithCode && typeof functionWithCode === 'function') {                                                   // 98
                                                                                                                      // 99
    try {                                                                                                             // 100
      ret = functionWithCode.apply(functionWithCode, Array.prototype.slice.call(arguments, 1));                       // 101
    } catch (ex) {                                                                                                    // 102
      ret = ex;                                                                                                       // 103
      bz.help.logError(ex);                                                                                           // 104
    }                                                                                                                 // 105
  }                                                                                                                   // 106
  return ret;                                                                                                         // 107
}                                                                                                                     // 108
Helpers.logError = function (exObject, message, logToRollbar) {                                                       // 109
  // check if first argument is of Error type:                                                                        // 110
  if (typeof exObject === 'object' && exObject instanceof Error) {                                                    // 111
                                                                                                                      // 112
  } else if (typeof exObject === 'string' && exObject !== '') {                                                       // 113
    message = exObject;                                                                                               // 114
                                                                                                                      // 115
    exObject = new Error(message);                                                                                    // 116
    if (typeof message === 'boolean') {                                                                               // 117
      logToRollbar = message;                                                                                         // 118
    }                                                                                                                 // 119
  }                                                                                                                   // 120
  if (bz && bz.config && bz.config.env) {                                                                             // 121
    if (bz.config.env === 'dev') {                                                                                    // 122
      if (console) {                                                                                                  // 123
        if (console.error) {                                                                                          // 124
          console.error(exObject);                                                                                    // 125
        } else if (console.log) {                                                                                     // 126
          console.log(message);                                                                                       // 127
        }                                                                                                             // 128
      }                                                                                                               // 129
      // log to rollbar if developer explicetely asked for this:                                                      // 130
      logToRollbar && typeof Rollbar !== 'undefined' && Rollbar.error(message, exObject);                             // 131
    } else if (bz.config.env === 'prod') {                                                                            // 132
      // do rollbar:                                                                                                  // 133
      // send to roolbar, if needed (see this api: https://rollbar.com/docs/notifier/rollbar.js/):                    // 134
      if (logToRollbar !== false) {// don't log to rollbar if developer explicetely asked for this:                   // 135
        typeof Rollbar !== 'undefined' && Rollbar.error(message, exObject);                                           // 136
      }                                                                                                               // 137
    }                                                                                                                 // 138
  }                                                                                                                   // 139
}                                                                                                                     // 140
Helpers.log = function (text){                                                                                        // 141
  if (bz.config.env === 'dev' && console && console.log) {                                                            // 142
                                                                                                                      // 143
  }                                                                                                                   // 144
}                                                                                                                     // 145
Helpers.collectionExists = function(name) {                                                                           // 146
  return Meteor.connection._mongo_livedata_collections[name] !== null && Meteor.connection._mongo_livedata_collections[name] !== undefined;
}                                                                                                                     // 148
Helpers.makeNamespace({                                                                                               // 149
  path: 'bz.help',                                                                                                    // 150
  object: Helpers                                                                                                     // 151
});                                                                                                                   // 152
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/01_inits/03_extends.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/20/15.                                                                                       // 2
 */                                                                                                                   // 3
  // extend standard and vendor objects:                                                                              // 4
(function () {                                                                                                        // 5
  //create new String.prototype method that will convert string to 'Capitalized' (first letter of each word capital): // 6
  if (String && String.prototype && !String.prototype.toCapitalCase) {                                                // 7
    String.prototype.toCapitalCase = function () {                                                                    // 8
      return this.replace(/(?:^|\s)\S/g, function(a) { return a.toUpperCase(); });                                    // 9
    }                                                                                                                 // 10
    //create new String.prototype method that will convert string to 'Capitalized' (first letter capital):            // 11
    if (String && String.prototype && !String.prototype.toCapitalFirst) {                                             // 12
      String.prototype.toCapitalFirst = function () {                                                                 // 13
        return this.charAt(0).toUpperCase() + this.slice(1);                                                          // 14
      }                                                                                                               // 15
    }                                                                                                                 // 16
  }                                                                                                                   // 17
})();                                                                                                                 // 18
bz.help.safeCode(function(){                                                                                          // 19
  if (Number.prototype.toRadians === undefined) {                                                                     // 20
    Number.prototype.toRadians = function() { return this * Math.PI / 180; };                                         // 21
  }                                                                                                                   // 22
                                                                                                                      // 23
                                                                                                                      // 24
  /** Extend Number object with method to convert radians to numeric (signed) degrees */                              // 25
  if (Number.prototype.toDegrees === undefined) {                                                                     // 26
    Number.prototype.toDegrees = function() { return this * 180 / Math.PI; };                                         // 27
  }                                                                                                                   // 28
  // UNDERSCORE:                                                                                                      // 29
  if(_ && !_.guid) {                                                                                                  // 30
    _.guid = function () {                                                                                            // 31
      function s4() {                                                                                                 // 32
        return Math.floor((1 + Math.random()) * 0x10000)                                                              // 33
            .toString(16)                                                                                             // 34
            .substring(1);                                                                                            // 35
      }                                                                                                               // 36
      return s4() + s4() + '-' + s4() + '-' + s4() + '-' +                                                            // 37
          s4() + '-' + s4() + s4() + s4();                                                                            // 38
    }                                                                                                                 // 39
  }                                                                                                                   // 40
  if(_ && !_.param) {                                                                                                 // 41
    _.param = function(parameters){                                                                                   // 42
      return _.map(_.keys(parameters), function(item){                                                                // 43
        return item + '=' + parameters[item];                                                                         // 44
      }).join('&');                                                                                                   // 45
    }                                                                                                                 // 46
  }                                                                                                                   // 47
});                                                                                                                   // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/shared/lib/02_business/posts.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by yvdorofeev on 10/22/15.                                                                                 // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
var helperFunctions = {                                                                                               // 5
  hasLivePresence: function () {                                                                                      // 6
    var loc = null;                                                                                                   // 7
    if (this.presences && Object.keys(this.presences).length > 0) {                                                   // 8
      _.each(this.presences, function (e, i) {                                                                        // 9
        if (i !== bz.const.locations.type.DYNAMIC && !loc) {                                                          // 10
          loc = _.find(this.details.locations, function (location) {                                                  // 11
            return location._id === i;                                                                                // 12
          });                                                                                                         // 13
        }                                                                                                             // 14
        if (i === bz.const.locations.type.DYNAMIC) {                                                                  // 15
          loc = _.find(this.details.locations, function (location) {                                                  // 16
            return location.placeType === bz.const.locations.type.DYNAMIC;                                            // 17
          });                                                                                                         // 18
        }                                                                                                             // 19
      }, this);                                                                                                       // 20
    }                                                                                                                 // 21
    return loc;                                                                                                       // 22
  }                                                                                                                   // 23
};                                                                                                                    // 24
                                                                                                                      // 25
bz.help.makeNamespace('bz.help.posts', helperFunctions);                                                              // 26
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-api/server/lib/config.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by ashot on 8/20/15.                                                                                       // 2
 */                                                                                                                   // 3
bz.help.makeNamespace({                                                                                               // 4
  path: 'bz.config',                                                                                                  // 5
  object: {                                                                                                           // 6
    env: 'dev',                                                                                                       // 7
    //env: 'prod',                                                                                                    // 8
    isCordova: Meteor.isCordova,                                                                                      // 9
    mapsKey: ''                                                                                                       // 10
  }                                                                                                                   // 11
})                                                                                                                    // 12
                                                                                                                      // 13
// Set up login services                                                                                              // 14
Meteor.startup( function () {                                                                                         // 15
  ServiceConfiguration.configurations.remove({                                                                        // 16
    $or: [ {service: "facebook"}, {service: "twitter"}, {service: "google"} ]                                         // 17
  });                                                                                                                 // 18
  // Add Facebook configuration entry                                                                                 // 19
  ServiceConfiguration.configurations.insert({                                                                        // 20
    "service": "facebook",                                                                                            // 21
    "appId": "1025008177543236",                                                                                      // 22
    "secret": "4fc9a62ae0c00d10fd8acdd2a66f695b"                                                                      // 23
  });                                                                                                                 // 24
});                                                                                                                   // 25
                                                                                                                      // 26
// Handle merge of application specific DB items                                                                      // 27
Meteor.methods({                                                                                                      // 28
                                                                                                                      // 29
  // After merging a user we need to change owner on orpahned collection items                                        // 30
  // (i.e. one user was deleted in the merge, move it's items to the                                                  // 31
  // destination user).                                                                                               // 32
  mergeItems: function (mergedUserId) {                                                                               // 33
                                                                                                                      // 34
    console.log('Merging DB items of user', mergedUserId, 'with user', Meteor.userId());                              // 35
                                                                                                                      // 36
    //  You'd typically do something like:                                                                            // 37
                                                                                                                      // 38
    /*                                                                                                                // 39
     try {                                                                                                            // 40
     var affectedRows = Items.update ({"owner":mergedUserId}, {$set: {"owner": Meteor.userId()}}, {"multi": true});   // 41
     } catch (e) {                                                                                                    // 42
     // TODO: Items are lost in merge when exception occurs - should clean up                                         // 43
     // orphans too, or make update continue after duplicate error.                                                   // 44
     // On error (typically "duplicate item", if you have unique indexes in                                           // 45
     // the items collection), throw exception.                                                                       // 46
     throw new Meteor.Error(500, e.toString());                                                                       // 47
     }                                                                                                                // 48
     return affectedRows;                                                                                             // 49
     */                                                                                                               // 50
  }                                                                                                                   // 51
});                                                                                                                   // 52
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
