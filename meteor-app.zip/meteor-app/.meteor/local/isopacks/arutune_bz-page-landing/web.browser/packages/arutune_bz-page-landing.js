(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/arutune:bz-page-landing/client/router.js                                //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
/**                                                                                 // 1
 * Created by Ashot on 9/18/15.                                                     // 2
 */                                                                                 // 3
Router.map(function () {                                                            // 4
  this.route('bz.aboutUs', {                                                        // 5
    path: '/about-us',                                                              // 6
    template: 'pageAboutUs'                                                         // 7
  });                                                                               // 8
  this.route('contactUs', {                                                         // 9
    path: '/contacts',                                                              // 10
    template: 'pageContactUs'                                                       // 11
  });                                                                               // 12
});                                                                                 // 13
                                                                                    // 14
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/arutune:bz-page-landing/client/browser/template.about-us.js             //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
                                                                                    // 1
Template.__checkName("aboutUs");                                                    // 2
Template["aboutUs"] = new Template("Template.aboutUs", (function() {                // 3
  var view = this;                                                                  // 4
  return HTML.Raw('<div class="main-content">\n    <h3 class="title">\n      Buzzar - instant posts bound to location.\n    </h3>\n\n    <div>\n      <p>\n        <b>What is Buzzar?</b>\n      </p>\n\n      <p>\n        Buzzar is a community, built on humanistic principles of compassion, awareness, consciousness and freedom of\n        choice.\n      </p>\n\n      <p>\n        Buzzar is a tool that aims to help people get a better deal.\n      </p>\n      <!--<p>Think of us as of "Google For People": the way Google lets you search through <b>urls in Web</b>,\n      we let you search among <b>real people around you</b>. Like Google has it\'s ranking system to order url relevancy,\n      we have our sophisticated Karma algorithm, phone# verification and other means to rank real posts\' credibility.\n      </p>-->\n\n      <p>Buzzar is a next step in community advertisement, powered by technology and social capabilities, that gives\n        another dimension to\n        a post - namely <i>web url, location, time and availability</i> bound together.\n      </p>\n\n      <p>\n        <b>The Problem</b>\n      </p>\n\n\n      <p>\n        People can not know who is around them, that is why can miss best opportunities.\n        The solution is to give them means to spread and get knowledge about available ads and posts around them by\n        binding location and their internet posts in one application.\n        By doing that we present an alternative to internet, agent, and other traditional means of search. The time of\n        spare can be easily converted into deals or at least fun time.\n      </p>\n\n      <p><b>So let local people know if you:</b></p>\n      <ul class="capitalize">\n        <li><a href="/posts/new#need-help">need immediate help</a></li>\n        <li><a href="/posts/new#need-help">offering/looking for a gig/job/service</a></li>\n        <li><a href="/posts/new#need-help">have something to sell/buy</a></li>\n        <li><a href="/posts/new#need-help">searching for a roommate</a></li>\n        <li><a href="/posts/new#need-help">lost/found something</a></li>\n        <li><a href="/posts/new#need-help">fundraising money</a></li>\n        <li><a href="/posts/new#need-help">anything else that can have URL, bound to your location</a></li>\n      </ul>\n      <!--<p>By joining the community you .. of dif things, but at the end of the day it is all about finding (real\n        interactions) with people.</p>-->\n    </div>\n\n    <p><b>What this will give you?</b></p>\n    <ul>\n      <li>\n        Immediate live meeting with a person, who got interested in your post.\n      </li>\n      <li>\n        A totally new source of visitors to your post, giving relevant and authentic traffic.\n      </li>\n\n      <li>\n        Less need to online advertise, less fees to online payment systems, less expenses/waiting time because of\n        delivery.\n      </li>\n      <li>\n        Get out of your device. Meet real people. Share live emotions and communication. Enjoy your life.\n      </li>\n    </ul>\n  </div>');
}));                                                                                // 6
                                                                                    // 7
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/arutune:bz-page-landing/client/browser/template.page-about-us.js        //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
                                                                                    // 1
Template.__checkName("pageAboutUs");                                                // 2
Template["pageAboutUs"] = new Template("Template.pageAboutUs", (function() {        // 3
  var view = this;                                                                  // 4
  return Spacebars.include(view.lookupTemplate("aboutUs"));                         // 5
}));                                                                                // 6
                                                                                    // 7
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/arutune:bz-page-landing/client/browser/template.page-contact-us.js      //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
                                                                                    // 1
Template.__checkName("pageContactUs");                                              // 2
Template["pageContactUs"] = new Template("Template.pageContactUs", (function() {    // 3
  var view = this;                                                                  // 4
  return HTML.Raw('<input type="text" class="js-message-text" placeholder="Put your question here.">\n    <button class="button js-send-btn">Send</button>');
}));                                                                                // 6
                                                                                    // 7
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/arutune:bz-page-landing/client/browser/page-contact-us.js               //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
/**                                                                                 // 1
 * Created by arutu_000 on 10/3/2015.                                               // 2
 */                                                                                 // 3
Template.pageContactUs.events({                                                     // 4
  'click .js-send-btn': function(){                                                 // 5
    var msg = $('.js-message-text').val();                                          // 6
    if(msg){                                                                        // 7
      Meteor.call('sendMessageContactUs', msg, Meteor.userId(), function(err, res){ // 8
        if(res && res!=='') {                                                       // 9
          alert('Message was successfully sent, we appreciate your feedback!');     // 10
        }                                                                           // 11
      });                                                                           // 12
    }                                                                               // 13
  }                                                                                 // 14
})                                                                                  // 15
                                                                                    // 16
                                                                                    // 17
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);
