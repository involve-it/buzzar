(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-page-landing/client/router.js                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by Ashot on 9/18/15.                                      // 2
 */                                                                  // 3
Router.map(function () {                                             // 4
  this.route('bz.aboutUs', {                                         // 5
    path: '/about-us',                                               // 6
    template: 'pageAboutUs'                                          // 7
  });                                                                // 8
  this.route('contactUs', {                                          // 9
    path: '/contacts',                                               // 10
    template: 'pageContactUs'                                        // 11
  });                                                                // 12
});                                                                  // 13
                                                                     // 14
///////////////////////////////////////////////////////////////////////

}).call(this);
