(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/arutune:bz-main/client/cordova/template.main-layout.js                                        //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
                                                                                                          // 1
Template.__checkName("mainLayout");                                                                       // 2
Template["mainLayout"] = new Template("Template.mainLayout", (function() {                                // 3
  var view = this;                                                                                        // 4
  return Blaze.If(function() {                                                                            // 5
    return Spacebars.call(view.lookup("currentUser"));                                                    // 6
  }, function() {                                                                                         // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("ionBody"), function() {                     // 8
      return [ "\n      ", HTML.Comment(' Вместо rendered, можно использовать side="left" '), "\n      ", Spacebars.include(view.lookupTemplate("ionSideMenuContainer"), function() {
        return [ "\n\n        ", Spacebars.include(view.lookupTemplate("ionMenus")), "\n\n        ", Spacebars.include(view.lookupTemplate("ionSideMenuContent"), function() {
          return [ "\n          ", HTML.Comment('<div id="drag-left"></div>'), "\n          ", HTML.DIV({ // 11
            id: "drag-right"                                                                              // 12
          }), "\n\n          ", Blaze._TemplateWith(function() {                                          // 13
            return {                                                                                      // 14
              "class": Spacebars.call("bar-fantasia")                                                     // 15
            };                                                                                            // 16
          }, function() {                                                                                 // 17
            return Spacebars.include(view.lookupTemplate("ionNavBar"));                                   // 18
          }), "\n\n          ", Spacebars.include(view.lookupTemplate("ionNavView"), function() {         // 19
            return [ "\n            ", Spacebars.include(view.lookupTemplate("yield")), "\n          " ]; // 20
          }), "\n\n        " ];                                                                           // 21
        }), "\n      " ];                                                                                 // 22
      }), "\n    " ];                                                                                     // 23
    }), "\n  " ];                                                                                         // 24
  }, function() {                                                                                         // 25
    return [ "\n    ", Spacebars.include(view.lookupTemplate("yield")), "\n  " ];                         // 26
  });                                                                                                     // 27
}));                                                                                                      // 28
                                                                                                          // 29
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/arutune:bz-main/client/cordova/main-layout.js                                                 //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
/**                                                                                                       // 1
 * Created by douson on 06.07.15.                                                                         // 2
 */                                                                                                       // 3
                                                                                                          // 4
bz.help.maps.initLocation();                                                                              // 5
Template.ionSideMenuContent.rendered = function () {                                                      // 6
                                                                                                          // 7
  var template = this;                                                                                    // 8
  var content = this.find('.menu-content');                                                               // 9
  content.setAttribute('id', 'drag-content');                                                             // 10
};                                                                                                        // 11
                                                                                                          // 12
                                                                                                          // 13
Template.ionBody.rendered = function () {                                                                 // 14
                                                                                                          // 15
  /*side menu settings*/                                                                                  // 16
  if (Meteor.user()) {                                                                                    // 17
                                                                                                          // 18
    IonSideMenu.snapper.settings({                                                                        // 19
      /*disable: 'right',*/                                                                               // 20
      /*touchToDrag: false,*/                                                                             // 21
      /*hyperextensible: false,*/                                                                         // 22
      element: document.getElementById('drag-content'),                                                   // 23
      dragger: document.getElementById('drag-right')                                                      // 24
    });                                                                                                   // 25
                                                                                                          // 26
  }                                                                                                       // 27
};                                                                                                        // 28
                                                                                                          // 29
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/arutune:bz-main/client/router.js                                                              //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
/**                                                                                                       // 1
 * Created by Ashot on 9/18/15.                                                                           // 2
 */                                                                                                       // 3
Router.configure({                                                                                        // 4
  layoutTemplate: 'mainLayout',                                                                           // 5
  waitOn: function () {                                                                                   // 6
    return Meteor.subscribe('settings', function () {                                                     // 7
      _.each(bz.cols.config.find().fetch(), function (item) {                                             // 8
        bz.config[item.name] = item.value;                                                                // 9
      });                                                                                                 // 10
    });                                                                                                   // 11
  },                                                                                                      // 12
  onBeforeAction: function () { // temp for closing whole site.                                           // 13
    //debugger;                                                                                           // 14
    var openRoutes = Router.current().url === Router.routes['entrySignUp'].path() || Router.current().url === Router.routes['entrySignIn'].path();
    if (Meteor.absoluteUrl() === 'http://buzzar.io/' && !Meteor.user() && !openRoutes) {                  // 16
      if (Meteor.loggingIn()) {                                                                           // 17
        this.render(this.loadingTemplate);                                                                // 18
      } else {                                                                                            // 19
        Router.go('entrySignUp');                                                                         // 20
      }                                                                                                   // 21
    } else {                                                                                              // 22
    }                                                                                                     // 23
    this.next();                                                                                          // 24
  },                                                                                                      // 25
  // the appNotFound template is used for unknown routes and missing lists                                // 26
  //notFoundTemplate: 'appNotFound',                                                                      // 27
                                                                                                          // 28
  // show the appLoading template whilst the subscriptions below load their data                          // 29
  loadingTemplate: 'appLoading'                                                                           // 30
});                                                                                                       // 31
                                                                                                          // 32
bz.help.makeNamespace('bz.router');                                                                       // 33
                                                                                                          // 34
// let's extend the router with convenience method:                                                       // 35
Router.signIn = function(isReturnBack){                                                                   // 36
  var sR = '/sign-in';                                                                                    // 37
  if(Router.routes['entrySignIn']) {                                                                      // 38
    sR = Router.routes['entrySignIn'].url()                                                               // 39
  } else {                                                                                                // 40
                                                                                                          // 41
  }                                                                                                       // 42
  if(isReturnBack) {                                                                                      // 43
    Session.set('fromWhere', window.document.location.href);                                              // 44
    //Session.set('fromWhere', 'http://dev.buzzar.io/post/jYYDxpvEXgtq93uDr');                            // 45
                                                                                                          // 46
  }                                                                                                       // 47
  Router.go(sR);                                                                                          // 48
};                                                                                                        // 49
/***********************                                                                                  // 50
 * requireLoginController                                                                                 // 51
 ************************/                                                                                // 52
bz.router.requireLoginController = RouteController.extend({                                               // 53
                                                                                                          // 54
  onBeforeAction: function () {                                                                           // 55
    if (!Meteor.user()) {                                                                                 // 56
      if (Meteor.loggingIn()) {                                                                           // 57
        this.render(this.loadingTemplate);                                                                // 58
      } else {                                                                                            // 59
        Router.go('entrySignUp');                                                                         // 60
        //Router.go('entrySignIn');                                                                       // 61
      }                                                                                                   // 62
    } else {                                                                                              // 63
      this.next();                                                                                        // 64
    }                                                                                                     // 65
  }                                                                                                       // 66
});                                                                                                       // 67
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/arutune:bz-main/client/template.app-loading.js                                                //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
                                                                                                          // 1
Template.__checkName("appLoading");                                                                       // 2
Template["appLoading"] = new Template("Template.appLoading", (function() {                                // 3
  var view = this;                                                                                        // 4
  return Spacebars.include(view.lookupTemplate("spinner"));                                               // 5
}));                                                                                                      // 6
                                                                                                          // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
