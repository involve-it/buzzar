(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/bz-control-common.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Write your package code here!                                                                                       // 1
                                                                                                                       // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/router.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Ashot on 9/25/15.                                                                                        // 2
 */                                                                                                                    // 3
/*                                                                                                                     // 4
 Router.onBeforeAction(function(){                                                                                     // 5
 loadFilePicker('ALnxiQfmTvCYXXHc2Xlb2z');                                                                             // 6
 this.next();                                                                                                          // 7
 //can leave out key if its in settings                                                                                // 8
 },{only:['settings.edit']});*/                                                                                        // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/model.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Ashot on 9/26/15.                                                                                        // 2
 */                                                                                                                    // 3
Meteor.subscribe('bz.reviews.all');                                                                                    // 4
                                                                                                                       // 5
imagesArrayGlobal = [];                                                                                                // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/controller.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Ashot on 9/25/15.                                                                                        // 2
 */                                                                                                                    // 3
// HELPERS:                                                                                                            // 4
saveImageAndGetUrlFromData = function(data){                                                                           // 5
                                                                                                                       // 6
}                                                                                                                      // 7
getDataFromImgUrl = function(url, img$, w, h, cb){                                                                     // 8
  var img, canvas, ctx, ret;                                                                                           // 9
  //var img = $('#asdf')[0];                   '                                                                       // 10
  var img = img$;                                                                                                      // 11
  img.setAttribute('crossOrigin', 'anonymous');                                                                        // 12
  canvas = document.createElement('canvas');                                                                           // 13
                                                                                                                       // 14
  ctx = canvas.getContext("2d");                                                                                       // 15
  img.onload = function () {                                                                                           // 16
    canvas.width = img.offsetWidth;                                                                                    // 17
    canvas.height = img.offsetHeight;                                                                                  // 18
    ctx.drawImage(img, 0, 0);                                                                                          // 19
    ret = canvas.toDataURL();                                                                                          // 20
    cb.call(this, ret);                                                                                                // 21
  }                                                                                                                    // 22
  img.src = url;                                                                                                       // 23
                                                                                                                       // 24
                                                                                                                       // 25
  return ret;                                                                                                          // 26
}                                                                                                                      // 27
addImageToArrSession = function(sessionName, img){                                                                     // 28
  var arr = [];                                                                                                        // 29
  console.log('sessionName: ' + sessionName);                                                                          // 30
  if(img && sessionName) {                                                                                             // 31
    imagesArrayGlobal.push({                                                                                           // 32
      sessionName: sessionName,                                                                                        // 33
      imgUrl: img                                                                                                      // 34
    });                                                                                                                // 35
  }                                                                                                                    // 36
  Session.set('bz.posts.postImgSrc', img);                                                                             // 37
    /*                                                                                                                 // 38
    arr = Session.get(sessionName);                                                                                    // 39
    if (!arr || !Array.isArray(arr)) {                                                                                 // 40
      arr = [];                                                                                                        // 41
    }                                                                                                                  // 42
    arr.push({                                                                                                         // 43
      data: img                                                                                                        // 44
    });                                                                                                                // 45
                                                                                                                       // 46
    Session.set(sessionName, arr);                                                                                     // 47
  }                                                                                                                    // 48
  return arr;*/                                                                                                        // 49
}                                                                                                                      // 50
                                                                                                                       // 51
doneCloseChooseImageDialog = function(){                                                                               // 52
  _.each(imagesArrayGlobal, function(image, i){                                                                        // 53
    var arr, img = image.imgUrl, sessionName = image.sessionName;                                                      // 54
    arr = Session.get(sessionName);                                                                                    // 55
    if (!arr || !Array.isArray(arr)) {                                                                                 // 56
      arr = [];                                                                                                        // 57
    }                                                                                                                  // 58
    arr.push({                                                                                                         // 59
      data: img                                                                                                        // 60
    });                                                                                                                // 61
                                                                                                                       // 62
    Session.set(sessionName, arr);                                                                                     // 63
  });                                                                                                                  // 64
}                                                                                                                      // 65
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/resources/t9-en.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by douson on 13.07.15.                                                                                      // 2
 */                                                                                                                    // 3
                                                                                                                       // 4
var en;                                                                                                                // 5
                                                                                                                       // 6
en = {                                                                                                                 // 7
  searchLocationText: 'Place name or address'                                                                          // 8
};                                                                                                                     // 9
                                                                                                                       // 10
T9n.map('en', en);                                                                                                     // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/template.category-list-buttons.js                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("categoryListButtons");                                                                           // 2
Template["categoryListButtons"] = new Template("Template.categoryListButtons", (function() {                           // 3
  var view = this;                                                                                                     // 4
  return Blaze.If(function() {                                                                                         // 5
    return Spacebars.call(view.lookup("getCategoryItems"));                                                            // 6
  }, function() {                                                                                                      // 7
    return [ "\n    ", HTML.UL({                                                                                       // 8
      "class": "control--category-list-buttons"                                                                        // 9
    }, "\n      ", Blaze.Each(function() {                                                                             // 10
      return Spacebars.call(view.lookup("getCategoryItems"));                                                          // 11
    }, function() {                                                                                                    // 12
      return [ "\n        ", HTML.LI({                                                                                 // 13
        "class": function() {                                                                                          // 14
          return [ "item-category ", Spacebars.mustache(view.lookup("isActive"), view.lookup(".")) ];                  // 15
        },                                                                                                             // 16
        "data-value": function() {                                                                                     // 17
          return Spacebars.mustache(view.lookup("name"));                                                              // 18
        }                                                                                                              // 19
      }, Blaze.View("lookup:name", function() {                                                                        // 20
        return Spacebars.mustache(view.lookup("name"));                                                                // 21
      })), "\n        ", HTML.Comment('<li class="item-category {{ isActive this}}" data-value="{{ id }}">{{ name }}</li>'), "\n      " ];
    }), "\n    "), "\n  " ];                                                                                           // 23
  });                                                                                                                  // 24
}));                                                                                                                   // 25
                                                                                                                       // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/category-list-buttons.js                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by root on 9/5/15.                                                                                          // 2
 */                                                                                                                    // 3
/* Make category list */                                                                                               // 4
Template.categoryListButtons.helpers({                                                                                 // 5
  getCategoryItems: function () {                                                                                      // 6
    data = bz.cols.siteTypes.find().fetch();                                                                           // 7
    return data;                                                                                                       // 8
  },                                                                                                                   // 9
  isActive: function (a, b) {                                                                                          // 10
    var cats = Session.get('bz.control.category-list.activeCategories') || [];                                         // 11
    return (cats && cats.indexOf(this.name) !== -1) ? 'active' : '';                                                   // 12
  }                                                                                                                    // 13
});                                                                                                                    // 14
                                                                                                                       // 15
Template.categoryListButtons.events({                                                                                  // 16
  'click .item-category': function (e, v) {                                                                            // 17
    var cats = Session.get('bz.control.category-list.activeCategories') || [],                                         // 18
        ind = cats.indexOf(this.name);                                                                                 // 19
    if (ind !== -1) {                                                                                                  // 20
      cats.splice(ind, 1);                                                                                             // 21
    } else {                                                                                                           // 22
      //cats.push(this.id);                                                                                            // 23
      cats.push(this.name);                                                                                            // 24
    }                                                                                                                  // 25
    Session.set('bz.control.category-list.activeCategories', cats);                                                    // 26
    //Session.set('activeTemplate', 'singleSearchTemplate');                                                           // 27
    Session.set('activeTemplate', null);                                                                               // 28
  }                                                                                                                    // 29
});                                                                                                                    // 30
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/template.main-menu.js                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("bzMenuLeft");                                                                                    // 2
Template["bzMenuLeft"] = new Template("Template.bzMenuLeft", (function() {                                             // 3
  var view = this;                                                                                                     // 4
  return HTML.NAV({                                                                                                    // 5
    "class": "left-off-canvas-menu"                                                                                    // 6
  }, "\n    ", Spacebars.include(view.lookupTemplate("bzInnerMenuLeft")), "\n  ");                                     // 7
}));                                                                                                                   // 8
                                                                                                                       // 9
Template.__checkName("bzInnerMenuLeft");                                                                               // 10
Template["bzInnerMenuLeft"] = new Template("Template.bzInnerMenuLeft", (function() {                                   // 11
  var view = this;                                                                                                     // 12
  return [ HTML.DIV({                                                                                                  // 13
    "class": "user-area",                                                                                              // 14
    role: "user-expand-menu"                                                                                           // 15
  }, "\n    ", HTML.DIV({                                                                                              // 16
    "class": "user-area-box clearfix"                                                                                  // 17
  }, "\n      ", HTML.A({                                                                                              // 18
    href: "/profile",                                                                                                  // 19
    "class": "user-area-avatar"                                                                                        // 20
  }, "\n        ", HTML.DIV({                                                                                          // 21
    "class": "bz-avatar",                                                                                              // 22
    style: function() {                                                                                                // 23
      return [ "background-image: url(", Spacebars.mustache(view.lookup("getUserAvatar")), ")" ];                      // 24
    }                                                                                                                  // 25
  }), "\n      "), "\n\n      ", HTML.DIV({                                                                            // 26
    "class": "user-area-side"                                                                                          // 27
  }, "\n        ", HTML.A({                                                                                            // 28
    href: "/profile",                                                                                                  // 29
    "class": "user-area-user-name"                                                                                     // 30
  }, " ", Blaze.View("lookup:getCurrentUserName", function() {                                                         // 31
    return Spacebars.mustache(view.lookup("getCurrentUserName"));                                                      // 32
  }), " "), "\n        ", HTML.Raw('<button class="button transparent btn-drop" role="expand-menu-trigger"><i class="fa fa-chevron-down"></i>\n        </button>'), "\n      "), "\n    "), "\n    ", HTML.DIV({
    "class": "user-area-menu clearfix"                                                                                 // 34
  }, "\n      ", HTML.UL({                                                                                             // 35
    "class": "off-canvas-list",                                                                                        // 36
    role: "expand-menu-dropdown"                                                                                       // 37
  }, "\n        ", Spacebars.include(view.lookupTemplate("bzSignOutListMenu")), "\n      "), "\n    "), "\n  "), "\n\n  ", HTML.UL({
    "class": "off-canvas-list"                                                                                         // 39
  }, "\n    ", HTML.Raw("<li><label>Main pages</label></li>"), "\n    ", HTML.LI({                                     // 40
    "class": function() {                                                                                              // 41
      return Spacebars.mustache(view.lookup("isActiveRoute"), "home");                                                 // 42
    }                                                                                                                  // 43
  }, HTML.A({                                                                                                          // 44
    href: function() {                                                                                                 // 45
      return Spacebars.mustache(view.lookup("pathFor"), "home");                                                       // 46
    }                                                                                                                  // 47
  }, "Home")), "\n\n    ", Blaze.If(function() {                                                                       // 48
    return Spacebars.call(view.lookup("currentUser"));                                                                 // 49
  }, function() {                                                                                                      // 50
    return [ "\n      ", Spacebars.include(view.lookupTemplate("checkingUserMenu")), "\n    " ];                       // 51
  }), "\n\n    ", HTML.LI({                                                                                            // 52
    "class": function() {                                                                                              // 53
      return Spacebars.mustache(view.lookup("isActiveRoute"), "bz.map");                                               // 54
    }                                                                                                                  // 55
  }, HTML.A({                                                                                                          // 56
    href: function() {                                                                                                 // 57
      return Spacebars.mustache(view.lookup("pathFor"), "bz.map");                                                     // 58
    }                                                                                                                  // 59
  }, "Map")), "\n    ", HTML.LI({                                                                                      // 60
    "class": function() {                                                                                              // 61
      return Spacebars.mustache(view.lookup("isActiveRoute"), "bz.aboutUs");                                           // 62
    }                                                                                                                  // 63
  }, HTML.A({                                                                                                          // 64
    href: function() {                                                                                                 // 65
      return Spacebars.mustache(view.lookup("pathFor"), "bz.aboutUs");                                                 // 66
    }                                                                                                                  // 67
  }, "About Us")), "\n  "), "\n  ", Blaze.If(function() {                                                              // 68
    return Spacebars.call(view.lookup("currentUser"));                                                                 // 69
  }, function() {                                                                                                      // 70
    return [ "\n    ", Spacebars.include(view.lookupTemplate("bzControlMenuHashes")), "\n  " ];                        // 71
  }) ];                                                                                                                // 72
}));                                                                                                                   // 73
                                                                                                                       // 74
Template.__checkName("checkingUserMenu");                                                                              // 75
Template["checkingUserMenu"] = new Template("Template.checkingUserMenu", (function() {                                 // 76
  var view = this;                                                                                                     // 77
  return [ HTML.LI({                                                                                                   // 78
    "class": function() {                                                                                              // 79
      return Spacebars.mustache(view.lookup("isActiveRoute"), "postsMy");                                              // 80
    }                                                                                                                  // 81
  }, HTML.A({                                                                                                          // 82
    href: function() {                                                                                                 // 83
      return Spacebars.mustache(view.lookup("pathFor"), "postsMy");                                                    // 84
    }                                                                                                                  // 85
  }, "My posts")), "\n  ", HTML.LI({                                                                                   // 86
    "class": function() {                                                                                              // 87
      return Spacebars.mustache(view.lookup("isActiveRoute"), "myProfile");                                            // 88
    }                                                                                                                  // 89
  }, HTML.A({                                                                                                          // 90
    href: function() {                                                                                                 // 91
      return Spacebars.mustache(view.lookup("pathFor"), "myProfile");                                                  // 92
    }                                                                                                                  // 93
  }, "My profile")), "\n  ", HTML.LI({                                                                                 // 94
    "class": function() {                                                                                              // 95
      return Spacebars.mustache(view.lookup("isActiveRoute"), "chats.my");                                             // 96
    }                                                                                                                  // 97
  }, HTML.Raw('<a href="/chats/my">Messages</a>')), HTML.Raw("\n  <!--<li class=\"{{isActiveRoute 'chats.my'}}\"><a href=\"{{pathFor 'chats.my'}}\">Messages</a></li>-->") ];
}));                                                                                                                   // 99
                                                                                                                       // 100
Template.__checkName("bzControlMenuHashes");                                                                           // 101
Template["bzControlMenuHashes"] = new Template("Template.bzControlMenuHashes", (function() {                           // 102
  var view = this;                                                                                                     // 103
  return HTML.UL({                                                                                                     // 104
    "class": "off-canvas-list only-menu-left"                                                                          // 105
  }, HTML.Raw("\n    <li><label>Hashes</label></li>\n\n    "), Blaze.Each(function() {                                 // 106
    return Spacebars.call(view.lookup("getUserHashes"));                                                               // 107
  }, function() {                                                                                                      // 108
    return [ "\n      ", HTML.LI(HTML.A({                                                                              // 109
      alt: function() {                                                                                                // 110
        return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "text"));                                      // 111
      },                                                                                                               // 112
      href: function() {                                                                                               // 113
        return Spacebars.mustache(view.lookup("getMenuLinkText"));                                                     // 114
      }                                                                                                                // 115
    }, Blaze.View("lookup:getMenuHashName", function() {                                                               // 116
      return Spacebars.mustache(view.lookup("getMenuHashName"));                                                       // 117
    }))), "\n    " ];                                                                                                  // 118
  }), "\n  ");                                                                                                         // 119
}));                                                                                                                   // 120
                                                                                                                       // 121
Template.__checkName("bzSignOutListMenu");                                                                             // 122
Template["bzSignOutListMenu"] = new Template("Template.bzSignOutListMenu", (function() {                               // 123
  var view = this;                                                                                                     // 124
  return Blaze.If(function() {                                                                                         // 125
    return Spacebars.call(view.lookup("currentUser"));                                                                 // 126
  }, function() {                                                                                                      // 127
    return [ "\n    ", HTML.LI({                                                                                       // 128
      "class": "log-out"                                                                                               // 129
    }, "\n      ", HTML.A({                                                                                            // 130
      "class": "item item-icon-left",                                                                                  // 131
      href: "/sign-out"                                                                                                // 132
    }, "\n        ", HTML.I({                                                                                          // 133
      "class": "fa fa-sign-out"                                                                                        // 134
    }), HTML.SPAN("Sign out"), "\n      "), "\n    "), "\n  " ];                                                       // 135
  }, function() {                                                                                                      // 136
    return [ "\n    ", HTML.LI({                                                                                       // 137
      "class": "log-out"                                                                                               // 138
    }, "\n      ", HTML.A({                                                                                            // 139
      "class": "item item-icon-left",                                                                                  // 140
      href: "/sign-in"                                                                                                 // 141
    }, "\n        ", HTML.I({                                                                                          // 142
      "class": "fa fa-sign-in"                                                                                         // 143
    }), HTML.SPAN("Sign in"), "\n      "), "\n    "), "\n  " ];                                                        // 144
  });                                                                                                                  // 145
}));                                                                                                                   // 146
                                                                                                                       // 147
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/main-menu.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Ashot on 9/27/15.                                                                                        // 2
 */                                                                                                                    // 3
Template.bzControlMenuHashes.onCreated(function(){                                                                     // 4
  Meteor.subscribe('bz.hashes.all');                                                                                   // 5
});                                                                                                                    // 6
Template.bzControlMenuHashes.helpers({                                                                                 // 7
  getUserHashes: function(){                                                                                           // 8
    return bz.cols.hashes.find({userId: Meteor.userId()});                                                             // 9
  },                                                                                                                   // 10
  getMenuHashName: function(){                                                                                         // 11
    var menuLinkText = '#' + this.details.text + ' @' + this.details.locName;                                          // 12
    return menuLinkText;                                                                                               // 13
  },                                                                                                                   // 14
  getMenuLinkText: function(){                                                                                         // 15
    //var menuLinkText = '#' + this.details.text + ' @' + ;                                                            // 16
    var url = '/home?locationName=' + this.details.locName + '&searchText=' + this.details.text + '';                  // 17
    return url;                                                                                                        // 18
    //return encodeURIComponent(url);                                                                                  // 19
  }                                                                                                                    // 20
});                                                                                                                    // 21
                                                                                                                       // 22
Template.bzInnerMenuLeft.helpers({                                                                                     // 23
  getCurrentUserName: function(){                                                                                      // 24
    return Meteor.user() && Meteor.user().username;                                                                    // 25
  },                                                                                                                   // 26
  getUserAvatar: function(){                                                                                           // 27
    var ret = '/img/content/avatars/avatar-no.png';                                                                    // 28
    var user = Meteor.user();                                                                                          // 29
    if(user && user._getAvatarImage()){                                                                                // 30
      ret = user._getAvatarImage();                                                                                    // 31
    }                                                                                                                  // 32
    return ret;                                                                                                        // 33
  }                                                                                                                    // 34
})                                                                                                                     // 35
Template.bzInnerMenuLeft.events({                                                                                      // 36
  'click .btn-drop': function(e) {                                                                                     // 37
    e.preventDefault();                                                                                                // 38
                                                                                                                       // 39
    var menuHeight = $("[role='expand-menu-dropdown']").height();                                                      // 40
    if($("[role='user-expand-menu']").hasClass("user-panel-expand")) {                                                 // 41
      $("[role='expand-menu-trigger']").removeClass("arrow-down");                                                     // 42
      $("[role='user-expand-menu']").removeClass("user-panel-expand");                                                 // 43
      $("[role='expand-menu-dropdown']").parent().height(0);                                                           // 44
    } else {                                                                                                           // 45
      $("[role='expand-menu-trigger']").addClass("arrow-down");                                                        // 46
      $("[role='user-expand-menu']").addClass("user-panel-expand");                                                    // 47
      $("[role='expand-menu-dropdown']").parent().height(menuHeight);                                                  // 48
    }                                                                                                                  // 49
  }                                                                                                                    // 50
});                                                                                                                    // 51
                                                                                                                       // 52
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/template.reviews.js                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("bzControlReviews");                                                                              // 2
Template["bzControlReviews"] = new Template("Template.bzControlReviews", (function() {                                 // 3
  var view = this;                                                                                                     // 4
  return [ HTML.H3({                                                                                                   // 5
    "class": "title-review"                                                                                            // 6
  }, Blaze.View("lookup:getCountsReviews", function() {                                                                // 7
    return Spacebars.mustache(view.lookup("getCountsReviews"));                                                        // 8
  }), " Comments"), "\n    ", HTML.DIV({                                                                               // 9
    "class": "bz-reviews-list"                                                                                         // 10
  }, "\n      ", Blaze.Each(function() {                                                                               // 11
    return Spacebars.call(view.lookup("getReviews"));                                                                  // 12
  }, function() {                                                                                                      // 13
    return [ "\n        ", Spacebars.include(view.lookupTemplate("bzControlReviewItem")), "\n      " ];                // 14
  }), "\n    ") ];                                                                                                     // 15
}));                                                                                                                   // 16
                                                                                                                       // 17
Template.__checkName("bzControlReviewItem");                                                                           // 18
Template["bzControlReviewItem"] = new Template("Template.bzControlReviewItem", (function() {                           // 19
  var view = this;                                                                                                     // 20
  return HTML.DIV({                                                                                                    // 21
    "class": "bz-post-content"                                                                                         // 22
  }, HTML.Raw('\n    \n    <div class="bz-review-avatar">\n        <!--{{ profileImage }}-->\n        <a href="#" class="bz-user-avatar">\n            <img src="/img/content/avatars/avatar-no.png" width="60" height="60" alt="avatar">\n        </a>\n    </div>\n      \n    '), HTML.DIV({
    "class": "bz-review-post-body"                                                                                     // 24
  }, "\n        ", HTML.DIV({                                                                                          // 25
    "class": "bz-review-post-body-header"                                                                              // 26
  }, "\n            ", HTML.Raw('<div class="bz-review-post-inline">\n                <span class="bz-author bz-publisher-anchor-color">\n                    <a href="#">USER NAME or FIRST NAME</a>\n                    <!--<a href="#">{{ userName }}</a>-->\n                </span>\n            </div>'), "\n            \n            ", HTML.DIV({
    "class": "bz-post-meta"                                                                                            // 28
  }, "\n                ", HTML.Raw('<span class="bz-bullet bz-time-ago-bullet">•</span>'), "\n                ", Blaze.View("lookup:getTime", function() {
    return Spacebars.mustache(view.lookup("getTime"));                                                                 // 30
  }), "\n            "), "\n        "), "\n        \n        ", HTML.DIV({                                             // 31
    "class": "bz-review-post-body-inner"                                                                               // 32
  }, "\n            ", HTML.DIV({                                                                                      // 33
    "class": "bz-review-post-message"                                                                                  // 34
  }, "\n                ", Blaze.View("lookup:text", function() {                                                      // 35
    return Spacebars.mustache(view.lookup("text"));                                                                    // 36
  }), "\n            "), "\n        "), "\n        \n        ", HTML.DIV({                                             // 37
    "class": "bz-review-post-body-footer"                                                                              // 38
  }, "\n            ", HTML.DIV("\n                Rating: ", Blaze.View("lookup:rating", function() {                 // 39
    return Spacebars.mustache(view.lookup("rating"));                                                                  // 40
  }), "\n            "), "\n        "), "\n    "), "    \n    \n  ");                                                  // 41
}));                                                                                                                   // 42
                                                                                                                       // 43
Template.__checkName("bzControlAddReview");                                                                            // 44
Template["bzControlAddReview"] = new Template("Template.bzControlAddReview", (function() {                             // 45
  var view = this;                                                                                                     // 46
  return [ HTML.TEXTAREA({                                                                                             // 47
    rows: "4",                                                                                                         // 48
    cols: "50",                                                                                                        // 49
    "class": "js-post-text-input",                                                                                     // 50
    placeholder: "put your review here"                                                                                // 51
  }), HTML.Raw('\n    \n    <div class="bz-control-reviews">\n        \n        <select id="single-bsg-pilot" class="js-rating-select" data-prompt="Choose rating">\n            <option value="1">1</option>\n            <option value="2">2</option>\n            <option value="3">3</option>\n            <option value="4">4</option>\n            <option value="5">5</option>\n        </select>\n  \n        <button class="button btn-default bz-small js-post-btn">Submit</button>\n        \n  </div>') ];
}));                                                                                                                   // 53
                                                                                                                       // 54
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/reviews.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Ashot on 9/26/15.                                                                                        // 2
 */                                                                                                                    // 3
Template.bzControlReviews.onCreated(function(){                                                                        // 4
});                                                                                                                    // 5
Template.bzControlReviews.events({                                                                                     // 6
                                                                                                                       // 7
});                                                                                                                    // 8
Template.bzControlReviews.helpers({                                                                                    // 9
  getReviews: function(){                                                                                              // 10
    return bz.cols.reviews.find({type: 'postType', entityId: this.postId}, { sort: { dateTime: -1}});                  // 11
  },                                                                                                                   // 12
  getCountsReviews: function() {                                                                                       // 13
    var counts = bz.cols.reviews.find({type: 'postType', entityId: this.postId}).count();                              // 14
    return counts || '';                                                                                               // 15
  }                                                                                                                    // 16
});                                                                                                                    // 17
Template.bzControlReviewItem.helpers({                                                                                 // 18
  getTime: function(){                                                                                                 // 19
    //debugger;                                                                                                        // 20
    var d = new Date(this.dateTime);                                                                                   // 21
    return d.toLocaleString();                                                                                         // 22
  }                                                                                                                    // 23
});                                                                                                                    // 24
Template.bzControlAddReview.onCreated(function(){                                                                      // 25
  //this.data.postId = this.data.toString();                                                                           // 26
});                                                                                                                    // 27
Template.bzControlAddReview.onRendered(function(){                                                                     // 28
  $('.js-rating-select').foundationSelect();                                                                           // 29
});                                                                                                                    // 30
Template.bzControlAddReview.events({                                                                                   // 31
  'click .js-post-btn': function(e, v){                                                                                // 32
    //debugger;                                                                                                        // 33
    var text = $('.js-post-text-input').val(),                                                                         // 34
        userId = Meteor.userId(),                                                                                      // 35
        postId = this.postId,                                                                                          // 36
        rating = $('.js-rating-select').val();                                                                         // 37
    if(!userId){                                                                                                       // 38
      // todo: after login the process should be continued                                                             // 39
      /*var loginFunc = accountsClientOrServer.onLogin(function(){                                                     // 40
                                                                                                                       // 41
      });*/                                                                                                            // 42
      Router.signIn(true);                                                                                             // 43
    } else {                                                                                                           // 44
      if(text.trim() && postId){                                                                                       // 45
        bz.cols.reviews.insert({                                                                                       // 46
          entityId: postId,                                                                                            // 47
          type: 'postType',                                                                                            // 48
          user: Meteor.user(),                                                                                         // 49
          userId: Meteor.userId(),                                                                                     // 50
          text: text.trim(),                                                                                           // 51
          rating: rating || undefined,                                                                                 // 52
          dateTime: Date.now()                                                                                         // 53
        });                                                                                                            // 54
        $('.js-post-text-input').val('');                                                                              // 55
      }                                                                                                                // 56
    }                                                                                                                  // 57
                                                                                                                       // 58
                                                                                                                       // 59
  }                                                                                                                    // 60
})                                                                                                                     // 61
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/template.upload-image.js                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("uploadImageModal");                                                                              // 2
Template["uploadImageModal"] = new Template("Template.uploadImageModal", (function() {                                 // 3
  var view = this;                                                                                                     // 4
  return [ HTML.Raw('<h2 id="modalTitle" class="title">Choose image</h2>\n  <!--<ul class="tabs" data-tab data-options="deep_linking: false; scroll_to_content: false">-->\n\n    <div class="bz-toolbar bz-upload-image-toolbar">\n        <div class="bz-upload-image-toolbar-wrapper">\n            <ul class="tabs bz-nav bz-horizontal" data-tab="">\n                <li class="tab-title active"><a href="#panel11">Upload Photo</a></li>\n                <li class="tab-title"><a href="#panel21">Take Photo</a></li>\n                <li class="tab-title"><a href="#panel31">Image from Url</a></li>\n                <li class="tab-title"><a href="#panel41">Random Image</a></li>\n            </ul>\n        </div>\n    </div>\n    \n    \n  '), HTML.DIV({
    "class": "tabs-content"                                                                                            // 6
  }, "\n    ", HTML.DIV({                                                                                              // 7
    "class": "content active",                                                                                         // 8
    id: "panel11"                                                                                                      // 9
  }, "\n      ", Blaze.If(function() {                                                                                 // 10
    return Spacebars.call(view.lookup("countFile"));                                                                   // 11
  }, function() {                                                                                                      // 12
    return [ "\n        ", HTML.P("\n            ", HTML.INPUT({                                                       // 13
      type: "file",                                                                                                    // 14
      accept: "image/*",                                                                                               // 15
      "class": "js-file-upload"                                                                                        // 16
    }), "\n            ", HTML.Comment('<button class="button js-photo-library">Choose file</button>'), "\n        "), "\n          " ];
  }, function() {                                                                                                      // 18
    return [ "\n            ", Spacebars.include(view.lookupTemplate("noUploadImagePhoto")), "\n        " ];           // 19
  }), "\n    "), "\n    ", HTML.Raw('<div class="content" id="panel21">\n      <div class="bz-upload-photo-wrapper">\n        <div class="bz-upload-photo-wrapper-image"><i class="fa fa-camera"></i></div>\n        <div class="bz-button-box"><button class="button btn-default btn-gray js-take-photo">Take Photo</button></div>\n      </div>\n    </div>'), "\n    ", HTML.Raw('<div class="content" id="panel31">\n        <div class="bz-upload-photo-wrapper">\n            <div class="bz-upload-photo-wrapper-check">\n                <div class="bz-input-flex"><input type="text" placeholder="image url" class="js-image-url"></div>\n                <div class="margin-left"><button class="button btn-default bz-small js-use-image-url">Check Image</button></div>\n            </div>\n        </div>\n    </div>'), "\n    ", HTML.Raw('<div class="content" id="panel41">\n        <div class="bz-upload-photo-wrapper">\n            <div class="bz-button-box"><button class="button btn-default btn-gray js-use-random-image-url">Random Image Url</button></div>\n        </div>\n    </div>'), "\n  "), HTML.Raw('\n\n  <a class="close-reveal-modal" aria-label="Close">&#215;</a>\n\n  <div data-alert="" class="alert-box alert hidden js-library-not-available-alert">\n    Photo Library is not available.\n    <a href="#" class="close">&times;</a>\n  </div>\n  \n \n  '), HTML.DIV({
    "class": "bz-js-preview-wrapper"                                                                                   // 21
  }, "\n      \n      ", HTML.IMG({                                                                                    // 22
    "class": "js-preview",                                                                                             // 23
    src: function() {                                                                                                  // 24
      return Spacebars.mustache(view.lookup("getPreviewImgSrc"));                                                      // 25
    }                                                                                                                  // 26
  }), "\n\n  "), HTML.Raw('\n\n    \n  <hr>\n    \n  <button class="js-ok-btn btn-default bz-small">Done</button>') ]; // 27
}));                                                                                                                   // 28
                                                                                                                       // 29
Template.__checkName("filePickerUpload");                                                                              // 30
Template["filePickerUpload"] = new Template("Template.filePickerUpload", (function() {                                 // 31
  var view = this;                                                                                                     // 32
  return HTML.Raw('<button id="upload">Upload New Profile Image with File Picker</button>');                           // 33
}));                                                                                                                   // 34
                                                                                                                       // 35
Template.__checkName("noUploadImagePhoto");                                                                            // 36
Template["noUploadImagePhoto"] = new Template("Template.noUploadImagePhoto", (function() {                             // 37
  var view = this;                                                                                                     // 38
  return HTML.Raw('<div class="no-upload-image">\n        <div class="no-upload-image-wrapper">\n            <div class="no-img"><i class="fa fa-picture-o"></i></div>\n            <div class="bz-files-button">\n                <input type="file" accept="image/*" class="bz-custom-file-input js-file-upload">\n            </div>\n        </div>\n    </div>');
}));                                                                                                                   // 40
                                                                                                                       // 41
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-control-common/client/browser/upload-image.js                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Ashot on 9/25/15.                                                                                        // 2
 */                                                                                                                    // 3
Template.uploadImageModal.onRendered(function () {                                                                     // 4
    setTimeout(function () {                                                                                           // 5
    $(document).off('open.fndtn.reveal', '[data-reveal].js-avatar-upload-modal');                                      // 6
    $(document).on('open.fndtn.reveal', '[data-reveal].js-avatar-upload-modal', function () {                          // 7
      Session.set('bz.posts.postImgSrc', '');                                                                          // 8
    });                                                                                                                // 9
  }, 1000);                                                                                                            // 10
  // this.data is session var name for holding img src                                                                 // 11
  $(document).foundation('tab', 'reflow');                                                                             // 12
});                                                                                                                    // 13
                                                                                                                       // 14
Template.uploadImageModal.helpers({                                                                                    // 15
  getPreviewImgSrc: function () {                                                                                      // 16
    var imgSrc = Session.get('bz.posts.postImgSrc') || '';                                                             // 17
    return Session.get(imgSrc);                                                                                        // 18
  },                                                                                                                   // 19
  countFile: function() {                                                                                              // 20
                                                                                                                       // 21
    if(Session.get('bz.posts.postImgArr') !== undefined) {                                                             // 22
      return true;                                                                                                     // 23
    }                                                                                                                  // 24
  }                                                                                                                    // 25
});                                                                                                                    // 26
                                                                                                                       // 27
Template.uploadImageModal.events({                                                                                     // 28
  'click .tabs a': function(e, v){                                                                                     // 29
    e.preventDefault();                                                                                                // 30
  },                                                                                                                   // 31
  'click .js-photo-library': function (e, v) {                                                                         // 32
    var options = {                                                                                                    // 33
      width: 350,                                                                                                      // 34
      height: 350,                                                                                                     // 35
      quality: 75                                                                                                      // 36
    }                                                                                                                  // 37
    if (typeof Camera !== 'undefined') {                                                                               // 38
                                                                                                                       // 39
      options.sourceType = Camera.PictureSourceType.PHOTOLIBRARY;                                                      // 40
      MeteorCamera.getPicture(options, function (err, data) {                                                          // 41
        if (err) {                                                                                                     // 42
          console.log('error', err);                                                                                   // 43
        }                                                                                                              // 44
        if (data) {                                                                                                    // 45
          addImageToArrSession(this.data.sessionName, data);                                                           // 46
        }                                                                                                              // 47
      });                                                                                                              // 48
                                                                                                                       // 49
    } else {                                                                                                           // 50
      $('.js-library-not-available-alert').show(function () {                                                          // 51
        setTimeout(function () {                                                                                       // 52
          $('.js-library-not-available-alert').hide();                                                                 // 53
        }, 3000);                                                                                                      // 54
      });                                                                                                              // 55
    }                                                                                                                  // 56
  },                                                                                                                   // 57
  'click .js-take-photo': function (e, v) {                                                                            // 58
    var options = {                                                                                                    // 59
          width: 350,                                                                                                  // 60
          height: 350,                                                                                                 // 61
          quality: 75                                                                                                  // 62
        },                                                                                                             // 63
        that = this;                                                                                                   // 64
                                                                                                                       // 65
    MeteorCamera.getPicture(options, function (err, data) {                                                            // 66
      if (err) {                                                                                                       // 67
        console.log('error', err);                                                                                     // 68
      }                                                                                                                // 69
      if (data) {                                                                                                      // 70
        //Session.set(that.sessionName, data);                                                                         // 71
        addImageToArrSession(that.sessionName, data);                                                                  // 72
      }                                                                                                                // 73
    });                                                                                                                // 74
  },                                                                                                                   // 75
  'click .js-use-image-url': function (e, v) {                                                                         // 76
    var imgData = $('.js-image-url').val();                                                                            // 77
    if (imgData) {                                                                                                     // 78
      //Session.set(this.sessionName, $('.js-image-url').val());                                                       // 79
      addImageToArrSession(this.data.sessionName, imgData);                                                            // 80
                                                                                                                       // 81
    }                                                                                                                  // 82
  },                                                                                                                   // 83
  'click .js-use-random-image-url': function (e, v) {                                                                  // 84
    var that = this, imgData,                                                                                          // 85
        randomImgUrl = bz.const.randomImageSite + '?ts=' + Date.now();                                                 // 86
    addImageToArrSession(this.data.sessionName, randomImgUrl);                                                         // 87
    /*getDataFromImgUrl(randomImgUrl, $('.js-preview')[0], 400, 300, function (imgData) {                              // 88
      //Session.set(that.sessionName, imgData);                                                                        // 89
      addImageToArrSession(that.sessionName, imgData);                                                                 // 90
                                                                                                                       // 91
    });*/                                                                                                              // 92
  },                                                                                                                   // 93
  'change .js-file-upload': function (e, v) {                                                                          // 94
    var input = e.target, that = this;                                                                                 // 95
    if (input.files && input.files[0]) {                                                                               // 96
      var reader = new FileReader();                                                                                   // 97
      reader.onload = function (e1) {                                                                                  // 98
        //Session.set(that.sessionName, e1.target.result);                                                             // 99
                                                                                                                       // 100
        addImageToArrSession(that.sessionName, e1.target.result);                                                      // 101
      };                                                                                                               // 102
      reader.readAsDataURL(input.files[0]);                                                                            // 103
    }                                                                                                                  // 104
  },                                                                                                                   // 105
  'click .js-ok-btn': function () {                                                                                    // 106
    debugger;                                                                                                          // 107
    $('.js-avatar-upload-modal').foundation('reveal', 'close');                                                        // 108
    doneCloseChooseImageDialog();                                                                                      // 109
    //Modules.client.uploadToAmazonS3( { event: event, template: template } );                                         // 110
                                                                                                                       // 111
  }                                                                                                                    // 112
});                                                                                                                    // 113
                                                                                                                       // 114
/*                                                                                                                     // 115
 Template.filePickerUpload.events({                                                                                    // 116
 'click #upload': function () {                                                                                        // 117
                                                                                                                       // 118
 filepicker.pick(                                                                                                      // 119
 {                                                                                                                     // 120
 mimetypes: ['image/gif','image/jpeg','image/png'],                                                                    // 121
 multiple: false                                                                                                       // 122
 },                                                                                                                    // 123
 function(InkBlob){                                                                                                    // 124
 var image = Images.findOne({userId:Meteor.userId()});                                                                 // 125
 if(image){                                                                                                            // 126
 Images.update({_id:image._id},                                                                                        // 127
 {                                                                                                                     // 128
 $set:{                                                                                                                // 129
 filepickerId:_.last(InkBlob.url.split("/"))                                                                           // 130
 }                                                                                                                     // 131
 });                                                                                                                   // 132
 }else{                                                                                                                // 133
 Images.insert({                                                                                                       // 134
 userId:Meteor.userId(),                                                                                               // 135
 filepickerId:_.last(InkBlob.url.split("/")),                                                                          // 136
 createdAt:new Date() //this isnt guarnteed accurate, but its ok for this simple demo                                  // 137
 });                                                                                                                   // 138
 }                                                                                                                     // 139
 },                                                                                                                    // 140
 function(FPError){                                                                                                    // 141
 if(FPError && FPError.code !== 101)                                                                                   // 142
 alert(FPError.toString());                                                                                            // 143
 }                                                                                                                     // 144
 );                                                                                                                    // 145
 }                                                                                                                     // 146
 })*/                                                                                                                  // 147
                                                                                                                       // 148
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
