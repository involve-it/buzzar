(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-control-common/bz-control-common.js           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
// Write your package code here!                                     // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-control-common/client/router.js               //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by Ashot on 9/25/15.                                      // 2
 */                                                                  // 3
/*                                                                   // 4
 Router.onBeforeAction(function(){                                   // 5
 loadFilePicker('ALnxiQfmTvCYXXHc2Xlb2z');                           // 6
 this.next();                                                        // 7
 //can leave out key if its in settings                              // 8
 },{only:['settings.edit']});*/                                      // 9
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-control-common/client/model.js                //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by Ashot on 9/26/15.                                      // 2
 */                                                                  // 3
Meteor.subscribe('bz.reviews.all');                                  // 4
                                                                     // 5
imagesArrayGlobal = [];                                              // 6
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-control-common/client/controller.js           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by Ashot on 9/25/15.                                      // 2
 */                                                                  // 3
// HELPERS:                                                          // 4
saveImageAndGetUrlFromData = function(data){                         // 5
                                                                     // 6
}                                                                    // 7
getDataFromImgUrl = function(url, img$, w, h, cb){                   // 8
  var img, canvas, ctx, ret;                                         // 9
  //var img = $('#asdf')[0];                   '                     // 10
  var img = img$;                                                    // 11
  img.setAttribute('crossOrigin', 'anonymous');                      // 12
  canvas = document.createElement('canvas');                         // 13
                                                                     // 14
  ctx = canvas.getContext("2d");                                     // 15
  img.onload = function () {                                         // 16
    canvas.width = img.offsetWidth;                                  // 17
    canvas.height = img.offsetHeight;                                // 18
    ctx.drawImage(img, 0, 0);                                        // 19
    ret = canvas.toDataURL();                                        // 20
    cb.call(this, ret);                                              // 21
  }                                                                  // 22
  img.src = url;                                                     // 23
                                                                     // 24
                                                                     // 25
  return ret;                                                        // 26
}                                                                    // 27
addImageToArrSession = function(sessionName, img){                   // 28
  var arr = [];                                                      // 29
  console.log('sessionName: ' + sessionName);                        // 30
  if(img && sessionName) {                                           // 31
    imagesArrayGlobal.push({                                         // 32
      sessionName: sessionName,                                      // 33
      imgUrl: img                                                    // 34
    });                                                              // 35
  }                                                                  // 36
  Session.set('bz.posts.postImgSrc', img);                           // 37
    /*                                                               // 38
    arr = Session.get(sessionName);                                  // 39
    if (!arr || !Array.isArray(arr)) {                               // 40
      arr = [];                                                      // 41
    }                                                                // 42
    arr.push({                                                       // 43
      data: img                                                      // 44
    });                                                              // 45
                                                                     // 46
    Session.set(sessionName, arr);                                   // 47
  }                                                                  // 48
  return arr;*/                                                      // 49
}                                                                    // 50
                                                                     // 51
doneCloseChooseImageDialog = function(){                             // 52
  _.each(imagesArrayGlobal, function(image, i){                      // 53
    var arr, img = image.imgUrl, sessionName = image.sessionName;    // 54
    arr = Session.get(sessionName);                                  // 55
    if (!arr || !Array.isArray(arr)) {                               // 56
      arr = [];                                                      // 57
    }                                                                // 58
    arr.push({                                                       // 59
      data: img                                                      // 60
    });                                                              // 61
                                                                     // 62
    Session.set(sessionName, arr);                                   // 63
  });                                                                // 64
}                                                                    // 65
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-control-common/client/resources/t9-en.js      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by douson on 13.07.15.                                    // 2
 */                                                                  // 3
                                                                     // 4
var en;                                                              // 5
                                                                     // 6
en = {                                                               // 7
  searchLocationText: 'Place name or address'                        // 8
};                                                                   // 9
                                                                     // 10
T9n.map('en', en);                                                   // 11
///////////////////////////////////////////////////////////////////////

}).call(this);
