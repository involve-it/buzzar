(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-page-user/collections/users.shared.js         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by arutu_000 on 10/20/2015.                               // 2
 * // for references see this :                                      // 3
 * see meteor add dburles:collection-helpers                         // 4
 * https://atmospherejs.com/dburles/collection-helpers               // 5
 *                                                                   // 6
 */                                                                  // 7
                                                                     // 8
var usersCol = Meteor.users;                                         // 9
usersCol.helpers({                                                   // 10
  _isOnline: function () {                                           // 11
    var ret;                                                         // 12
    if(this.online){                                                 // 13
      ret = this.online;                                             // 14
    }                                                                // 15
    return ret;                                                      // 16
  },                                                                 // 17
  _getAvatarImage: function (userId) {                               // 18
    var ret;                                                         // 19
    if (this.profile && this.profile.image) {                        // 20
      ret = this.profile.image.data;                                 // 21
    }                                                                // 22
    return ret;                                                      // 23
  }                                                                  // 24
});                                                                  // 25
                                                                     // 26
                                                                     // 27
///////////////////////////////////////////////////////////////////////

}).call(this);
