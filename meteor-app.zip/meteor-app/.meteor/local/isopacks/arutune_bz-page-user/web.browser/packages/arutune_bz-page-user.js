(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/collections/users.shared.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by arutu_000 on 10/20/2015.                                                                                // 2
 * // for references see this :                                                                                       // 3
 * see meteor add dburles:collection-helpers                                                                          // 4
 * https://atmospherejs.com/dburles/collection-helpers                                                                // 5
 *                                                                                                                    // 6
 */                                                                                                                   // 7
                                                                                                                      // 8
var usersCol = Meteor.users;                                                                                          // 9
usersCol.helpers({                                                                                                    // 10
  _isOnline: function () {                                                                                            // 11
    var ret;                                                                                                          // 12
    if(this.online){                                                                                                  // 13
      ret = this.online;                                                                                              // 14
    }                                                                                                                 // 15
    return ret;                                                                                                       // 16
  },                                                                                                                  // 17
  _getAvatarImage: function (userId) {                                                                                // 18
    var ret;                                                                                                          // 19
    if (this.profile && this.profile.image) {                                                                         // 20
      ret = this.profile.image.data;                                                                                  // 21
    }                                                                                                                 // 22
    return ret;                                                                                                       // 23
  }                                                                                                                   // 24
});                                                                                                                   // 25
                                                                                                                      // 26
                                                                                                                      // 27
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/router.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/18/15.                                                                                       // 2
 */                                                                                                                   // 3
Router.map(function () {                                                                                              // 4
  this.route('myProfile', {                                                                                           // 5
    path: 'profile',                                                                                                  // 6
    template: 'profileSettings',                                                                                      // 7
    controller: 'requireLoginController',                                                                             // 8
    waitOn: function () {                                                                                             // 9
      return [                                                                                                        // 10
        Meteor.subscribe('users')                                                                                     // 11
      ]                                                                                                               // 12
    },                                                                                                                // 13
    data: function () {                                                                                               // 14
      return Meteor.user();                                                                                           // 15
    }                                                                                                                 // 16
  });                                                                                                                 // 17
  this.route('settings.edit', {                                                                                       // 18
    path: '/profile/edit',                                                                                            // 19
    template: 'userEdit',                                                                                             // 20
    controller: 'requireLoginController',                                                                             // 21
    waitOn: function () {                                                                                             // 22
      return []                                                                                                       // 23
    },                                                                                                                // 24
    data: function () {                                                                                               // 25
      return Meteor.user();                                                                                           // 26
    }                                                                                                                 // 27
  });                                                                                                                 // 28
                                                                                                                      // 29
  this.route('userProfile', {                                                                                         // 30
    path: '/user/:_id',                                                                                               // 31
    template: 'userSettings',                                                                                         // 32
    //controller: 'requireLoginController',                                                                           // 33
    waitOn: function () {                                                                                             // 34
      //var user = Meteor.users.findOne({_id: Meteor.userId()});                                                      // 35
      return [                                                                                                        // 36
        Meteor.subscribe('users'),                                                                                    // 37
        Meteor.subscribe('bz.chats.my', Meteor.userId())                                                              // 38
      ]                                                                                                               // 39
    },                                                                                                                // 40
    data: function () {                                                                                               // 41
      return Meteor.users.findOne({_id: this.params._id});                                                            // 42
    }                                                                                                                 // 43
  });                                                                                                                 // 44
                                                                                                                      // 45
                                                                                                                      // 46
});                                                                                                                   // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/model.js                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/25/15.                                                                                       // 2
 */                                                                                                                   // 3
Meteor.startup(function(){                                                                                            // 4
  Session.set('bz.user.profileImgUploaded', '');                                                                      // 5
})                                                                                                                    // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/controller.js                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/25/15.                                                                                       // 2
 */                                                                                                                   // 3
Meteor.startup(function () {                                                                                          // 4
  Tracker.autorun(function () {                                                                                       // 5
    var img = Session.get('bz.user.profileImgUploaded');                                                              // 6
    if (img && img !== '' && Array.isArray(img)) {                                                                    // 7
      Meteor.users.update(Meteor.userId(), { $set: {'profile.image': img[0] }});                                      // 8
    }                                                                                                                 // 9
  });                                                                                                                 // 10
});                                                                                                                   // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/template.common.js                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("avatarThumbnail");                                                                              // 2
Template["avatarThumbnail"] = new Template("Template.avatarThumbnail", (function() {                                  // 3
  var view = this;                                                                                                    // 4
  return [ HTML.DIV({                                                                                                 // 5
    "class": "bz-avatar",                                                                                             // 6
    style: function() {                                                                                               // 7
      return [ "background-image: url(", Spacebars.mustache(view.lookup("getAvatarImage")), ")" ];                    // 8
    }                                                                                                                 // 9
  }), "\n    \n    ", Blaze.If(function() {                                                                           // 10
    return Spacebars.call(view.lookup("canWrite"));                                                                   // 11
  }, function() {                                                                                                     // 12
    return [ "\n        ", HTML.DIV({                                                                                 // 13
      "class": "edit-image-holder"                                                                                    // 14
    }, "\n            ", HTML.A({                                                                                     // 15
      "class": "js-edit-image-icon"                                                                                   // 16
    }, "\n              ", HTML.I({                                                                                   // 17
      "class": "fa fa-pencil"                                                                                         // 18
    }), "\n            "), "\n            ", HTML.DIV({                                                               // 19
      "class": "reveal-modal js-avatar-upload-modal",                                                                 // 20
      "data-reveal": "",                                                                                              // 21
      "aria-labelledby": "modalTitle",                                                                                // 22
      "aria-hidden": "true",                                                                                          // 23
      role: "dialog"                                                                                                  // 24
    }, "\n              ", Blaze._TemplateWith(function() {                                                           // 25
      return {                                                                                                        // 26
        sessionName: Spacebars.call("bz.user.profileImgUploaded")                                                     // 27
      };                                                                                                              // 28
    }, function() {                                                                                                   // 29
      return Spacebars.include(view.lookupTemplate("uploadImageModal"));                                              // 30
    }), "\n            "), "\n        "), "\n    " ];                                                                 // 31
  }) ];                                                                                                               // 32
}));                                                                                                                  // 33
                                                                                                                      // 34
Template.__checkName("bzUserProfileBasic");                                                                           // 35
Template["bzUserProfileBasic"] = new Template("Template.bzUserProfileBasic", (function() {                            // 36
  var view = this;                                                                                                    // 37
  return HTML.DIV({                                                                                                   // 38
    "class": "bz-user-card"                                                                                           // 39
  }, "\n      ", HTML.DIV({                                                                                           // 40
    "class": "bz-padding-10 overflow"                                                                                 // 41
  }, "\n        ", HTML.DIV({                                                                                         // 42
    "class": "bz-user-badge"                                                                                          // 43
  }, "\n            ", Blaze._TemplateWith(function() {                                                               // 44
    return {                                                                                                          // 45
      image: Spacebars.call(Spacebars.dot(view.lookup("profile"), "image"))                                           // 46
    };                                                                                                                // 47
  }, function() {                                                                                                     // 48
    return Spacebars.include(view.lookupTemplate("avatarThumbnail"));                                                 // 49
  }), "\n        "), "\n          \n        ", HTML.DIV({                                                             // 50
    "class": "bz-user-date"                                                                                           // 51
  }, "\n          ", HTML.DIV({                                                                                       // 52
    "class": "bz-user-date-status"                                                                                    // 53
  }, "\n              ", Spacebars.include(view.lookupTemplate("bzAvatarUserStatus")), "\n              ", HTML.DIV({ // 54
    "class": "bz-user-date-username"                                                                                  // 55
  }, Blaze.View("lookup:username", function() {                                                                       // 56
    return Spacebars.mustache(view.lookup("username"));                                                               // 57
  })), "\n          "), "\n          ", HTML.Raw('<!--<div class="">\n            {{#if isOnline }}\n              [[Online]]\n            {{else }}\n              [[offline]]\n            {{/if}}\n          </div>-->'), "\n          ", HTML.Raw('<!--<div class="bz-rating"></div>-->'), "\n        "), "\n        \n        ", HTML.Raw('<div class="bz-send-message">\n          <button class="js-send-message-btn bz-small">Send Message</button>\n        </div>'), "\n      "), "\n      \n  ");
}));                                                                                                                  // 59
                                                                                                                      // 60
Template.__checkName("bzUserProfileAroundYou");                                                                       // 61
Template["bzUserProfileAroundYou"] = new Template("Template.bzUserProfileAroundYou", (function() {                    // 62
  var view = this;                                                                                                    // 63
  return [ HTML.DIV({                                                                                                 // 64
    "class": "bz-status-wrapper"                                                                                      // 65
  }, "\n    ", HTML.A({                                                                                               // 66
    href: function() {                                                                                                // 67
      return [ "/user/", Spacebars.mustache(view.lookup("userId")) ];                                                 // 68
    }                                                                                                                 // 69
  }, "\n      ", HTML.DIV({                                                                                           // 70
    "class": "bz-avatar",                                                                                             // 71
    style: function() {                                                                                               // 72
      return [ "background-image: url(", Spacebars.mustache(view.lookup("_getAvatarImage")), ");" ];                  // 73
    }                                                                                                                 // 74
  }), "\n    "), "\n    ", Spacebars.include(view.lookupTemplate("bzAvatarUserStatus")), "\n  "), HTML.Raw('\n  <!--<div class="bz-rating">{{ getPostRating }}</div>-->\n  '), HTML.DIV({
    "class": "bz-username"                                                                                            // 76
  }, HTML.A({                                                                                                         // 77
    href: function() {                                                                                                // 78
      return [ "/user/", Spacebars.mustache(view.lookup("userId")) ];                                                 // 79
    }                                                                                                                 // 80
  }, Blaze.View("lookup:getNameFormatted", function() {                                                               // 81
    return Spacebars.mustache(view.lookup("getNameFormatted"));                                                       // 82
  }))) ];                                                                                                             // 83
}));                                                                                                                  // 84
                                                                                                                      // 85
Template.__checkName("bzAvatarUserStatus");                                                                           // 86
Template["bzAvatarUserStatus"] = new Template("Template.bzAvatarUserStatus", (function() {                            // 87
  var view = this;                                                                                                    // 88
  return HTML.DIV({                                                                                                   // 89
    "class": "bz-avatar-user-status"                                                                                  // 90
  }, "\n        ", HTML.DIV({                                                                                         // 91
    "class": function() {                                                                                             // 92
      return [ "bz-avatar-user-status-wrapper ", Blaze.If(function() {                                                // 93
        return Spacebars.call(view.lookup("_isOnline"));                                                              // 94
      }, function() {                                                                                                 // 95
        return " bz-online ";                                                                                         // 96
      }, function() {                                                                                                 // 97
        return " bz-offline ";                                                                                        // 98
      }) ];                                                                                                           // 99
    }                                                                                                                 // 100
  }, "\n            ", HTML.Raw('<!--{{#if _isOnline}} <i class="fa fa-check"></i> {{else}} <i class="fa fa-clock-o"></i> {{/if}}-->'), "\n        "), "\n    ");
}));                                                                                                                  // 102
                                                                                                                      // 103
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/common.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/26/15.                                                                                       // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
Template.avatarThumbnail.onCreated(function () {                                                                      // 5
});                                                                                                                   // 6
                                                                                                                      // 7
Template.bzUserProfileBasic.rendered = function () {                                                                  // 8
                                                                                                                      // 9
  /*init Rate*/                                                                                                       // 10
  $('.bz-rating').raty({                                                                                              // 11
    starType: 'i'                                                                                                     // 12
  });                                                                                                                 // 13
                                                                                                                      // 14
};                                                                                                                    // 15
                                                                                                                      // 16
Template.avatarThumbnail.helpers({                                                                                    // 17
  getAvatarImage: function (e, v) {                                                                                   // 18
    var ret = this.image && this.image.data;                                                                          // 19
    if (ret) {                                                                                                        // 20
                                                                                                                      // 21
    } else {                                                                                                          // 22
      ret = '/img/content/avatars/avatar-no.png';                                                                     // 23
      /*var user = Meteor.users.findOne(Meteor.userId()),                                                             // 24
       ret = '/img/content/avatars/avatar-no.png';                                                                    // 25
       if(user && user.profile && user.profile.image) {                                                               // 26
       ret = user.profile.image;                                                                                      // 27
       }*/                                                                                                            // 28
    }                                                                                                                 // 29
    return ret;                                                                                                       // 30
  },                                                                                                                  // 31
  canWrite: function () {                                                                                             // 32
    return this.write;                                                                                                // 33
  }                                                                                                                   // 34
})                                                                                                                    // 35
Template.avatarThumbnail.events({                                                                                     // 36
  'click .js-edit-image-icon': function () {                                                                          // 37
    $('.js-avatar-upload-modal').foundation('reveal', 'open');                                                        // 38
  }                                                                                                                   // 39
  /*'click .js-image-upload-modal': function (event, template) {                                                      // 40
                                                                                                                      // 41
   },*/                                                                                                               // 42
});                                                                                                                   // 43
Template.bzUserProfileBasic.events({                                                                                  // 44
  'click .js-send-message-btn': function (e, v) {                                                                     // 45
    /*var qs = {                                                                                                      // 46
     toUser: this._id                                                                                                 // 47
     }*/                                                                                                              // 48
    if (Meteor.userId() !== this._id) {                                                                               // 49
      var chatId = bz.buz.chats.createChatIfFirstMessage(Meteor.userId(), this._id);                                  // 50
      Router.go('/chat/' + chatId);                                                                                   // 51
    }                                                                                                                 // 52
  }                                                                                                                   // 53
})                                                                                                                    // 54
Template.bzUserProfileBasic.onRendered(function () {                                                                  // 55
  if (Meteor.userId() === this.data._id) {                                                                            // 56
    $('.js-send-message-btn').addClass('disabled');                                                                   // 57
  }                                                                                                                   // 58
});                                                                                                                   // 59
Template.bzUserProfileAroundYou.helpers({                                                                             // 60
  getNameFormatted: function () {                                                                                     // 61
    var ret = '';                                                                                                     // 62
    if (this.userId && Meteor.users.findOne(this.userId)) {                                                           // 63
      ret = Meteor.users.findOne(this.userId).username.toCapitalCase();                                               // 64
    }                                                                                                                 // 65
    return ret;                                                                                                       // 66
  },                                                                                                                  // 67
  isOnline1: function(){                                                                                              // 68
    debugger;                                                                                                         // 69
    return true;                                                                                                      // 70
  }                                                                                                                   // 71
});                                                                                                                   // 72
                                                                                                                      // 73
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/template.profile.js                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("profileSettings");                                                                              // 2
Template["profileSettings"] = new Template("Template.profileSettings", (function() {                                  // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "main-content"                                                                                           // 6
  }, "\n    ", HTML.DIV({                                                                                             // 7
    "class": "page-settings"                                                                                          // 8
  }, "\n      ", HTML.DIV({                                                                                           // 9
    "class": "profile-box"                                                                                            // 10
  }, "\n\n        ", HTML.Raw("<!--SIDE A-->"), "\n        ", HTML.DIV({                                              // 11
    "class": "side-a text-center small-12 medium-4 columns"                                                           // 12
  }, "\n          ", HTML.Raw('<div class="item item-divider">\n            <h3 class="title">User profile details</h3>\n          </div>'), "\n\n            ", HTML.DIV({
    "class": "bz-status-wrapper"                                                                                      // 14
  }, "\n                ", HTML.DIV({                                                                                 // 15
    "class": "user-avatar"                                                                                            // 16
  }, "\n                    ", Blaze._TemplateWith(function() {                                                       // 17
    return {                                                                                                          // 18
      image: Spacebars.call(Spacebars.dot(view.lookup("profile"), "image"))                                           // 19
    };                                                                                                                // 20
  }, function() {                                                                                                     // 21
    return Spacebars.include(view.lookupTemplate("avatarThumbnail"));                                                 // 22
  }), "\n                "), "\n                ", Spacebars.include(view.lookupTemplate("bzAvatarUserStatus")), "\n            "), "\n\n          ", HTML.DIV({
    "class": "user-info"                                                                                              // 24
  }, "\n            ", HTML.DIV({                                                                                     // 25
    "class": "user-name capitalize"                                                                                   // 26
  }, " ", Blaze.View("lookup:username", function() {                                                                  // 27
    return Spacebars.mustache(view.lookup("username"));                                                               // 28
  }), " "), "\n            ", HTML.Raw('<div class="user-location"> San-Francisco, CA</div>'), "\n          "), "\n\n          ", HTML.Raw('<div class="user-attainment">\n            <div class="count-posts">86<span>posts</span></div>\n            <div class="count-comments">1,1k<span>comments</span></div>\n            <div class="count-smth">666<span>something</span></div>\n          </div>'), "\n\n\n          ", HTML.DIV({
    "class": "btn-edit-account"                                                                                       // 30
  }, "\n            ", HTML.A({                                                                                       // 31
    "class": "button btn-default",                                                                                    // 32
    href: function() {                                                                                                // 33
      return Spacebars.mustache(view.lookup("pathFor"), "settings.edit");                                             // 34
    }                                                                                                                 // 35
  }, "Edit your profile"), "\n          "), "\n\n        "), "\n\n        ", HTML.Raw("<!--SIDE B-->"), "\n        ", HTML.DIV({
    "class": "side-b small-12 medium-8 large-8 columns"                                                               // 37
  }, "\n\n          ", HTML.Raw('<div class="item-divider">\n            <h3 class="title">Your personal settings</h3>\n          </div>'), "\n          ", HTML.DIV({
    "class": "user-item overflow"                                                                                     // 39
  }, "\n            ", HTML.DIV({                                                                                     // 40
    "class": "item-details"                                                                                           // 41
  }, "\n              ", HTML.Raw('<div class="small-12 medium-2 bz-input-label columns">Profile Url</div>'), "\n              ", HTML.DIV({
    "class": "small-12 medium-10 large-10 bz-input-result columns"                                                    // 43
  }, "\n                ", HTML.DIV({                                                                                 // 44
    "class": "bz-text-overflow-ellipsis"                                                                              // 45
  }, "\n                  ", HTML.P(HTML.A({                                                                          // 46
    href: function() {                                                                                                // 47
      return Spacebars.mustache(view.lookup("getIdProfile"));                                                         // 48
    }                                                                                                                 // 49
  }, Blaze.View("lookup:getIdProfile", function() {                                                                   // 50
    return Spacebars.mustache(view.lookup("getIdProfile"));                                                           // 51
  }))), "\n                "), "\n              "), "\n            "), "\n\n            ", HTML.Raw('<div class="item-details">\n              <div class="small-12 medium-2 bz-input-label columns">Phone</div>\n              <div class="small-12 medium-10 large-10 bz-input-result columns"><p> Upon request </p></div>\n            </div>'), "\n\n            ", HTML.Raw('<div class="item-details">\n              <div class="small-12 medium-2 bz-input-label columns">Skype</div>\n              <div class="small-12 medium-10 large-10 bz-input-result columns"><p> Hidden </p></div>\n            </div>'), "\n            ", HTML.DIV({
    "class": "item-details"                                                                                           // 53
  }, "\n              ", HTML.Raw('<div class="small-12 medium-2 bz-input-label columns">Status</div>'), "\n              ", HTML.DIV({
    "class": "small-12 medium-10 large-10 bz-input-result columns"                                                    // 55
  }, "\n                ", HTML.P("\n                  ", Blaze.If(function() {                                       // 56
    return Spacebars.call(view.lookup("_isOnline"));                                                                  // 57
  }, function() {                                                                                                     // 58
    return "\n                    Online\n                  ";                                                        // 59
  }, function() {                                                                                                     // 60
    return "\n                    offline\n                  ";                                                       // 61
  }), "\n                "), "\n              "), "\n            "), "\n          "), "\n\n          ", HTML.Raw('<div class="clearfix"></div>'), "\n\n          ", HTML.Raw('<div class="item item-divider">\n            <h3 class="title">Your external links</h3>\n          </div>'), "\n          ", HTML.Raw('<div class="user-item overflow">\n            <div class="item-details">\n              <div class="small-12 medium-2 bz-input-label columns">Facebook Url</div>\n              <div class="small-12 medium-10 large-10 bz-input-result columns"><p> -------\n                <!--{{ getFaceBookDetails }}--> </p></div>\n            </div>\n          </div>'), "\n\n        "), "\n\n        ", HTML.Raw('<div class="clearfix"></div>'), "\n\n      "), "\n    "), "\n\n  ");
}));                                                                                                                  // 63
                                                                                                                      // 64
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/profile.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by douson on 09.07.15.                                                                                     // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
Template.profileSettings.onCreated(function() {                                                                       // 5
                                                                                                                      // 6
                                                                                                                      // 7
});                                                                                                                   // 8
                                                                                                                      // 9
Template.profileSettings.helpers({                                                                                    // 10
    username: function () {                                                                                           // 11
        // username of logged in user                                                                                 // 12
        var user = Meteor.users.findOne({_id: Meteor.userId()});                                                      // 13
        return user && user.username;                                                                                 // 14
    },                                                                                                                // 15
    getIdProfile: function () {                                                                                       // 16
        //console.log('ID профайла пользователя ' + this._id);                                                        // 17
        return Meteor.absoluteUrl() + 'user/' + this._id;                                                             // 18
    },                                                                                                                // 19
    getIdGuestUser: function () {                                                                                     // 20
        //console.log('ID гостя ( залогиненного ) ' + Meteor.userId());                                               // 21
        return Meteor.userId();                                                                                       // 22
    },                                                                                                                // 23
    getFaceBookDetails: function () {                                                                                 // 24
    },                                                                                                                // 25
    getStatusLocation: function () {                                                                                  // 26
                                                                                                                      // 27
    }                                                                                                                 // 28
});                                                                                                                   // 29
                                                                                                                      // 30
                                                                                                                      // 31
                                                                                                                      // 32
                                                                                                                      // 33
Template.profileSettings.events({                                                                                     // 34
    'click [data-action=share-profile]': function (event, template) {                                                 // 35
        IonActionSheet.show({                                                                                         // 36
            titleText: 'Share Profile',                                                                               // 37
            buttons: [                                                                                                // 38
                { text: 'One' },                                                                                      // 39
                { text: 'Two' },                                                                                      // 40
                { text: 'Some text' }                                                                                 // 41
            ],                                                                                                        // 42
            cancelText: 'Cancel',                                                                                     // 43
            buttonClicked: function(index) {                                                                          // 44
                if (index === 0) {                                                                                    // 45
                    console.log('ONE!');                                                                              // 46
                }                                                                                                     // 47
                if (index === 1) {                                                                                    // 48
                    console.log('TWO!');                                                                              // 49
                }                                                                                                     // 50
                if (index === 2) {                                                                                    // 51
                    console.log('SOME TEXT');                                                                         // 52
                }                                                                                                     // 53
                return true;                                                                                          // 54
            }                                                                                                         // 55
        });                                                                                                           // 56
    },                                                                                                                // 57
    'click [data-action=edit-avatar]': function (event, template) {                                                   // 58
        /*IonActionSheet.show({                                                                                       // 59
              titleText: 'Edit picture',                                                                              // 60
              buttons: [                                                                                              // 61
                  { text: 'Photo Library' },                                                                          // 62
                  { text: 'Take Photo' }                                                                              // 63
              ],                                                                                                      // 64
              cancelText: 'Cancel'                                                                                    // 65
          }                                                                                                           // 66
        )*/                                                                                                           // 67
    }                                                                                                                 // 68
});                                                                                                                   // 69
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/template.user-settings.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("userSettings");                                                                                 // 2
Template["userSettings"] = new Template("Template.userSettings", (function() {                                        // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "main-content"                                                                                           // 6
  }, "\n    ", HTML.DIV({                                                                                             // 7
    "class": "page-settings"                                                                                          // 8
  }, "\n      ", HTML.DIV({                                                                                           // 9
    "class": "profile-box"                                                                                            // 10
  }, "\n\n\n        ", HTML.Raw("<!--SIDE A-->"), "\n        ", HTML.DIV({                                            // 11
    "class": "side-a text-center small-12 medium-4 columns"                                                           // 12
  }, "\n          ", HTML.Raw('<div class="item item-divider">\n            <h3 class="title">User profile details</h3>\n          </div>'), "\n\n           ", HTML.DIV({
    "class": "bz-status-wrapper"                                                                                      // 14
  }, "\n               ", HTML.DIV({                                                                                  // 15
    "class": "user-avatar"                                                                                            // 16
  }, "\n                   ", Blaze._TemplateWith(function() {                                                        // 17
    return {                                                                                                          // 18
      image: Spacebars.call(Spacebars.dot(view.lookup("profile"), "image"))                                           // 19
    };                                                                                                                // 20
  }, function() {                                                                                                     // 21
    return Spacebars.include(view.lookupTemplate("avatarThumbnail"));                                                 // 22
  }), "\n               "), "\n               ", Spacebars.include(view.lookupTemplate("bzAvatarUserStatus")), "\n           "), "\n\n          ", HTML.DIV({
    "class": "user-info"                                                                                              // 24
  }, "\n            ", HTML.DIV({                                                                                     // 25
    "class": "user-name capitalize"                                                                                   // 26
  }, " ", Blaze.View("lookup:username", function() {                                                                  // 27
    return Spacebars.mustache(view.lookup("username"));                                                               // 28
  }), " "), "\n            ", HTML.Raw('<div class="user-location"> San-Francisco, CA</div>'), "\n          "), "\n\n\n          ", HTML.Raw('<div class="btn-edit-account">\n            <button class="button btn-default js-send-message-btn">Send Message</button>\n          </div>'), "\n\n        "), "\n\n        ", HTML.Raw("<!--SIDE B-->"), "\n        ", HTML.DIV({
    "class": "side-b small-12 medium-8 large-8 columns"                                                               // 30
  }, "\n\n          ", HTML.Raw('<div class="item-divider">\n            <h3 class="title">Your personal settings</h3>\n          </div>'), "\n          ", HTML.DIV({
    "class": "user-item overflow"                                                                                     // 32
  }, "\n            ", HTML.DIV({                                                                                     // 33
    "class": "item-details"                                                                                           // 34
  }, "\n              ", HTML.Raw('<div class="small-12 medium-2 bz-input-label columns">Profile Url</div>'), "\n              ", HTML.DIV({
    "class": "small-12 medium-10 large-10 bz-input-result columns"                                                    // 36
  }, "\n                ", HTML.DIV({                                                                                 // 37
    "class": "bz-text-overflow-ellipsis"                                                                              // 38
  }, "\n                  ", HTML.P(HTML.A({                                                                          // 39
    href: function() {                                                                                                // 40
      return Spacebars.mustache(view.lookup("getIdProfile"));                                                         // 41
    }                                                                                                                 // 42
  }, Blaze.View("lookup:getIdProfile", function() {                                                                   // 43
    return Spacebars.mustache(view.lookup("getIdProfile"));                                                           // 44
  }))), "\n                "), "\n              "), "\n            "), "\n\n            ", HTML.Raw('<div class="item-details">\n              <div class="small-12 medium-2 bz-input-label columns">Phone</div>\n              <div class="small-12 medium-10 large-10 bz-input-result columns"><p> +1 (800) 123-456 </p></div>\n            </div>'), "\n\n            ", HTML.Raw('<div class="item-details">\n              <div class="small-12 medium-2 bz-input-label columns">Skype</div>\n              <div class="small-12 medium-10 large-10 bz-input-result columns"><p> Underground87 </p></div>\n            </div>'), "\n            ", HTML.DIV({
    "class": "item-details"                                                                                           // 46
  }, "\n              ", HTML.Raw('<div class="small-12 medium-2 bz-input-label columns">Status</div>'), "\n              ", HTML.DIV({
    "class": "small-12 medium-10 large-10 bz-input-result columns"                                                    // 48
  }, "\n                ", HTML.P("\n                  ", Blaze.If(function() {                                       // 49
    return Spacebars.call(view.lookup("_isOnline"));                                                                  // 50
  }, function() {                                                                                                     // 51
    return "\n                    Online\n                  ";                                                        // 52
  }, function() {                                                                                                     // 53
    return "\n                    offline\n                  ";                                                       // 54
  }), "\n                "), "\n              "), "\n            "), "\n          "), "\n\n          ", HTML.Raw('<div class="clearfix"></div>'), "\n\n          ", HTML.Raw('<div class="item item-divider">\n            <h3 class="title">Your external links</h3>\n          </div>'), "\n          ", HTML.Raw('<div class="user-item overflow">\n            <div class="item-details">\n              <div class="small-12 medium-2 bz-input-label columns">Facebook Url</div>\n              <div class="small-12 medium-10 large-10 bz-input-result columns"><p> Upon request\n                <!--{{ getFaceBookDetails }}--> </p></div>\n            </div>\n          </div>'), "\n\n        "), "\n\n        ", HTML.Raw('<div class="clearfix"></div>'), "\n        ", HTML.Raw('<div class="bz-separate"></div>'), "\n\n        ", HTML.Raw('<div style="display: none">ТУТ МОГУТ БЫТЬ ОТЗЫВЫ или ДРУГАЯ ВАЖНАЯ ИНФОРМАЦИЯ КОТОРАЯ ВАЖНА ПРОСМАТРИВАЮЩИМ ПРОФИЛЬ</div>'), "\n        ", HTML.Raw('<p style="display: none">Скажем, тут могут находится другие posts пользователя</p>'), "\n\n\n      "), "\n    "), "\n  ");
}));                                                                                                                  // 56
                                                                                                                      // 57
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/user-settings.js                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by douson on 09.07.15.                                                                                     // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
Template.userSettings.onCreated(function () {                                                                         // 5
});                                                                                                                   // 6
Template.userSettings.onRendered(function () {                                                                        // 7
  if(Meteor.userId() === this.data._id) {                                                                             // 8
    $('.js-send-message-btn').addClass('disabled');                                                                   // 9
  }                                                                                                                   // 10
});                                                                                                                   // 11
                                                                                                                      // 12
Template.userSettings.helpers({                                                                                       // 13
  userName: function () {                                                                                             // 14
    // username of logged in user                                                                                     // 15
    return this.username;                                                                                             // 16
  },                                                                                                                  // 17
  getIdProfile: function () {                                                                                         // 18
    //console.log('ID профайла пользователя ' + this._id);                                                            // 19
    return Meteor.absoluteUrl() + 'user/' + this._id;                                                                 // 20
  },                                                                                                                  // 21
/*  getIdGuestUser: function () {                                                                                     // 22
    //console.log('ID гостя ( залогиненного ) ' + Meteor.userId());                                                   // 23
    return Meteor.userId();                                                                                           // 24
  },*/                                                                                                                // 25
  getFaceBookDetails: function () {                                                                                   // 26
    return 'N/A';                                                                                                     // 27
  },                                                                                                                  // 28
  getStatusLocation: function () {                                                                                    // 29
  }                                                                                                                   // 30
});                                                                                                                   // 31
                                                                                                                      // 32
                                                                                                                      // 33
Template.userSettings.events({                                                                                        // 34
  'click [data-action=share-profile]': function (event, template) {                                                   // 35
  },                                                                                                                  // 36
  'click [data-action=edit-avatar]': function (event, template) {                                                     // 37
    /*IonActionSheet.show({                                                                                           // 38
          titleText: 'Edit picture',                                                                                  // 39
          buttons: [                                                                                                  // 40
            {text: 'Photo Library'},                                                                                  // 41
            {text: 'Take Photo'}                                                                                      // 42
          ],                                                                                                          // 43
          cancelText: 'Cancel'                                                                                        // 44
        }                                                                                                             // 45
    )*/                                                                                                               // 46
  },                                                                                                                  // 47
  'click .js-send-message-btn': function(e,v){                                                                        // 48
    /*var qs = {                                                                                                      // 49
      toUser: this._id                                                                                                // 50
    }*/                                                                                                               // 51
    //debugger;                                                                                                       // 52
    if(Meteor.userId() !== this._id) {                                                                                // 53
      var chatId = bz.buz.chats.createChatIfFirstMessage(Meteor.userId(), this._id);                                  // 54
      Router.go('/chat/' + chatId);                                                                                   // 55
    }                                                                                                                 // 56
  }                                                                                                                   // 57
});                                                                                                                   // 58
                                                                                                                      // 59
                                                                                                                      // 60
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/template.profile-edit.js                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("userEdit");                                                                                     // 2
Template["userEdit"] = new Template("Template.userEdit", (function() {                                                // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "main-content"                                                                                           // 6
  }, "\n                \n                ", HTML.DIV({                                                               // 7
    "class": "page-settings"                                                                                          // 8
  }, "\n                ", HTML.DIV({                                                                                 // 9
    "class": "profile-box"                                                                                            // 10
  }, "\n\n\n                    ", HTML.Raw("<!--SIDE A-->"), "\n                    ", HTML.DIV({                    // 11
    "class": "side-a text-center small-12 medium-4 columns"                                                           // 12
  }, "\n                        ", HTML.Raw('<div class="item item-divider">\n                            <h3 class="title">Edit user avatar</h3>\n                        </div>'), "\n\n                        ", HTML.DIV({
    "class": "user-avatar"                                                                                            // 14
  }, "\n                            ", Blaze._TemplateWith(function() {                                               // 15
    return {                                                                                                          // 16
      write: Spacebars.call(true),                                                                                    // 17
      image: Spacebars.call(Spacebars.dot(view.lookup("profile"), "image"))                                           // 18
    };                                                                                                                // 19
  }, function() {                                                                                                     // 20
    return Spacebars.include(view.lookupTemplate("avatarThumbnail"));                                                 // 21
  }), "\n                        "), "\n\n                        ", HTML.Raw('<div class="user-item overflow">\n                            <div class="item-details bz-user-status-width">\n                                <!--<div class="small-12 bz-input-label columns">Your status</div>-->\n                                <div class="small-12 bz-input-result columns">\n                                    <select id="bz-user-status">\n                                        <option value="online">Online</option>\n                                        <option value="offline">Offline</option>\n                                        <option value="invisible">Invisible</option>\n                                    </select>\n                                </div>\n                            </div>\n                        </div>'), "\n\n                        ", HTML.Raw('<div class="btn-edit-account">\n                            <button class="button btn-default js-done-btn">Save &amp; Update</button>\n                        </div>'), "\n\n                    "), "\n\n                    ", HTML.Raw("<!--SIDE B-->"), "\n                    ", HTML.DIV({
    "class": "side-b small-12 medium-8 large-8 columns"                                                               // 23
  }, "\n\n                        ", HTML.Raw('<div class="item-divider">\n                            <h3 class="title">Edit your personal settings</h3>\n                        </div>'), "\n                        ", HTML.DIV({
    "class": "user-item overflow"                                                                                     // 25
  }, "\n                            ", HTML.DIV({                                                                     // 26
    "class": "item-details"                                                                                           // 27
  }, "\n                                ", HTML.Raw('<div class="small-12 medium-2 bz-input-label columns">Username</div>'), "\n                                ", HTML.DIV({
    "class": "small-12 medium-10 large-10 bz-input-result columns"                                                    // 29
  }, "\n                                    ", HTML.DIV({                                                             // 30
    "class": "bz-text-overflow-ellipsis"                                                                              // 31
  }, HTML.P(" ", Blaze.View("lookup:username", function() {                                                           // 32
    return Spacebars.mustache(view.lookup("username"));                                                               // 33
  }), " ")), "\n                                "), "\n                            "), "\n\n                            ", HTML.DIV({
    "class": "item-details"                                                                                           // 35
  }, "\n                                ", HTML.Raw('<div class="small-12 medium-2 bz-input-label columns">First name</div>'), "\n                                ", HTML.DIV({
    "class": "small-12 medium-10 large-10 bz-input-result columns"                                                    // 37
  }, "\n                                    ", HTML.INPUT({                                                           // 38
    "class": "bz-first-name",                                                                                         // 39
    autocomplete: "off",                                                                                              // 40
    type: "text",                                                                                                     // 41
    value: function() {                                                                                               // 42
      return Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "firstName"));                                  // 43
    }                                                                                                                 // 44
  }), "\n                                "), "\n                            "), "\n\n                            ", HTML.DIV({
    "class": "item-details"                                                                                           // 46
  }, "\n                                ", HTML.Raw('<div class="small-12 medium-2 bz-input-label columns">Last name</div>'), "\n                                ", HTML.DIV({
    "class": "small-12 medium-10 large-10 bz-input-result columns"                                                    // 48
  }, "\n                                    ", HTML.INPUT({                                                           // 49
    "class": "bz-last-name",                                                                                          // 50
    autocomplete: "off",                                                                                              // 51
    type: "text",                                                                                                     // 52
    value: function() {                                                                                               // 53
      return Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "lastName"));                                   // 54
    }                                                                                                                 // 55
  }), "\n                                "), "\n                            "), "\n\n                            ", HTML.Raw('<div class="bz-separate"></div>'), "\n\n                            ", HTML.Raw('<div class="item-details">\n                                <div class="small-12 medium-6 large-6 bz-input-label columns">\n                                    <div class="small-12 bz-input-label columns">Phone number</div>\n                                    <div class="small-12 bz-input-result columns">\n                                        <input class="bz-phone-number" autocomplete="off" type="text">\n                                    </div>\n                                </div>\n                                <div class="small-12 medium-6 large-6 bz-input-label columns">\n                                    <div class="small-12 bz-input-label columns">Security settings</div>\n                                    <div class="small-12 bz-input-result columns">\n                                        <select id="phone-status">\n                                            <option value="">Public</option>\n                                            <option value="">Upon request</option>\n                                            <option value="">Hide</option>\n                                        </select>\n                                    </div>\n                                </div>\n                            </div>'), "\n\n                            ", HTML.Raw('<div class="item-details">\n                                <div class="small-12 medium-6 large-6 bz-input-label columns">\n                                    <div class="small-12 bz-input-label columns">Skype username</div>\n                                    <div class="small-12 bz-input-result columns">\n                                        <input class="bz-skype-account" autocomplete="off" type="text">\n                                    </div>\n                                </div>\n                                <div class="small-12 medium-6 large-6 bz-input-label columns">\n                                    <div class="small-12 bz-input-label columns">Security settings</div>\n                                    <div class="small-12 bz-input-result columns">\n                                        <select id="bz-skype-status">\n                                            <option value="">Public</option>\n                                            <option value="">Upon request</option>\n                                            <option value="">Hide</option>\n                                        </select>\n                                    </div>\n                                </div>\n                            </div>'), "\n                            \n                            \n                        \n                        "), "\n                        \n                        ", HTML.Raw('<div class="clearfix"></div>'), "\n                        \n\n                        ", HTML.Raw('<div class="item item-divider">\n                            <h3 class="title">Your external links</h3>\n                        </div>'), "\n                        ", HTML.Raw('<div class="user-item overflow">\n                            <div class="item-details">\n                                <div class="small-12 medium-2 bz-input-label columns">Facebook Url</div>\n                                <div class="small-12 medium-10 large-10 bz-input-result columns">\n                                    <select id="fb-status">\n                                        <option value="" selected="selected">Public</option>\n                                        <option value="">Upon request</option>\n                                        <option value="">Hide</option>\n                                    </select>\n                                </div>\n                            </div>\n                        </div>'), "\n\n                    "), "\n\n                    ", HTML.Raw('<div class="clearfix"></div>'), "\n                    \n                    \n                    ", HTML.Raw("<!--***-->"), "\n                    \n                "), "\n              "), "\n\n            ");
}));                                                                                                                  // 57
                                                                                                                      // 58
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-user/client/browser/profile-edit.js                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by douson on 29.07.15.                                                                                     // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
Template.userEdit.onCreated(function () {                                                                             // 5
  return Meteor.subscribe('users', Router.current().params._id);                                                      // 6
});                                                                                                                   // 7
                                                                                                                      // 8
Template.userEdit.events({                                                                                            // 9
  'click .js-done-btn': function(e, v){                                                                               // 10
    var r = Router.routes['myProfile'];                                                                               // 11
    Router.go(r.url());                                                                                               // 12
  }                                                                                                                   // 13
})                                                                                                                    // 14
Template.userEdit.helpers({                                                                                           // 15
  contact: function () {                                                                                              // 16
    return Meteor.users.findOne({_id: Router.current().params._id});                                                  // 17
  }                                                                                                                   // 18
});                                                                                                                   // 19
                                                                                                                      // 20
Schema = {};                                                                                                          // 21
                                                                                                                      // 22
Template.registerHelper("Schema", Schema);                                                                            // 23
                                                                                                                      // 24
Schema.UserProfile = new SimpleSchema({                                                                               // 25
                                                                                                                      // 26
  firstName: {                                                                                                        // 27
    type: String,                                                                                                     // 28
    regEx: /^[a-zA-Z-]{2,25}$/,                                                                                       // 29
    optional: true                                                                                                    // 30
  },                                                                                                                  // 31
  lastName: {                                                                                                         // 32
    type: String,                                                                                                     // 33
    regEx: /^[a-zA-Z]{2,25}$/,                                                                                        // 34
    optional: true                                                                                                    // 35
  },                                                                                                                  // 36
  birthday: {                                                                                                         // 37
    type: Date,                                                                                                       // 38
    optional: true                                                                                                    // 39
  },                                                                                                                  // 40
  gender: {                                                                                                           // 41
    type: String,                                                                                                     // 42
    allowedValues: ['Male', 'Female'],                                                                                // 43
    optional: true                                                                                                    // 44
  },                                                                                                                  // 45
  website: {                                                                                                          // 46
    type: String,                                                                                                     // 47
    regEx: SimpleSchema.RegEx.Url,                                                                                    // 48
    optional: true                                                                                                    // 49
  },                                                                                                                  // 50
  feeling: {                                                                                                          // 51
    type: String,                                                                                                     // 52
    optional: true,                                                                                                   // 53
    autoform: {                                                                                                       // 54
      afFieldInput: {                                                                                                 // 55
        type: "textarea",                                                                                             // 56
        rows: 2                                                                                                       // 57
      }                                                                                                               // 58
    }                                                                                                                 // 59
  }                                                                                                                   // 60
});                                                                                                                   // 61
                                                                                                                      // 62
Schema.User = new SimpleSchema({                                                                                      // 63
  username: {                                                                                                         // 64
    type: String,                                                                                                     // 65
    regEx: /^[a-z0-9A-Z_]{3,15}$/                                                                                     // 66
  },                                                                                                                  // 67
  _id: {                                                                                                              // 68
    type: String,                                                                                                     // 69
    regEx: SimpleSchema.RegEx.Id                                                                                      // 70
  },                                                                                                                  // 71
  email: {                                                                                                            // 72
    type: String,                                                                                                     // 73
    regEx: SimpleSchema.RegEx.Email                                                                                   // 74
  },                                                                                                                  // 75
  createdAt: {                                                                                                        // 76
    type: Date                                                                                                        // 77
  },                                                                                                                  // 78
  profile: {                                                                                                          // 79
    type: Schema.UserProfile                                                                                          // 80
  },                                                                                                                  // 81
  services: {                                                                                                         // 82
    type: Object,                                                                                                     // 83
    optional: true,                                                                                                   // 84
    blackbox: false                                                                                                   // 85
  },                                                                                                                  // 86
  profilePic: {                                                                                                       // 87
    type: String,                                                                                                     // 88
    label: 'Your photo',                                                                                              // 89
    autoform: {                                                                                                       // 90
      afFieldInput: {                                                                                                 // 91
        type: 'fileUpload',                                                                                           // 92
        collection: 'Images',                                                                                         // 93
        label: 'Choose file'                                                                                          // 94
      }                                                                                                               // 95
    }                                                                                                                 // 96
  }                                                                                                                   // 97
});                                                                                                                   // 98
                                                                                                                      // 99
Meteor.users.attachSchema(Schema.User);                                                                               // 100
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
