(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/arutune:bz-page-user/collections/users.shared.js                     //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/**                                                                              // 1
 * Created by arutu_000 on 10/20/2015.                                           // 2
 * // for references see this :                                                  // 3
 * see meteor add dburles:collection-helpers                                     // 4
 * https://atmospherejs.com/dburles/collection-helpers                           // 5
 *                                                                               // 6
 */                                                                              // 7
                                                                                 // 8
var usersCol = Meteor.users;                                                     // 9
usersCol.helpers({                                                               // 10
  _isOnline: function () {                                                       // 11
    var ret;                                                                     // 12
    if(this.online){                                                             // 13
      ret = this.online;                                                         // 14
    }                                                                            // 15
    return ret;                                                                  // 16
  },                                                                             // 17
  _getAvatarImage: function (userId) {                                           // 18
    var ret;                                                                     // 19
    if (this.profile && this.profile.image) {                                    // 20
      ret = this.profile.image.data;                                             // 21
    }                                                                            // 22
    return ret;                                                                  // 23
  }                                                                              // 24
});                                                                              // 25
                                                                                 // 26
                                                                                 // 27
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/arutune:bz-page-user/client/router.js                                //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/**                                                                              // 1
 * Created by Ashot on 9/18/15.                                                  // 2
 */                                                                              // 3
Router.map(function () {                                                         // 4
  this.route('myProfile', {                                                      // 5
    path: 'profile',                                                             // 6
    template: 'profileSettings',                                                 // 7
    controller: 'requireLoginController',                                        // 8
    waitOn: function () {                                                        // 9
      return [                                                                   // 10
        Meteor.subscribe('users')                                                // 11
      ]                                                                          // 12
    },                                                                           // 13
    data: function () {                                                          // 14
      return Meteor.user();                                                      // 15
    }                                                                            // 16
  });                                                                            // 17
  this.route('settings.edit', {                                                  // 18
    path: '/profile/edit',                                                       // 19
    template: 'userEdit',                                                        // 20
    controller: 'requireLoginController',                                        // 21
    waitOn: function () {                                                        // 22
      return []                                                                  // 23
    },                                                                           // 24
    data: function () {                                                          // 25
      return Meteor.user();                                                      // 26
    }                                                                            // 27
  });                                                                            // 28
                                                                                 // 29
  this.route('userProfile', {                                                    // 30
    path: '/user/:_id',                                                          // 31
    template: 'userSettings',                                                    // 32
    //controller: 'requireLoginController',                                      // 33
    waitOn: function () {                                                        // 34
      //var user = Meteor.users.findOne({_id: Meteor.userId()});                 // 35
      return [                                                                   // 36
        Meteor.subscribe('users'),                                               // 37
        Meteor.subscribe('bz.chats.my', Meteor.userId())                         // 38
      ]                                                                          // 39
    },                                                                           // 40
    data: function () {                                                          // 41
      return Meteor.users.findOne({_id: this.params._id});                       // 42
    }                                                                            // 43
  });                                                                            // 44
                                                                                 // 45
                                                                                 // 46
});                                                                              // 47
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/arutune:bz-page-user/client/model.js                                 //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/**                                                                              // 1
 * Created by Ashot on 9/25/15.                                                  // 2
 */                                                                              // 3
Meteor.startup(function(){                                                       // 4
  Session.set('bz.user.profileImgUploaded', '');                                 // 5
})                                                                               // 6
///////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/arutune:bz-page-user/client/controller.js                            //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/**                                                                              // 1
 * Created by Ashot on 9/25/15.                                                  // 2
 */                                                                              // 3
Meteor.startup(function () {                                                     // 4
  Tracker.autorun(function () {                                                  // 5
    var img = Session.get('bz.user.profileImgUploaded');                         // 6
    if (img && img !== '' && Array.isArray(img)) {                               // 7
      Meteor.users.update(Meteor.userId(), { $set: {'profile.image': img[0] }}); // 8
    }                                                                            // 9
  });                                                                            // 10
});                                                                              // 11
///////////////////////////////////////////////////////////////////////////////////

}).call(this);
