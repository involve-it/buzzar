(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/collections/posts.shared.js                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by yvdorofeev on 10/20/15.                                                                                // 2
 */                                                                                                                  // 3
bz.cols.posts = new Mongo.Collection('posts');                                                                       // 4
                                                                                                                     // 5
var postsColl = bz.cols.posts;                                                                                       // 6
                                                                                                                     // 7
postsColl.helpers({                                                                                                  // 8
  _hasLivePresence: bz.help.posts.hasLivePresence                                                                    // 9
});                                                                                                                  // 10
                                                                                                                     // 11
                                                                                                                     // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/router.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by douson on 03.07.15.                                                                                    // 2
 */                                                                                                                  // 3
var requireLoginController = bz.router.requireLoginController;                                                       // 4
// POSTS:                                                                                                            // 5
Router.map(function () {                                                                                             // 6
  this.route('posts', {                                                                                              // 7
    path: '/posts',                                                                                                  // 8
    controller: 'requireLoginController',                                                                            // 9
    onBeforeAction: function () {                                                                                    // 10
      Router.go('/posts/my');                                                                                        // 11
    }                                                                                                                // 12
                                                                                                                     // 13
  });                                                                                                                // 14
  this.route('posts.details', {                                                                                      // 15
    path: '/post/:_id',                                                                                              // 16
    template: 'postsPageDetails',                                                                                    // 17
    data: function () {                                                                                              // 18
      var ret;                                                                                                       // 19
      ret = bz.cols.posts.findOne({_id: this.params._id});                                                           // 20
      return ret;                                                                                                    // 21
    },                                                                                                               // 22
    //controller: 'requireLoginController',                                                                          // 23
    onAfterAction: function () {                                                                                     // 24
      var post = this.data();                                                                                        // 25
      post && runHitTracking(post);                                                                                  // 26
      console.log('onAfterAction' + this.data());                                                                    // 27
    },                                                                                                               // 28
    onBeforeAction: function () {                                                                                    // 29
      if (!this.data()) {                                                                                            // 30
        Router.go('/page-not-found');                                                                                // 31
      }                                                                                                              // 32
      this.next();                                                                                                   // 33
    }                                                                                                                // 34
  });                                                                                                                // 35
                                                                                                                     // 36
  this.route('postsMy', {                                                                                            // 37
    path: '/posts/my',                                                                                               // 38
    layoutTemplate: 'mainLayout',                                                                                    // 39
    controller: 'requireLoginController'                                                                             // 40
  });                                                                                                                // 41
                                                                                                                     // 42
  // create post flow:                                                                                               // 43
  this.route('postsNew', {                                                                                           // 44
    path: '/posts/new',                                                                                              // 45
    controller: 'requireLoginController',                                                                            // 46
    waitOn: function () {                                                                                            // 47
      return [                                                                                                       // 48
        bz.help.maps.googleMapsLoad()                                                                                // 49
      ]                                                                                                              // 50
    }                                                                                                                // 51
    /*data: function () {                                                                                            // 52
     return Meteor.users.findOne({_id: this.params._id});                                                            // 53
     }*/                                                                                                             // 54
  });                                                                                                                // 55
  this.route('postsNewShare', {                                                                                      // 56
    path: '/posts/new/share',                                                                                        // 57
    template: 'newPostPageShare',                                                                                    // 58
    controller: 'requireLoginController',                                                                            // 59
    waitOn: function () {                                                                                            // 60
      return []                                                                                                      // 61
    }                                                                                                                // 62
  });                                                                                                                // 63
});                                                                                                                  // 64
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/controller.js                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by Ashot on 9/19/15.                                                                                      // 2
 */                                                                                                                  // 3
bz.help.makeNamespace('bz.runtime.newPost.location');                                                                // 4
                                                                                                                     // 5
createNewPostFromView = function (v) {                                                                               // 6
  var userId = Meteor.userId(), imgId, imgArr = [], locationsArr = [],                                               // 7
    locDef = $.Deferred(),                                                                                           // 8
    loc1 = Session.get(bz.const.posts.location1),                                                                    // 9
    loc2 = Session.get(bz.const.posts.location2),                                                                    // 10
                                                                                                                     // 11
    rad = $('.js-radius-slider').attr('data-slider') && Number.parseInt($('.js-radius-slider').attr('data-slider')), // 12
    otherKeyValuePairs = [], timestamp;                                                                              // 13
                                                                                                                     // 14
  // gather all data and submit for post-create:                                                                     // 15
  if (userId) {                                                                                                      // 16
    if (Session.get('bz.posts.postImgArr')) {                                                                        // 17
      //if (bz.runtime.newPost.postImage) {                                                                          // 18
      _.each(Session.get('bz.posts.postImgArr'), function (img) {                                                    // 19
        img = img || {};                                                                                             // 20
        imgId = bz.cols.images.insert({                                                                              // 21
          data: img.data,                                                                                            // 22
          userId: userId                                                                                             // 23
        });                                                                                                          // 24
        imgArr.push(imgId);                                                                                          // 25
      });                                                                                                            // 26
    }                                                                                                                // 27
    // set location:                                                                                                 // 28
    //if (bz.runtime.newPost.location && bz.runtime.newPost.location.current) {                                      // 29
    if (loc1 && location1.isSet) {                                                                                   // 30
      // bz.help.maps.getCurrentLocation(function (loc) {                                                            // 31
      locationsArr.push(loc1);                                                                                       // 32
      //locDef.resolve();                                                                                            // 33
      //});                                                                                                          // 34
    }                                                                                                                // 35
    if (loc2 && location2.isSet) {                                                                                   // 36
      locationsArr.push(loc2);                                                                                       // 37
      //locDef.resolve();                                                                                            // 38
    }                                                                                                                // 39
    // set the 'other' field, that contains: all other post-specific key-value pairs of info that we want:           // 40
    if (v.$('.js-charity-type-select').val()) {                                                                      // 41
      otherKeyValuePairs.push({                                                                                      // 42
        key: 'whatHappened',                                                                                         // 43
        value: v.$('.js-charity-type-select').val()                                                                  // 44
      });                                                                                                            // 45
    }                                                                                                                // 46
    // created timestamp:                                                                                            // 47
    timestamp = Date.now();                                                                                          // 48
    var newPost = {                                                                                                  // 49
                                                                                                                     // 50
      userId: userId,                                                                                                // 51
      type: v.$('.js-post-type-select').val(),                                                                       // 52
      details: {                                                                                                     // 53
                                                                                                                     // 54
        hashes: bz.runtime.newPost.hashes,                                                                           // 55
        //location: bz.runtime.newPost.location,                                                                     // 56
        locations: locationsArr,                                                                                     // 57
        radius: rad,                                                                                                 // 58
        url: v.$('.js-original-url').val(),                                                                          // 59
                                                                                                                     // 60
        //details:                                                                                                   // 61
        title: v.$('.js-post-title').val(),                                                                          // 62
        description: v.$('.js-post-description').val(),                                                              // 63
        price: v.$('.js-post-price').val(),                                                                          // 64
        photos: imgArr,                                                                                              // 65
                                                                                                                     // 66
        // specific:                                                                                                 // 67
        other: otherKeyValuePairs                                                                                    // 68
      },                                                                                                             // 69
      status: {                                                                                                      // 70
        visible: bz.const.posts.status.visibility.VISIBLE                                                            // 71
      },                                                                                                             // 72
      timestamp: timestamp                                                                                           // 73
    };                                                                                                               // 74
                                                                                                                     // 75
    var currentLoc = Session.get('currentLocation');                                                                 // 76
    if (currentLoc){                                                                                                 // 77
      currentLoc = {                                                                                                 // 78
        lat: currentLoc.latitude,                                                                                    // 79
        lng: currentLoc.longitude                                                                                    // 80
      };                                                                                                             // 81
    } else {                                                                                                         // 82
      currentLoc = Session.get('bz.control.search.location');                                                        // 83
      if (currentLoc){                                                                                               // 84
        currentLoc = currentLoc.coords;                                                                              // 85
      }                                                                                                              // 86
    }                                                                                                                // 87
                                                                                                                     // 88
    //$.when(locDef).then(function () {                                                                              // 89
    Meteor.call('addNewPost', newPost, currentLoc, Meteor.connection._lastSessionId, function (err, res) {           // 90
      if (!err && res && res !== '') {                                                                               // 91
        clearPostData();                                                                                             // 92
        bz.runtime.newPost.postId = res;                                                                             // 93
        Router.go('/posts/my');                                                                                      // 94
      }                                                                                                              // 95
    });                                                                                                              // 96
  }                                                                                                                  // 97
};                                                                                                                   // 98
movingLocationPanelClick = function () {                                                                             // 99
  var chosenLocation = Session.get(location1.sessionName);                                                           // 100
  if (!chosenLocation) {                                                                                             // 101
    // nothing is set as a location, need to set it, for this show user location-choose control:                     // 102
    //$('.js-location-holder a').click();                                                                            // 103
    bz.help.maps.getCurrentLocation(function (loc) {                                                                 // 104
      /*var chosenLocation = Session.get('bz.posts.new.location1');                                                  // 105
       var name = 'current';                                                                                         // 106
       var existLoc = bz.cols.locations.findOne({name: name, userId: Meteor.userId()});                              // 107
       if (existLoc) {                                                                                               // 108
       bz.cols.locations.remove(existLoc._id);                                                                       // 109
       }                                                                                                             // 110
       bz.cols.locations.insert({                                                                                    // 111
       userId: Meteor.userId(),                                                                                      // 112
       name: 'current',                                                                                              // 113
       coords: loc                                                                                                   // 114
       });*/                                                                                                         // 115
                                                                                                                     // 116
      Meteor.call('setUserCurrentLocation', Meteor.userId(), loc, function (err, resLocation) {                      // 117
        location1.setLocation(resLocation);                                                                          // 118
      });                                                                                                            // 119
      /*locationsArr.push({                                                                                          // 120
       coords: loc,                                                                                                  // 121
       type: bz.const.locations.type.STATIC                                                                          // 122
       });                                                                                                           // 123
       locDef.resolve();*/                                                                                           // 124
    });                                                                                                              // 125
    //Template.bzLocationNameNewPost.showModal();                                                                    // 126
  }                                                                                                                  // 127
};                                                                                                                   // 128
staticLocationPanelClick = function () {                                                                             // 129
  var chosenLocation = Session.get(location2.sessionName);                                                           // 130
  if (!chosenLocation) {                                                                                             // 131
    // nothing is set as a location, need to set it, for this show user location-choose control:                     // 132
    //$('.js-location-holder a').click();                                                                            // 133
    Template.bzLocationNameNewPost.showModal();                                                                      // 134
  }                                                                                                                  // 135
};                                                                                                                   // 136
userSeenAll;                                                                                                         // 137
// this function calculates browser-specific hits                                                                    // 138
runHitTracking = function (post, browserInfo) {                                                                      // 139
  var userSeenTotal, userSeenToday, seenTotalPost, seenTodayPost;                                                    // 140
  userSeenTotal = Cookie.get('bz.posts.seenTotal.postId.' + post._id)                                                // 141
  if (!userSeenTotal) {                                                                                              // 142
    seenTotalPost = post.stats && post.stats.seenTotal || 0;                                                         // 143
    bz.cols.posts.update(post._id, {$set: {'stats.seenTotal': ++seenTotalPost }});                                   // 144
    //setCookie('bz.posts.seenTotal.postId.' + post._id, true);                                                      // 145
    Cookie.set('bz.posts.seenTotal.postId.' + post._id, true);                                                       // 146
    userSeenTotal = undefined;                                                                                       // 147
  } else {                                                                                                           // 148
    // user seen this already, do nothing!                                                                           // 149
  }                                                                                                                  // 150
  // set total unique today:                                                                                         // 151
  userSeenToday = Cookie.get('bz.posts.seenToday.postId.' + post._id);                                               // 152
  if (!userSeenToday) {                                                                                              // 153
    seenTodayPost = post.stats && post.stats.seenToday || 0;                                                         // 154
    bz.cols.posts.update(post._id, {$set: {'stats.seenToday': ++seenTodayPost }});                                   // 155
    Cookie.set('bz.posts.seenToday.postId.' + post._id, true, { days: 1 });                                          // 156
    userSeenToday = undefined;                                                                                       // 157
  } else {                                                                                                           // 158
    // user seen this already, do nothing!                                                                           // 159
  }                                                                                                                  // 160
  // set total loads (non-unique):                                                                                   // 161
  if(!userSeenAll) { // need to run only on-time on full load                                                        // 162
    userSeenAll = !userSeenAll && post.stats && post.stats.seenAll || 0;                                             // 163
    bz.cols.posts.update(post._id, {$set: {'stats.seenAll': ++userSeenAll}});                                        // 164
  }                                                                                                                  // 165
};                                                                                                                   // 166
                                                                                                                     // 167
//HELPERS:                                                                                                           // 168
function clearPostData() {                                                                                           // 169
                                                                                                                     // 170
}                                                                                                                    // 171
                                                                                                                     // 172
// location1 variable:                                                                                               // 173
location1 = {                                                                                                        // 174
  isSet: false,                                                                                                      // 175
  sessionName: 'bz.posts.new.location1',                                                                             // 176
  dbObject: undefined,                                                                                               // 177
  setLocation: function (dbObject) {                                                                                 // 178
    this.isSet = true;                                                                                               // 179
    this.dbObject = dbObject;                                                                                        // 180
    Session.set(this.sessionName, dbObject);                                                                         // 181
  }                                                                                                                  // 182
};                                                                                                                   // 183
location2 = {                                                                                                        // 184
  isSet: false,                                                                                                      // 185
  sessionName: 'bz.posts.new.location2',                                                                             // 186
  dbObject: undefined,                                                                                               // 187
  setLocation: function (dbObject) {                                                                                 // 188
    this.isSet = true;                                                                                               // 189
    this.dbObject = dbObject;                                                                                        // 190
    Session.set(this.sessionName, dbObject);                                                                         // 191
  }                                                                                                                  // 192
};                                                                                                                   // 193
                                                                                                                     // 194
getPostPhotoObjectsByIds = function(photoIds){                                                                       // 195
  var photos = photoIds, ret = [];                                                                                   // 196
  _.each(photos, function(id){                                                                                       // 197
    ret.push(bz.cols.images.findOne(id));                                                                            // 198
  });                                                                                                                // 199
  return ret;                                                                                                        // 200
};                                                                                                                   // 201
                                                                                                                     // 202
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
