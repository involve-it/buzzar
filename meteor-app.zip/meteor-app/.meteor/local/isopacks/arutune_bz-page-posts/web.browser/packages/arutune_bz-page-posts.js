(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/collections/posts.shared.js                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by yvdorofeev on 10/20/15.                                                                                // 2
 */                                                                                                                  // 3
bz.cols.posts = new Mongo.Collection('posts');                                                                       // 4
                                                                                                                     // 5
var postsColl = bz.cols.posts;                                                                                       // 6
                                                                                                                     // 7
postsColl.helpers({                                                                                                  // 8
  _hasLivePresence: bz.help.posts.hasLivePresence                                                                    // 9
});                                                                                                                  // 10
                                                                                                                     // 11
                                                                                                                     // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/router.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by douson on 03.07.15.                                                                                    // 2
 */                                                                                                                  // 3
var requireLoginController = bz.router.requireLoginController;                                                       // 4
// POSTS:                                                                                                            // 5
Router.map(function () {                                                                                             // 6
  this.route('posts', {                                                                                              // 7
    path: '/posts',                                                                                                  // 8
    controller: 'requireLoginController',                                                                            // 9
    onBeforeAction: function () {                                                                                    // 10
      Router.go('/posts/my');                                                                                        // 11
    }                                                                                                                // 12
                                                                                                                     // 13
  });                                                                                                                // 14
  this.route('posts.details', {                                                                                      // 15
    path: '/post/:_id',                                                                                              // 16
    template: 'postsPageDetails',                                                                                    // 17
    data: function () {                                                                                              // 18
      var ret;                                                                                                       // 19
      ret = bz.cols.posts.findOne({_id: this.params._id});                                                           // 20
      return ret;                                                                                                    // 21
    },                                                                                                               // 22
    //controller: 'requireLoginController',                                                                          // 23
    onAfterAction: function () {                                                                                     // 24
      var post = this.data();                                                                                        // 25
      post && runHitTracking(post);                                                                                  // 26
      console.log('onAfterAction' + this.data());                                                                    // 27
    },                                                                                                               // 28
    onBeforeAction: function () {                                                                                    // 29
      if (!this.data()) {                                                                                            // 30
        Router.go('/page-not-found');                                                                                // 31
      }                                                                                                              // 32
      this.next();                                                                                                   // 33
    }                                                                                                                // 34
  });                                                                                                                // 35
                                                                                                                     // 36
  this.route('postsMy', {                                                                                            // 37
    path: '/posts/my',                                                                                               // 38
    layoutTemplate: 'mainLayout',                                                                                    // 39
    controller: 'requireLoginController'                                                                             // 40
  });                                                                                                                // 41
                                                                                                                     // 42
  // create post flow:                                                                                               // 43
  this.route('postsNew', {                                                                                           // 44
    path: '/posts/new',                                                                                              // 45
    controller: 'requireLoginController',                                                                            // 46
    waitOn: function () {                                                                                            // 47
      return [                                                                                                       // 48
        bz.help.maps.googleMapsLoad()                                                                                // 49
      ]                                                                                                              // 50
    }                                                                                                                // 51
    /*data: function () {                                                                                            // 52
     return Meteor.users.findOne({_id: this.params._id});                                                            // 53
     }*/                                                                                                             // 54
  });                                                                                                                // 55
  this.route('postsNewShare', {                                                                                      // 56
    path: '/posts/new/share',                                                                                        // 57
    template: 'newPostPageShare',                                                                                    // 58
    controller: 'requireLoginController',                                                                            // 59
    waitOn: function () {                                                                                            // 60
      return []                                                                                                      // 61
    }                                                                                                                // 62
  });                                                                                                                // 63
});                                                                                                                  // 64
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/controller.js                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by Ashot on 9/19/15.                                                                                      // 2
 */                                                                                                                  // 3
bz.help.makeNamespace('bz.runtime.newPost.location');                                                                // 4
                                                                                                                     // 5
createNewPostFromView = function (v) {                                                                               // 6
  var userId = Meteor.userId(), imgId, imgArr = [], locationsArr = [],                                               // 7
    locDef = $.Deferred(),                                                                                           // 8
    loc1 = Session.get(bz.const.posts.location1),                                                                    // 9
    loc2 = Session.get(bz.const.posts.location2),                                                                    // 10
                                                                                                                     // 11
    rad = $('.js-radius-slider').attr('data-slider') && Number.parseInt($('.js-radius-slider').attr('data-slider')), // 12
    otherKeyValuePairs = [], timestamp;                                                                              // 13
                                                                                                                     // 14
  // gather all data and submit for post-create:                                                                     // 15
  if (userId) {                                                                                                      // 16
    if (Session.get('bz.posts.postImgArr')) {                                                                        // 17
      //if (bz.runtime.newPost.postImage) {                                                                          // 18
      _.each(Session.get('bz.posts.postImgArr'), function (img) {                                                    // 19
        img = img || {};                                                                                             // 20
        imgId = bz.cols.images.insert({                                                                              // 21
          data: img.data,                                                                                            // 22
          userId: userId                                                                                             // 23
        });                                                                                                          // 24
        imgArr.push(imgId);                                                                                          // 25
      });                                                                                                            // 26
    }                                                                                                                // 27
    // set location:                                                                                                 // 28
    //if (bz.runtime.newPost.location && bz.runtime.newPost.location.current) {                                      // 29
    if (loc1 && location1.isSet) {                                                                                   // 30
      // bz.help.maps.getCurrentLocation(function (loc) {                                                            // 31
      locationsArr.push(loc1);                                                                                       // 32
      //locDef.resolve();                                                                                            // 33
      //});                                                                                                          // 34
    }                                                                                                                // 35
    if (loc2 && location2.isSet) {                                                                                   // 36
      locationsArr.push(loc2);                                                                                       // 37
      //locDef.resolve();                                                                                            // 38
    }                                                                                                                // 39
    // set the 'other' field, that contains: all other post-specific key-value pairs of info that we want:           // 40
    if (v.$('.js-charity-type-select').val()) {                                                                      // 41
      otherKeyValuePairs.push({                                                                                      // 42
        key: 'whatHappened',                                                                                         // 43
        value: v.$('.js-charity-type-select').val()                                                                  // 44
      });                                                                                                            // 45
    }                                                                                                                // 46
    // created timestamp:                                                                                            // 47
    timestamp = Date.now();                                                                                          // 48
    var newPost = {                                                                                                  // 49
                                                                                                                     // 50
      userId: userId,                                                                                                // 51
      type: v.$('.js-post-type-select').val(),                                                                       // 52
      details: {                                                                                                     // 53
                                                                                                                     // 54
        hashes: bz.runtime.newPost.hashes,                                                                           // 55
        //location: bz.runtime.newPost.location,                                                                     // 56
        locations: locationsArr,                                                                                     // 57
        radius: rad,                                                                                                 // 58
        url: v.$('.js-original-url').val(),                                                                          // 59
                                                                                                                     // 60
        //details:                                                                                                   // 61
        title: v.$('.js-post-title').val(),                                                                          // 62
        description: v.$('.js-post-description').val(),                                                              // 63
        price: v.$('.js-post-price').val(),                                                                          // 64
        photos: imgArr,                                                                                              // 65
                                                                                                                     // 66
        // specific:                                                                                                 // 67
        other: otherKeyValuePairs                                                                                    // 68
      },                                                                                                             // 69
      status: {                                                                                                      // 70
        visible: bz.const.posts.status.visibility.VISIBLE                                                            // 71
      },                                                                                                             // 72
      timestamp: timestamp                                                                                           // 73
    };                                                                                                               // 74
                                                                                                                     // 75
    var currentLoc = Session.get('currentLocation');                                                                 // 76
    if (currentLoc){                                                                                                 // 77
      currentLoc = {                                                                                                 // 78
        lat: currentLoc.latitude,                                                                                    // 79
        lng: currentLoc.longitude                                                                                    // 80
      };                                                                                                             // 81
    } else {                                                                                                         // 82
      currentLoc = Session.get('bz.control.search.location');                                                        // 83
      if (currentLoc){                                                                                               // 84
        currentLoc = currentLoc.coords;                                                                              // 85
      }                                                                                                              // 86
    }                                                                                                                // 87
                                                                                                                     // 88
    //$.when(locDef).then(function () {                                                                              // 89
    Meteor.call('addNewPost', newPost, currentLoc, Meteor.connection._lastSessionId, function (err, res) {           // 90
      if (!err && res && res !== '') {                                                                               // 91
        clearPostData();                                                                                             // 92
        bz.runtime.newPost.postId = res;                                                                             // 93
        Router.go('/posts/my');                                                                                      // 94
      }                                                                                                              // 95
    });                                                                                                              // 96
  }                                                                                                                  // 97
};                                                                                                                   // 98
movingLocationPanelClick = function () {                                                                             // 99
  var chosenLocation = Session.get(location1.sessionName);                                                           // 100
  if (!chosenLocation) {                                                                                             // 101
    // nothing is set as a location, need to set it, for this show user location-choose control:                     // 102
    //$('.js-location-holder a').click();                                                                            // 103
    bz.help.maps.getCurrentLocation(function (loc) {                                                                 // 104
      /*var chosenLocation = Session.get('bz.posts.new.location1');                                                  // 105
       var name = 'current';                                                                                         // 106
       var existLoc = bz.cols.locations.findOne({name: name, userId: Meteor.userId()});                              // 107
       if (existLoc) {                                                                                               // 108
       bz.cols.locations.remove(existLoc._id);                                                                       // 109
       }                                                                                                             // 110
       bz.cols.locations.insert({                                                                                    // 111
       userId: Meteor.userId(),                                                                                      // 112
       name: 'current',                                                                                              // 113
       coords: loc                                                                                                   // 114
       });*/                                                                                                         // 115
                                                                                                                     // 116
      Meteor.call('setUserCurrentLocation', Meteor.userId(), loc, function (err, resLocation) {                      // 117
        location1.setLocation(resLocation);                                                                          // 118
      });                                                                                                            // 119
      /*locationsArr.push({                                                                                          // 120
       coords: loc,                                                                                                  // 121
       type: bz.const.locations.type.STATIC                                                                          // 122
       });                                                                                                           // 123
       locDef.resolve();*/                                                                                           // 124
    });                                                                                                              // 125
    //Template.bzLocationNameNewPost.showModal();                                                                    // 126
  }                                                                                                                  // 127
};                                                                                                                   // 128
staticLocationPanelClick = function () {                                                                             // 129
  var chosenLocation = Session.get(location2.sessionName);                                                           // 130
  if (!chosenLocation) {                                                                                             // 131
    // nothing is set as a location, need to set it, for this show user location-choose control:                     // 132
    //$('.js-location-holder a').click();                                                                            // 133
    Template.bzLocationNameNewPost.showModal();                                                                      // 134
  }                                                                                                                  // 135
};                                                                                                                   // 136
userSeenAll;                                                                                                         // 137
// this function calculates browser-specific hits                                                                    // 138
runHitTracking = function (post, browserInfo) {                                                                      // 139
  var userSeenTotal, userSeenToday, seenTotalPost, seenTodayPost;                                                    // 140
  userSeenTotal = Cookie.get('bz.posts.seenTotal.postId.' + post._id)                                                // 141
  if (!userSeenTotal) {                                                                                              // 142
    seenTotalPost = post.stats && post.stats.seenTotal || 0;                                                         // 143
    bz.cols.posts.update(post._id, {$set: {'stats.seenTotal': ++seenTotalPost }});                                   // 144
    //setCookie('bz.posts.seenTotal.postId.' + post._id, true);                                                      // 145
    Cookie.set('bz.posts.seenTotal.postId.' + post._id, true);                                                       // 146
    userSeenTotal = undefined;                                                                                       // 147
  } else {                                                                                                           // 148
    // user seen this already, do nothing!                                                                           // 149
  }                                                                                                                  // 150
  // set total unique today:                                                                                         // 151
  userSeenToday = Cookie.get('bz.posts.seenToday.postId.' + post._id);                                               // 152
  if (!userSeenToday) {                                                                                              // 153
    seenTodayPost = post.stats && post.stats.seenToday || 0;                                                         // 154
    bz.cols.posts.update(post._id, {$set: {'stats.seenToday': ++seenTodayPost }});                                   // 155
    Cookie.set('bz.posts.seenToday.postId.' + post._id, true, { days: 1 });                                          // 156
    userSeenToday = undefined;                                                                                       // 157
  } else {                                                                                                           // 158
    // user seen this already, do nothing!                                                                           // 159
  }                                                                                                                  // 160
  // set total loads (non-unique):                                                                                   // 161
  if(!userSeenAll) { // need to run only on-time on full load                                                        // 162
    userSeenAll = !userSeenAll && post.stats && post.stats.seenAll || 0;                                             // 163
    bz.cols.posts.update(post._id, {$set: {'stats.seenAll': ++userSeenAll}});                                        // 164
  }                                                                                                                  // 165
};                                                                                                                   // 166
                                                                                                                     // 167
//HELPERS:                                                                                                           // 168
function clearPostData() {                                                                                           // 169
                                                                                                                     // 170
}                                                                                                                    // 171
                                                                                                                     // 172
// location1 variable:                                                                                               // 173
location1 = {                                                                                                        // 174
  isSet: false,                                                                                                      // 175
  sessionName: 'bz.posts.new.location1',                                                                             // 176
  dbObject: undefined,                                                                                               // 177
  setLocation: function (dbObject) {                                                                                 // 178
    this.isSet = true;                                                                                               // 179
    this.dbObject = dbObject;                                                                                        // 180
    Session.set(this.sessionName, dbObject);                                                                         // 181
  }                                                                                                                  // 182
};                                                                                                                   // 183
location2 = {                                                                                                        // 184
  isSet: false,                                                                                                      // 185
  sessionName: 'bz.posts.new.location2',                                                                             // 186
  dbObject: undefined,                                                                                               // 187
  setLocation: function (dbObject) {                                                                                 // 188
    this.isSet = true;                                                                                               // 189
    this.dbObject = dbObject;                                                                                        // 190
    Session.set(this.sessionName, dbObject);                                                                         // 191
  }                                                                                                                  // 192
};                                                                                                                   // 193
                                                                                                                     // 194
getPostPhotoObjectsByIds = function(photoIds){                                                                       // 195
  var photos = photoIds, ret = [];                                                                                   // 196
  _.each(photos, function(id){                                                                                       // 197
    ret.push(bz.cols.images.findOne(id));                                                                            // 198
  });                                                                                                                // 199
  return ret;                                                                                                        // 200
};                                                                                                                   // 201
                                                                                                                     // 202
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/template.common.js                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("bzPostsPostPresence");                                                                         // 2
Template["bzPostsPostPresence"] = new Template("Template.bzPostsPostPresence", (function() {                         // 3
  var view = this;                                                                                                   // 4
  return HTML.DIV({                                                                                                  // 5
    "class": "bz-post-presence"                                                                                      // 6
  }, "\n        ", Blaze.If(function() {                                                                             // 7
    return Spacebars.call(view.lookup("_hasLivePresence"));                                                          // 8
  }, function() {                                                                                                    // 9
    return [ "\n          ", HTML.A({                                                                                // 10
      title: function() {                                                                                            // 11
        return [ "address: ", Spacebars.mustache(Spacebars.dot(view.lookup("_hasLivePresence"), "name")), ", lat: ", Spacebars.mustache(Spacebars.dot(view.lookup("_hasLivePresence"), "coords", "lat")), ", lng: ", Spacebars.mustache(Spacebars.dot(view.lookup("_hasLivePresence"), "coords", "lng")) ];
      }                                                                                                              // 13
    }, "\n              ", HTML.DIV({                                                                                // 14
      "class": "bz-i-wrapper"                                                                                        // 15
    }, "\n                  live\n              "), "\n          "), "\n        " ];                                 // 16
  }, function() {                                                                                                    // 17
    return [ "\n            ", HTML.DIV({                                                                            // 18
      "class": "bz-i-wrapper"                                                                                        // 19
    }, "\n                away\n            "), "\n        " ];                                                      // 20
  }), "\n    ");                                                                                                     // 21
}));                                                                                                                 // 22
                                                                                                                     // 23
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/details/template.details-controls.js                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("bzPostDetails");                                                                               // 2
Template["bzPostDetails"] = new Template("Template.bzPostDetails", (function() {                                     // 3
  var view = this;                                                                                                   // 4
  return [ HTML.Raw("<!--SIDE A-->\n  "), HTML.DIV({                                                                 // 5
    "class": "side-a text-center small-12 medium-6 columns"                                                          // 6
  }, "\n\n    ", HTML.DIV({                                                                                          // 7
    "class": "post-item bz-post-published overflow"                                                                  // 8
  }, "\n      ", HTML.DIV({                                                                                          // 9
    "class": "post-details"                                                                                          // 10
  }, "\n        ", HTML.DIV({                                                                                        // 11
    "class": "small-12 bz-post-label columns"                                                                        // 12
  }, HTML.Raw('<i class="fa fa-clock-o"></i>'), " Published on ", HTML.Raw("&nbsp;"), " ", HTML.SPAN({               // 13
    "class": "bz-text-italic"                                                                                        // 14
  }, Blaze.View("lookup:getPostCreatedDate", function() {                                                            // 15
    return Spacebars.mustache(view.lookup("getPostCreatedDate"));                                                    // 16
  }))), "\n      "), "\n    "), "\n\n    ", HTML.DIV({                                                               // 17
    "class": "user-avatar"                                                                                           // 18
  }, "\n      ", Spacebars.include(view.lookupTemplate("postDetailsPhoto")), "\n    "), "\n\n    ", HTML.Raw("<!--Additional information of the post-->"), "\n\n\n  "), HTML.Raw("\n\n  <!--SIDE B-->\n  "), HTML.DIV({
    "class": "side-b small-12 medium-6 large-6 columns"                                                              // 20
  }, "\n\n    ", HTML.Raw('<div class="item-divider">\n      <h3 class="title">Post Details</h3>\n    </div>'), "\n\n    ", HTML.DIV({
    "class": "post-item overflow"                                                                                    // 22
  }, "\n      ", HTML.DIV({                                                                                          // 23
    "class": "post-details"                                                                                          // 24
  }, "\n        ", HTML.Raw('<div class="small-12 medium-4 bz-post-label columns"><i class="fa fa-eye"></i> Views</div>'), "\n        ", HTML.DIV({
    "class": "small-12 medium-8 large-8 bz-post-result columns"                                                      // 26
  }, "\n          ", HTML.P(HTML.Raw("<span>all</span>"), " ", Blaze.View("lookup:stats.seenTotal", function() {     // 27
    return Spacebars.mustache(Spacebars.dot(view.lookup("stats"), "seenTotal"));                                     // 28
  }), ", ", HTML.Raw("<span>today</span>"), " ", Blaze.View("lookup:stats.seenToday", function() {                   // 29
    return Spacebars.mustache(Spacebars.dot(view.lookup("stats"), "seenToday"));                                     // 30
  }), " "), "\n        "), "\n      "), "\n\n    ", Blaze.If(function() {                                            // 31
    return {                                                                                                         // 32
      _hasLivePresence: Spacebars.call(view.lookup("away"))                                                          // 33
    };                                                                                                               // 34
  }, function() {                                                                                                    // 35
    return [ "\n        ", HTML.DIV({                                                                                // 36
      "class": "post-details"                                                                                        // 37
    }, "\n            ", HTML.DIV({                                                                                  // 38
      "class": "small-12 medium-4 bz-post-label columns"                                                             // 39
    }, HTML.I({                                                                                                      // 40
      "class": "fa fa-street-view"                                                                                   // 41
    }), " Status"), "\n            ", HTML.DIV({                                                                     // 42
      "class": "small-12 medium-8 large-8 bz-post-result columns"                                                    // 43
    }, "\n                ", HTML.P(" ", Blaze._TemplateWith(function() {                                            // 44
      return Spacebars.call(view.lookup("."));                                                                       // 45
    }, function() {                                                                                                  // 46
      return Spacebars.include(view.lookupTemplate("bzPostsPostPresence"));                                          // 47
    }), " "), "\n            "), "\n        "), "\n    " ];                                                          // 48
  }), "\n\n      ", Blaze.If(function() {                                                                            // 49
    return Spacebars.call(Spacebars.dot(view.lookup("details"), "duration"));                                        // 50
  }, function() {                                                                                                    // 51
    return [ "\n      ", HTML.DIV({                                                                                  // 52
      "class": "post-details"                                                                                        // 53
    }, "\n        ", HTML.DIV({                                                                                      // 54
      "class": "small-12 medium-4 bz-post-label columns"                                                             // 55
    }, HTML.I({                                                                                                      // 56
      "class": "fa fa-info-circle"                                                                                   // 57
    }), " Left"), "\n        ", HTML.DIV({                                                                           // 58
      "class": "small-12 medium-8 large-8 bz-post-result columns"                                                    // 59
    }, HTML.P(" 10 days ")), "\n      "), "\n\n      ", HTML.DIV({                                                   // 60
      "class": "post-details"                                                                                        // 61
    }, "\n        ", HTML.DIV({                                                                                      // 62
      "class": "small-12 medium-4 bz-post-label columns"                                                             // 63
    }, HTML.I({                                                                                                      // 64
      "class": "fa fa-list-alt"                                                                                      // 65
    }), " Type"), "\n        ", HTML.DIV({                                                                           // 66
      "class": "small-12 medium-8 large-8 bz-post-result columns"                                                    // 67
    }, "\n          ", HTML.DIV({                                                                                    // 68
      "class": function() {                                                                                          // 69
        return [ "button bz-btn-category type-category-", Spacebars.mustache(view.lookup("categoryType")) ];         // 70
      }                                                                                                              // 71
    }, " Trade"), "\n        "), "\n      "), "\n      " ];                                                          // 72
  }), "\n\n      ", Blaze.If(function() {                                                                            // 73
    return Spacebars.call(Spacebars.dot(view.lookup("details"), "price"));                                           // 74
  }, function() {                                                                                                    // 75
    return [ "\n        ", HTML.DIV({                                                                                // 76
      "class": "post-details"                                                                                        // 77
    }, "\n          ", HTML.DIV({                                                                                    // 78
      "class": "small-12 medium-4 bz-post-label columns"                                                             // 79
    }, HTML.I({                                                                                                      // 80
      "class": "fa fa-money"                                                                                         // 81
    }), " Price"), "\n          ", HTML.DIV({                                                                        // 82
      "class": "small-12 medium-8 large-8 bz-post-result columns"                                                    // 83
    }, "\n            ", HTML.DIV({                                                                                  // 84
      "class": "bz-price"                                                                                            // 85
    }, "\n              200 ", HTML.SPAN({                                                                           // 86
      "class": "bz-prefix"                                                                                           // 87
    }, "$"), "\n            "), "\n          "), "\n        "), "\n      " ];                                        // 88
  }), "\n\n      ", HTML.Raw('<div class="bz-separate"></div>'), "\n\n      ", Spacebars.include(view.lookupTemplate("saveToWishList")), "\n\n    "), "\n\n\n  "), HTML.Raw('\n\n  <div class="clearfix"></div>\n\n  '), Spacebars.include(view.lookupTemplate("postDetailsDetailsCommon")), HTML.Raw('\n\n  <div class="js-post-details-categorized"></div>\n  '), Spacebars.include(view.lookupTemplate("postDetailsHashesControl")) ];
}));                                                                                                                 // 90
                                                                                                                     // 91
Template.__checkName("saveToWishList");                                                                              // 92
Template["saveToWishList"] = new Template("Template.saveToWishList", (function() {                                   // 93
  var view = this;                                                                                                   // 94
  return HTML.Raw('<div class="bz-wish-list">\n    <div class="bz-wish-list-title"><i class="fa fa-heart-o"></i> Save to favorites</div>\n    <div class="bz-wish-list-items">\n      <div class="bz-wish-list-item"><i class="fa fa-envelope-o"></i> Email</div>\n      <div class="bz-wish-list-item"><i class="fa fa-facebook"></i> Facebook</div>\n      <div class="bz-wish-list-item"><i class="fa fa-ellipsis-h"></i> more</div>\n    </div>\n  </div>');
}));                                                                                                                 // 96
                                                                                                                     // 97
Template.__checkName("postDetailsDetailsCommon");                                                                    // 98
Template["postDetailsDetailsCommon"] = new Template("Template.postDetailsDetailsCommon", (function() {               // 99
  var view = this;                                                                                                   // 100
  return [ HTML.DIV({                                                                                                // 101
    "class": "item-divider"                                                                                          // 102
  }, "\n    ", HTML.H2({                                                                                             // 103
    "class": "title space-1"                                                                                         // 104
  }, Blaze.View("lookup:getTitle", function() {                                                                      // 105
    return Spacebars.mustache(view.lookup("getTitle"));                                                              // 106
  })), "\n\n    ", Blaze.Each(function() {                                                                           // 107
    return Spacebars.call(view.lookup("getMyLocations"));                                                            // 108
  }, function() {                                                                                                    // 109
    return [ "\n      ", HTML.DIV({                                                                                  // 110
      "class": "post-location"                                                                                       // 111
    }, "\n        ", HTML.I({                                                                                        // 112
      "class": "fa fa-map-marker"                                                                                    // 113
    }), "\n          ", HTML.SPAN("\n            ", Blaze.View("lookup:name", function() {                           // 114
      return Spacebars.mustache(view.lookup("name"));                                                                // 115
    }), "\n            ", Blaze.If(function() {                                                                      // 116
      return Spacebars.dataMustache(view.lookup("$eq"), view.lookup("placeType"), "bz.dynamic");                     // 117
    }, function() {                                                                                                  // 118
      return "\n              (DYNAMIC)\n            ";                                                              // 119
    }, function() {                                                                                                  // 120
      return "\n              (STATIC)\n            ";                                                               // 121
    }), "\n        "), "\n        ", HTML.A({                                                                        // 122
      "class": "js-show-location-on-map"                                                                             // 123
    }, "(view map)"), "\n      "), "\n    " ];                                                                       // 124
  }), "\n  "), "\n\n\n  ", HTML.DIV({                                                                                // 125
    "class": "post-item overflow"                                                                                    // 126
  }, "\n    ", HTML.DIV({                                                                                            // 127
    "class": "post-details"                                                                                          // 128
  }, "\n      ", HTML.DIV({                                                                                          // 129
    "class": "small-12 bz-post-description"                                                                          // 130
  }, HTML.P(" ", Blaze.View("lookup:getDescription", function() {                                                    // 131
    return Spacebars.mustache(view.lookup("getDescription"));                                                        // 132
  }), " ")), "\n      \n        \n\n    "), "\n  ") ];                                                               // 133
}));                                                                                                                 // 134
                                                                                                                     // 135
Template.__checkName("postDetailsDetailsHelp");                                                                      // 136
Template["postDetailsDetailsHelp"] = new Template("Template.postDetailsDetailsHelp", (function() {                   // 137
  var view = this;                                                                                                   // 138
  return HTML.Raw('<label class="item item-input item-select">\n    <div class="input-label">\n      What happened?\n    </div>\n    <select class="js-charity-type-select" disabled="">\n      <option value="roommates">Lost my pet</option>\n      <option value="rent">Need money for food</option>\n      <option value="buy">Emergency situation</option>\n      <option value="buy">Other</option>\n    </select>\n  </label>');
}));                                                                                                                 // 140
                                                                                                                     // 141
Template.__checkName("postDetailsDetailsConnect");                                                                   // 142
Template["postDetailsDetailsConnect"] = new Template("Template.postDetailsDetailsConnect", (function() {             // 143
  var view = this;                                                                                                   // 144
  return HTML.Raw('<label class="item item-input item-select">\n    <div class="input-label">\n      I am looking for:\n    </div>\n    <select class="js-charity-type-select" disabled="">\n      <option value="artists">artists and other creative people</option>\n      <option value="friends">friends</option>\n      <option value="professionals">professionals</option>\n      <option value="other">Other</option>\n    </select>\n  </label>');
}));                                                                                                                 // 146
                                                                                                                     // 147
Template.__checkName("postDetailsDetailsTrade");                                                                     // 148
Template["postDetailsDetailsTrade"] = new Template("Template.postDetailsDetailsTrade", (function() {                 // 149
  var view = this;                                                                                                   // 150
  return HTML.LABEL({                                                                                                // 151
    type: "stacked",                                                                                                 // 152
    "class": "item item-input item-stacked-label"                                                                    // 153
  }, HTML.Raw('\n    <span class="input-label">Price</span>\n    '), HTML.INPUT({                                    // 154
    "class": "js-post-price",                                                                                        // 155
    type: "number",                                                                                                  // 156
    value: function() {                                                                                              // 157
      return Spacebars.mustache(view.lookup("getPrice"));                                                            // 158
    },                                                                                                               // 159
    "label-type": "stacked",                                                                                         // 160
    disabled: ""                                                                                                     // 161
  }), "\n\n  ");                                                                                                     // 162
}));                                                                                                                 // 163
                                                                                                                     // 164
Template.__checkName("postDetailsDetailsJobs");                                                                      // 165
Template["postDetailsDetailsJobs"] = new Template("Template.postDetailsDetailsJobs", (function() {                   // 166
  var view = this;                                                                                                   // 167
  return HTML.Raw('<label class="item item-input">\n    <span class="input-label">Position</span>\n    <input class="js-job-title" type="text" label-type="stacked" name="title" maxlength="200" disabled="">\n  </label>');
}));                                                                                                                 // 169
                                                                                                                     // 170
Template.__checkName("postDetailsDetailsHousing");                                                                   // 171
Template["postDetailsDetailsHousing"] = new Template("Template.postDetailsDetailsHousing", (function() {             // 172
  var view = this;                                                                                                   // 173
  return HTML.Raw('<label class="item item-input item-select">\n    <div class="input-label">\n      Looking for\n    </div>\n    <select class="js-housing-type-select" disabled="">\n      <option value="roommates">Roommates</option>\n      <option value="rent">Renting</option>\n      <option value="rentOut">Renting out</option>\n      <option value="buy">Buying a house</option>\n      <option value="sell">Selling a house</option>\n    </select>\n  </label>');
}));                                                                                                                 // 175
                                                                                                                     // 176
Template.__checkName("postDetailsHashesControl");                                                                    // 177
Template["postDetailsHashesControl"] = new Template("Template.postDetailsHashesControl", (function() {               // 178
  var view = this;                                                                                                   // 179
  return Blaze.If(function() {                                                                                       // 180
    return Spacebars.call(view.lookup("getHashes"));                                                                 // 181
  }, function() {                                                                                                    // 182
    return [ "\n\n    ", HTML.LABEL({                                                                                // 183
      type: "stacked",                                                                                               // 184
      "class": "item item-input item-stacked-label padding-right"                                                    // 185
    }, "\n      ", HTML.SPAN({                                                                                       // 186
      "class": "input-label"                                                                                         // 187
    }, "Hashes"), "\n      ", HTML.BUTTON({                                                                          // 188
      "class": "button button-block button-stable js-hashes-holder"                                                  // 189
    }, Blaze.View("lookup:getHashes", function() {                                                                   // 190
      return Spacebars.mustache(view.lookup("getHashes"));                                                           // 191
    })), "\n    "), "\n    ", HTML.Comment("input with bottons know-how:"), "\n    ", HTML.Comment('<label class="item item-input item-stacked-label">\n        <span class="input-label">Original Url (optional)</span>\n        <div class="item item-input-inset">\n            <input name="url" placeholder="" class="original-url js-original-url" type="text">\n            <a name="original-post-details" class=" button button-small disabled js-post-details-link" href="/posts/new/original-details">\n                Check >>\n            </a>\n        </div>\n    </label>'), "\n\n  " ];
  });                                                                                                                // 193
}));                                                                                                                 // 194
                                                                                                                     // 195
Template.__checkName("postDetailsPhoto");                                                                            // 196
Template["postDetailsPhoto"] = new Template("Template.postDetailsPhoto", (function() {                               // 197
  var view = this;                                                                                                   // 198
  return [ HTML.DIV({                                                                                                // 199
    "class": "photos"                                                                                                // 200
  }, "\n    ", HTML.Raw("<!--{{#if getPhotoUrl}}-->"), "\n      ", HTML.DIV({                                        // 201
    "class": "single-photo cover-img js-main-photo-large",                                                           // 202
    style: function() {                                                                                              // 203
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getMainPhoto")), "')" ];                   // 204
    }                                                                                                                // 205
  }), "\n    ", HTML.Raw("<!--{{else}}-->"), "\n      ", HTML.Raw('<!--<div class="single-photo cover-img"-->'), "\n           ", HTML.Raw("<!--style=\"background-color: #efefef; background-image: url('{{ getMainImage }}')\"></div>-->"), "\n    ", HTML.Raw("<!--{{/if}}-->"), "\n        \n    ", Blaze.If(function() {
    return Spacebars.call(view.lookup("moreThanOnePhotos"));                                                         // 207
  }, function() {                                                                                                    // 208
    return [ "\n        ", HTML.UL({                                                                                 // 209
      "class": "clearing-thumbs js-clearing-thumbs",                                                                 // 210
      "data-clearing": ""                                                                                            // 211
    }, "\n            ", Blaze.Each(function() {                                                                     // 212
      return Spacebars.call(view.lookup("getPhotos"));                                                               // 213
    }, function() {                                                                                                  // 214
      return [ "\n                ", HTML.LI("\n                    ", HTML.A({                                      // 215
        href: function() {                                                                                           // 216
          return [ "data:", Spacebars.mustache(view.lookup("data")) ];                                               // 217
        }                                                                                                            // 218
      }, "\n                      ", HTML.IMG({                                                                      // 219
        src: function() {                                                                                            // 220
          return Spacebars.mustache(view.lookup("data"));                                                            // 221
        },                                                                                                           // 222
        style: "height: 60px;"                                                                                       // 223
      }), "\n                    "), "\n                "), "\n            " ];                                      // 224
    }), "\n        "), "\n    " ];                                                                                   // 225
  }), "\n  "), HTML.Raw('\n\n\n  <!--  <ul class="clearing-thumbs" data-clearing>\n    <li><a href="/img/content/avatars/avatar-no.png"><img src="{{ getPhotoUrl }}"></a></li>\n    <li><a href="/img/content/avatars/avatar-no.png"><img src="{{ getPhotoUrl }}"></a></li>\n    <li><a href="/img/content/avatars/avatar-no.png"><img src="{{ getPhotoUrl }}"></a></li>\n  </ul>-->\n\n\n  <!-- 09.23.15 old markup-->\n  <!--<div class="post-photo-upload">\n        &lt;!&ndash;<div class="image-holder js-image-holder js-get-picture" style="background-image:url(\'/img/content/avatars/avatar-no.png\');"></div>&ndash;&gt;\n        <div class="owner-photo-wrap">\n            <div class="img-avatar" data-action="edit-avatar">\n                <i class="icon ion-camera"></i>\n\n                <img src="{{ getPhotoUrl }}" >\n\n            </div>\n        </div>\n        &lt;!&ndash;<a class="js-get-picture button">get pic</a>\n        <br/>\n        <a class="js-get-picture-lib button">get pic lib</a>&ndash;&gt;\n    </div>-->\n  <!-- END 09.23.15 old markup-->') ];
}));                                                                                                                 // 227
                                                                                                                     // 228
Template.__checkName("bzPostLocationMapModal");                                                                      // 229
Template["bzPostLocationMapModal"] = new Template("Template.bzPostLocationMapModal", (function() {                   // 230
  var view = this;                                                                                                   // 231
  return "";                                                                                                         // 232
}));                                                                                                                 // 233
                                                                                                                     // 234
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/details/details-controls.js                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Template.bzPostDetails.events({});                                                                                   // 1
Template.bzPostDetails.helpers({                                                                                     // 2
  getPostCreatedDate: function () {                                                                                  // 3
    var ret = '';                                                                                                    // 4
    if (this.timestamp) {                                                                                            // 5
      ret = new Date(this.timestamp).toDateString();                                                                 // 6
    }                                                                                                                // 7
    return ret;                                                                                                      // 8
  }                                                                                                                  // 9
})                                                                                                                   // 10
                                                                                                                     // 11
                                                                                                                     // 12
Template.postDetailsHashesControl.helpers({                                                                          // 13
  getHashes: function () {                                                                                           // 14
    var hash = this.details.hash;                                                                                    // 15
    return hash;                                                                                                     // 16
  }                                                                                                                  // 17
});                                                                                                                  // 18
Template.postDetailsDetailsCommon.events({                                                                           // 19
  'click .js-show-location-on-map': function(e, v){                                                                  // 20
    // show modal with map here:                                                                                     // 21
                                                                                                                     // 22
  }                                                                                                                  // 23
})                                                                                                                   // 24
Template.postDetailsDetailsCommon.helpers({                                                                          // 25
  getTitle: function () {                                                                                            // 26
    return this.details.title;                                                                                       // 27
  },                                                                                                                 // 28
  getDescription: function () {                                                                                      // 29
    return this.details.description || '';                                                                           // 30
  },                                                                                                                 // 31
  getMyLocations: function () {                                                                                      // 32
    return this.details.locations;                                                                                   // 33
  }                                                                                                                  // 34
});                                                                                                                  // 35
//$('.backdrop.visible.active .popup .popup-title').text().toLowerCase()                                             // 36
                                                                                                                     // 37
Template.postDetailsPhoto.onCreated(function () {                                                                    // 38
                                                                                                                     // 39
});                                                                                                                  // 40
Template.postDetailsPhoto.onRendered(function () {                                                                   // 41
  if (this.data.details.photos) {                                                                                    // 42
    Session.set('postDetailsImgSrc', this.data.details.photos[0]);                                                   // 43
  }                                                                                                                  // 44
  $(document).foundation();                                                                                          // 45
  $(document).foundation('clearing', 'reflow');                                                                      // 46
});                                                                                                                  // 47
Template.postDetailsPhoto.events({                                                                                   // 48
  'click .js-main-photo-large': function(e, v){                                                                      // 49
    v.$('.js-clearing-thumbs li:first-child a').click();                                                             // 50
  }                                                                                                                  // 51
})                                                                                                                   // 52
Template.postDetailsPhoto.helpers({                                                                                  // 53
  /*getImageSrc: function () {                                                                                       // 54
   var ret = '/img/content/avatars/avatar-no.png';                                                                   // 55
   return Session.get('postDetailsImgSrc') || ret;                                                                   // 56
   },*/                                                                                                              // 57
  getPhotoUrl: function () {                                                                                         // 58
    /*var ret = '/img/content/avatars/avatar-no.png';*/                                                              // 59
    var photoId = Session.get('postDetailsImgSrc');                                                                  // 60
                                                                                                                     // 61
    if (photoId) {                                                                                                   // 62
      //ret = bz.cols.images.findOne({_id: photoId}).data;                                                           // 63
    } else {                                                                                                         // 64
      return false;                                                                                                  // 65
    }                                                                                                                // 66
    /*return ret;*/                                                                                                  // 67
                                                                                                                     // 68
  },                                                                                                                 // 69
  getPhotos: function(){                                                                                             // 70
    var ret = getPostPhotoObjectsByIds(this.details.photos);                                                         // 71
    return ret;                                                                                                      // 72
  },                                                                                                                 // 73
  getMainPhoto: function(){                                                                                          // 74
    var ret = {                                                                                                      // 75
        data: '../img/content/no-photo.png'                                                                          // 76
      },                                                                                                             // 77
      main, photos = getPostPhotoObjectsByIds(this.details.photos);                                                  // 78
    if (photos) {                                                                                                    // 79
      main = _.filter(photos, function(item){                                                                        // 80
        return item.isMain === true;                                                                                 // 81
      });                                                                                                            // 82
      if (main && main.length > 0){                                                                                  // 83
        ret = main[0];                                                                                               // 84
      } else if(photos && photos[0]) {                                                                               // 85
        ret = photos[0];                                                                                             // 86
      }                                                                                                              // 87
    }                                                                                                                // 88
    return ret.data;                                                                                                 // 89
  },                                                                                                                 // 90
  moreThanOnePhotos: function(){                                                                                     // 91
    var ret = false,                                                                                                 // 92
      photos = getPostPhotoObjectsByIds(this.details.photos);                                                        // 93
    if (!photos || photos.length < 2){                                                                               // 94
      ret = false;                                                                                                   // 95
    } else {                                                                                                         // 96
      ret = true;                                                                                                    // 97
    }                                                                                                                // 98
    return ret;                                                                                                      // 99
  }                                                                                                                  // 100
});                                                                                                                  // 101
                                                                                                                     // 102
// HELPERS:PostDetails                                                                                               // 103
/*function setTemplate(name, v) {                                                                                    // 104
 $('.js-post-details-categorized').empty();                                                                          // 105
 Blaze.renderWithData(Template['postDetails' + name], v.data, $('.js-post-details-categorized')[0]);                 // 106
 }*/                                                                                                                 // 107
function setPostDetailsTemplate(name, v) {                                                                           // 108
  $('.js-post-details-categorized').empty();                                                                         // 109
  Blaze.renderWithData(Template['postDetailsDetails' + name], v.data, $('.js-post-details-categorized')[0]);         // 110
}                                                                                                                    // 111
// set new image to db:                                                                                              // 112
Meteor.startup(function () {                                                                                         // 113
});                                                                                                                  // 114
                                                                                                                     // 115
Template.bzAroundYouItem.helpers({});                                                                                // 116
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/details/template.page-details.js                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("postsPageDetails");                                                                            // 2
Template["postsPageDetails"] = new Template("Template.postsPageDetails", (function() {                               // 3
  var view = this;                                                                                                   // 4
  return HTML.DIV({                                                                                                  // 5
    "class": "main-content"                                                                                          // 6
  }, "\n        ", HTML.DIV({                                                                                        // 7
    "class": "bz-post-details"                                                                                       // 8
  }, "\n            ", Spacebars.include(view.lookupTemplate("bzPostDetails")), "\n                        \n            ", Blaze._TemplateWith(function() {
    return Spacebars.call(view.lookup("getUserObj"));                                                                // 10
  }, function() {                                                                                                    // 11
    return Spacebars.include(view.lookupTemplate("bzUserProfileBasic"));                                             // 12
  }), "\n            \n            ", HTML.Raw('<div class="bz-separate"></div>'), "\n\n            ", HTML.Raw("<!--Reviews-->"), "\n            ", HTML.DIV({
    "class": "bz-post-reviews"                                                                                       // 14
  }, "\n                ", HTML.DIV({                                                                                // 15
    "class": "bz-post-review"                                                                                        // 16
  }, "\n                    ", Blaze._TemplateWith(function() {                                                      // 17
    return {                                                                                                         // 18
      postId: Spacebars.call(view.lookup("_id"))                                                                     // 19
    };                                                                                                               // 20
  }, function() {                                                                                                    // 21
    return Spacebars.include(view.lookupTemplate("bzControlReviews"));                                               // 22
  }), "\n                "), "\n                ", HTML.DIV({                                                        // 23
    "class": "bz-post-leave-review"                                                                                  // 24
  }, "\n                    ", Blaze._TemplateWith(function() {                                                      // 25
    return {                                                                                                         // 26
      postId: Spacebars.call(view.lookup("_id"))                                                                     // 27
    };                                                                                                               // 28
  }, function() {                                                                                                    // 29
    return Spacebars.include(view.lookupTemplate("bzControlAddReview"));                                             // 30
  }), "\n                "), "\n            "), "\n        "), "\n    ");                                            // 31
}));                                                                                                                 // 32
                                                                                                                     // 33
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/details/page-details.js                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by ashot on 8/25/15.                                                                                      // 2
 */                                                                                                                  // 3
Template.postsPageDetails.onCreated(function(){                                                                      // 4
                                                                                                                     // 5
});                                                                                                                  // 6
Template.postsPageDetails.helpers({                                                                                  // 7
  getUserObj: function(){                                                                                            // 8
    //debugger;                                                                                                      // 9
    var user = Meteor.users.findOne(this.userId);                                                                    // 10
    return user;                                                                                                     // 11
  }                                                                                                                  // 12
});                                                                                                                  // 13
                                                                                                                     // 14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/my-posts/template.my-items.js                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("myItems");                                                                                     // 2
Template["myItems"] = new Template("Template.myItems", (function() {                                                 // 3
  var view = this;                                                                                                   // 4
  return HTML.DIV({                                                                                                  // 5
    "class": "list"                                                                                                  // 6
  }, "\n\n    ", Blaze.If(function() {                                                                               // 7
    return Spacebars.call(view.lookup("hasPosts"));                                                                  // 8
  }, function() {                                                                                                    // 9
    return [ "\n\n      ", HTML.Comment('<div class="side-a small-12 medium-3 columns">\n\n        <div class="bz-posts-items-owner-menu">\n          <ul class="bz-nav bz-nav-side-a">\n            <li class="active"><a href="#">Your posts</a></li>\n            <li><a href="#">Posts Requirements</a></li>\n          </ul>\n        </div>\n\n\n      </div>'), "\n\n      ", HTML.Comment("SIDE B"), "\n      ", HTML.Comment('<div class="side-b small-12 medium-9 large-9 columns">'), "\n    \n       \n        ", HTML.DIV("\n            ", HTML.DIV({
      "class": "bz-posts-items-owner-post-menu"                                                                      // 11
    }, "\n                ", HTML.UL({                                                                               // 12
      "class": "tabs bz-nav bz-horizontal bz-nav-side-b",                                                            // 13
      "data-tab": ""                                                                                                 // 14
    }, "\n                    ", HTML.LI({                                                                           // 15
      "class": "tab-title active"                                                                                    // 16
    }, HTML.A({                                                                                                      // 17
      id: "active",                                                                                                  // 18
      href: "#allPosts",                                                                                             // 19
      "aria-selected": "true",                                                                                       // 20
      tabindex: "0"                                                                                                  // 21
    }, "All")), "\n                    ", HTML.LI({                                                                  // 22
      "class": "tab-title"                                                                                           // 23
    }, HTML.A({                                                                                                      // 24
      id: "livePosts",                                                                                               // 25
      href: "#livePosts",                                                                                            // 26
      "aria-selected": "false",                                                                                      // 27
      tabindex: "0"                                                                                                  // 28
    }, "Live ", HTML.Comment("({{ getCountLivePosts }})"))), "\n                    ", HTML.LI({                     // 29
      "class": "tab-title"                                                                                           // 30
    }, HTML.A({                                                                                                      // 31
      id: "activePosts",                                                                                             // 32
      href: "#activePosts",                                                                                          // 33
      "aria-selected": "false",                                                                                      // 34
      tabindex: "0"                                                                                                  // 35
    }, "Active ", HTML.Comment("({{ getCountActivePosts }})"))), "\n                "), "\n            "), "\n                        \n            ", HTML.DIV({
      "class": "tabs-content"                                                                                        // 37
    }, "\n                ", HTML.DIV({                                                                              // 38
      "class": "content active",                                                                                     // 39
      id: "allPosts",                                                                                                // 40
      "aria-hidden": "false"                                                                                         // 41
    }, "\n                    ", Blaze.Each(function() {                                                             // 42
      return Spacebars.call(view.lookup("allPosts"));                                                                // 43
    }, function() {                                                                                                  // 44
      return [ "\n                        ", Spacebars.include(view.lookupTemplate("onePostRowItemOwner")), "\n                    " ];
    }), "\n                "), "\n                ", HTML.DIV({                                                      // 46
      "class": "content",                                                                                            // 47
      id: "livePosts",                                                                                               // 48
      "aria-hidden": "true"                                                                                          // 49
    }, "\n                    ", Blaze.Each(function() {                                                             // 50
      return Spacebars.call(view.lookup("livePosts"));                                                               // 51
    }, function() {                                                                                                  // 52
      return [ "\n                        ", Spacebars.include(view.lookupTemplate("onePostRowItemOwner")), "\n                    " ];
    }), "\n                "), "\n                ", HTML.DIV({                                                      // 54
      "class": "content",                                                                                            // 55
      id: "activePosts",                                                                                             // 56
      "aria-hidden": "true"                                                                                          // 57
    }, "\n                    ", Blaze.Each(function() {                                                             // 58
      return Spacebars.call(view.lookup("activePosts"));                                                             // 59
    }, function() {                                                                                                  // 60
      return [ "\n                        ", Spacebars.include(view.lookupTemplate("onePostRowItemOwner")), "\n                    " ];
    }), "\n                "), "\n                \n            "), "\n        "), "\n    \n    \n        \n    \n    \n    \n    \n    \n    \n\n      ", HTML.Comment("</div>"), "\n\n      ", HTML.DIV({
      "class": "clearfix"                                                                                            // 63
    }), "\n\n\n      ", HTML.Comment("<div class=\"item item-divider item-active\">\n                {{t9n 'inactive'}}\n            </div>\n            {{#each inactivePosts}}\n        {{> onePostRowItem}}\n      {{/each}}"), "\n    " ];
  }, function() {                                                                                                    // 65
    return [ "\n      ", Spacebars.include(view.lookupTemplate("noPosts")), "\n    " ];                              // 66
  }), "\n\n  ");                                                                                                     // 67
}));                                                                                                                 // 68
                                                                                                                     // 69
Template.__checkName("onePostRowItem");                                                                              // 70
Template["onePostRowItem"] = new Template("Template.onePostRowItem", (function() {                                   // 71
  var view = this;                                                                                                   // 72
  return HTML.DIV({                                                                                                  // 73
    "class": "bz-item bz-item-fixed"                                                                                 // 74
  }, "\n    ", HTML.DIV({                                                                                            // 75
    "class": "bz-item-mask"                                                                                          // 76
  }, "\n      ", HTML.A({                                                                                            // 77
    href: function() {                                                                                               // 78
      return [ "/post/", Spacebars.mustache(view.lookup("_id")) ];                                                   // 79
    }                                                                                                                // 80
  }, "\n        ", HTML.DIV({                                                                                        // 81
    "class": "bz-item-photo"                                                                                         // 82
  }, "\n          ", Blaze.If(function() {                                                                           // 83
    return Spacebars.call(Spacebars.dot(view.lookup("getPhotoUrl"), "data"));                                        // 84
  }, function() {                                                                                                    // 85
    return [ "\n            ", HTML.IMG({                                                                            // 86
      src: function() {                                                                                              // 87
        return Spacebars.mustache(Spacebars.dot(view.lookup("getPhotoUrl"), "data"));                                // 88
      }                                                                                                              // 89
    }), "\n          " ];                                                                                            // 90
  }, function() {                                                                                                    // 91
    return [ "\n            ", HTML.IMG({                                                                            // 92
      src: "/img/content/no-photo.png"                                                                               // 93
    }), "\n          " ];                                                                                            // 94
  }), "\n        "), "\n\n        ", HTML.DIV({                                                                      // 95
    "class": "bz-item-content"                                                                                       // 96
  }, "\n          ", HTML.DIV({                                                                                      // 97
    "class": "bz-item-content-context"                                                                               // 98
  }, "\n              ", HTML.DIV({                                                                                  // 99
    "class": "bz-item-content-context-wrapper"                                                                       // 100
  }, "\n                  ", HTML.DIV({                                                                              // 101
    "class": function() {                                                                                            // 102
      return [ "bz-item-type type-category-", Spacebars.mustache(view.lookup("categoryType")) ];                     // 103
    }                                                                                                                // 104
  }, Blaze.View("lookup:categoryType", function() {                                                                  // 105
    return Spacebars.mustache(view.lookup("categoryType"));                                                          // 106
  })), "\n                  ", Blaze._TemplateWith(function() {                                                      // 107
    return Spacebars.call(view.lookup("."));                                                                         // 108
  }, function() {                                                                                                    // 109
    return Spacebars.include(view.lookupTemplate("bzPostsPostPresence"));                                            // 110
  }), "\n              "), "\n          "), "\n          ", HTML.H4({                                                // 111
    "class": "bz-item-title"                                                                                         // 112
  }, Blaze.View("lookup:details.title", function() {                                                                 // 113
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "title"));                                       // 114
  })), "\n\n          ", HTML.P({                                                                                    // 115
    "class": "bz-item-text"                                                                                          // 116
  }, Blaze.View("lookup:details.description", function() {                                                           // 117
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "description"));                                 // 118
  })), "\n          \n\n        "), "\n        ", HTML.DIV({                                                         // 119
    "class": "bz-item-footer"                                                                                        // 120
  }, "\n          ", HTML.DIV({                                                                                      // 121
    "class": "bz-item-views"                                                                                         // 122
  }, Blaze.View("lookup:t9n", function() {                                                                           // 123
    return Spacebars.mustache(view.lookup("t9n"), "views");                                                          // 124
  }), "  ", Blaze.View("lookup:stats.seenTotal", function() {                                                        // 125
    return Spacebars.mustache(Spacebars.dot(view.lookup("stats"), "seenTotal"));                                     // 126
  }), " ", HTML.SPAN({                                                                                               // 127
    "class": "today"                                                                                                 // 128
  }, "(", Blaze.View("lookup:stats.seenToday", function() {                                                          // 129
    return Spacebars.mustache(Spacebars.dot(view.lookup("stats"), "seenToday"));                                     // 130
  }), "\n            today)"), "\n          "), "\n        "), "\n\n      "), "\n    "), "\n    ", HTML.DIV({        // 131
    "class": "bz-tem-additional-tags"                                                                                // 132
  }, "\n      ", Blaze.If(function() {                                                                               // 133
    return Spacebars.call(Spacebars.dot(view.lookup("details"), "price"));                                           // 134
  }, function() {                                                                                                    // 135
    return [ "\n        ", HTML.DIV({                                                                                // 136
      "class": "price"                                                                                               // 137
    }, " ", Blaze.View("lookup:details.price", function() {                                                          // 138
      return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "price"));                                     // 139
    }), " ", HTML.SPAN({                                                                                             // 140
      "class": "bz-prefix"                                                                                           // 141
    }, "$")), "\n      " ];                                                                                          // 142
  }), "\n    "), "\n    ", HTML.DIV({                                                                                // 143
    "class": "bz-item-owner"                                                                                         // 144
  }, "\n      ", HTML.DIV({                                                                                          // 145
    "class": "bz-avatar",                                                                                            // 146
    style: function() {                                                                                              // 147
      return [ "background-image: url(", Spacebars.mustache(view.lookup("getAvatarImg")), ")" ];                     // 148
    }                                                                                                                // 149
  }), "\n      ", HTML.DIV({                                                                                         // 150
    "class": "bz-item-user-info"                                                                                     // 151
  }, "\n        ", HTML.DIV({                                                                                        // 152
    "class": "bz-username"                                                                                           // 153
  }, HTML.A({                                                                                                        // 154
    href: function() {                                                                                               // 155
      return [ "/user/", Spacebars.mustache(view.lookup("userId")) ];                                                // 156
    }                                                                                                                // 157
  }, Blaze.View("lookup:getUserName", function() {                                                                   // 158
    return Spacebars.mustache(view.lookup("getUserName"));                                                           // 159
  }))), "\n        ", HTML.Raw('<!--<div class="bz-rating"></div>-->'), "\n      "), "\n    "), "\n  ");             // 160
}));                                                                                                                 // 161
                                                                                                                     // 162
Template.__checkName("onePostRowItemOwner");                                                                         // 163
Template["onePostRowItemOwner"] = new Template("Template.onePostRowItemOwner", (function() {                         // 164
  var view = this;                                                                                                   // 165
  return HTML.DIV({                                                                                                  // 166
    "class": "item"                                                                                                  // 167
  }, "\n\n    ", HTML.DIV({                                                                                          // 168
    "class": "bz-switch-activity-post"                                                                               // 169
  }, "\n      ", HTML.DIV({                                                                                          // 170
    "class": "switch-wrapper js-switch-wrapper"                                                                      // 171
  }, "\n          ", HTML.DIV({                                                                                      // 172
    "class": "switch bz-small"                                                                                       // 173
  }, "\n              ", HTML.INPUT(HTML.Attrs({                                                                     // 174
    id: function() {                                                                                                 // 175
      return [ "switch-activity-", Spacebars.mustache(view.lookup("_id")) ];                                         // 176
    },                                                                                                               // 177
    type: "checkbox",                                                                                                // 178
    "class": "js-switch-activity-input"                                                                              // 179
  }, function() {                                                                                                    // 180
    return Spacebars.attrMustache(view.lookup("getVisibilityVal"));                                                  // 181
  })), "\n              ", HTML.LABEL({                                                                              // 182
    "for": function() {                                                                                              // 183
      return [ "switch-activity-", Spacebars.mustache(view.lookup("_id")) ];                                         // 184
    }                                                                                                                // 185
  }), "\n          "), "\n      "), "\n    "), "\n      \n    ", HTML.A({                                            // 186
    href: function() {                                                                                               // 187
      return [ "/post/", Spacebars.mustache(view.lookup("_id")) ];                                                   // 188
    },                                                                                                               // 189
    "class": function() {                                                                                            // 190
      return [ " ", Blaze.If(function() {                                                                            // 191
        return Spacebars.call(view.lookup("_hasLivePresence"));                                                      // 192
      }, function() {                                                                                                // 193
        return " bz-post-live ";                                                                                     // 194
      }, function() {                                                                                                // 195
        return " bz-post-away ";                                                                                     // 196
      }), " " ];                                                                                                     // 197
    }                                                                                                                // 198
  }, "\n      ", HTML.DIV({                                                                                          // 199
    "class": "photo"                                                                                                 // 200
  }, "\n        ", HTML.DIV({                                                                                        // 201
    "class": "photo-wrapper"                                                                                         // 202
  }, "\n          ", Blaze.If(function() {                                                                           // 203
    return Spacebars.call(Spacebars.dot(view.lookup("getPhotoUrl"), "data"));                                        // 204
  }, function() {                                                                                                    // 205
    return [ "\n            ", HTML.IMG({                                                                            // 206
      src: function() {                                                                                              // 207
        return Spacebars.mustache(Spacebars.dot(view.lookup("getPhotoUrl"), "data"));                                // 208
      }                                                                                                              // 209
    }), "\n          " ];                                                                                            // 210
  }, function() {                                                                                                    // 211
    return [ "\n            ", HTML.IMG({                                                                            // 212
      src: "/img/content/no-photo.png"                                                                               // 213
    }), "\n          " ];                                                                                            // 214
  }), "\n        "), "\n      "), "\n    \n      ", HTML.DIV({                                                       // 215
    "class": "description"                                                                                           // 216
  }, "\n    \n        ", HTML.H3({                                                                                   // 217
    "class": "title"                                                                                                 // 218
  }, Blaze.View("lookup:details.title", function() {                                                                 // 219
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "title"));                                       // 220
  })), "\n    \n        ", Blaze.If(function() {                                                                     // 221
    return Spacebars.call(Spacebars.dot(view.lookup("details"), "price"));                                           // 222
  }, function() {                                                                                                    // 223
    return [ "\n          ", HTML.DIV({                                                                              // 224
      "class": "price"                                                                                               // 225
    }, " ", Blaze.View("lookup:details.price", function() {                                                          // 226
      return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "price"));                                     // 227
    }), " ", HTML.SPAN({                                                                                             // 228
      "class": "bz-prefix"                                                                                           // 229
    }, "$")), "\n        " ];                                                                                        // 230
  }), "\n        ", HTML.DIV({                                                                                       // 231
    "class": "bz-count-view"                                                                                         // 232
  }, Blaze.View("lookup:t9n", function() {                                                                           // 233
    return Spacebars.mustache(view.lookup("t9n"), "views");                                                          // 234
  }), ": ", Blaze.View("lookup:stats.seenTotal", function() {                                                        // 235
    return Spacebars.mustache(Spacebars.dot(view.lookup("stats"), "seenTotal"));                                     // 236
  }), ", today ", HTML.SPAN({                                                                                        // 237
    "class": "today"                                                                                                 // 238
  }, " ", Blaze.View("lookup:stats.seenToday", function() {                                                          // 239
    return Spacebars.mustache(Spacebars.dot(view.lookup("stats"), "seenToday"));                                     // 240
  }))), "\n        ", Blaze.If(function() {                                                                          // 241
    return Spacebars.call(Spacebars.dot(view.lookup("details"), "duration"));                                        // 242
  }, function() {                                                                                                    // 243
    return [ "\n          ", HTML.DIV({                                                                              // 244
      "class": "bz-progress"                                                                                         // 245
    }, Blaze.View("lookup:t9n", function() {                                                                         // 246
      return Spacebars.mustache(view.lookup("t9n"), "left");                                                         // 247
    }), ": 15 days"), "\n        " ];                                                                                // 248
  }), "\n    \n      "), "\n    "), "\n\n    ", HTML.DIV({                                                           // 249
    "class": "bz-services"                                                                                           // 250
  }, "\n          ", HTML.DIV({                                                                                      // 251
    "class": "bz-services-wrapper"                                                                                   // 252
  }, "\n              \n              ", Blaze._TemplateWith(function() {                                            // 253
    return Spacebars.call(view.lookup("."));                                                                         // 254
  }, function() {                                                                                                    // 255
    return Spacebars.include(view.lookupTemplate("bzPostsPostPresence"));                                            // 256
  }), "\n              \n          "), "\n    "), "\n      \n  ");                                                   // 257
}));                                                                                                                 // 258
                                                                                                                     // 259
Template.__checkName("noPosts");                                                                                     // 260
Template["noPosts"] = new Template("Template.noPosts", (function() {                                                 // 261
  var view = this;                                                                                                   // 262
  return HTML.DIV({                                                                                                  // 263
    "class": "bz-wrapper-no-message"                                                                                 // 264
  }, "\n    ", HTML.DIV({                                                                                            // 265
    "class": "bz-flex-box"                                                                                           // 266
  }, "\n\n      ", HTML.Raw('<div class="bz-img-conversation">\n        <i class="fa fa-envelope"></i>\n      </div>'), "\n\n      ", HTML.Raw('<div class="title-message">You have no posts yet</div>'), "\n      ", HTML.Raw('<div class="subtitle-message">Press button below.</div>'), "\n\n      ", HTML.DIV({
    "class": "bz-padding-top-x2"                                                                                     // 268
  }, "\n        ", HTML.A({                                                                                          // 269
    href: function() {                                                                                               // 270
      return Spacebars.mustache(view.lookup("pathFor"), "postsNew");                                                 // 271
    },                                                                                                               // 272
    "class": "button alert"                                                                                          // 273
  }, "New Post"), "\n      "), "\n    "), "\n  ");                                                                   // 274
}));                                                                                                                 // 275
                                                                                                                     // 276
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/my-posts/my-items.js                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by douson on 24.08.15.                                                                                    // 2
 */                                                                                                                  // 3
                                                                                                                     // 4
Template.myItems.onCreated(function () {                                                                             // 5
  //return Meteor.subscribe('posts-images');                                                                         // 6
});                                                                                                                  // 7
                                                                                                                     // 8
                                                                                                                     // 9
Template.onePostRowItem.rendered = function() {                                                                      // 10
  /*init Rate*/                                                                                                      // 11
  $('.bz-rating').raty({                                                                                             // 12
    starType: 'i'                                                                                                    // 13
  });                                                                                                                // 14
};                                                                                                                   // 15
                                                                                                                     // 16
                                                                                                                     // 17
                                                                                                                     // 18
Template.myItems.onRendered(function () {                                                                            // 19
  $(document).foundation();                                                                                          // 20
});                                                                                                                  // 21
                                                                                                                     // 22
                                                                                                                     // 23
                                                                                                                     // 24
Template.myItems.helpers({                                                                                           // 25
  hasPosts: function () {                                                                                            // 26
    var posts = bz.cols.posts.find({userId: Meteor.userId()}).fetch();                                               // 27
    return posts.length !== 0;                                                                                       // 28
  },                                                                                                                 // 29
  allPosts: function () {                                                                                            // 30
    var posts = bz.cols.posts.find({userId: Meteor.userId()});                                                       // 31
    console.log('all' + posts.count());                                                                              // 32
                                                                                                                     // 33
    return posts;                                                                                                    // 34
  },                                                                                                                 // 35
  activePosts: function () {                                                                                         // 36
    var posts = bz.cols.posts.find({userId: Meteor.userId(), 'status.visible': 'visible'});                          // 37
    console.log('active' + posts.count());                                                                           // 38
    return posts;                                                                                                    // 39
  },                                                                                                                 // 40
  livePosts: function () {                                                                                           // 41
    var posts = bz.cols.posts.find({userId: Meteor.userId()}).fetch();                                               // 42
    var ret = _.filter(posts, function(item){                                                                        // 43
      var ret = !!item._hasLivePresence();                                                                           // 44
      return ret;                                                                                                    // 45
    });                                                                                                              // 46
    console.log('live' + ret.length);                                                                                // 47
    return ret;                                                                                                      // 48
  },                                                                                                                 // 49
  getCountActivePosts: function() {                                                                                  // 50
    //var postsCount = bz.cols.posts.find({userId: Meteor.userId()}).count();                                        // 51
    //return postsCount || '0';                                                                                      // 52
  },                                                                                                                 // 53
  getCountLivePosts: function() {                                                                                    // 54
    //var postsCount;                                                                                                // 55
    //return postsCount || '0';                                                                                      // 56
  }                                                                                                                  // 57
});                                                                                                                  // 58
                                                                                                                     // 59
Template.onePostRowItem.helpers({                                                                                    // 60
  getPhotoUrl: function () {                                                                                         // 61
    var photo = bz.cols.posts.findOne({_id: this._id}),                                                              // 62
      photoId = photo.details.photos && photo.details.photos[0] || undefined;                                        // 63
                                                                                                                     // 64
    if (photoId) {                                                                                                   // 65
      var image = bz.cols.images.findOne({_id: photoId});                                                            // 66
    }                                                                                                                // 67
                                                                                                                     // 68
    return image;                                                                                                    // 69
                                                                                                                     // 70
  },                                                                                                                 // 71
  getPrice: function () {},                                                                                          // 72
  categoryType: function() {                                                                                         // 73
    return bz.cols.posts.find({_id: this._id}).fetch()[0].type;                                                      // 74
  },                                                                                                                 // 75
  getAvatarImg: function () {                                                                                        // 76
    var ret ='';                                                                                                     // 77
    if(this.userId && Meteor.users.findOne(this.userId) && Meteor.users.findOne(this.userId).profile.image) {        // 78
      return ret = Meteor.users.findOne(this.userId).profile.image.data;                                             // 79
                                                                                                                     // 80
    } else {                                                                                                         // 81
      return '/img/content/avatars/avatar-no.png';                                                                   // 82
    }                                                                                                                // 83
  },                                                                                                                 // 84
  getUserName: function() {                                                                                          // 85
    var ret = '';                                                                                                    // 86
    if(this.userId && Meteor.users.findOne(this.userId)) {                                                           // 87
      ret = Meteor.users.findOne(this.userId).username.toCapitalCase();                                              // 88
    }                                                                                                                // 89
    return ret;                                                                                                      // 90
  }                                                                                                                  // 91
});                                                                                                                  // 92
                                                                                                                     // 93
                                                                                                                     // 94
                                                                                                                     // 95
                                                                                                                     // 96
/*                                                                                                                   // 97
* Template for owner posts                                                                                           // 98
*/                                                                                                                   // 99
                                                                                                                     // 100
Template.onePostRowItemOwner.events({                                                                                // 101
  'click .js-switch-wrapper': function(e, v){                                                                        // 102
  },                                                                                                                 // 103
  'click .js-switch-activity-input': function(e,v){                                                                  // 104
    if(v.data) {                                                                                                     // 105
      v.data.status = v.data.status || {}                                                                            // 106
                                                                                                                     // 107
      if (e.target.checked === false) {                                                                              // 108
        v.data.status.visible = null;                                                                                // 109
      } else {                                                                                                       // 110
        v.data.status.visible = 'visible';                                                                           // 111
      }                                                                                                              // 112
      setTimeout(function(){                                                                                         // 113
        bz.cols.posts.update(v.data._id, {$set: {'status.visible': v.data.status.visible}})                          // 114
      }, 10);                                                                                                        // 115
    }                                                                                                                // 116
  }                                                                                                                  // 117
})                                                                                                                   // 118
Template.onePostRowItemOwner.helpers({                                                                               // 119
  getPhotoUrl: function () {                                                                                         // 120
    var photo = bz.cols.posts.findOne({_id: this._id}),                                                              // 121
        photoId = photo && photo.details.photos && photo.details.photos[0] || undefined;                             // 122
                                                                                                                     // 123
    if (photoId) {                                                                                                   // 124
      var image = bz.cols.images.findOne({_id: photoId});                                                            // 125
    }                                                                                                                // 126
                                                                                                                     // 127
    return image;                                                                                                    // 128
                                                                                                                     // 129
  },                                                                                                                 // 130
  getPrice: function () {},                                                                                          // 131
  categoryType: function() {                                                                                         // 132
    return bz.cols.posts.find({_id: this._id}).fetch()[0].type;                                                      // 133
  },                                                                                                                 // 134
  getAvatarImg: function () {                                                                                        // 135
    var ret ='';                                                                                                     // 136
                                                                                                                     // 137
    if(this.userId && Meteor.users.findOne(this.userId) && Meteor.users.findOne(this.userId).profile.image) {        // 138
      return ret = Meteor.users.findOne(this.userId).profile.image;                                                  // 139
    } else {                                                                                                         // 140
      return '/img/content/avatars/avatar-no.png';                                                                   // 141
    }                                                                                                                // 142
  },                                                                                                                 // 143
  getUserName: function() {                                                                                          // 144
    var ret = '';                                                                                                    // 145
    if(this.userId && Meteor.users.findOne(this.userId)) {                                                           // 146
      ret = Meteor.users.findOne(this.userId).username.toCapitalCase();                                              // 147
    }                                                                                                                // 148
    return ret;                                                                                                      // 149
  },                                                                                                                 // 150
  getVisibilityVal: function(e,v,c){                                                                                 // 151
    var ret;                                                                                                         // 152
    if(this.status.visible === 'visible'){                                                                           // 153
      ret = 'checked'                                                                                                // 154
    } else {                                                                                                         // 155
      ret = '';                                                                                                      // 156
    }                                                                                                                // 157
    return ret;                                                                                                      // 158
  }                                                                                                                  // 159
});                                                                                                                  // 160
                                                                                                                     // 161
                                                                                                                     // 162
                                                                                                                     // 163
                                                                                                                     // 164
                                                                                                                     // 165
                                                                                                                     // 166
                                                                                                                     // 167
                                                                                                                     // 168
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/my-posts/template.page-my.js                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("postsMy");                                                                                     // 2
Template["postsMy"] = new Template("Template.postsMy", (function() {                                                 // 3
  var view = this;                                                                                                   // 4
  return HTML.DIV({                                                                                                  // 5
    "class": "main-content"                                                                                          // 6
  }, "\n        ", HTML.DIV({                                                                                        // 7
    "class": "bz-wrapper-messages"                                                                                   // 8
  }, "\n            \n            ", Spacebars.include(view.lookupTemplate("bzOwnerItemsToolbar")), "\n            \n            ", Spacebars.include(view.lookupTemplate("myItems")), "\n            \n        "), "\n    ");
}));                                                                                                                 // 10
                                                                                                                     // 11
Template.__checkName("bzOwnerItemsToolbar");                                                                         // 12
Template["bzOwnerItemsToolbar"] = new Template("Template.bzOwnerItemsToolbar", (function() {                         // 13
  var view = this;                                                                                                   // 14
  return HTML.Raw('<div class="bz-toolbar bz-owner-items-toolbar">\n        <div class="bz-owner-items-wrapper">\n            <div>\n                <!--<div>Some menu </div>-->\n            </div>\n            <!--<div class="bz-switch-activity-items">\n                <div class="switch-wrapper">\n                    <label>Activity posts</label>\n                    <div class="switch small">\n                        <input id="exampleCheckboxSwitch" type="checkbox">\n                        <label for="exampleCheckboxSwitch"></label>\n                    </div>\n                </div>\n            </div>-->\n        </div>\n    </div>');
}));                                                                                                                 // 16
                                                                                                                     // 17
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/my-posts/page-my.js                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by douson on 24.08.15.                                                                                    // 2
 */                                                                                                                  // 3
                                                                                                                     // 4
Template.postsMy.events({                                                                                            // 5
    'click .toggle-checked-state': function() {                                                                      // 6
        /*Set state active/inactive*/                                                                                // 7
    }                                                                                                                // 8
});                                                                                                                  // 9
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/template.new-post-controls.js                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("postsNewForm");                                                                                // 2
Template["postsNewForm"] = new Template("Template.postsNewForm", (function() {                                       // 3
  var view = this;                                                                                                   // 4
  return [ HTML.DIV({                                                                                                // 5
    "class": "item-group"                                                                                            // 6
  }, "\n    ", HTML.Raw('<div class="item item-divider ">\n      <h3 class="title">Basic</h3>\n    </div>'), "\n    ", HTML.DIV({
    "class": "row"                                                                                                   // 8
  }, "\n      ", Spacebars.include(view.lookupTemplate("postsNewUrl")), "\n    "), "\n    ", HTML.DIV({              // 9
    "class": "row"                                                                                                   // 10
  }, "\n      ", Spacebars.include(view.lookupTemplate("postDetailsCommon")), "\n    "), "\n\n    ", HTML.DIV({      // 11
    "class": "row"                                                                                                   // 12
  }, "\n      ", Spacebars.include(view.lookupTemplate("postTypeSelect")), "\n    "), "\n    ", HTML.Raw('<div class="row">\n        <div class="js-post-details-categorized"></div>\n    </div>'), "\n    ", HTML.Raw('<div class="item item-divider ">\n      <h3 class="title">Location</h3>\n    </div>'), "\n\n    ", Spacebars.include(view.lookupTemplate("postsPlacesAutoform")), "\n\n  "), "\n\n\n  ", HTML.DIV({
    "class": "item-group"                                                                                            // 14
  }, "\n    ", HTML.Raw('<div class="item item-divider">\n      <h3 class="title">Photos</h3>\n    </div>'), "\n    ", HTML.Raw('<!--<div class="clearfix">-->'), "\n    ", HTML.DIV({
    "class": "row"                                                                                                   // 16
  }, "\n      ", Spacebars.include(view.lookupTemplate("postPhotoUpload")), "\n    "), "\n\n    ", HTML.Raw('<div class="row">\n      <!--{{> postHashesControl }}-->\n    </div>'), "\n    ", HTML.Raw('<!--<div class="row">\n      {{> postProfileInfo }}\n    </div>-->'), "\n  ") ];
}));                                                                                                                 // 18
                                                                                                                     // 19
Template.__checkName("postTypeSelect");                                                                              // 20
Template["postTypeSelect"] = new Template("Template.postTypeSelect", (function() {                                   // 21
  var view = this;                                                                                                   // 22
  return HTML.DIV({                                                                                                  // 23
    "class": "clearfix"                                                                                              // 24
  }, "\n    ", HTML.DIV({                                                                                            // 25
    "class": "item-details"                                                                                          // 26
  }, "\n      ", HTML.LABEL({                                                                                        // 27
    "class": "item item-input item-select"                                                                           // 28
  }, "\n        ", HTML.Raw('<div class="small-12 medium-3 input-label left">Select type</div>'), "\n        ", HTML.DIV({
    "class": "small-12 medium-9 large-9 left"                                                                        // 30
  }, "\n          ", HTML.SELECT({                                                                                   // 31
    "class": "js-post-type-select"                                                                                   // 32
  }, "\n            ", Blaze.Each(function() {                                                                       // 33
    return Spacebars.call(view.lookup("getSiteTypes"));                                                              // 34
  }, function() {                                                                                                    // 35
    return [ "\n              ", HTML.OPTION({                                                                       // 36
      value: function() {                                                                                            // 37
        return Spacebars.mustache(view.lookup("name"));                                                              // 38
      }                                                                                                              // 39
    }, Blaze.View("lookup:fullName", function() {                                                                    // 40
      return Spacebars.mustache(view.lookup("fullName"));                                                            // 41
    })), "\n            " ];                                                                                         // 42
  }), "\n          "), "\n        "), "\n      "), "\n    "), "\n  ");                                               // 43
}));                                                                                                                 // 44
                                                                                                                     // 45
Template.__checkName("postDetailsCommon");                                                                           // 46
Template["postDetailsCommon"] = new Template("Template.postDetailsCommon", (function() {                             // 47
  var view = this;                                                                                                   // 48
  return [ HTML.DIV({                                                                                                // 49
    "class": "clearfix"                                                                                              // 50
  }, "\n    ", HTML.DIV({                                                                                            // 51
    "class": "item-details"                                                                                          // 52
  }, "\n\n      ", HTML.LABEL({                                                                                      // 53
    "class": "item item-input"                                                                                       // 54
  }, "\n        ", HTML.Raw('<div class="small-12 medium-3 input-label left">Title</div>'), "\n        ", HTML.DIV({ // 55
    "class": "small-12 medium-9 large-9 left"                                                                        // 56
  }, "\n          ", HTML.INPUT({                                                                                    // 57
    "class": "js-post-title",                                                                                        // 58
    type: "text",                                                                                                    // 59
    "label-type": "stacked",                                                                                         // 60
    name: "title",                                                                                                   // 61
    required: "",                                                                                                    // 62
    "data-schema-key": "title",                                                                                      // 63
    maxlength: "200",                                                                                                // 64
    value: function() {                                                                                              // 65
      return Spacebars.mustache(view.lookup("getTitle"));                                                            // 66
    }                                                                                                                // 67
  }), "\n        "), "\n      "), "\n    "), "\n  "), "\n\n  ", HTML.DIV({                                           // 68
    "class": "clearfix"                                                                                              // 69
  }, "\n    ", HTML.DIV({                                                                                            // 70
    "class": "item-details"                                                                                          // 71
  }, "\n      ", HTML.LABEL({                                                                                        // 72
    type: "stacked",                                                                                                 // 73
    "class": "item item-input item-stacked-label"                                                                    // 74
  }, "\n        ", HTML.Raw('<div class="small-12 medium-3 input-label left">Description</div>'), "\n        ", HTML.DIV({
    "class": "small-12 medium-9 large-9 left"                                                                        // 76
  }, "\n                        ", HTML.TEXTAREA({                                                                   // 77
    "class": "js-post-description",                                                                                  // 78
    rows: "3",                                                                                                       // 79
    "label-type": "stacked",                                                                                         // 80
    name: "body",                                                                                                    // 81
    required: "",                                                                                                    // 82
    "data-schema-key": "body",                                                                                       // 83
    value: function() {                                                                                              // 84
      return Spacebars.mustache(view.lookup("getDescription"));                                                      // 85
    }                                                                                                                // 86
  }), "\n        "), "\n      "), "\n    "), "\n  ") ];                                                              // 87
}));                                                                                                                 // 88
                                                                                                                     // 89
Template.__checkName("postPhotoUpload");                                                                             // 90
Template["postPhotoUpload"] = new Template("Template.postPhotoUpload", (function() {                                 // 91
  var view = this;                                                                                                   // 92
  return [ HTML.DIV({                                                                                                // 93
    "class": "post-photo-upload"                                                                                     // 94
  }, "\n    ", HTML.Raw('<!--<div class="image-holder js-image-holder js-get-picture" style="background-image:url(\'/img/content/avatars/avatar-no.png\');"></div>-->'), "\n    ", HTML.DIV({
    "class": "bz-owner-photo-wrap"                                                                                   // 96
  }, "\n      ", HTML.Raw('<!--gallery:\n      <ul class="clearing-thumbs clearing-feature" data-clearing>\n        <li class="clearing-featured-img">\n          <a href="http://www.stepfordwives.org/diary/wp-content/uploads/2014/01/stepford-wife-organization-perfect-proportion1.jpg">\n            <img src="http://www.stepfordwives.org/diary/wp-content/uploads/2014/01/stepford-wife-organization-perfect-proportion1.jpg">\n          </a>\n        </li>\n      </ul>-->'), "\n      ", HTML.DIV({
    "class": "img-avatar js-edit-avatar"                                                                             // 98
  }, "\n        ", HTML.UL({                                                                                         // 99
    "class": "clearing-thumbs clearing-feature",                                                                     // 100
    "data-clearing": ""                                                                                              // 101
  }, "\n          ", HTML.Raw('<!--<li class="clearing-featured-img">\n            <a href="http://localhost:3000/img/content/avatars/avatar-no.png" onclick="return false;">\n              <img src="http://localhost:3000/img/content/avatars/avatar-no.png" style="height: 50px;">\n            </a>\n          </li>-->'), "\n          ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("getPostImages"));                                                             // 103
  }, function() {                                                                                                    // 104
    return [ "\n            ", HTML.LI({                                                                             // 105
      "class": "clearing-featured-img"                                                                               // 106
    }, "\n              ", HTML.A({                                                                                  // 107
      onclick: "return false;"                                                                                       // 108
    }, "\n                ", HTML.IMG({                                                                              // 109
      src: function() {                                                                                              // 110
        return Spacebars.mustache(view.lookup("data"));                                                              // 111
      }                                                                                                              // 112
    }), "\n              "), "\n              ", HTML.Comment('<a href="{{ getImageSrc }}" onclick="return false;">\n              <img src="{{ getImageSrc }}">\n            </a>'), "\n            "), "\n          " ];
  }), "\n          ", HTML.Raw('<a class="js-plus-img"><img src="/img/plus-button.png"> </a>'), "\n\n          ", HTML.Raw("<!--<li></li>-->"), "\n        "), "\n        ", HTML.Raw('<!--<img src="{{ getImageSrc }}" width="60" height="60">-->'), "\n      "), "\n    "), "\n\n    ", HTML.Raw('<!--<a class="js-get-picture button">get pic</a>\n    <br/>\n    <a class="js-get-picture-lib button">get pic lib</a>-->'), "\n  "), "\n\n  ", HTML.DIV({
    "class": "reveal-modal js-avatar-upload-modal",                                                                  // 115
    "data-reveal": "",                                                                                               // 116
    "aria-labelledby": "modalTitle",                                                                                 // 117
    "aria-hidden": "true",                                                                                           // 118
    role: "dialog"                                                                                                   // 119
  }, "\n    ", Blaze._TemplateWith(function() {                                                                      // 120
    return {                                                                                                         // 121
      sessionName: Spacebars.call("bz.posts.postImgArr")                                                             // 122
    };                                                                                                               // 123
  }, function() {                                                                                                    // 124
    return Spacebars.include(view.lookupTemplate("uploadImageModal"));                                               // 125
  }), "\n  ") ];                                                                                                     // 126
}));                                                                                                                 // 127
                                                                                                                     // 128
Template.__checkName("postDetailsHelp");                                                                             // 129
Template["postDetailsHelp"] = new Template("Template.postDetailsHelp", (function() {                                 // 130
  var view = this;                                                                                                   // 131
  return HTML.Raw('<div class="clearfix padding-top">\n    <label class="item item-input item-select">\n        <div class="small-12 medium-3 input-label left">Describe</div>\n        <div class="small-12 medium-9 large-9 left">\n\n            <div class="bz-describe-wrapper">\n                <div class="panel radius">Lost my pet</div>\n                <div class="panel radius">Need money for food</div>\n                <div class="panel radius">Emergency situation</div>\n                <div class="panel radius">Other</div>\n            </div>\n\n            <ul class="small-block-grid-2 medium-block-grid-3 large-block-grid-4 hidden">\n                <li class="panel radius">\n                    <div>Lost my pet</div>\n                </li>\n                <li class="panel radius">\n                    <div>Need money for food</div>\n                </li>\n                <li class="panel radius">\n                    <div>Emergency situation</div>\n                </li>\n                <li class="panel radius">\n                    <div>Other</div>\n                </li>\n            </ul>\n        </div>\n\n        <div class="medium-5 large-7 left hidden">\n            <select class="js-charity-type-select">\n                <option value="roommates">Lost my pet</option>\n                <option value="rent">Need money for food</option>\n                <option value="buy">Emergency situation</option>\n                <option value="buy">Other:</option>\n            </select>\n        </div>\n    </label>\n  </div>');
}));                                                                                                                 // 133
                                                                                                                     // 134
Template.__checkName("postDetailsConnect");                                                                          // 135
Template["postDetailsConnect"] = new Template("Template.postDetailsConnect", (function() {                           // 136
  var view = this;                                                                                                   // 137
  return HTML.Raw('<div class="clearfix padding-top">\n    <label class="item item-input item-select">\n      <div class="medium-3 input-label left">I am looking for:</div>\n      <div class="medium-5 large-7 left">\n        <select class="js-charity-type-select">\n          <option value="artists">artists and other creative people</option>\n          <option value="friends">friends</option>\n          <option value="professionals">professionals</option>\n          <option value="other">Other:</option>\n        </select>\n      </div>\n    </label>\n  </div>');
}));                                                                                                                 // 139
                                                                                                                     // 140
Template.__checkName("postDetailsTrade");                                                                            // 141
Template["postDetailsTrade"] = new Template("Template.postDetailsTrade", (function() {                               // 142
  var view = this;                                                                                                   // 143
  return HTML.DIV({                                                                                                  // 144
    "class": "clearfix padding-top"                                                                                  // 145
  }, "\n    ", HTML.LABEL({                                                                                          // 146
    type: "stacked",                                                                                                 // 147
    "class": "item item-input item-stacked-label"                                                                    // 148
  }, "\n      ", HTML.Raw('<div class="medium-3 input-label left">Price</div>'), "\n      ", HTML.DIV({              // 149
    "class": "medium-5 large-7 left"                                                                                 // 150
  }, "\n        ", HTML.INPUT({                                                                                      // 151
    "class": "js-post-price",                                                                                        // 152
    type: "number",                                                                                                  // 153
    value: function() {                                                                                              // 154
      return Spacebars.mustache(view.lookup("getPrice"));                                                            // 155
    },                                                                                                               // 156
    "label-type": "stacked"                                                                                          // 157
  }), "\n      "), "\n    "), "\n  ");                                                                               // 158
}));                                                                                                                 // 159
                                                                                                                     // 160
Template.__checkName("postDetailsJobs");                                                                             // 161
Template["postDetailsJobs"] = new Template("Template.postDetailsJobs", (function() {                                 // 162
  var view = this;                                                                                                   // 163
  return HTML.Raw('<div class="clearfix padding-top">\n    <label class="item item-input">\n      <div class="medium-3 input-label left">Position</div>\n      <div class="medium-5 large-7 left">\n        <input class="js-job-title" type="text" label-type="stacked" name="title" maxlength="200">\n      </div>\n    </label>\n  </div>');
}));                                                                                                                 // 165
                                                                                                                     // 166
Template.__checkName("postDetailsHousing");                                                                          // 167
Template["postDetailsHousing"] = new Template("Template.postDetailsHousing", (function() {                           // 168
  var view = this;                                                                                                   // 169
  return HTML.Raw('<div class="clearfix padding-top">\n    <label class="item item-input item-select">\n      <div class="medium-3 input-label left">Looking for</div>\n      <div class="medium-5 large-7 left">\n        <select class="js-housing-type-select">\n          <option value="roommates">Roommates</option>\n          <option value="rent">Renting</option>\n          <option value="rentOut">Renting out</option>\n          <option value="buy">Buying a house</option>\n          <option value="sell">Selling a house</option>\n        </select>\n      </div>\n    </label>\n  </div>');
}));                                                                                                                 // 171
                                                                                                                     // 172
Template.__checkName("postHashesControl");                                                                           // 173
Template["postHashesControl"] = new Template("Template.postHashesControl", (function() {                             // 174
  var view = this;                                                                                                   // 175
  return [ HTML.DIV({                                                                                                // 176
    "class": "clearfix"                                                                                              // 177
  }, "\n    ", HTML.LABEL({                                                                                          // 178
    type: "stacked",                                                                                                 // 179
    "class": "item item-input item-stacked-label padding-right"                                                      // 180
  }, "\n      ", HTML.Raw('<div class="medium-3 input-label left">Hashes</div>'), "\n      ", HTML.DIV({             // 181
    "class": "medium-5 large-7 left"                                                                                 // 182
  }, "\n        ", HTML.BUTTON({                                                                                     // 183
    "class": "button button-block button-stable js-hashes-holder",                                                   // 184
    "data-action": "showPrompt"                                                                                      // 185
  }, Blaze.View("lookup:getHashes", function() {                                                                     // 186
    return Spacebars.mustache(view.lookup("getHashes"));                                                             // 187
  })), "\n      "), "\n    "), "\n  "), HTML.Raw('\n  <!--input with bottons know-how:-->\n  <!--<label class="item item-input item-stacked-label">\n      <span class="input-label">Original Url (optional)</span>\n      <div class="item item-input-inset">\n          <input name="url" placeholder="" class="original-url js-original-url" type="text">\n          <a name="original-post-details" class=" button button-small disabled js-post-details-link" href="/posts/new/original-details">\n              Check >>\n          </a>\n      </div>\n  </label>-->') ];
}));                                                                                                                 // 189
                                                                                                                     // 190
Template.__checkName("postProfileInfo");                                                                             // 191
Template["postProfileInfo"] = new Template("Template.postProfileInfo", (function() {                                 // 192
  var view = this;                                                                                                   // 193
  return HTML.Raw('<div class="clearfix">\n    <div class="item-details">\n      <div class="medium-3 input-label left">Incognito mode</div>\n      <div class="medium-5 large-7 left input-clear">\n        <input type="radio" name="pokemon" value="Red" id="pokemonRed"><label for="pokemonRed">Yes</label>\n        <input type="radio" name="pokemon" value="Blue" id="pokemonBlue"><label for="pokemonBlue">No</label>\n      </div>\n    </div>\n  </div>');
}));                                                                                                                 // 195
                                                                                                                     // 196
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/new-post-controls.js                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Template.postsNewForm.events({});                                                                                    // 1
Template.postTypeSelect.helpers({                                                                                    // 2
  getSiteTypes: function () {                                                                                        // 3
    return bz.cols.siteTypes.find();                                                                                 // 4
  }                                                                                                                  // 5
});                                                                                                                  // 6
Template.postTypeSelect.events({                                                                                     // 7
  'change .js-post-type-select': function (e, v) {                                                                   // 8
    var name = e.target.value.toCapitalCase();                                                                       // 9
    setPostDetailsTemplate(name, v);                                                                                 // 10
  }                                                                                                                  // 11
});                                                                                                                  // 12
Template.postTypeSelect.rendered = function () {                                                                     // 13
  var name = this.$('.js-post-type-select').val().toCapitalCase();                                                   // 14
  setPostDetailsTemplate(name, this);                                                                                // 15
}                                                                                                                    // 16
                                                                                                                     // 17
Template.postHashesControl.destroyed = function () {                                                                 // 18
  $('[data-action="buttonTapped"]').off();                                                                           // 19
}                                                                                                                    // 20
Template.postHashesControl.helpers({                                                                                 // 21
  getHashes: function () {                                                                                           // 22
    var arr = Session.get('hashes') || [];                                                                           // 23
    return arr.join(', ');                                                                                           // 24
  }                                                                                                                  // 25
})                                                                                                                   // 26
Template.postHashesControl.events({                                                                                  // 27
  'click [data-action="showPrompt"]': function (o, t) {                                                              // 28
    a = IonPopup.prompt({                                                                                            // 29
      title: "Hashes",                                                                                               // 30
      template: "Please enter hashes, separated by space",                                                           // 31
      okText: "Submit",                                                                                              // 32
      inputType: "text",                                                                                             // 33
      text: 'IonPopup',                                                                                              // 34
      inputPlaceholder: "Your Hashes"                                                                                // 35
      //js-hashes-holder                                                                                             // 36
    });                                                                                                              // 37
    $('[data-action="buttonTapped"]').click(function (e) {                                                           // 38
      var inpVal = $('input[name=prompt]').val();                                                                    // 39
      if ($(e.target).data().index === 0 && inpVal && inpVal.trim() !== '') {                                        // 40
        Session.set('hashes', inpVal.trim().split(' '));                                                             // 41
      }                                                                                                              // 42
    });                                                                                                              // 43
  }                                                                                                                  // 44
});                                                                                                                  // 45
Template.postDetailsHelp.events({                                                                                    // 46
  'click .panel': function(e,v){                                                                                     // 47
    $(e.target).closest('.panel').toggleClass('callout');                                                            // 48
  }                                                                                                                  // 49
});                                                                                                                  // 50
Template.postDetailsCommon.helpers({                                                                                 // 51
  getTitle: function () {                                                                                            // 52
    return Session.get('post-title') || '';                                                                          // 53
  },                                                                                                                 // 54
  getDescription: function () {                                                                                      // 55
    return Session.get('post-description') || '';                                                                    // 56
  }                                                                                                                  // 57
});                                                                                                                  // 58
//$('.backdrop.visible.active .popup .popup-title').text().toLowerCase()                                             // 59
                                                                                                                     // 60
Template.postDetailsTrade.helpers({                                                                                  // 61
  getPrice: function () {                                                                                            // 62
    return Session.get('post-price') || '';                                                                          // 63
  }                                                                                                                  // 64
});                                                                                                                  // 65
                                                                                                                     // 66
Template.postPhotoUpload.helpers({                                                                                   // 67
  getImageSrc: function () {                                                                                         // 68
    var ret = 'http://localhost:3000/img/content/avatars/avatar-no.png';                                             // 69
    return Session.get('bz.posts.postImgSrc') || ret;                                                                // 70
  },                                                                                                                 // 71
  getPostImages: function(){                                                                                         // 72
    var imgArr = Session.get('bz.posts.postImgArr');                                                                 // 73
    if(!imgArr || !Array.isArray(imgArr)) {                                                                          // 74
      imgArr = []                                                                                                    // 75
    } else {                                                                                                         // 76
    }                                                                                                                // 77
    return imgArr;                                                                                                   // 78
  }                                                                                                                  // 79
});                                                                                                                  // 80
Template.postPhotoUpload.events({                                                                                    // 81
  'click .js-edit-avatar': function (event, template) {                                                              // 82
    //$('.js-avatar-upload-modal').foundation('reveal', 'open');                                                     // 83
  },                                                                                                                 // 84
  'click .js-plus-img': function(e,v){                                                                               // 85
    $('.js-avatar-upload-modal').foundation('reveal', 'open');                                                       // 86
  }                                                                                                                  // 87
});                                                                                                                  // 88
                                                                                                                     // 89
                                                                                                                     // 90
function setPostDetailsTemplate(name, v) {                                                                           // 91
  $('.js-post-details-categorized').empty();                                                                         // 92
  Blaze.renderWithData(Template['postDetails' + name], v.data, $('.js-post-details-categorized')[0]);                // 93
}                                                                                                                    // 94
// set new image to db:                                                                                              // 95
Meteor.startup(function () {                                                                                         // 96
                                                                                                                     // 97
  Tracker.autorun(function () {                                                                                      // 98
    bz.runtime.newPost.postImage = Session.get('bz.posts.postImgSrc');                                               // 99
    bz.runtime.newPost.hashes = Session.get('hashes');                                                               // 100
  });                                                                                                                // 101
});                                                                                                                  // 102
                                                                                                                     // 103
                                                                                                                     // 104
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/template.add-new-location.js                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("bzControlAddNewLocation");                                                                     // 2
Template["bzControlAddNewLocation"] = new Template("Template.bzControlAddNewLocation", (function() {                 // 3
  var view = this;                                                                                                   // 4
  return HTML.Raw('<input class="form-control typeahead js-add-new-location" name="team" type="text" placeholder="Select location to add" data-sets="joinedArray" autocomplete="on" spellcheck="off" data-min-length="0" data-opened="opened" data-selected="selected1" data-template="teamList">');
}));                                                                                                                 // 6
                                                                                                                     // 7
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/add-new-location.js                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by arutu_000 on 9/28/2015.                                                                                // 2
 */                                                                                                                  // 3
Template.bzControlAddNewLocation.helpers({                                                                           // 4
  joinedArray: function () {                                                                                         // 5
    var ret = [{                                                                                                     // 6
      name: 'google-places',                                                                                         // 7
      valueKey: 'name',                                                                                              // 8
      displayKey: 'name',                                                                                            // 9
      template: 'googlePlacesItem',                                                                                  // 10
      header: '<h3 class="league-name">Please select/h3>',                                                           // 11
      local: function () {                                                                                           // 12
        ret =[                                                                                                       // 13
          'My live location',                                                                                        // 14
          'Pinned location'                                                                                          // 15
        ];                                                                                                           // 16
                                                                                                                     // 17
        return ret;                                                                                                  // 18
      }                                                                                                              // 19
    }]                                                                                                               // 20
    return ret;                                                                                                      // 21
  }                                                                                                                  // 22
});                                                                                                                  // 23
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/template.new-url.js                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("postsNewUrl");                                                                                 // 2
Template["postsNewUrl"] = new Template("Template.postsNewUrl", (function() {                                         // 3
  var view = this;                                                                                                   // 4
  return HTML.Raw('<!--<span>*note: try this url as a sample:-->\n        <!--<i>http://www.youcaring.com/ashley-reed-376889</i></span>-->\n    <div class="clearfix">\n        <div class="item-details">\n            <label class="item item-input item-stacked-label">\n                <!--<span class="input-label">Original Url (optional)</span>-->\n                <div class="item1 item-input-inset">\n                    <div class="small-12 medium-3 input-label left">Import from Web (optional)</div>\n                    <div class="small-12 medium-9 large-9 left">\n                        <div class="bz-flex-style">\n                            <div><input name="url" placeholder="Original Post Url" class="original-url error js-original-url" type="text"></div>\n                        <!--<small class="error hidden">Value is required</small>-->\n                            <div>\n                                <a name="original-post-details" class="button small disabled margin-left js-post-details-link" data-ion-modal="parsedPostDetailsModal">\n                                    Check >>\n                                </a>\n                            </div>\n                    </div>\n                </div>\n                    <!--<a name="original-post-details" class="button button-small disabled js-post-details-link" href="/posts/new/original-details" >-->\n                </div>\n            </label>\n        </div>\n        <input type="button" value="scan" class="js-scan-url hidden">\n    </div>');
}));                                                                                                                 // 6
                                                                                                                     // 7
Template.__checkName("parsedPostDetailsModal");                                                                      // 8
Template["parsedPostDetailsModal"] = new Template("Template.parsedPostDetailsModal", (function() {                   // 9
  var view = this;                                                                                                   // 10
  return HTML.Raw('<!--{{#ionModal title="Url Post Details"}}\n        <div class="padding">\n            Title: <span>{{ getTitle }}</span>\n        </div>\n    {{/ionModal}}-->');
}));                                                                                                                 // 12
                                                                                                                     // 13
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/new-url.js                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Template.postsNewUrl.created = function(){                                                                           // 1
};                                                                                                                   // 2
Template.postsNewUrl.events({                                                                                        // 3
  'keydown .js-original-url': function(e,v){                                                                         // 4
    var url = e.target.value;                                                                                        // 5
    if(e.keyCode === 13 &&  url!== '' && isUrl(url)) {                                                               // 6
      v.$('.js-post-details-link').click();                                                                          // 7
      //v.$('.js-scan-url').click();                                                                                 // 8
    } else {                                                                                                         // 9
      console.log('keydown');                                                                                        // 10
      if(isUrl(url)) {                                                                                               // 11
        v.$('.js-post-details-link').removeClass('disabled');                                                        // 12
      }                                                                                                              // 13
    }                                                                                                                // 14
  },                                                                                                                 // 15
  'paste .js-original-url': function(e,v){                                                                           // 16
    var pastedText = getClipBoardDataFromEvent(e);                                                                   // 17
    if(isUrl(pastedText)) {                                                                                          // 18
      v.$('.js-post-details-link').removeClass('disabled');                                                          // 19
    }                                                                                                                // 20
  },                                                                                                                 // 21
  'blur .js-original-url': function(e,v){                                                                            // 22
    var url = e.target.value;                                                                                        // 23
    if(isUrl(url)) {                                                                                                 // 24
      v.$('.js-post-details-link').removeClass('disabled');                                                          // 25
    }                                                                                                                // 26
  },                                                                                                                 // 27
  'click .js-post-details-link': function (e, v) {                                                                   // 28
    Meteor.call('parseUrl', v.$('.js-original-url').val(), function(err, res) {                                      // 29
      // async scan is done:                                                                                         // 30
      if(res && res.success) {                                                                                       // 31
        if (res.title){                                                                                              // 32
          Session.set('post-title', res.title);                                                                      // 33
        }                                                                                                            // 34
        if (res.content){                                                                                            // 35
          Session.set('post-description', res.content);                                                              // 36
        }                                                                                                            // 37
        if (res.imageUrl){                                                                                           // 38
          Session.set('bz.posts.postImgSrc', res.imageUrl);                                                          // 39
        }                                                                                                            // 40
      }                                                                                                              // 41
      v.$('.js-post-details-link').removeClass('disabled');                                                          // 42
    })                                                                                                               // 43
                                                                                                                     // 44
  }                                                                                                                  // 45
});                                                                                                                  // 46
Template.parsedPostDetailsModal.helpers({                                                                            // 47
  getTitle: function() {                                                                                             // 48
    return Session.get('post-title');                                                                                // 49
  }                                                                                                                  // 50
})                                                                                                                   // 51
// HELPERS:                                                                                                          // 52
function isUrl(str){                                                                                                 // 53
  var ret = false;                                                                                                   // 54
  if(ret !== '') {                                                                                                   // 55
    var urlRegEx = /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-]*)?\??(?:[\-\+=&;%@\.\w]*)#?(?:[\.\!\/\\\w]*))?)/g;
    ret = urlRegEx.test(str);                                                                                        // 57
  }                                                                                                                  // 58
  return ret;                                                                                                        // 59
}                                                                                                                    // 60
function getClipBoardDataFromEvent(e){                                                                               // 61
  var pastedText;                                                                                                    // 62
                                                                                                                     // 63
  if (window.clipboardData && window.clipboardData.getData) { // IE                                                  // 64
    pastedText = window.clipboardData.getData('Text');                                                               // 65
  } else if (e.originalEvent.clipboardData && e.originalEvent.clipboardData.getData) {                               // 66
    pastedText = e.originalEvent.clipboardData.getData('text/plain');                                                // 67
  } else if (window.event && window.event.clipboardData && window.event.clipboardData.getData) {                     // 68
    pastedText = window.event.clipboardData.getData('text/plain');                                                   // 69
  }                                                                                                                  // 70
  return pastedText;                                                                                                 // 71
}                                                                                                                    // 72
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/template.page-new.js                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("postsNew");                                                                                    // 2
Template["postsNew"] = new Template("Template.postsNew", (function() {                                               // 3
  var view = this;                                                                                                   // 4
  return HTML.DIV({                                                                                                  // 5
    "class": "main-content"                                                                                          // 6
  }, "\n                ", Spacebars.include(view.lookupTemplate("postsNewForm")), HTML.Raw('\n\n                <div class="padding">\n                    <button type="submit" class="button btn-default js-create-post">Create Post</button>\n                </div>\n            '));
}));                                                                                                                 // 8
                                                                                                                     // 9
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/new-post/page-new.js                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var data = bz.help.makeNamespace('bz.runtime.newPost');                                                              // 1
Template.postsNew.created = function () {                                                                            // 2
  this.data ? _.extend(this.data, data) : _.extend({}, data);                                                        // 3
                                                                                                                     // 4
  //temp                                                                                                             // 5
  /*Meteor.call('parseUrl', 'https://en.wikipedia.org/wiki/NASA', function(error, response){                         // 6
   if (response.success) {                                                                                           // 7
   console.log('success\ntitle: ' + response.title + '\nurl: ' + response.imageUrl + '\ncontent: ' + response.content);
   } else {                                                                                                          // 9
   console.log('failed');                                                                                            // 10
   }                                                                                                                 // 11
   });*/                                                                                                             // 12
                                                                                                                     // 13
};                                                                                                                   // 14
Template.postsNew.events({                                                                                           // 15
  'click .js-create-post': function (e, v) {                                                                         // 16
    createNewPostFromView(v);                                                                                        // 17
  }                                                                                                                  // 18
});                                                                                                                  // 19
                                                                                                                     // 20
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/template.places-autoform.js                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("postsPlacesAutoform");                                                                         // 2
Template["postsPlacesAutoform"] = new Template("Template.postsPlacesAutoform", (function() {                         // 3
  var view = this;                                                                                                   // 4
  return HTML.DIV({                                                                                                  // 5
    "class": "row"                                                                                                   // 6
  }, "\n        ", HTML.DIV({                                                                                        // 7
    "class": "view--places-autoform"                                                                                 // 8
  }, "\n    ", HTML.Raw("<!--{{> bzControlAddNewLocation }}-->"), "\n    ", HTML.DIV({                               // 9
    "class": "clearfix"                                                                                              // 10
  }, "\n        ", HTML.DIV({                                                                                        // 11
    "class": "item-details"                                                                                          // 12
  }, "\n      ", HTML.LABEL({                                                                                        // 13
    "class": "item item-input item-stacked-label"                                                                    // 14
  }, "\n\n          ", HTML.DIV({                                                                                    // 15
    "class": "choose-place-buttons"                                                                                  // 16
  }, "\n          ", HTML.Raw('<!--<a class="js-plus-img"><img src="/img/plus-button.png" style="width: 60px; height: 60px;"/> </a>-->'), "\n\n\n              ", HTML.Raw('<div class="small-12 medium-3 input-label left"></div>'), "\n              ", HTML.DIV({
    "class": "small-12 medium-9 large-9 left"                                                                        // 18
  }, "\n                  ", HTML.DIV({                                                                              // 19
    "class": "bz-location-position"                                                                                  // 20
  }, "\n                      ", HTML.Raw('<div class="bz-style-soft-background bz-dynamic bz-panel-overlay panel padding js-moving-location-panel">\n                          <i class="fa fa-map-signs"></i>\n\n                          <div class="title uppercase">Dynamic</div>\n\n                          <p>Moving with you ad</p>\n\n                          <!--<p class="hidden">Use my current location live (online when your app is running/you are logged in to the\n						  website).</p>-->\n\n                          <!--<div class="current-location-btn">\n							  <a class="button small button-calm js-current-location-a" style="display: none;">\n								  <i class="fa fa-location-arrow placeholder-icon"></i>\n							  </a>\n						  </div>-->\n                      </div>'), "\n\n                      ", HTML.DIV({
    "class": "bz-style-soft-background bz-static bz-panel-overlay panel padding js-fixed-location-panel",            // 22
    id: "moving-ad"                                                                                                  // 23
  }, "\n                          ", HTML.Raw('<i class="fa fa-thumb-tack"></i>'), "\n\n                          ", HTML.Raw('<div class="title uppercase">Static</div>'), "\n                          ", HTML.Raw("<p>Pinned to static location</p>"), "\n                          ", HTML.Raw('<!--<p class="hidden">Pinned Location (online when you are within a Radius from the board address)</p>-->'), "\n                    \n                  ", HTML.SPAN({
    "class": "js-location-holder"                                                                                    // 25
  }, "\n                      ", Blaze._TemplateWith(function() {                                                    // 26
    return {                                                                                                         // 27
      sessionName: Spacebars.call("bz.posts.new.location2")                                                          // 28
    };                                                                                                               // 29
  }, function() {                                                                                                    // 30
    return Spacebars.include(view.lookupTemplate("bzLocationNameNewPost"));                                          // 31
  }), "\n                  "), "\n                          ", HTML.Raw('<!--<p class="note">* If empty - Ad will be bound to your current location.</p>-->'), "\n\n                          ", HTML.Raw('<!--<div class="location-nearby js-location-nearby hidden">\n							<input class="form-control typeahead capitalize js-nearby-places" name="team" type="text" id="place1"\n								   placeholder="address, zip or place nearby"\n								   data-source="placesArray"\n			\n								   autocomplete="on" spellcheck="off"\n								   data-opened="opened" data-selected="selected"\n								   data-min-length="0"\n								   data-autocompleted="autocompleted"\n							  />\n						  </div>-->'), "\n                      "), "\n                  "), "\n            "), "\n\n\n              ", HTML.Raw('<!--\n	\n						<div class="small-12 medium-4 large-4 columns hidden">\n						  <div class="panel padding hidden">\n							<h5><strong class="uppercase">bulletin boards ad 2</strong></h5>\n	\n							<p>Pinned Location (online when you are within a Radius from the board address)</p>\n	\n							&lt;!&ndash;<p class="note">* If empty - Ad will be bound to your current location.</p>&ndash;&gt;\n	\n							<div class="location-nearby js-location-nearby">\n							  <input class="form-control typeahead capitalize js-nearby-places" name="team" type="text"\n									 placeholder="address, zip or place nearby"\n									 data-source="placesArray"\n	\n									 autocomplete="on" spellcheck="off"\n									 data-opened="opened" data-selected="selected"\n									 data-min-length="0"\n									 data-autocompleted="autocompleted"\n								/>\n							</div>\n						  </div>\n						</div>\n	\n			  -->'), "\n\n          ", HTML.Raw('<!--<ul class="small-block-grid-3">\n          <li>\n            <div class="panel">\n              <h5><b class="uppercase">Moving with you ad</b> - Use my current location live\n                (online when your app is running/you are logged in to the website).\n              </h5>\n\n              <div class="current-location-btn">\n              <a class="button small button-calm js-current-location-a" style="display: none;">\n                <i class="fa fa-location-arrow placeholder-icon"></i>\n              </a>\n            </div>\n            </div>\n          </li>\n          <li>\n            <div class="panel" id="moving-ad">\n              <h5><b class="uppercase">bulletin boards ad 1</b> - Specify Location 1\n              (online when you are within a Radius from the board address)\n              </h5>\n              * If empty - Ad will be bound to your current location.\n              <div class="location-nearby js-location-nearby">\n              <input class="form-control typeahead capitalize js-nearby-places" name="team" type="text" id="place1"\n                     placeholder="address, zip or place nearby"\n                     data-source="placesArray"\n\n                     autocomplete="on" spellcheck="off"\n                     data-opened="opened" data-selected="selected"\n                     data-min-length="0"\n                     data-autocompleted="autocompleted"\n                />\n            </div>\n            </div>\n\n          </li>\n          <li>\n            <div class="panel">\n              <h5><b class="uppercase">bulletin boards ad 2</b> - Specify Location 2\n                (online when you are within a Radius from the board address)\n              </h5>\n              * If empty - Ad will be bound to your current location.\n\n              <div class="location-nearby js-location-nearby">\n                <input class="form-control typeahead capitalize js-nearby-places" name="team" type="text"\n                       placeholder="address, zip or place nearby"\n                       data-source="placesArray"\n\n                       autocomplete="on" spellcheck="off"\n                       data-opened="opened" data-selected="selected"\n                       data-min-length="0"\n                       data-autocompleted="autocompleted"\n                  />\n              </div>\n            </div>\n\n          </li>\n        </ul>-->'), "\n\n\n          ", HTML.Raw('<!--<div class="place-btn padding">-->'), "\n\n          ", HTML.Raw('<!--<div class="place-btn padding">-->'), "\n          ", HTML.Raw('<!--<div class="card left">\n            <button class="button small js-my-places-button disabled" data-ion-popover="myPlacesPopover">\n              My places\n            </button>\n\n          </div>-->'), "\n        "), "\n\n", HTML.Raw("<!--this is latest working radius:-->"), "\n        ", HTML.Raw('<!--<div class="clearfix">\n          <div class="choose-radius">\n            <label class="item item-input item-select">\n              <div class="small-12 medium-3 input-label column left">Choose radius (your status will be "online" only if\n                you stay within)\n              </div>\n              <div class="small-12 medium-9 large-9 left">\n                <div class="range-slider js-radius-slider" data-slider\n                     data-options="display_selector: #sliderOutput3; start: 50; end: 2000; initial: 200;">\n                  <span class="range-slider-handle" role="slider" tabindex="0"></span>\n                  <span class="range-slider-active-segment"></span>\n                </div>\n\n                <div class="">\n                  <span id="sliderOutput3"></span> ft\n                </div>\n\n              </div>\n            </label>\n          </div>\n        </div>-->'), "\n      "), "\n        "), "\n    "), "\n  "), "\n    ");
}));                                                                                                                 // 33
                                                                                                                     // 34
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-posts/client/browser/places-autoform.js                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by ashot on 8/19/15.                                                                                      // 2
 */                                                                                                                  // 3
                                                                                                                     // 4
                                                                                                                     // 5
//bz.help.maps.initLocation();                                                                                       // 6
//bz.help.maps.initPlaces();                                                                                         // 7
                                                                                                                     // 8
Template.postsPlacesAutoform.created = function () {                                                                 // 9
  bz.help.maps.initLocation();                                                                                       // 10
  bz.help.maps.initPlacesCollection();                                                                               // 11
  // doc.ready happened, so:                                                                                         // 12
  bz.help.maps.googleMapsLoad();                                                                                     // 13
}                                                                                                                    // 14
                                                                                                                     // 15
Template.postsPlacesAutoform.onRendered(function () {                                                                // 16
  this.autorun(function () {                                                                                         // 17
    if (GoogleMaps.loaded() && Session.get('bz.api.maps.recentLoc')) {                                               // 18
      var map = document.createElement('div');                                                                       // 19
      var service = new google.maps.places.PlacesService(map);                                                       // 20
      service.nearbySearch({                                                                                         // 21
        location: Session.get('bz.api.maps.recentLoc'),                                                              // 22
        radius: 2 // km, 1.24 miß                                                                                    // 23
        //types: ['store']                                                                                           // 24
      }, callbackNearbySearch);                                                                                      // 25
    }                                                                                                                // 26
  });                                                                                                                // 27
  $(document).foundation();                                                                                          // 28
});                                                                                                                  // 29
Template.postsPlacesAutoform.rendered = function () {                                                                // 30
  Meteor.typeahead.inject();                                                                                         // 31
}                                                                                                                    // 32
Template.postsPlacesAutoform.helpers({                                                                               // 33
  placesArray: function () {                                                                                         // 34
    return bz.runtime.maps.places.find().fetch().map(function(object){ return {id: object._id, value: object.name}; });
  },                                                                                                                 // 36
  selected: function (event, suggestion, datasetName) {                                                              // 37
    var mapsPlaceId = suggestion && suggestion.id;                                                                   // 38
    bz.runtime.newPost.location.mapsPlaceId = mapsPlaceId;                                                           // 39
    // make it look selected:                                                                                        // 40
    $('.js-location-nearby').addClass('selected');                                                                   // 41
  }                                                                                                                  // 42
});                                                                                                                  // 43
Template.postsPlacesAutoform.events({                                                                                // 44
  'click .js-current-location-a': function (e, v) {                                                                  // 45
    v.$('.js-current-location-a').toggleClass('selected');  //button-clear                                           // 46
    if (v.$('.js-current-location-a').hasClass('selected')) {                                                        // 47
      bz.runtime.newPost.location.current = true;                                                                    // 48
    } else {                                                                                                         // 49
      bz.runtime.newPost.location.current = false;                                                                   // 50
    }                                                                                                                // 51
  },                                                                                                                 // 52
  'click .js-location-holder': function(e, v){                                                                       // 53
    e.preventDefault();                                                                                              // 54
  },                                                                                                                 // 55
  'blur .js-nearby-places': function(){                                                                              // 56
                                                                                                                     // 57
  },                                                                                                                 // 58
  'click .choose-place-buttons .panel': function(e,v){                                                               // 59
    if(e.target.nodeName !== "INPUT" && e.target.className.indexOf('tt-suggestion') === -1) { // strange bug         // 60
      var panel = $(e.currentTarget).closest('.panel');                                                              // 61
      panel.toggleClass('callout');                                                                                  // 62
      if(panel.hasClass('js-moving-location-panel')){                                                                // 63
        if(panel.hasClass('callout')){                                                                               // 64
          location1.isSet = true;                                                                                    // 65
          movingLocationPanelClick();                                                                                // 66
        } else {                                                                                                     // 67
          location1.isSet = false;                                                                                   // 68
        }                                                                                                            // 69
      } else if(panel.hasClass('js-fixed-location-panel')){                                                          // 70
        location2.isSet = true;                                                                                      // 71
        staticLocationPanelClick();                                                                                  // 72
      } else {                                                                                                       // 73
        location2.isSet = false;                                                                                     // 74
      }                                                                                                              // 75
    }                                                                                                                // 76
  }                                                                                                                  // 77
})                                                                                                                   // 78
// HELPERS:                                                                                                          // 79
                                                                                                                     // 80
function callbackNearbySearch(results, status) {                                                                     // 81
  console.log('results: ', results);                                                                                 // 82
  console.log('status: ', status);                                                                                   // 83
  console.log('length: ', results.length);                                                                           // 84
  if (status === google.maps.places.PlacesServiceStatus.OK) {                                                        // 85
    for (var i = 0; i < results.length; i++) {                                                                       // 86
      bz.runtime.maps.places._collection.insert(results[i]);                                                         // 87
    }                                                                                                                // 88
  }                                                                                                                  // 89
}                                                                                                                    // 90
// INFO:                                                                                                             // 91
// see this for autoforms: https://github.com/sergeyt/meteor-typeahead/, http://typeahead.meteor.com/                // 92
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
