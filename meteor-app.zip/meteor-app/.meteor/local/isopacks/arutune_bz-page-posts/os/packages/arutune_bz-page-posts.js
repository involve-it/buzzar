(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-page-posts/collections/posts.shared.js        //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by yvdorofeev on 10/20/15.                                // 2
 */                                                                  // 3
bz.cols.posts = new Mongo.Collection('posts');                       // 4
                                                                     // 5
var postsColl = bz.cols.posts;                                       // 6
                                                                     // 7
postsColl.helpers({                                                  // 8
  _hasLivePresence: bz.help.posts.hasLivePresence                    // 9
});                                                                  // 10
                                                                     // 11
                                                                     // 12
///////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/arutune:bz-page-posts/server/model.js                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
/**                                                                  // 1
 * Created by Ashot on 9/27/15.                                      // 2
 */                                                                  // 3
//comments = new Meteor.Pagination('bz.reviews');                    // 4
///////////////////////////////////////////////////////////////////////

}).call(this);
