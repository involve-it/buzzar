(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/arutune:bz-page-search/client/router.js                                                   //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
/**                                                                                                   // 1
 * Created by Ashot on 9/19/15.                                                                       // 2
 */                                                                                                   // 3
Router.map(function () {                                                                              // 4
  this.route('search.results', {                                                                      // 5
    path: '/search-results',                                                                          // 6
    template: 'pageSearchResults',                                                                    // 7
    //controller: 'requireLoginController',                                                           // 8
    onBeforeAction: function () {                                                                     // 9
      //Router.go('/posts/my');                                                                       // 10
      this.next();                                                                                    // 11
    }                                                                                                 // 12
  });                                                                                                 // 13
});                                                                                                   // 14
// load google maps before some routes                                                                // 15
Router.onBeforeAction(function() {                                                                    // 16
  bz.help.maps.googleMapsLoad();                                                                      // 17
                                                                                                      // 18
  this.next();                                                                                        // 19
}, {                                                                                                  // 20
  only: ['home']                                                                                      // 21
});                                                                                                   // 22
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/arutune:bz-page-search/client/model.js                                                    //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
/**                                                                                                   // 1
 * Created by Ashot on 9/21/15.                                                                       // 2
 */                                                                                                   // 3
                                                                                                      // 4
              //connect to Yelp:                                                                      // 5
//http://api.yelp.com/v2/search/?location=270 holly ln, orinda, ca                                    // 6
const YELP_API_URL = 'http://api.yelp.com/v2/search/';                                                // 7
                                                                                                      // 8
                                                                                                      // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/arutune:bz-page-search/client/controller.js                                               //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
/**                                                                                                   // 1
 * Created by Ashot on 9/19/15.                                                                       // 2
 */                                                                                                   // 3
const SEARCH_RADIUS = 4000; // 1km ~ 10 min walk                                                      // 4
bz.help.makeNamespace('bz.bus.search');                                                               // 5
                                                                                                      // 6
                                                                                                      // 7
Meteor.startup(function () {                                                                          // 8
  Tracker.autorun(function(){                                                                         // 9
    if(GoogleMaps.loaded()){                                                                          // 10
      bz.help.maps.initGeocoding();                                                                   // 11
      bz.help.maps.initLocation();                                                                    // 12
    }                                                                                                 // 13
  });                                                                                                 // 14
                                                                                                      // 15
  Session.set('bz.control.search.distance', 1);                                                       // 16
  bz.help.maps.getCurrentLocation(function (loc) {                                                    // 17
    Session.set('bz.control.search.location', {                                                       // 18
      coords: loc,                                                                                    // 19
      placeType: bz.const.locations.type.STATIC,                                                      // 20
      name: bz.const.places.CURRENT_LOCATION,                                                         // 21
      userId: Meteor.userId(),                                                                        // 22
      public: false // private, user's place                                                          // 23
                                                                                                      // 24
    });                                                                                               // 25
  });                                                                                                 // 26
                                                                                                      // 27
  if (!bz.cols.searchRt && !bz.help.collectionExists('bz.cols.searchRt')) {                           // 28
    var placesCol = new Meteor.Collection("bz.cols.searchRt"); // client-side only.                   // 29
    bz.help.makeNamespace('bz.cols.searchRt', placesCol);                                             // 30
    bz.cols.searchRt.helpers({                                                                        // 31
          _hasLivePresence: bz.help.posts.hasLivePresence                                             // 32
        }                                                                                             // 33
    );                                                                                                // 34
  }                                                                                                   // 35
  searchPostsReactive();                                                                              // 36
                                                                                                      // 37
  bz.help.maps.initPlacesCollection();                                                                // 38
  Template.bzControlSearch.onCreated(function () {                                                    // 39
                                                                                                      // 40
    //bz.help.maps.initLocation();                                                                    // 41
                                                                                                      // 42
    // doc.ready happened, so:                                                                        // 43
    //bz.help.maps.googleMapsLoad();                                                                  // 44
  });                                                                                                 // 45
                                                                                                      // 46
                                                                                                      // 47
  // fill google maps locations into bz.runtime.maps.places:                                          // 48
  Tracker.autorun(function () {                                                                       // 49
    //bz.help.maps.initPlacesCollection();                                                            // 50
    bz.runtime.maps.places._collection.remove({});                                                    // 51
    if (Session.get('bz.control.search.location')) {                                                  // 52
      if (GoogleMaps.loaded()) {                                                                      // 53
        fillNearByPlacesFromLocationGoogle(Session.get('bz.control.search.location'), SEARCH_RADIUS); // 54
      }                                                                                               // 55
                                                                                                      // 56
      //fillNearByPlacesFromLocationYelp(Session.get('bz.control.search.location'), SEARCH_RADIUS);   // 57
    }                                                                                                 // 58
  });                                                                                                 // 59
});                                                                                                   // 60
                                                                                                      // 61
bz.bus.search.doSearch = function(callback){                                                          // 62
  var searchedText = Session.get('bz.control.search.searchedText');                                   // 63
  searchedText = searchedText && searchedText.trim();                                                 // 64
  if (searchedText) {                                                                                 // 65
    var query = {},                                                                                   // 66
    //map = GoogleMaps.maps.map.instance, latitude, longitude,                                        // 67
        activeCats = Session.get('bz.control.category-list.activeCategories') || [],                  // 68
        searchDistance = Session.get('bz.control.search.distance'),                                   // 69
        location = Session.get('bz.control.search.location') || {};                                   // 70
    if (!searchedText && searchedText === undefined) {                                                // 71
      searchedText = '';                                                                              // 72
    }                                                                                                 // 73
    query = {                                                                                         // 74
      text: searchedText,                                                                             // 75
      distance: searchDistance,                                                                       // 76
      activeCats: activeCats,                                                                         // 77
      location: location.coords,                                                                      // 78
      limit: 10                                                                                       // 79
    };                                                                                                // 80
                                                                                                      // 81
    Meteor.call('search', query, function (err, results) {                                            // 82
      bz.cols.searchRt._collection.remove({});                                                        // 83
      if (results && results.length > 0) {                                                            // 84
        for (var i = 0; i < results.length; i++) {                                                    // 85
          bz.cols.searchRt._collection.upsert({_id: results[i]._id}, results[i]);                     // 86
        }                                                                                             // 87
      }                                                                                               // 88
                                                                                                      // 89
      if (callback && typeof callback === 'function'){                                                // 90
        callback(err, results);                                                                       // 91
      }                                                                                               // 92
    });                                                                                               // 93
  } else {                                                                                            // 94
                                                                                                      // 95
  }                                                                                                   // 96
};                                                                                                    // 97
                                                                                                      // 98
function searchPostsReactive() {                                                                      // 99
  Tracker.autorun(function () {                                                                       // 100
    bz.cols.searchRt._collection.remove({});                                                          // 101
    bz.cols.posts.find().count();                                                                     // 102
    bz.bus.search.doSearch();                                                                         // 103
  });                                                                                                 // 104
}                                                                                                     // 105
setSearchedText = function (text) {                                                                   // 106
  return Session.set('bz.control.search.searchedText', text);                                         // 107
}                                                                                                     // 108
                                                                                                      // 109
// HELPERS:                                                                                           // 110
function fillNearByPlacesFromLocationYelp(loc, radius) {                                              // 111
  /*var map = document.createElement('div');                                                          // 112
   var service = new google.maps.places.PlacesService(map);                                           // 113
   service.nearbySearch({                                                                             // 114
   location: loc.coords,                                                                              // 115
   radius: radius,                                                                                    // 116
   //types: ['store']                                                                                 // 117
   }, callbackNearbySearchYelp);*/                                                                    // 118
  callbackNearbySearchYelp(window.yelpRes.businesses, 'OK'); // stub, todo                            // 119
}                                                                                                     // 120
function callbackNearbySearchYelp(results, status) {                                                  // 121
  if (status === 'OK') {                                                                              // 122
    for (var i = 0; i < results.length; i++) {                                                        // 123
      results[i].searchEngine = 'yelp';                                                               // 124
      bz.runtime.maps.places._collection.upsert({name: results[i].name}, results[i]);                 // 125
    }                                                                                                 // 126
  }                                                                                                   // 127
  //Session.set('bz.control.search.places', bz.runtime.maps.places.find().fetch());                   // 128
  //return bz.runtime.maps.places;                                                                    // 129
}                                                                                                     // 130
function fillNearByPlacesFromLocationGoogle(loc, radius) {                                            // 131
  var map = document.createElement('div');                                                            // 132
  var service = new google.maps.places.PlacesService(map);                                            // 133
  /*service.nearbySearch({                                                                            // 134
   location: loc.coords,                                                                              // 135
   radius: radius,                                                                                    // 136
   //types: ['store']                                                                                 // 137
   }, callbackNearbySearch);*/                                                                        // 138
  //console.log(radius);                                                                              // 139
  service.nearbySearch({                                                                              // 140
    //service.radarSearch({                                                                           // 141
    location: loc.coords,                                                                             // 142
    radius: radius                                                                                    // 143
    //types: allTypes                                                                                 // 144
  }, callbackNearbySearchGoogle);                                                                     // 145
}                                                                                                     // 146
                                                                                                      // 147
function callbackNearbySearchGoogle(results, status, html_attributions, next_page_token) {            // 148
  if (status === google.maps.places.PlacesServiceStatus.OK && results.length > 0) {                   // 149
    res1 = _.filter(results, function (item) {                                                        // 150
      return _.intersection(['locality'], item.types).length === 0;                                   // 151
    });                                                                                               // 152
    results = res1;                                                                                   // 153
    //console.log(res1.length);                                                                       // 154
    for (var i = 0; i < results.length; i++) {                                                        // 155
      //console.log(results[i])                                                                       // 156
      results[i].searchEngine = 'google';                                                             // 157
                                                                                                      // 158
      bz.runtime.maps.places._collection.upsert({name: results[i].name}, results[i]);                 // 159
    }                                                                                                 // 160
  }                                                                                                   // 161
  //Session.set('bz.control.search.places', bz.runtime.maps.places.find().fetch());                   // 162
  //return bz.runtime.maps.places;                                                                    // 163
}                                                                                                     // 164
                                                                                                      // 165
createLocationFromObject = function(obj){                                                             // 166
  var ret, toRemove,                                                                                  // 167
    locName = obj.name, coords = obj.coords;                                                          // 168
    // save to locations history collection                                                           // 169
                                                                                                      // 170
    if (locName && Meteor.userId()) {                                                                 // 171
      ret = {                                                                                         // 172
        userId: Meteor.userId(),                                                                      // 173
        name: locName,                                                                                // 174
        coords: coords,                                                                               // 175
        placeType: bz.const.locations.type.STATIC,                                                    // 176
        public: false,                                                                                // 177
        timestamp: Date.now()                                                                         // 178
      }                                                                                               // 179
      toRemove = bz.cols.locations.findOne({                                                          // 180
        name: locName,                                                                                // 181
        userId: Meteor.userId()                                                                       // 182
      });                                                                                             // 183
      if(toRemove) {                                                                                  // 184
        bz.cols.locations.remove(toRemove._id);                                                       // 185
      }                                                                                               // 186
                                                                                                      // 187
      ret._id = bz.cols.locations.insert(ret);                                                        // 188
    }                                                                                                 // 189
    //ret.resolve(true);                                                                              // 190
  /*} else {                                                                                          // 191
    ret.resolve(false);                                                                               // 192
  }*/                                                                                                 // 193
  // 2. set sitewide current location:                                                                // 194
  return ret;                                                                                         // 195
}                                                                                                     // 196
setLocationToSessionFromData = function(locName, data, sessionName){                                  // 197
  var placeType;                                                                                      // 198
  if(sessionName === bz.const.posts.location2) {                                                      // 199
    placeType = bz.const.locations.type.STATIC;                                                       // 200
  } else if (sessionName === bz.const.posts.location1) {                                              // 201
    placeType = bz.const.locations.type.DYNAMIC;                                                      // 202
  }                                                                                                   // 203
  var locId, bzPlace, res;                                                                            // 204
  // do something with the result:                                                                    // 205
  //Session.get('bz.control.search.location')                                                         // 206
  //console.log(this.locationId);                                                                     // 207
  sessionName = sessionName || 'bz.control.search.location';                                          // 208
  if (data.selectedPlace) {                                                                           // 209
    // if selected from a dropdown:                                                                   // 210
    Session.set(sessionName, data.selectedPlace);                                                     // 211
  } else if (data.locationId) {                                                                       // 212
    locId = data.locationId;                                                                          // 213
    // if selected from most recent: search product by id in our database                             // 214
    bzPlace = bz.cols.locations.findOne(locId);                                                       // 215
    if (bzPlace) {                                                                                    // 216
      Session.set(sessionName, bzPlace)                                                               // 217
    } else {                                                                                          // 218
      bz.help.logError('Location with id ' + locId + 'was not found!');                               // 219
    }                                                                                                 // 220
  } else if (data.isCurrentLocation){                                                                 // 221
    // selected moving location type                                                                  // 222
    bz.help.maps.getCurrentLocation(function (loc) {                                                  // 223
      if (placeType === bz.const.locations.type.DYNAMIC) {                                            // 224
        Session.set(sessionName, {                                                                    // 225
          coords: loc,                                                                                // 226
          placeType: placeType,                                                                       // 227
          name: bz.const.places.CURRENT_LOCATION,                                                     // 228
          userId: Meteor.userId(),                                                                    // 229
          public: false // private, user's place                                                      // 230
        });                                                                                           // 231
      } else {                                                                                        // 232
        bz.help.maps.getAddressFromCoords(loc).done(function(address){                                // 233
          var locObj = createLocationFromObject({                                                     // 234
            name: address,                                                                            // 235
            coords: loc                                                                               // 236
          });                                                                                         // 237
          Session.set(sessionName, locObj);                                                           // 238
        });                                                                                           // 239
      }                                                                                               // 240
    });                                                                                               // 241
  } else {                                                                                            // 242
    // user entered his own text: this is not our place and we just have a name OR address            // 243
    // check if this is an address with geocoding:                                                    // 244
    bz.help.maps.getCoordsFromAddress(locName).done(function(coords){                                 // 245
      if(coords){                                                                                     // 246
        res = createLocationFromObject({                                                              // 247
          name: locName,                                                                              // 248
          coords: coords                                                                              // 249
        });                                                                                           // 250
        Session.set(sessionName, res);                                                                // 251
      } else {                                                                                        // 252
        bz.help.maps.getCurrentLocation(function (loc) {                                              // 253
          res = createLocationFromObject({                                                            // 254
            name: locName,                                                                            // 255
            coords: loc                                                                               // 256
          });                                                                                         // 257
          Session.set(sessionName, res);                                                              // 258
        });                                                                                           // 259
      }                                                                                               // 260
    });                                                                                               // 261
  }                                                                                                   // 262
}                                                                                                     // 263
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/arutune:bz-page-search/resources/t9-en.js                                                 //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
/**                                                                                                   // 1
 * Created by douson on 13.07.15.                                                                     // 2
 */                                                                                                   // 3
                                                                                                      // 4
var en;                                                                                               // 5
                                                                                                      // 6
en = {                                                                                                // 7
  lookingForText: 'Buzz I\'m Looking for'                                                             // 8
};                                                                                                    // 9
                                                                                                      // 10
T9n.map('en', en);                                                                                    // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
