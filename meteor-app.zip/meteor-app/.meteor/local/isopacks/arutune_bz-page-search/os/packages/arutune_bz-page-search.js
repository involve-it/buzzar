(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/arutune:bz-page-search/server/model.js                                                 //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
/**                                                                                                // 1
 * Created by Ashot on 9/27/15.                                                                    // 2
 */                                                                                                // 3
Meteor.methods({                                                                                   // 4
  getYelpPlaces: function(location){                                                               // 5
    var res;                                                                                       // 6
    try {                                                                                          // 7
      res = Meteor.http.call('GET', 'http://api.yelp.com/v2/search/', {                            // 8
        params: {                                                                                  // 9
          location: location,                                                                      // 10
          oauth_consumer_key: 'hXSdjS1jlEsBuf1IgSIMdw',                                            // 11
          oauth_token: 'v5rNRAHLK0Is7H9gsCF2fwUjvks0X9gR',                                         // 12
          oauth_signature_method: 'HMAC-SHA1',                                                     // 13
          oauth_signature: 'rIQhb5XI5pjWvLRnA8Dkrr4DRi0', //Consumer Secret                        // 14
          //oauth_signature: 'qVqB06AiObkjkM4BSdKeFG66DvE', //Token Secret                         // 15
          oauth_timestamp: Date.now(),                                                             // 16
          oauth_nonce: _.guid()                                                                    // 17
                                                                                                   // 18
        }                                                                                          // 19
      });                                                                                          // 20
    } catch(ex){                                                                                   // 21
      console.log(ex);                                                                             // 22
      res = ex;                                                                                    // 23
    }                                                                                              // 24
    console.log(res);                                                                              // 25
    return res;                                                                                    // 26
  },                                                                                               // 27
  ///Input Parameters                                                                              // 28
  //  search: Search term or category names                                                        // 29
  //  isCategory: Boolean stating whether ‘search’ parameter is a category                         // 30
  //longitude and latitude: Latitude and Longitude of user’s location (optional)                   // 31
  //Default location is statically set to San Francisco                                            // 32
  yelpQuery: function(search, isCategory, longitude, latitude) {                                   // 33
    console.log('Yelp search for userId: ' + this.userId + '(search, isCategory, lng, lat) with vals (', search, isCategory, longitude, latitude, ')');
                                                                                                   // 35
    // Query OAUTH credentials (these are set manually)                                            // 36
    var auth = Accounts.loginServiceConfiguration.findOne({service: 'yelp'});                      // 37
                                                                                                   // 38
    // Add auth signature manually                                                                 // 39
    auth['serviceProvider'] = { signatureMethod: "HMAC-SHA1" };                                    // 40
                                                                                                   // 41
    var accessor = {                                                                               // 42
          consumerSecret: auth.consumerSecret,                                                     // 43
          tokenSecret: auth.accessTokenSecret                                                      // 44
        },                                                                                         // 45
        parameters = {};                                                                           // 46
                                                                                                   // 47
    // Search term or categories query                                                             // 48
    if(isCategory)                                                                                 // 49
      parameters.category_filter = search;                                                         // 50
    else                                                                                           // 51
      parameters.term = search;                                                                    // 52
                                                                                                   // 53
    // Set lat, lon location, if available (SF is default location)                                // 54
    if(longitude && latitude)                                                                      // 55
      parameters.ll = latitude + ',' + longitude;                                                  // 56
    else                                                                                           // 57
      parameters.location = 'San+Francisco';                                                       // 58
                                                                                                   // 59
    // Results limited to 5                                                                        // 60
    parameters.limit = 5;                                                                          // 61
                                                                                                   // 62
    // Configure OAUTH parameters for REST call                                                    // 63
    parameters.oauth_consumer_key = auth.consumerKey;                                              // 64
    parameters.oauth_consumer_secret = auth.consumerSecret;                                        // 65
    parameters.oauth_token = auth.accessToken;                                                     // 66
    parameters.oauth_signature_method = auth.serviceProvider.signatureMethod;                      // 67
                                                                                                   // 68
    // Create OAUTH1 headers to make request to Yelp API                                           // 69
    var qs = _.param(parameters);                                                                  // 70
    var fullUrl = 'http://api.yelp.com/v2/search' + '/?' + qs;                                     // 71
    var oauthBinding = new OAuth1Binding(auth.consumerKey, auth.consumerSecret, fullUrl);          // 72
    oauthBinding.accessTokenSecret = auth.accessTokenSecret;                                       // 73
    var headers = oauthBinding._buildHeader();                                                     // 74
    // Return data results only                                                                    // 75
    return oauthBinding._call('GET', fullUrl, headers).data;                                       // 76
    //return oauthBinding._call('GET', 'http://api.yelp.com/v2/search', headers, parameters).data; // 77
  }                                                                                                // 78
                                                                                                   // 79
});                                                                                                // 80
/////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
