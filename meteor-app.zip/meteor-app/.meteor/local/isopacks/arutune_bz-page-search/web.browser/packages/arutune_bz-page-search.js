(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/router.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/19/15.                                                                                       // 2
 */                                                                                                                   // 3
Router.map(function () {                                                                                              // 4
  this.route('search.results', {                                                                                      // 5
    path: '/search-results',                                                                                          // 6
    template: 'pageSearchResults',                                                                                    // 7
    //controller: 'requireLoginController',                                                                           // 8
    onBeforeAction: function () {                                                                                     // 9
      //Router.go('/posts/my');                                                                                       // 10
      this.next();                                                                                                    // 11
    }                                                                                                                 // 12
  });                                                                                                                 // 13
});                                                                                                                   // 14
// load google maps before some routes                                                                                // 15
Router.onBeforeAction(function() {                                                                                    // 16
  bz.help.maps.googleMapsLoad();                                                                                      // 17
                                                                                                                      // 18
  this.next();                                                                                                        // 19
}, {                                                                                                                  // 20
  only: ['home']                                                                                                      // 21
});                                                                                                                   // 22
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/model.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/21/15.                                                                                       // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
              //connect to Yelp:                                                                                      // 5
//http://api.yelp.com/v2/search/?location=270 holly ln, orinda, ca                                                    // 6
const YELP_API_URL = 'http://api.yelp.com/v2/search/';                                                                // 7
                                                                                                                      // 8
                                                                                                                      // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/controller.js                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/19/15.                                                                                       // 2
 */                                                                                                                   // 3
const SEARCH_RADIUS = 4000; // 1km ~ 10 min walk                                                                      // 4
bz.help.makeNamespace('bz.bus.search');                                                                               // 5
                                                                                                                      // 6
                                                                                                                      // 7
Meteor.startup(function () {                                                                                          // 8
  Tracker.autorun(function(){                                                                                         // 9
    if(GoogleMaps.loaded()){                                                                                          // 10
      bz.help.maps.initGeocoding();                                                                                   // 11
      bz.help.maps.initLocation();                                                                                    // 12
    }                                                                                                                 // 13
  });                                                                                                                 // 14
                                                                                                                      // 15
  Session.set('bz.control.search.distance', 1);                                                                       // 16
  bz.help.maps.getCurrentLocation(function (loc) {                                                                    // 17
    Session.set('bz.control.search.location', {                                                                       // 18
      coords: loc,                                                                                                    // 19
      placeType: bz.const.locations.type.STATIC,                                                                      // 20
      name: bz.const.places.CURRENT_LOCATION,                                                                         // 21
      userId: Meteor.userId(),                                                                                        // 22
      public: false // private, user's place                                                                          // 23
                                                                                                                      // 24
    });                                                                                                               // 25
  });                                                                                                                 // 26
                                                                                                                      // 27
  if (!bz.cols.searchRt && !bz.help.collectionExists('bz.cols.searchRt')) {                                           // 28
    var placesCol = new Meteor.Collection("bz.cols.searchRt"); // client-side only.                                   // 29
    bz.help.makeNamespace('bz.cols.searchRt', placesCol);                                                             // 30
    bz.cols.searchRt.helpers({                                                                                        // 31
          _hasLivePresence: bz.help.posts.hasLivePresence                                                             // 32
        }                                                                                                             // 33
    );                                                                                                                // 34
  }                                                                                                                   // 35
  searchPostsReactive();                                                                                              // 36
                                                                                                                      // 37
  bz.help.maps.initPlacesCollection();                                                                                // 38
  Template.bzControlSearch.onCreated(function () {                                                                    // 39
                                                                                                                      // 40
    //bz.help.maps.initLocation();                                                                                    // 41
                                                                                                                      // 42
    // doc.ready happened, so:                                                                                        // 43
    //bz.help.maps.googleMapsLoad();                                                                                  // 44
  });                                                                                                                 // 45
                                                                                                                      // 46
                                                                                                                      // 47
  // fill google maps locations into bz.runtime.maps.places:                                                          // 48
  Tracker.autorun(function () {                                                                                       // 49
    //bz.help.maps.initPlacesCollection();                                                                            // 50
    bz.runtime.maps.places._collection.remove({});                                                                    // 51
    if (Session.get('bz.control.search.location')) {                                                                  // 52
      if (GoogleMaps.loaded()) {                                                                                      // 53
        fillNearByPlacesFromLocationGoogle(Session.get('bz.control.search.location'), SEARCH_RADIUS);                 // 54
      }                                                                                                               // 55
                                                                                                                      // 56
      //fillNearByPlacesFromLocationYelp(Session.get('bz.control.search.location'), SEARCH_RADIUS);                   // 57
    }                                                                                                                 // 58
  });                                                                                                                 // 59
});                                                                                                                   // 60
                                                                                                                      // 61
bz.bus.search.doSearch = function(callback){                                                                          // 62
  var searchedText = Session.get('bz.control.search.searchedText');                                                   // 63
  searchedText = searchedText && searchedText.trim();                                                                 // 64
  if (searchedText) {                                                                                                 // 65
    var query = {},                                                                                                   // 66
    //map = GoogleMaps.maps.map.instance, latitude, longitude,                                                        // 67
        activeCats = Session.get('bz.control.category-list.activeCategories') || [],                                  // 68
        searchDistance = Session.get('bz.control.search.distance'),                                                   // 69
        location = Session.get('bz.control.search.location') || {};                                                   // 70
    if (!searchedText && searchedText === undefined) {                                                                // 71
      searchedText = '';                                                                                              // 72
    }                                                                                                                 // 73
    query = {                                                                                                         // 74
      text: searchedText,                                                                                             // 75
      distance: searchDistance,                                                                                       // 76
      activeCats: activeCats,                                                                                         // 77
      location: location.coords,                                                                                      // 78
      limit: 10                                                                                                       // 79
    };                                                                                                                // 80
                                                                                                                      // 81
    Meteor.call('search', query, function (err, results) {                                                            // 82
      bz.cols.searchRt._collection.remove({});                                                                        // 83
      if (results && results.length > 0) {                                                                            // 84
        for (var i = 0; i < results.length; i++) {                                                                    // 85
          bz.cols.searchRt._collection.upsert({_id: results[i]._id}, results[i]);                                     // 86
        }                                                                                                             // 87
      }                                                                                                               // 88
                                                                                                                      // 89
      if (callback && typeof callback === 'function'){                                                                // 90
        callback(err, results);                                                                                       // 91
      }                                                                                                               // 92
    });                                                                                                               // 93
  } else {                                                                                                            // 94
                                                                                                                      // 95
  }                                                                                                                   // 96
};                                                                                                                    // 97
                                                                                                                      // 98
function searchPostsReactive() {                                                                                      // 99
  Tracker.autorun(function () {                                                                                       // 100
    bz.cols.searchRt._collection.remove({});                                                                          // 101
    bz.cols.posts.find().count();                                                                                     // 102
    bz.bus.search.doSearch();                                                                                         // 103
  });                                                                                                                 // 104
}                                                                                                                     // 105
setSearchedText = function (text) {                                                                                   // 106
  return Session.set('bz.control.search.searchedText', text);                                                         // 107
}                                                                                                                     // 108
                                                                                                                      // 109
// HELPERS:                                                                                                           // 110
function fillNearByPlacesFromLocationYelp(loc, radius) {                                                              // 111
  /*var map = document.createElement('div');                                                                          // 112
   var service = new google.maps.places.PlacesService(map);                                                           // 113
   service.nearbySearch({                                                                                             // 114
   location: loc.coords,                                                                                              // 115
   radius: radius,                                                                                                    // 116
   //types: ['store']                                                                                                 // 117
   }, callbackNearbySearchYelp);*/                                                                                    // 118
  callbackNearbySearchYelp(window.yelpRes.businesses, 'OK'); // stub, todo                                            // 119
}                                                                                                                     // 120
function callbackNearbySearchYelp(results, status) {                                                                  // 121
  if (status === 'OK') {                                                                                              // 122
    for (var i = 0; i < results.length; i++) {                                                                        // 123
      results[i].searchEngine = 'yelp';                                                                               // 124
      bz.runtime.maps.places._collection.upsert({name: results[i].name}, results[i]);                                 // 125
    }                                                                                                                 // 126
  }                                                                                                                   // 127
  //Session.set('bz.control.search.places', bz.runtime.maps.places.find().fetch());                                   // 128
  //return bz.runtime.maps.places;                                                                                    // 129
}                                                                                                                     // 130
function fillNearByPlacesFromLocationGoogle(loc, radius) {                                                            // 131
  var map = document.createElement('div');                                                                            // 132
  var service = new google.maps.places.PlacesService(map);                                                            // 133
  /*service.nearbySearch({                                                                                            // 134
   location: loc.coords,                                                                                              // 135
   radius: radius,                                                                                                    // 136
   //types: ['store']                                                                                                 // 137
   }, callbackNearbySearch);*/                                                                                        // 138
  //console.log(radius);                                                                                              // 139
  service.nearbySearch({                                                                                              // 140
    //service.radarSearch({                                                                                           // 141
    location: loc.coords,                                                                                             // 142
    radius: radius                                                                                                    // 143
    //types: allTypes                                                                                                 // 144
  }, callbackNearbySearchGoogle);                                                                                     // 145
}                                                                                                                     // 146
                                                                                                                      // 147
function callbackNearbySearchGoogle(results, status, html_attributions, next_page_token) {                            // 148
  if (status === google.maps.places.PlacesServiceStatus.OK && results.length > 0) {                                   // 149
    res1 = _.filter(results, function (item) {                                                                        // 150
      return _.intersection(['locality'], item.types).length === 0;                                                   // 151
    });                                                                                                               // 152
    results = res1;                                                                                                   // 153
    //console.log(res1.length);                                                                                       // 154
    for (var i = 0; i < results.length; i++) {                                                                        // 155
      //console.log(results[i])                                                                                       // 156
      results[i].searchEngine = 'google';                                                                             // 157
                                                                                                                      // 158
      bz.runtime.maps.places._collection.upsert({name: results[i].name}, results[i]);                                 // 159
    }                                                                                                                 // 160
  }                                                                                                                   // 161
  //Session.set('bz.control.search.places', bz.runtime.maps.places.find().fetch());                                   // 162
  //return bz.runtime.maps.places;                                                                                    // 163
}                                                                                                                     // 164
                                                                                                                      // 165
createLocationFromObject = function(obj){                                                                             // 166
  var ret, toRemove,                                                                                                  // 167
    locName = obj.name, coords = obj.coords;                                                                          // 168
    // save to locations history collection                                                                           // 169
                                                                                                                      // 170
    if (locName && Meteor.userId()) {                                                                                 // 171
      ret = {                                                                                                         // 172
        userId: Meteor.userId(),                                                                                      // 173
        name: locName,                                                                                                // 174
        coords: coords,                                                                                               // 175
        placeType: bz.const.locations.type.STATIC,                                                                    // 176
        public: false,                                                                                                // 177
        timestamp: Date.now()                                                                                         // 178
      }                                                                                                               // 179
      toRemove = bz.cols.locations.findOne({                                                                          // 180
        name: locName,                                                                                                // 181
        userId: Meteor.userId()                                                                                       // 182
      });                                                                                                             // 183
      if(toRemove) {                                                                                                  // 184
        bz.cols.locations.remove(toRemove._id);                                                                       // 185
      }                                                                                                               // 186
                                                                                                                      // 187
      ret._id = bz.cols.locations.insert(ret);                                                                        // 188
    }                                                                                                                 // 189
    //ret.resolve(true);                                                                                              // 190
  /*} else {                                                                                                          // 191
    ret.resolve(false);                                                                                               // 192
  }*/                                                                                                                 // 193
  // 2. set sitewide current location:                                                                                // 194
  return ret;                                                                                                         // 195
}                                                                                                                     // 196
setLocationToSessionFromData = function(locName, data, sessionName){                                                  // 197
  var placeType;                                                                                                      // 198
  if(sessionName === bz.const.posts.location2) {                                                                      // 199
    placeType = bz.const.locations.type.STATIC;                                                                       // 200
  } else if (sessionName === bz.const.posts.location1) {                                                              // 201
    placeType = bz.const.locations.type.DYNAMIC;                                                                      // 202
  }                                                                                                                   // 203
  var locId, bzPlace, res;                                                                                            // 204
  // do something with the result:                                                                                    // 205
  //Session.get('bz.control.search.location')                                                                         // 206
  //console.log(this.locationId);                                                                                     // 207
  sessionName = sessionName || 'bz.control.search.location';                                                          // 208
  if (data.selectedPlace) {                                                                                           // 209
    // if selected from a dropdown:                                                                                   // 210
    Session.set(sessionName, data.selectedPlace);                                                                     // 211
  } else if (data.locationId) {                                                                                       // 212
    locId = data.locationId;                                                                                          // 213
    // if selected from most recent: search product by id in our database                                             // 214
    bzPlace = bz.cols.locations.findOne(locId);                                                                       // 215
    if (bzPlace) {                                                                                                    // 216
      Session.set(sessionName, bzPlace)                                                                               // 217
    } else {                                                                                                          // 218
      bz.help.logError('Location with id ' + locId + 'was not found!');                                               // 219
    }                                                                                                                 // 220
  } else if (data.isCurrentLocation){                                                                                 // 221
    // selected moving location type                                                                                  // 222
    bz.help.maps.getCurrentLocation(function (loc) {                                                                  // 223
      if (placeType === bz.const.locations.type.DYNAMIC) {                                                            // 224
        Session.set(sessionName, {                                                                                    // 225
          coords: loc,                                                                                                // 226
          placeType: placeType,                                                                                       // 227
          name: bz.const.places.CURRENT_LOCATION,                                                                     // 228
          userId: Meteor.userId(),                                                                                    // 229
          public: false // private, user's place                                                                      // 230
        });                                                                                                           // 231
      } else {                                                                                                        // 232
        bz.help.maps.getAddressFromCoords(loc).done(function(address){                                                // 233
          var locObj = createLocationFromObject({                                                                     // 234
            name: address,                                                                                            // 235
            coords: loc                                                                                               // 236
          });                                                                                                         // 237
          Session.set(sessionName, locObj);                                                                           // 238
        });                                                                                                           // 239
      }                                                                                                               // 240
    });                                                                                                               // 241
  } else {                                                                                                            // 242
    // user entered his own text: this is not our place and we just have a name OR address                            // 243
    // check if this is an address with geocoding:                                                                    // 244
    bz.help.maps.getCoordsFromAddress(locName).done(function(coords){                                                 // 245
      if(coords){                                                                                                     // 246
        res = createLocationFromObject({                                                                              // 247
          name: locName,                                                                                              // 248
          coords: coords                                                                                              // 249
        });                                                                                                           // 250
        Session.set(sessionName, res);                                                                                // 251
      } else {                                                                                                        // 252
        bz.help.maps.getCurrentLocation(function (loc) {                                                              // 253
          res = createLocationFromObject({                                                                            // 254
            name: locName,                                                                                            // 255
            coords: loc                                                                                               // 256
          });                                                                                                         // 257
          Session.set(sessionName, res);                                                                              // 258
        });                                                                                                           // 259
      }                                                                                                               // 260
    });                                                                                                               // 261
  }                                                                                                                   // 262
}                                                                                                                     // 263
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/resources/t9-en.js                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by douson on 13.07.15.                                                                                     // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
var en;                                                                                                               // 5
                                                                                                                      // 6
en = {                                                                                                                // 7
  lookingForText: 'Buzz I\'m Looking for'                                                                             // 8
};                                                                                                                    // 9
                                                                                                                      // 10
T9n.map('en', en);                                                                                                    // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/location/template.choose-location.js                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("bzLocationName");                                                                               // 2
Template["bzLocationName"] = new Template("Template.bzLocationName", (function() {                                    // 3
  var view = this;                                                                                                    // 4
  return [ HTML.DIV({                                                                                                 // 5
    "class": "bz-location-name"                                                                                       // 6
  }, "\n    ", HTML.A({                                                                                               // 7
    href: "#",                                                                                                        // 8
    "data-reveal-id": "choose-locations-global"                                                                       // 9
  }, "\n      ", HTML.Raw('<i class="fa fa-map-marker"></i>'), " ", Blaze.If(function() {                             // 10
    return Spacebars.call(view.lookup("getCurrentLocationName"));                                                     // 11
  }, function() {                                                                                                     // 12
    return [ " ", HTML.SPAN(Blaze.View("lookup:getCurrentLocationName", function() {                                  // 13
      return Spacebars.mustache(view.lookup("getCurrentLocationName"));                                               // 14
    })), " " ];                                                                                                       // 15
  }, function() {                                                                                                     // 16
    return [ "\n      ", HTML.SPAN(Blaze.View("lookup:getCurrentLocationName", function() {                           // 17
      return Spacebars.mustache(view.lookup("getCurrentLocationName"));                                               // 18
    })), "\n    " ];                                                                                                  // 19
  }), "\n    "), "\n  "), HTML.Raw('\n\n  <div id="choose-locations-global" class="reveal-modal js-global-location" data-reveal="" aria-labelledby="modalTitle" aria-hidden="true" role="dialog">\n    <!--{{> bzChooseLocationModal}}-->\n    <div class=" js-location-modal-holder-global"></div>\n    <a class="close-reveal-modal" aria-label="Close">&#215;</a>\n  </div>') ];
}));                                                                                                                  // 21
                                                                                                                      // 22
Template.__checkName("bzLocationNameNewPost");                                                                        // 23
Template["bzLocationNameNewPost"] = new Template("Template.bzLocationNameNewPost", (function() {                      // 24
  var view = this;                                                                                                    // 25
  return [ HTML.DIV({                                                                                                 // 26
    "class": "bz-location-name"                                                                                       // 27
  }, "\n    ", HTML.A({                                                                                               // 28
    href: "#",                                                                                                        // 29
    "data-reveal-id": "choose-locations-new-post"                                                                     // 30
  }, "\n      ", Blaze.If(function() {                                                                                // 31
    return Spacebars.call(view.lookup("getCurrentLocationName"));                                                     // 32
  }, function() {                                                                                                     // 33
    return [ "\n        ", HTML.SPAN(Blaze.View("lookup:getCurrentLocationName", function() {                         // 34
      return Spacebars.mustache(view.lookup("getCurrentLocationName"));                                               // 35
    })), "\n      " ];                                                                                                // 36
  }, function() {                                                                                                     // 37
    return [ "\n      ", HTML.SPAN("Click to choose location"), "\n    " ];                                           // 38
  }), "\n    "), "\n  "), HTML.Raw('\n\n  <div id="choose-locations-new-post" class="reveal-modal js-new-post-location" data-reveal="" aria-labelledby="modalTitle" aria-hidden="true" role="dialog">\n    <div class="js-location-modal-holder-new-post"></div>\n    <a class="close-reveal-modal" aria-label="Close">&#215;</a>\n  </div>') ];
}));                                                                                                                  // 40
                                                                                                                      // 41
Template.__checkName("bzChooseLocationModal");                                                                        // 42
Template["bzChooseLocationModal"] = new Template("Template.bzChooseLocationModal", (function() {                      // 43
  var view = this;                                                                                                    // 44
  return HTML.DIV({                                                                                                   // 45
    "class": "bz-choose-location-control"                                                                             // 46
  }, "\n\n    ", HTML.DIV({                                                                                           // 47
    "class": "header-toolbar"                                                                                         // 48
  }, "\n      ", HTML.Raw('<div class="header-toolbar-title">\n        <span>Set your location</span>\n      </div>'), "\n\n      ", HTML.DIV({
    "class": "header-toolbar-search"                                                                                  // 50
  }, "\n        ", HTML.DIV({                                                                                         // 51
    "class": "header-toolbar-search-field"                                                                            // 52
  }, "\n            ", HTML.FORM({                                                                                    // 53
    id: "bzSetLocationForm"                                                                                           // 54
  }, "\n                ", HTML.DIV({                                                                                 // 55
    "class": "bz-control--search-location search-field"                                                               // 56
  }, "\n                    ", HTML.DIV({                                                                             // 57
    "class": "form-group bz-search-size"                                                                              // 58
  }, "\n                        \n                        ", HTML.INPUT({                                             // 59
    "class": "form-control typeahead js-location-name-input",                                                         // 60
    name: "team",                                                                                                     // 61
    type: "text",                                                                                                     // 62
    style: "height: 44px;",                                                                                           // 63
    placeholder: function() {                                                                                         // 64
      return Spacebars.mustache(view.lookup("t9n"), "searchLocationText");                                            // 65
    },                                                                                                                // 66
    "data-sets": "placesArray",                                                                                       // 67
    autocomplete: "on",                                                                                               // 68
    spellcheck: "off",                                                                                                // 69
    "data-min-length": "0",                                                                                           // 70
    "data-opened": "opened",                                                                                          // 71
    "data-selected": "locationItemSelected",                                                                          // 72
    "data-template": "teamList"                                                                                       // 73
  }), "\n                        \n                    "), "\n                "), "\n            \n          ", HTML.Raw('<!--<input type="text" id="choose-location-search" class="input-clear js-location-name-input"/>-->'), "\n            ", HTML.Raw('<div class="margin-left">\n                <button class="button btn-default bz-small js-set-location-button">Set</button>\n            </div>'), "\n            "), "\n        "), "\n      "), "\n\n      ", HTML.DIV({
    "class": "header-toolbar-regions"                                                                                 // 75
  }, "\n        ", HTML.DIV({                                                                                         // 76
    "class": "row"                                                                                                    // 77
  }, "\n          ", HTML.DIV({                                                                                       // 78
    "class": "small-12 medium-6 large-4 columns left"                                                                 // 79
  }, "\n            ", HTML.Raw('<ul class="none-list js-locations-list">\n              <li><a data-iscurrentlocation="true" data-locationname="My Location"><i class="fa fa-map-marker"></i> My Current Location</a></li>\n            </ul>'), "\n            ", Blaze.If(function() {
    return Spacebars.call(view.lookup("currentUser"));                                                                // 81
  }, function() {                                                                                                     // 82
    return [ "\n              ", HTML.UL({                                                                            // 83
      "class": "none-list js-locations-list"                                                                          // 84
    }, "\n                  ", HTML.LI(HTML.DIV({                                                                     // 85
      "class": "title"                                                                                                // 86
    }, "Your most recent locations:")), "\n                ", Blaze.Each(function() {                                 // 87
      return Spacebars.call(view.lookup("getUserLocations"));                                                         // 88
    }, function() {                                                                                                   // 89
      return [ "\n                  ", HTML.LI(HTML.A({                                                               // 90
        "data-locationid": function() {                                                                               // 91
          return Spacebars.mustache(view.lookup("_id"));                                                              // 92
        },                                                                                                            // 93
        "data-locationname": function() {                                                                             // 94
          return Spacebars.mustache(view.lookup("name"));                                                             // 95
        }                                                                                                             // 96
      }, " ", Blaze.View("lookup:name", function() {                                                                  // 97
        return Spacebars.mustache(view.lookup("name"));                                                               // 98
      }), " ")), "\n                " ];                                                                              // 99
    }), "\n              "), "\n            " ];                                                                      // 100
  }, function() {                                                                                                     // 101
    return [ "\n              ", HTML.DIV({                                                                           // 102
      "data-alert": "",                                                                                               // 103
      "class": "alert-box info"                                                                                       // 104
    }, "\n                ", HTML.STRONG("Sign In"), " Please ", HTML.A({                                             // 105
      href: "/sign-in"                                                                                                // 106
    }, "sign in"), " to see your places history.\n                ", HTML.A({                                         // 107
      href: "#",                                                                                                      // 108
      "class": "close"                                                                                                // 109
    }, HTML.CharRef({                                                                                                 // 110
      html: "&times;",                                                                                                // 111
      str: "×"                                                                                                        // 112
    })), "\n              "), "\n            " ];                                                                     // 113
  }), "\n          "), "\n        ", HTML.Raw('<!--  <div class="small-12 medium-6 large-4 columns left">\n            <h5>Popular places around you</h5>\n            <ul class="none-list js-locations-list">\n              {{#each getPopularPlacesAround }}\n                <li><a data-placeid="{{_id}}" data-placeName="{{name}}"> {{name}} </a></li>\n              {{/each}}\n            </ul>\n          </div>-->'), "\n        "), "\n      "), "\n    "), "\n  ");
}));                                                                                                                  // 115
                                                                                                                      // 116
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/location/choose-location.js                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by root on 9/23/15.                                                                                        // 2
 */                                                                                                                   // 3
Template.bzLocationName.helpers({                                                                                     // 4
  getCurrentLocationName: function(){                                                                                 // 5
    var ret = Session.get('bz.control.search.location');                                                              // 6
    return ret && ret.name || 'Location is not defined';                                                              // 7
  }                                                                                                                   // 8
})                                                                                                                    // 9
Template.bzLocationName.rendered = function () {                                                                      // 10
  var that = this;                                                                                                    // 11
  setTimeout(function () {                                                                                            // 12
    $(document).off('open.fndtn.reveal', '[data-reveal].js-global-location');                                         // 13
    $(document).on('open.fndtn.reveal', '[data-reveal].js-global-location', function () {                             // 14
      $('.js-location-modal-holder-global').empty();                                                                  // 15
      searchModalView = Blaze.renderWithData(Template.bzChooseLocationModal, {}, $('.js-location-modal-holder-global')[0]);
      //Session.set('bz.search.searchModalView');                                                                     // 17
      //var modal = $(this); bzChooseLocationModal                                                                    // 18
    });                                                                                                               // 19
    //$(document).on('opened.fndtn.reveal', '[data-reveal]', function () {                                            // 20
    //});                                                                                                             // 21
  }, 1000);                                                                                                           // 22
}                                                                                                                     // 23
                                                                                                                      // 24
Template.bzLocationNameNewPost.rendered = function () {                                                               // 25
  this.data = this.data || {}                                                                                         // 26
  this.modalSelector = '[data-reveal].js-new-post-location';                                                          // 27
  this.data.sessionName = this.data.sessionName || location2.sessionName;                                             // 28
  var that = this;                                                                                                    // 29
  setTimeout(function () {                                                                                            // 30
    $(document).off('open.fndtn.reveal', '[data-reveal].js-new-post-location');                                       // 31
    $(document).on('open.fndtn.reveal', '[data-reveal].js-new-post-location', function () {                           // 32
      $('.js-location-modal-holder-new-post').empty();                                                                // 33
      searchModalView2 = Blaze.renderWithData(Template.bzChooseLocationModal, {                                       // 34
        sessionName: that.data.sessionName                                                                            // 35
      }, $('.js-location-modal-holder-new-post')[0]);                                                                 // 36
      //Session.set('bz.search.searchModalView');                                                                     // 37
      //var modal = $(this); bzChooseLocationModal                                                                    // 38
    });                                                                                                               // 39
    //$(document).on('opened.fndtn.reveal', '[data-reveal]', function () {                                            // 40
    //});                                                                                                             // 41
  }, 1000);                                                                                                           // 42
}                                                                                                                     // 43
// custom helper to show the modal:                                                                                   // 44
Template.bzLocationNameNewPost.showModal = function(){                                                                // 45
  $('[data-reveal].js-new-post-location').foundation('reveal', 'open');                                               // 46
}                                                                                                                     // 47
Template.bzLocationNameNewPost.helpers({                                                                              // 48
  getCurrentLocationName: function(){                                                                                 // 49
    var ret = Session.get(this.sessionName)// && Session.get(this.sessionName).dbObject;                              // 50
    return ret && ret.name;                                                                                           // 51
  }                                                                                                                   // 52
});                                                                                                                   // 53
                                                                                                                      // 54
                                                                                                                      // 55
Template.bzChooseLocationModal.created = function () {                                                                // 56
                                                                                                                      // 57
  this.data = this.data || {}                                                                                         // 58
  this.data.sessionName = this.data.sessionName || 'bz.control.search.location';                                      // 59
                                                                                                                      // 60
  Meteor.subscribe('locations-my');                                                                                   // 61
};                                                                                                                    // 62
Template.bzChooseLocationModal.rendered = function () {                                                               // 63
  Meteor.typeahead.inject();                                                                                          // 64
};                                                                                                                    // 65
Template.bzChooseLocationModal.destroyed = function () {                                                              // 66
}                                                                                                                     // 67
Template.bzChooseLocationModal.events({                                                                               // 68
  'click .js-set-location-button': function (e, v) {                                                                  // 69
    //var that = this;                                                                                                // 70
    //Tracker.nonreactive(function () {                                                                               // 71
    var locName = $('.js-location-name-input.tt-input').val()                                                         // 72
    setLocationToSessionFromData(locName, v.data, this.sessionName);                                                  // 73
    if(this.sessionName === 'bz.control.search.location') {                                                           // 74
      searchModalView && Blaze.remove(searchModalView);                                                               // 75
      $('.js-global-location').foundation('reveal', 'close');                                                         // 76
    } else {                                                                                                          // 77
      searchModalView2 && Blaze.remove(searchModalView2);                                                             // 78
      $('.js-new-post-location').foundation('reveal', 'close');                                                       // 79
    }                                                                                                                 // 80
    return false;                                                                                                     // 81
  },                                                                                                                  // 82
  'click .js-locations-list a': function (e, v) {                                                                     // 83
    var locName, locId;                                                                                               // 84
    locName = e.currentTarget.dataset.locationname;                                                                   // 85
    if (locName) {                                                                                                    // 86
      $('.js-location-name-input.tt-input').val(locName);                                                             // 87
    }                                                                                                                 // 88
    var locId = e.currentTarget.dataset.locationid;                                                                   // 89
    if (locId) {                                                                                                      // 90
      v.data.locationId = locId;                                                                                      // 91
    }                                                                                                                 // 92
    var isCurrentLocation = e.currentTarget.dataset.iscurrentlocation;                                                // 93
    if(isCurrentLocation){                                                                                            // 94
      v.data.isCurrentLocation = true;                                                                                // 95
    }                                                                                                                 // 96
    $('.js-set-location-button').click();                                                                             // 97
    return false;                                                                                                     // 98
  },                                                                                                                  // 99
  'typeahead:select .js-location-name-input': function (e, v, val) {                                                  // 100
    var placeObj = {}, textName = val.name && val.name.trim() || '';                                                  // 101
    if (val.searchEngine && val.searchEngine === 'google') {                                                          // 102
      // this is google place:                                                                                        // 103
      placeObj = bz.cols.locations.insertFromGoogleObject(val);                                                       // 104
    } else {                                                                                                          // 105
      placeObj = val;                                                                                                 // 106
    }                                                                                                                 // 107
    v.data.selectedPlace = placeObj;                                                                                  // 108
                                                                                                                      // 109
    Session.set('bz.control.search.searchedText', textName);                                                          // 110
    $('.js-nearby-places').typeahead('close');                                                                        // 111
    $('.js-nearby-places').blur();                                                                                    // 112
  }                                                                                                                   // 113
});                                                                                                                   // 114
Template.bzChooseLocationModal.helpers({                                                                              // 115
  placesArray: function () {                                                                                          // 116
    var ret = [                                                                                                       // 117
      {                                                                                                               // 118
        name: 'my-places',                                                                                            // 119
        valueKey: 'name',                                                                                             // 120
        displayKey: 'name',                                                                                           // 121
        template: 'googlePlacesItem',                                                                                 // 122
        header: '<h3 class="league-name">My Saved Places</h3>',                                                       // 123
        local: function () {                                                                                          // 124
          ret = bz.cols.locations.find().fetch().map(function (item) {                                                // 125
            //return {id: item._id, value: item.name};                                                                // 126
            return item;                                                                                              // 127
          });                                                                                                         // 128
                                                                                                                      // 129
          return ret;                                                                                                 // 130
        }                                                                                                             // 131
      },                                                                                                              // 132
      {                                                                                                               // 133
        name: 'google-places',                                                                                        // 134
        valueKey: 'name',                                                                                             // 135
        displayKey: 'name',                                                                                           // 136
        template: 'googlePlacesItem',                                                                                 // 137
        header: '<h3 class="league-name">Google Places Nearby</h3>',                                                  // 138
        local: function () {                                                                                          // 139
          ret = bz.runtime.maps.places.find({searchEngine: 'google'}).fetch().map(function (item) {                   // 140
            return item;                                                                                              // 141
          });                                                                                                         // 142
                                                                                                                      // 143
          return ret;                                                                                                 // 144
        }                                                                                                             // 145
      },                                                                                                              // 146
      {                                                                                                               // 147
        name: 'yelp-places',                                                                                          // 148
        valueKey: 'name',                                                                                             // 149
        displayKey: 'name',                                                                                           // 150
        template: 'googlePlacesItem',                                                                                 // 151
        header: '<h3 class="league-name">Yelp Places Nearby</h3>',                                                    // 152
        local: function () {                                                                                          // 153
          ret = bz.runtime.maps.places.find().fetch().map(function (item) {                                           // 154
            return item;                                                                                              // 155
          });                                                                                                         // 156
                                                                                                                      // 157
          return ret;                                                                                                 // 158
        }                                                                                                             // 159
      }                                                                                                               // 160
    ];                                                                                                                // 161
    return ret;                                                                                                       // 162
  },                                                                                                                  // 163
  /*getCurrentLocationName: function () { //FromSearchControl                                                         // 164
    return Session.get(this.sessionName) &&  Session.get(this.sessionName).dbObject && Session.get(this.sessionName).dbObject.name;
  },*/                                                                                                                // 166
  getUserLocations: function () {                                                                                     // 167
    var ret;                                                                                                          // 168
    if (Meteor.userId()) {                                                                                            // 169
                                                                                                                      // 170
      ret = bz.cols.locations.find({                                                                                  // 171
        userId: Meteor.userId()                                                                                       // 172
      });                                                                                                             // 173
    }                                                                                                                 // 174
    return ret;                                                                                                       // 175
  },                                                                                                                  // 176
  getPopularPlacesAround: function () {                                                                               // 177
                                                                                                                      // 178
  }                                                                                                                   // 179
});                                                                                                                   // 180
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/template.search-location.js                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("bzControlSearchLocation");                                                                      // 2
Template["bzControlSearchLocation"] = new Template("Template.bzControlSearchLocation", (function() {                  // 3
  var view = this;                                                                                                    // 4
  return HTML.Raw('<div class="bz-control--search-location search-field">\n    <div class="form-group bz-search-size">\n\n      <!--<input type="search" placeholder="I am looking for OR I am going to ..." name="searchword" autocomplete="off">-->\n\n      <!-- <input class="form-control typeahead capitalize js-nearby-places" name="team" type="text"\n              placeholder="place nearby"\n              data-source="placesArray"\n\n              autocomplete="on" spellcheck="off"\n              data-opened="opened" data-selected="selected"\n              data-min-length="0"\n              data-autocompleted="autocompleted"\n           />-->\n      <!--<input class="form-control typeahead js-nearby-places" name="team" type="text"-->\n             <!--placeholder="{{ t9n \'searchLocationText\'}}"-->\n             <!--data-sets="joinedArray"-->\n\n             <!--autocomplete="on" spellcheck="off"-->\n             <!--data-min-length="0"-->\n             <!--data-opened="opened" data-selected="selected1"-->\n             <!--data-template="teamList"-->\n          <!--/>-->\n    </div>\n  </div>');
}));                                                                                                                  // 6
                                                                                                                      // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/search-location.js                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/8/15.                                                                                        // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
/*Meteor.startup(function () {                                                                                        // 5
  bz.help.maps.getCurrentLocation(function (loc) {                                                                    // 6
    Session.set('bz.control.search.location', {                                                                       // 7
      coords: loc,                                                                                                    // 8
      name: 'My Location'                                                                                             // 9
    });                                                                                                               // 10
  });                                                                                                                 // 11
});*/                                                                                                                 // 12
                                                                                                                      // 13
Template.bzControlSearchLocation.created = function () {                                                              // 14
  /*bz.help.maps.initLocation();                                                                                      // 15
  bz.help.maps.initPlaces();                                                                                          // 16
  // doc.ready happened, so:                                                                                          // 17
  bz.help.maps.googleMapsLoad();*/                                                                                    // 18
                                                                                                                      // 19
}                                                                                                                     // 20
                                                                                                                      // 21
Template.bzControlSearchLocation.onRendered(function () {                                                             // 22
                                                                                                                      // 23
  Meteor.typeahead.inject();                                                                                          // 24
                                                                                                                      // 25
});                                                                                                                   // 26
                                                                                                                      // 27
Template.bzControlSearchLocation.helpers({                                                                            // 28
  placesArray: function () {                                                                                          // 29
    return bz.runtime.maps.places.find().fetch().map(function (object) {                                              // 30
      return {id: object._id, value: object.name};                                                                    // 31
    });                                                                                                               // 32
  },                                                                                                                  // 33
  joinedArray: function () {                                                                                          // 34
    var ret = [                                                                                                       // 35
      {                                                                                                               // 36
        name: 'google-places',                                                                                        // 37
        valueKey: 'name',                                                                                             // 38
        displayKey: 'name',                                                                                           // 39
        template: 'googlePlacesItem',                                                                                 // 40
        header: '<h3 class="league-name">Google Places Nearby</h3>',                                                  // 41
        local: function () {                                                                                          // 42
          ret = bz.runtime.maps.places.find({searchEngine: 'google'}).fetch().map(function (item) {                   // 43
            return item;                                                                                              // 44
          });                                                                                                         // 45
                                                                                                                      // 46
          return ret;                                                                                                 // 47
        }                                                                                                             // 48
      }/*,                                                                                                            // 49
      {                                                                                                               // 50
        name: 'yelp-places',                                                                                          // 51
        valueKey: 'name',                                                                                             // 52
        displayKey: 'name',                                                                                           // 53
        template: 'googlePlacesItem',                                                                                 // 54
        header: '<h3 class="league-name">Yelp Places Nearby</h3>',                                                    // 55
        local: function () {                                                                                          // 56
          ret = bz.runtime.maps.places.find({searchEngine: 'yelp'}).fetch().map(function (item) {                     // 57
            return item;                                                                                              // 58
          });                                                                                                         // 59
                                                                                                                      // 60
          return ret;                                                                                                 // 61
        }                                                                                                             // 62
      }*/                                                                                                             // 63
    ];                                                                                                                // 64
    return ret;                                                                                                       // 65
                                                                                                                      // 66
                                                                                                                      // 67
    /* {                                                                                                              // 68
     name: 'post-found',                                                                                              // 69
     valueKey: 'name',                                                                                                // 70
     displayKey: 'name',                                                                                              // 71
     template: 'postFoundItem',                                                                                       // 72
     header: '<h3 class="league-name">Post found</h3>',                                                               // 73
     local: function () {                                                                                             // 74
     //console.log(Session.get('bz.control.category-list.activeCategories'));                                         // 75
     var searchSelector, catList = Session.get('bz.control.category-list.activeCategories');                          // 76
     if (!catList || catList.length === 0) {                                                                          // 77
     searchSelector = {}                                                                                              // 78
     } else {                                                                                                         // 79
     searchSelector = {type: {$in: catList}}                                                                          // 80
     }                                                                                                                // 81
     Session.set('bz.control.search-selector', searchSelector);                                                       // 82
     var ret = _.unique(bz.cols.posts.find(searchSelector).fetch().map(function (item) {                              // 83
     item.name = item.details.title;                                                                                  // 84
     return item;                                                                                                     // 85
     }), function (item) {                                                                                            // 86
     return item.name                                                                                                 // 87
     });                                                                                                              // 88
                                                                                                                      // 89
     return ret;                                                                                                      // 90
     }                                                                                                                // 91
     }*/                                                                                                              // 92
  },                                                                                                                  // 93
  selected: function (event, suggestion, datasetName) {                                                               // 94
    var mapsPlaceId = suggestion && suggestion.id;                                                                    // 95
    //bz.runtime.newPost.location.mapsPlaceId = mapsPlaceId;                                                          // 96
    // make it look selected:                                                                                         // 97
    $('.js-location-nearby').addClass('selected');                                                                    // 98
  }                                                                                                                   // 99
});                                                                                                                   // 100
Template.bzControlSearchLocation.events({                                                                             // 101
  'blur .js-nearby-places': function () {                                                                             // 102
  },                                                                                                                  // 103
  'click .js-search-btn': function (e, v) {                                                                           // 104
    var text = $('.js-nearby-places.tt-input').val();                                                                 // 105
    if (text) {                                                                                                       // 106
      setSearchedText(text);                                                                                          // 107
    }                                                                                                                 // 108
    return false;                                                                                                     // 109
  },                                                                                                                  // 110
  //typeahead:                                                                                                        // 111
  'change .js-nearby-places': function (e) {                                                                          // 112
    var val = e.target.value;                                                                                         // 113
    if (!val || val.trim() === '') {                                                                                  // 114
      Session.set('bz.control.search.searchedText', '');                                                              // 115
    }                                                                                                                 // 116
  },                                                                                                                  // 117
  'typeahead:change .js-nearby-places': function (e, v, val) {                                                        // 118
    val = val && val.trim() || '';                                                                                    // 119
    Session.set('bz.control.search.searchedText', val);                                                               // 120
  },                                                                                                                  // 121
  'typeahead:select .js-nearby-places': function (e, v, val) {                                                        // 122
    val = val.name && val.name.trim() || '';                                                                          // 123
    Session.set('bz.control.search.searchedText', val);                                                               // 124
    $('.js-nearby-places').typeahead('close');                                                                        // 125
    $('.js-nearby-places').blur();                                                                                    // 126
  },                                                                                                                  // 127
  'keydown .js-nearby-places': function (e, v, val) {                                                                 // 128
    if(e.keyCode === 13){                                                                                             // 129
      // enter bnt hit                                                                                                // 130
      $('.js-nearby-places').typeahead('close');                                                                      // 131
      $('.js-nearby-places').blur();                                                                                  // 132
    }                                                                                                                 // 133
  }                                                                                                                   // 134
                                                                                                                      // 135
});                                                                                                                   // 136
                                                                                                                      // 137
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/template.search-results.js                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("searchResults");                                                                                // 2
Template["searchResults"] = new Template("Template.searchResults", (function() {                                      // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("getSearchedResults"));                                                         // 6
  }, function() {                                                                                                     // 7
    return [ "\n        ", HTML.DIV({                                                                                 // 8
      "class": "js-container-search-results bz-container-body"                                                        // 9
    }, "    \n            ", HTML.H2({                                                                                // 10
      "class": "title"                                                                                                // 11
    }, "Search result"), "\n        \n            ", HTML.DIV({                                                       // 12
      "class": "bz-search-results clearfix"                                                                           // 13
    }, "\n                ", HTML.DIV({                                                                               // 14
      "class": "bz-search-items"                                                                                      // 15
    }, "\n                    ", Blaze.Each(function() {                                                              // 16
      return Spacebars.call(view.lookup("getSearchedResults"));                                                       // 17
    }, function() {                                                                                                   // 18
      return [ "\n                        ", Spacebars.include(view.lookupTemplate("onePostRowItem")), "\n                    " ];
    }), "\n                "), "\n            "), "\n        "), "\n    " ];                                          // 20
  });                                                                                                                 // 21
}));                                                                                                                  // 22
                                                                                                                      // 23
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/search-results.js                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/19/15.                                                                                       // 2
 */                                                                                                                   // 3
Template.searchResults.onCreated(function () {                                                                        // 4
  //Session.get('bz.control.search.location');                                                                        // 5
});                                                                                                                   // 6
Template.searchResults.helpers({                                                                                      // 7
  getSearchedResults: function(){                                                                                     // 8
    return bz.cols.searchRt.find().fetch();                                                                           // 9
  }                                                                                                                   // 10
});                                                                                                                   // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/template.search.js                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("bzControlSearch");                                                                              // 2
Template["bzControlSearch"] = new Template("Template.bzControlSearch", (function() {                                  // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "bz-control--search search-field"                                                                        // 6
  }, "\n    ", HTML.DIV({                                                                                             // 7
    "class": "form-group bz-search-size"                                                                              // 8
  }, "\n\n      ", HTML.Raw('<!--<input type="search" placeholder="I am looking for OR I am going to ..." name="searchword" autocomplete="off">-->'), "\n\n      ", HTML.Raw('<!-- <input class="form-control typeahead capitalize js-nearby-places" name="team" type="text"\n              placeholder="place nearby"\n              data-source="placesArray"\n\n              autocomplete="on" spellcheck="off"\n              data-opened="opened" data-selected="selected"\n              data-min-length="0"\n              data-autocompleted="autocompleted"\n           />-->'), "\n      ", HTML.INPUT({
    "class": "form-control typeahead js-nearby-places",                                                               // 10
    name: "team",                                                                                                     // 11
    type: "text",                                                                                                     // 12
    placeholder: function() {                                                                                         // 13
      return Spacebars.mustache(view.lookup("t9n"), "lookingForText");                                                // 14
    },                                                                                                                // 15
    "data-sets": "joinedArray",                                                                                       // 16
    value: function() {                                                                                               // 17
      return Spacebars.mustache(Spacebars.dot(view.lookup("$"), "Session", "get"), "bz.control.search.searchedText"); // 18
    },                                                                                                                // 19
    autocomplete: "on",                                                                                               // 20
    spellcheck: "off",                                                                                                // 21
    "data-min-length": "0",                                                                                           // 22
    "data-opened": "opened",                                                                                          // 23
    "data-selected": "searchItemSelected",                                                                            // 24
    "data-template": "teamList"                                                                                       // 25
  }), "\n    "), "\n      \n      ", Spacebars.include(view.lookupTemplate("bzDistance")), HTML.Raw('\n      \n      <button class="button bz-btn-search js-search-btn"></button>\n\n      '), Blaze.If(function() {
    return Spacebars.call(view.lookup("searchTagIsVisible"));                                                         // 27
  }, function() {                                                                                                     // 28
    return [ "\n          ", Spacebars.include(view.lookupTemplate("bzSearchHashTagLabel")), "\n      " ];            // 29
  }), "\n      \n  ");                                                                                                // 30
}));                                                                                                                  // 31
                                                                                                                      // 32
Template.__checkName("googlePlacesItem");                                                                             // 33
Template["googlePlacesItem"] = new Template("Template.googlePlacesItem", (function() {                                // 34
  var view = this;                                                                                                    // 35
  return HTML.H4(HTML.Raw('<i class="fa fa-map-marker"></i>'), HTML.I(Blaze.View("lookup:name", function() {          // 36
    return Spacebars.mustache(view.lookup("name"));                                                                   // 37
  })));                                                                                                               // 38
}));                                                                                                                  // 39
                                                                                                                      // 40
Template.__checkName("postFoundItem");                                                                                // 41
Template["postFoundItem"] = new Template("Template.postFoundItem", (function() {                                      // 42
  var view = this;                                                                                                    // 43
  return HTML.H4(HTML.Raw('<i class="fa fa-map-pin"></i>'), HTML.I(Blaze.View("lookup:name", function() {             // 44
    return Spacebars.mustache(view.lookup("name"));                                                                   // 45
  })));                                                                                                               // 46
}));                                                                                                                  // 47
                                                                                                                      // 48
Template.__checkName("bzSearchHashTagLabel");                                                                         // 49
Template["bzSearchHashTagLabel"] = new Template("Template.bzSearchHashTagLabel", (function() {                        // 50
  var view = this;                                                                                                    // 51
  return Blaze.Unless(function() {                                                                                    // 52
    return Spacebars.call(view.lookup("isHashTagLabel"));                                                             // 53
  }, function() {                                                                                                     // 54
    return [ "\n ", HTML.DIV({                                                                                        // 55
      "class": "bz-hash-tag-label"                                                                                    // 56
    }, "\n     ", HTML.DIV({                                                                                          // 57
      "class": "bz-hash-tag-label-wrapper"                                                                            // 58
    }, "\n         ", HTML.DIV({                                                                                      // 59
      "class": "bz-hash-icon"                                                                                         // 60
    }, "#"), "\n         ", HTML.DIV({                                                                                // 61
      "class": "bz-hash-tag-label-text"                                                                               // 62
    }, Blaze.View("lookup:getLookingForPhrase", function() {                                                          // 63
      return Spacebars.mustache(view.lookup("getLookingForPhrase"));                                                  // 64
    })), "\n       ", HTML.DIV({                                                                                      // 65
      "class": "bz-hash-tag-label-button"                                                                             // 66
    }, HTML.BUTTON({                                                                                                  // 67
      "class": "button bz-small btn-default js-save-hash-btn"                                                         // 68
    }, "Save hash")), "\n     "), "\n "), "\n    " ];                                                                 // 69
  });                                                                                                                 // 70
}));                                                                                                                  // 71
                                                                                                                      // 72
Template.__checkName("bzDistance");                                                                                   // 73
Template["bzDistance"] = new Template("Template.bzDistance", (function() {                                            // 74
  var view = this;                                                                                                    // 75
  return HTML.DIV({                                                                                                   // 76
    "class": "bz-distance"                                                                                            // 77
  }, "\n        ", HTML.FORM({                                                                                        // 78
    id: "dropdown-distance",                                                                                          // 79
    "class": "bz-dropdown"                                                                                            // 80
  }, "\n            ", HTML.SELECT({                                                                                  // 81
    id: "selectDis11",                                                                                                // 82
    "class": "js-dropdown-distance",                                                                                  // 83
    "data-prompt": function() {                                                                                       // 84
      return Spacebars.mustache(view.lookup("t9n"), "distance");                                                      // 85
    }                                                                                                                 // 86
  }, "\n                ", HTML.Raw('<option value="0.0378788">200 ft</option>'), "\n                ", HTML.Raw('<option value="1" selected="">1 mile</option>'), "\n                ", HTML.Raw('<option value="5">5 mile</option>'), "\n                ", HTML.Raw('<option value="20">20 mile</option>'), "\n            "), "\n        "), "\n    ");
}));                                                                                                                  // 88
                                                                                                                      // 89
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arutune:bz-page-search/client/browser/search.js                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by Ashot on 9/8/15.                                                                                        // 2
 */                                                                                                                   // 3
/*Template.bzControlSearch.rendered = function () {                                                                   // 4
                                                                                                                      // 5
 }                                                                                                                    // 6
 Template.bzControlSearch.events({                                                                                    // 7
 'keydown .js-search-text': function (e, v) {                                                                         // 8
 if (!isOn) {                                                                                                         // 9
 v.$('.js-search-posts-link').click();                                                                                // 10
 $('.js-search-text-modal').val($('.js-search-text').val())                                                           // 11
 $('.js-search-text-modal').focus();                                                                                  // 12
 }                                                                                                                    // 13
 }                                                                                                                    // 14
 });*/                                                                                                                // 15
                                                                                                                      // 16
                                                                                                                      // 17
Template.bzDistance.rendered = function () {                                                                          // 18
  //$("#selectDis").trigger("change", true);                                                                          // 19
  $('select').foundationSelect();                                                                                     // 20
};                                                                                                                    // 21
                                                                                                                      // 22
Template.bzDistance.events({                                                                                          // 23
  'change #selectDis': function (e) {                                                                                 // 24
    var $this = $(this);                                                                                              // 25
    console.log($this);                                                                                               // 26
  },                                                                                                                  // 27
  'click #select-selectDis li': function(e) {                                                                         // 28
    var target = $(e.target);                                                                                         // 29
    if (target.is('li.disable')) {                                                                                    // 30
      return false;                                                                                                   // 31
    }                                                                                                                 // 32
                                                                                                                      // 33
    var ret = target.text();                                                                                          // 34
    console.log(ret);                                                                                                 // 35
  },                                                                                                                  // 36
  'click #select-selectDis11 li': function(e, v){                                                                     // 37
    var distStr = e.target.dataset.value,                                                                             // 38
      dist = Number.parseFloat(distStr);                                                                              // 39
    if(dist !== NaN) {                                                                                                // 40
      Session.set('bz.control.search.distance', dist);                                                                // 41
    }                                                                                                                 // 42
  }                                                                                                                   // 43
});                                                                                                                   // 44
                                                                                                                      // 45
                                                                                                                      // 46
Meteor.startup(function () {                                                                                          // 47
  bz.help.maps.getCurrentLocation(function (loc) {                                                                    // 48
    Session.set('bz.control.search.location', {                                                                       // 49
      coords: loc,                                                                                                    // 50
      name: bz.const.places.CURRENT_LOCATION                                                                          // 51
    });                                                                                                               // 52
  });                                                                                                                 // 53
});                                                                                                                   // 54
                                                                                                                      // 55
                                                                                                                      // 56
Template.bzControlSearch.created = function () {                                                                      // 57
  //bzControlSearchCreated();                                                                                         // 58
}                                                                                                                     // 59
                                                                                                                      // 60
Template.bzControlSearch.onRendered(function () {                                                                     // 61
  Meteor.typeahead.inject();                                                                                          // 62
  Session.set('bz.control.search.searchedText', '');                                                                  // 63
});                                                                                                                   // 64
                                                                                                                      // 65
Template.bzControlSearch.helpers({                                                                                    // 66
  placesArray: function () {                                                                                          // 67
    return bz.runtime.maps.places.find().fetch().map(function (object) {                                              // 68
      return {id: object._id, value: object.name};                                                                    // 69
    });                                                                                                               // 70
  },                                                                                                                  // 71
  joinedArray: function () {                                                                                          // 72
    var ret = [                                                                                                       // 73
      /*{                                                                                                             // 74
        name: 'google-places',                                                                                        // 75
        valueKey: 'name',                                                                                             // 76
        displayKey: 'name',                                                                                           // 77
        template: 'googlePlacesItem',                                                                                 // 78
        header: '<h3 class="league-name">Google Places Nearby</h3>',                                                  // 79
        local: function () {                                                                                          // 80
          ret = bz.runtime.maps.places.find({searchEngine: 'google'}).fetch().map(function (item) {                   // 81
            return item;                                                                                              // 82
          });                                                                                                         // 83
                                                                                                                      // 84
          return ret;                                                                                                 // 85
        }                                                                                                             // 86
      },                                                                                                              // 87
      {                                                                                                               // 88
        name: 'yelp-places',                                                                                          // 89
        valueKey: 'name',                                                                                             // 90
        displayKey: 'name',                                                                                           // 91
        template: 'googlePlacesItem',                                                                                 // 92
        header: '<h3 class="league-name">Yelp Places Nearby</h3>',                                                    // 93
        local: function () {                                                                                          // 94
          ret = bz.runtime.maps.places.find().fetch().map(function (item) {                                           // 95
            return item;                                                                                              // 96
          });                                                                                                         // 97
                                                                                                                      // 98
          return ret;                                                                                                 // 99
        }                                                                                                             // 100
      },*/                                                                                                            // 101
      {                                                                                                               // 102
        name: 'post-found',                                                                                           // 103
        valueKey: 'name',                                                                                             // 104
        displayKey: 'name',                                                                                           // 105
        template: 'postFoundItem',                                                                                    // 106
        header: '<h3 class="league-name">Posts found</h3>',                                                           // 107
        local: function () {                                                                                          // 108
          //console.log(Session.get('bz.control.category-list.activeCategories'));                                    // 109
          var searchSelector = {                                                                                      // 110
                'status.visible': bz.const.posts.status.visibility.VISIBLE                                            // 111
              },                                                                                                      // 112
              catList = Session.get('bz.control.category-list.activeCategories');                                     // 113
                                                                                                                      // 114
          if (catList && catList.length > 0) {                                                                        // 115
            searchSelector.type = {$in: catList};                                                                     // 116
          }                                                                                                           // 117
                                                                                                                      // 118
          Session.set('bz.control.search-selector', searchSelector);                                                  // 119
          var ret = _.unique(bz.cols.posts.find(searchSelector).fetch().map(function (item) {                         // 120
            item.name = item.details.title;                                                                           // 121
            return item;                                                                                              // 122
          }), function (item) {                                                                                       // 123
            return item.name                                                                                          // 124
          });                                                                                                         // 125
          /*                                                                                                          // 126
           var ret = bz.cols.posts.find(searchSelector).fetch().map(function (item) {                                 // 127
           item.name = item.details.title;                                                                            // 128
           return item;                                                                                               // 129
           });*/                                                                                                      // 130
          return ret;                                                                                                 // 131
        }                                                                                                             // 132
      }];                                                                                                             // 133
                                                                                                                      // 134
    return ret;                                                                                                       // 135
    /*var ret = {                                                                                                     // 136
     id: object._id,                                                                                                  // 137
     value: object.name                                                                                               // 138
     };*/                                                                                                             // 139
    /*{                                                                                                               // 140
     name: 'nba-teams',                                                                                               // 141
     local: function() { return Nba.find().fetch().map(function(it){ return it.name; }); },                           // 142
     header: '<h3 class="league-name">NBA Teams</h3>'                                                                 // 143
     }                                                                                                                // 144
     return bz.runtime.maps.places.find().fetch().map(function (object) {                                             // 145
     return ret;                                                                                                      // 146
     });*/                                                                                                            // 147
  },                                                                                                                  // 148
  searchItemSelected: function (event, suggestion, datasetName) {                                                     // 149
    var mapsPlaceId = suggestion && suggestion.id;                                                                    // 150
    //bz.runtime.newPost.location.mapsPlaceId = mapsPlaceId;                                                          // 151
    // make it look selected:                                                                                         // 152
    $('.js-location-nearby').addClass('selected');                                                                    // 153
  },                                                                                                                  // 154
  searchTagIsVisible: function(e, v){                                                                                 // 155
    return Session.get('bz.control.search.searchedText') !== '' && Session.get('bz.control.search.searchedText') !== undefined;
  }                                                                                                                   // 157
});                                                                                                                   // 158
Template.bzControlSearch.events({                                                                                     // 159
  'blur .js-nearby-places': function () {                                                                             // 160
  },                                                                                                                  // 161
  'click .js-search-btn': function (e, v) {                                                                           // 162
    var text = $('.js-nearby-places.tt-input').val();                                                                 // 163
    if (text) {                                                                                                       // 164
      Session.set('bz.control.search.searchedText', text);                                                            // 165
    }                                                                                                                 // 166
    return false;                                                                                                     // 167
  },                                                                                                                  // 168
  //typeahead:                                                                                                        // 169
  'change .js-nearby-places': function (e) {                                                                          // 170
    var val = e.target.value;                                                                                         // 171
    if (!val || val.trim() === '') {                                                                                  // 172
      Session.set('bz.control.search.searchedText', '');                                                              // 173
    }                                                                                                                 // 174
  },                                                                                                                  // 175
  'typeahead:change .js-nearby-places': function (e, v, val) {                                                        // 176
    val = val && val.trim() || '';                                                                                    // 177
    Session.set('bz.control.search.searchedText', val);                                                               // 178
  },                                                                                                                  // 179
  'typeahead:select .js-nearby-places': function (e, v, val) {                                                        // 180
    val = val.name && val.name.trim() || '';                                                                          // 181
    Session.set('bz.control.search.searchedText', val);                                                               // 182
    $('.js-nearby-places').typeahead('close');                                                                        // 183
    $('.js-nearby-places').blur();                                                                                    // 184
  },                                                                                                                  // 185
  'keydown .js-nearby-places': function (e, v, val) {                                                                 // 186
    if (e.keyCode === 13) {                                                                                           // 187
      // enter bnt hit                                                                                                // 188
      $('.js-nearby-places').typeahead('close');                                                                      // 189
      $('.js-nearby-places').blur();                                                                                  // 190
    }                                                                                                                 // 191
  }                                                                                                                   // 192
                                                                                                                      // 193
});                                                                                                                   // 194
                                                                                                                      // 195
Template.bzSearchHashTagLabel.rendered = function() {                                                                 // 196
  var el = $('.bz-hash-tag-label');                                                                                   // 197
                                                                                                                      // 198
  if(el) {                                                                                                            // 199
    var elHeight = $('.bz-hash-tag-label').height(),                                                                  // 200
        elHeigtZero = $('.bz-hash-tag-label').height(0);                                                              // 201
                                                                                                                      // 202
    setTimeout(function() {                                                                                           // 203
      el.height(elHeight);                                                                                            // 204
    } ,250);                                                                                                          // 205
  }                                                                                                                   // 206
                                                                                                                      // 207
                                                                                                                      // 208
                                                                                                                      // 209
};                                                                                                                    // 210
                                                                                                                      // 211
Template.bzSearchHashTagLabel.helpers({                                                                               // 212
  getLookingForPhrase: function(){                                                                                    // 213
    var loc = Session.get('bz.control.search.location') || '',                                                        // 214
      dist = Session.get('bz.control.search.distance') || '',                                                         // 215
      text = Session.get('bz.control.search.searchedText') || 'buzz',                                                 // 216
    ret = 'Looking for '  + text + ' around ';                                                                        // 217
    if(loc.name){                                                                                                     // 218
      loc = loc.name;                                                                                                 // 219
    }                                                                                                                 // 220
    if(dist){                                                                                                         // 221
      dist = ' within ' + dist + ' mile';                                                                             // 222
    }                                                                                                                 // 223
    ret += loc + dist;                                                                                                // 224
                                                                                                                      // 225
    return ret;                                                                                                       // 226
  },                                                                                                                  // 227
  isHashTagLabel: function() {                                                                                        // 228
                                                                                                                      // 229
    var userTypeHash = Session.get('bz.control.search.searchedText');                                                 // 230
                                                                                                                      // 231
    var isHashTag = bz.cols.hashes.find({userId: Meteor.userId()}).fetch().map(function(obj) {                        // 232
      return {value: obj.details.text}                                                                                // 233
    });                                                                                                               // 234
                                                                                                                      // 235
    for(var i = 0; i < isHashTag.length; i++) {                                                                       // 236
      if(userTypeHash == isHashTag[i].value) {                                                                        // 237
        var result = isHashTag[i].value;                                                                              // 238
        return result;                                                                                                // 239
      }                                                                                                               // 240
    }                                                                                                                 // 241
  }                                                                                                                   // 242
});                                                                                                                   // 243
Template.bzSearchHashTagLabel.events({                                                                                // 244
  'click .js-save-hash-btn': function(e, v) {                                                                         // 245
    var loc = Session.get('bz.control.search.location') || {                                                          // 246
          coords: {}                                                                                                  // 247
        },                                                                                                            // 248
        dist = Session.get('bz.control.search.distance') || '',                                                       // 249
        text = Session.get('bz.control.search.searchedText') || '';                                                   // 250
                                                                                                                      // 251
    bz.cols.hashes.insert({                                                                                           // 252
      userId: Meteor.userId(),                                                                                        // 253
      details: {                                                                                                      // 254
        text: text,                                                                                                   // 255
        distance: dist,                                                                                               // 256
        coords: loc.coords,                                                                                           // 257
        locName: loc.name                                                                                             // 258
      }                                                                                                               // 259
    });                                                                                                               // 260
                                                                                                                      // 261
                                                                                                                      // 262
                                                                                                                      // 263
    return false;                                                                                                     // 264
  }                                                                                                                   // 265
});                                                                                                                   // 266
                                                                                                                      // 267
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
