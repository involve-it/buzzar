(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-page-home/client/router.js                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by douson on 03.07.15.                                                                                   // 2
 */                                                                                                                 // 3
                                                                                                                    // 4
Router.map(function () {                                                                                            // 5
  this.route('home', {                                                                                              // 6
    path: '/home',                                                                                                  // 7
    template: 'pageHome',                                                                                           // 8
    layoutTemplate: 'mainLayoutHome',                                                                               // 9
    onBeforeAction: function () {                                                                                   // 10
      var qs = this.params.query;                                                                                   // 11
                                                                                                                    // 12
      setSearchTextFromQs(qs);                                                                                      // 13
      setSearchLocationFromQs(qs);                                                                                  // 14
                                                                                                                    // 15
      this.next();                                                                                                  // 16
    }                                                                                                               // 17
  });                                                                                                               // 18
});                                                                                                                 // 19
                                                                                                                    // 20
                                                                                                                    // 21
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-page-home/client/controller.js                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by Ashot on 9/19/15.                                                                                     // 2
 */                                                                                                                 // 3
                                                                                                                    // 4
setSearchTextFromQs = function(qs) {                                                                                // 5
  var qs = qs || {}                                                                                                 // 6
                                                                                                                    // 7
  if(qs.searchText){                                                                                                // 8
    Session.set('bz.control.search.searchedText', qs.searchText);                                                   // 9
  }                                                                                                                 // 10
}                                                                                                                   // 11
                                                                                                                    // 12
setSearchLocationFromQs = function(qs){                                                                             // 13
  var qs = qs || {}                                                                                                 // 14
                                                                                                                    // 15
  if(qs.locationName){ // there is a location defined, need to put it in the search field:                          // 16
    //var loc = Session.get('bz.control.search.location'),                                                          // 17
    var  userId = Meteor.userId(), locObj;                                                                          // 18
    if(!userId) {                                                                                                   // 19
      bz.help.logError('home qs error: userId not defined');                                                        // 20
    }                                                                                                               // 21
    locObj = bz.cols.locations.searchByLocationNamedUserId(qs.locationName, userId);                                // 22
                                                                                                                    // 23
    if(locObj){                                                                                                     // 24
      Session.set('bz.control.search.location', locObj);                                                            // 25
    }                                                                                                               // 26
  }                                                                                                                 // 27
}                                                                                                                   // 28
                                                                                                                    // 29
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-page-home/client/browser/template.around-you.js                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("aroundYou");                                                                                  // 2
Template["aroundYou"] = new Template("Template.aroundYou", (function() {                                            // 3
  var view = this;                                                                                                  // 4
  return HTML.DIV({                                                                                                 // 5
    "class": "bz-around-you"                                                                                        // 6
  }, "\n\n    ", HTML.DIV({                                                                                         // 7
    "class": "bz-items"                                                                                             // 8
  }, "\n      ", HTML.DIV({                                                                                         // 9
    "class": "row"                                                                                                  // 10
  }, "\n        ", HTML.Raw('<h2 class="title">Buzz Around you</h2>'), "\n        ", Blaze.Each(function() {        // 11
    return Spacebars.call(view.lookup("aroundItem"));                                                               // 12
  }, function() {                                                                                                   // 13
    return [ "\n          ", Spacebars.include(view.lookupTemplate("bzAroundYouItem")), "\n        " ];             // 14
  }), "\n      "), "\n    "), "\n\n  ");                                                                            // 15
}));                                                                                                                // 16
                                                                                                                    // 17
Template.__checkName("bzAroundYouItem");                                                                            // 18
Template["bzAroundYouItem"] = new Template("Template.bzAroundYouItem", (function() {                                // 19
  var view = this;                                                                                                  // 20
  return HTML.DIV({                                                                                                 // 21
    "class": "small-12 medium-6 large-4 columns left"                                                               // 22
  }, "\n    ", HTML.DIV({                                                                                           // 23
    "class": "bz-item"                                                                                              // 24
  }, "\n      ", HTML.DIV({                                                                                         // 25
    "class": "bz-side-a"                                                                                            // 26
  }, "\n        ", Blaze._TemplateWith(function() {                                                                 // 27
    return Spacebars.call(view.lookup("getPostOwner"));                                                             // 28
  }, function() {                                                                                                   // 29
    return Spacebars.include(view.lookupTemplate("bzUserProfileAroundYou"));                                        // 30
  }), "\n      "), "\n      ", HTML.DIV({                                                                           // 31
    "class": "bz-side-b"                                                                                            // 32
  }, "\n        ", HTML.Raw('<div class="arrow"></div>'), "\n        ", HTML.DIV({                                  // 33
    "class": "bz-photo bz-overlay-hover"                                                                            // 34
  }, "\n          ", HTML.A({                                                                                       // 35
    href: function() {                                                                                              // 36
      return [ "/post/", Spacebars.mustache(view.lookup("_id")) ];                                                  // 37
    }                                                                                                               // 38
  }, "\n            ", HTML.IMG({                                                                                   // 39
    width: "400",                                                                                                   // 40
    height: "300",                                                                                                  // 41
    "class": "bz-overlay-scale",                                                                                    // 42
    src: function() {                                                                                               // 43
      return Spacebars.mustache(view.lookup("getImgSrc"));                                                          // 44
    },                                                                                                              // 45
    alt: ""                                                                                                         // 46
  }), "\n            ", HTML.DIV({                                                                                  // 47
    "class": "bz-post-info"                                                                                         // 48
  }, "\n                ", HTML.Raw('<!--<div class="bz-distance"><i class="fa fa-location-arrow"></i> 30 km</div>-->'), "\n                ", Blaze._TemplateWith(function() {
    return Spacebars.call(view.lookup("."));                                                                        // 50
  }, function() {                                                                                                   // 51
    return Spacebars.include(view.lookupTemplate("bzPostsPostPresence"));                                           // 52
  }), "\n                ", HTML.Raw('<!--<a class="bz-position-cover" href="#"></a>-->'), "\n            "), "\n          "), "\n        "), "\n\n        ", HTML.DIV({
    "class": "bz-content"                                                                                           // 54
  }, "\n            ", HTML.H4({                                                                                    // 55
    "class": "bz-title"                                                                                             // 56
  }, Blaze.View("lookup:details.title", function() {                                                                // 57
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "title"));                                      // 58
  })), "\n            ", HTML.P({                                                                                   // 59
    "class": "post-item-text"                                                                                       // 60
  }, "\n                ", Blaze.View("lookup:details.description", function() {                                    // 61
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "description"));                                // 62
  }), "\n            "), "\n            ", HTML.DIV({                                                               // 63
    "class": "bz-text-align-right"                                                                                  // 64
  }, "\n                ", HTML.A({                                                                                 // 65
    "class": "bz-read-more",                                                                                        // 66
    href: function() {                                                                                              // 67
      return [ "/post/", Spacebars.mustache(view.lookup("_id")) ];                                                  // 68
    }                                                                                                               // 69
  }, "Read more"), "\n            "), "\n        "), "\n        ", HTML.DIV({                                       // 70
    "class": "bz-item-footer"                                                                                       // 71
  }, "\n            ", Blaze.If(function() {                                                                        // 72
    return Spacebars.call(Spacebars.dot(view.lookup("details"), "price"));                                          // 73
  }, function() {                                                                                                   // 74
    return [ "\n                ", HTML.DIV({                                                                       // 75
      "class": "bz-price"                                                                                           // 76
    }, Blaze.View("lookup:details.price", function() {                                                              // 77
      return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "price"));                                    // 78
    }), " ", HTML.SPAN({                                                                                            // 79
      "class": "bz-prefix"                                                                                          // 80
    }, "$")), "\n            " ];                                                                                   // 81
  }), "\n          ", HTML.DIV({                                                                                    // 82
    "class": "bz-category"                                                                                          // 83
  }, "\n            ", HTML.DIV({                                                                                   // 84
    "class": function() {                                                                                           // 85
      return [ "button bz-btn-category type-category-", Spacebars.mustache(view.lookup("categoryType")) ];          // 86
    }                                                                                                               // 87
  }, "\n              ", Blaze.View("lookup:categoryType", function() {                                             // 88
    return Spacebars.mustache(view.lookup("categoryType"));                                                         // 89
  }), "\n            "), "\n          "), "\n          \n\n        "), "\n      "), "\n    "), "\n  ");             // 90
}));                                                                                                                // 91
                                                                                                                    // 92
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-page-home/client/browser/around-you.js                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by root on 9/15/15.                                                                                      // 2
 */                                                                                                                 // 3
                                                                                                                    // 4
Template.bzAroundYouItem.onCreated(function(){                                                                      // 5
  Meteor.subscribe('bz.users.all');                                                                                 // 6
});                                                                                                                 // 7
                                                                                                                    // 8
Template.bzAroundYouItem.rendered = function() {                                                                    // 9
                                                                                                                    // 10
  /*init Rate*/                                                                                                     // 11
  $('.bz-rating').raty({                                                                                            // 12
    starType: 'i'                                                                                                   // 13
  });                                                                                                               // 14
                                                                                                                    // 15
  var lineH = $('.bz-content .post-item-text').css('line-height');                                                  // 16
  if (Number.parseInt(lineH) !== 'NaN'){                                                                            // 17
    lineH = Number.parseInt(lineH);                                                                                 // 18
  } else {                                                                                                          // 19
    lineH = 20;                                                                                                     // 20
  }                                                                                                                 // 21
  $('.bz-content .post-item-text').css('max-height', lineH * 2);                                                    // 22
};                                                                                                                  // 23
                                                                                                                    // 24
Template.aroundYou.helpers({                                                                                        // 25
  aroundItem: function() {                                                                                          // 26
    var searchSelector = Session.get('bz.control.search-selector');                                                 // 27
    var ret = bz.cols.posts.find(searchSelector, {limit:3}).fetch();                                                // 28
                                                                                                                    // 29
    return ret;                                                                                                     // 30
  }                                                                                                                 // 31
});                                                                                                                 // 32
                                                                                                                    // 33
Template.bzAroundYouItem.helpers({                                                                                  // 34
  getPostOwner: function(){                                                                                         // 35
    return Meteor.users.findOne(this.userId);                                                                       // 36
  },                                                                                                                // 37
  categoryType: function() {                                                                                        // 38
    /*                                                                                                              // 39
    var postsId = bz.cols.posts.find({_id: this._id}).fetch()[0].type;                                              // 40
                                                                                                                    // 41
    if(postsId) {                                                                                                   // 42
      var ret = bz.cols.siteTypes.find({_id: postsId}).fetch()[0].name;                                             // 43
    }*/                                                                                                             // 44
    return bz.cols.posts.find({_id: this._id}).fetch()[0].type;                                                     // 45
  },                                                                                                                // 46
  getRank: function() {},                                                                                           // 47
  getTimeStamp: function(){                                                                                         // 48
    return Date.now();                                                                                              // 49
  },                                                                                                                // 50
  getImgSrc: function(){                                                                                            // 51
    var ret, phId = this.details.photos && this.details.photos[0];                                                  // 52
    if(phId){                                                                                                       // 53
      ret = bz.cols.images.findOne(phId);                                                                           // 54
      ret = ret && ret.data;                                                                                        // 55
    }                                                                                                               // 56
    return ret;                                                                                                     // 57
  }                                                                                                                 // 58
});                                                                                                                 // 59
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-page-home/client/browser/template.page-home.js                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("pageHome");                                                                                   // 2
Template["pageHome"] = new Template("Template.pageHome", (function() {                                              // 3
  var view = this;                                                                                                  // 4
  return [ HTML.DIV({                                                                                               // 5
    "class": "bz-container nav-bg-transparent"                                                                      // 6
  }, "\n    ", HTML.DIV({                                                                                           // 7
    "class": "bz-header"                                                                                            // 8
  }, "\n\n      ", Spacebars.include(view.lookupTemplate("bzNavBar")), "\n\n      ", HTML.DIV({                     // 9
    "class": "bz-search"                                                                                            // 10
  }, "\n        ", HTML.DIV({                                                                                       // 11
    "class": "box-search"                                                                                           // 12
  }, "\n          ", HTML.DIV({                                                                                     // 13
    "class": "bz-category-buttons"                                                                                  // 14
  }, "\n            ", Spacebars.include(view.lookupTemplate("categoryListButtons")), "\n          "), "\n\n          ", HTML.FORM({
    "class": "search",                                                                                              // 16
    id: "bz-search",                                                                                                // 17
    role: "search",                                                                                                 // 18
    method: "post",                                                                                                 // 19
    action: "#"                                                                                                     // 20
  }, "\n            ", HTML.Raw('<i class="icon ion-search placeholder-icon"></i>'), "\n            ", HTML.Raw('<!--<div class="search-field"><input type="search" placeholder="I am looking for OR I am going to ..." name="searchword"  autocomplete="off"></div>-->'), "\n            \n\n            ", Spacebars.include(view.lookupTemplate("bzControlSearch")), "\n\n          "), "\n            \n        "), "\n      "), "\n\n    "), "\n  "), HTML.Raw("\n\n    <!-- search result on the home page -->\n  "), HTML.DIV({
    "class": "container-background"                                                                                 // 22
  }, "\n    \n    ", Spacebars.include(view.lookupTemplate("searchResults")), "\n    \n    ", HTML.SECTION({        // 23
    id: "bz-around-you",                                                                                            // 24
    "class": "bz-container-body"                                                                                    // 25
  }, "\n        ", Spacebars.include(view.lookupTemplate("aroundYou")), "\n    "), "\n      \n    ", HTML.SECTION({ // 26
    id: "bz-bottom-a",                                                                                              // 27
    "class": "bz-container-body bz-gray-background"                                                                 // 28
  }, "\n        \n        ", HTML.DIV({                                                                             // 29
    "class": "bz-about-us"                                                                                          // 30
  }, "\n            ", HTML.Raw('<h2 class="title">About us</h2>'), "\n            \n            ", HTML.Raw('<div class="text-overlay-bottom">\n                <p class="bz-padding-top-x1 text-center">\n                    Think of us as of "Google For People": the way Google lets you search through urls in Web, we let you search among real people around you. Like Google has it\'s ranking system to order url relevancy, we have our sophisticated Karma algorithm, phone# verification and other means to rank real posts\' credibility.\n                </p>\n            </div>'), "\n            \n            ", HTML.DIV({
    "class": "js-about-us hidden"                                                                                   // 32
  }, "\n                ", Spacebars.include(view.lookupTemplate("aboutUs")), "\n            "), "\n\n            ", HTML.Raw('<div class="text-center bz-padding-top-x1">\n                <a class="button btn-default" href="/about-us">read more</a>\n            </div>'), "\n            \n            \n        "), "\n        \n    "), "\n      \n  ") ];
}));                                                                                                                // 34
                                                                                                                    // 35
Template.__checkName("bzMeteorLogo");                                                                               // 36
Template["bzMeteorLogo"] = new Template("Template.bzMeteorLogo", (function() {                                      // 37
  var view = this;                                                                                                  // 38
  return HTML.Raw('<div>\n    <a href="/home" style="color: white;">\n      BUZZAR<span>ound</span>\n    </a>\n  </div>');
}));                                                                                                                // 40
                                                                                                                    // 41
Template.__checkName("searchPostsModal");                                                                           // 42
Template["searchPostsModal"] = new Template("Template.searchPostsModal", (function() {                              // 43
  var view = this;                                                                                                  // 44
  return Blaze._TemplateWith(function() {                                                                           // 45
    return {                                                                                                        // 46
      title: Spacebars.call("Url Post Details")                                                                     // 47
    };                                                                                                              // 48
  }, function() {                                                                                                   // 49
    return Spacebars.include(view.lookupTemplate("ionModal"), function() {                                          // 50
      return [ "\n    ", HTML.DIV({                                                                                 // 51
        "class": "padding"                                                                                          // 52
      }, "\n      ", HTML.LABEL({                                                                                   // 53
        "class": "item item-input"                                                                                  // 54
      }, "\n        ", HTML.I({                                                                                     // 55
        "class": "icon ion-search placeholder-icon"                                                                 // 56
      }), "\n        ", HTML.INPUT({                                                                                // 57
        type: "text",                                                                                               // 58
        "class": "capitalize js-search-text-modal",                                                                 // 59
        placeholder: "find anything around you"                                                                     // 60
      }), "\n      "), "\n\n      ", HTML.Comment("Title: <span>{{ getTitle }}</span>"), "\n\n      ", Spacebars.include(view.lookupTemplate("globalSearch")), "\n    "), "\n  " ];
    });                                                                                                             // 62
  });                                                                                                               // 63
}));                                                                                                                // 64
                                                                                                                    // 65
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-page-home/client/browser/page-home.js                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by ashot on 8/20/15.                                                                                     // 2
 */                                                                                                                 // 3
var isOn = false;                                                                                                   // 4
Template.pageHome.events({                                                                                          // 5
  'click .js-read-more': function (e,v){                                                                            // 6
    v.$('.js-about-us').toggleClass('hidden');                                                                      // 7
    v.$('.js-read-more span').toggleClass('hidden');                                                                // 8
  },                                                                                                                // 9
  'keydown .js-search-text': function(e,v){                                                                         // 10
    if(!isOn) {                                                                                                     // 11
      v.$('.js-search-posts-link').click();                                                                         // 12
      $('.js-search-text-modal').val($('.js-search-text').val())                                                    // 13
      $('.js-search-text-modal').focus();                                                                           // 14
    }                                                                                                               // 15
  }                                                                                                                 // 16
})                                                                                                                  // 17
                                                                                                                    // 18
                                                                                                                    // 19
                                                                                                                    // 20
                                                                                                                    // 21
                                                                                                                    // 22
Template.pageHome.rendered = function () {                                                                          // 23
                                                                                                                    // 24
  $('select').foundationSelect();                                                                                   // 25
  $(document).foundation();                                                                                         // 26
                                                                                                                    // 27
};                                                                                                                  // 28
                                                                                                                    // 29
                                                                                                                    // 30
                                                                                                                    // 31
                                                                                                                    // 32
                                                                                                                    // 33
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
