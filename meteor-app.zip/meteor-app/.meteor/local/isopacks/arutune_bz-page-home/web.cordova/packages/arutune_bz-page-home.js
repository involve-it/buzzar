(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/arutune:bz-page-home/client/router.js                                                          //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
/**                                                                                                        // 1
 * Created by douson on 03.07.15.                                                                          // 2
 */                                                                                                        // 3
                                                                                                           // 4
Router.map(function () {                                                                                   // 5
  this.route('home', {                                                                                     // 6
    path: '/home',                                                                                         // 7
    template: 'pageHome',                                                                                  // 8
    layoutTemplate: 'mainLayoutHome',                                                                      // 9
    onBeforeAction: function () {                                                                          // 10
      var qs = this.params.query;                                                                          // 11
                                                                                                           // 12
      setSearchTextFromQs(qs);                                                                             // 13
      setSearchLocationFromQs(qs);                                                                         // 14
                                                                                                           // 15
      this.next();                                                                                         // 16
    }                                                                                                      // 17
  });                                                                                                      // 18
});                                                                                                        // 19
                                                                                                           // 20
                                                                                                           // 21
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/arutune:bz-page-home/client/controller.js                                                      //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
/**                                                                                                        // 1
 * Created by Ashot on 9/19/15.                                                                            // 2
 */                                                                                                        // 3
                                                                                                           // 4
setSearchTextFromQs = function(qs) {                                                                       // 5
  var qs = qs || {}                                                                                        // 6
                                                                                                           // 7
  if(qs.searchText){                                                                                       // 8
    Session.set('bz.control.search.searchedText', qs.searchText);                                          // 9
  }                                                                                                        // 10
}                                                                                                          // 11
                                                                                                           // 12
setSearchLocationFromQs = function(qs){                                                                    // 13
  var qs = qs || {}                                                                                        // 14
                                                                                                           // 15
  if(qs.locationName){ // there is a location defined, need to put it in the search field:                 // 16
    //var loc = Session.get('bz.control.search.location'),                                                 // 17
    var  userId = Meteor.userId(), locObj;                                                                 // 18
    if(!userId) {                                                                                          // 19
      bz.help.logError('home qs error: userId not defined');                                               // 20
    }                                                                                                      // 21
    locObj = bz.cols.locations.searchByLocationNamedUserId(qs.locationName, userId);                       // 22
                                                                                                           // 23
    if(locObj){                                                                                            // 24
      Session.set('bz.control.search.location', locObj);                                                   // 25
    }                                                                                                      // 26
  }                                                                                                        // 27
}                                                                                                          // 28
                                                                                                           // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/arutune:bz-page-home/client/cordova/template.around-you.js                                     //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
                                                                                                           // 1
Template.__checkName("aroundYou");                                                                         // 2
Template["aroundYou"] = new Template("Template.aroundYou", (function() {                                   // 3
  var view = this;                                                                                         // 4
  return HTML.DIV({                                                                                        // 5
    "class": "bz-around-you"                                                                               // 6
  }, "\n\n        ", HTML.DIV({                                                                            // 7
    "class": "bz-items"                                                                                    // 8
  }, "\n            ", HTML.DIV({                                                                          // 9
    "class": "row"                                                                                         // 10
  }, "\n                ", HTML.Raw('<h3 class="title">Buzz Around you</h3>'), "\n                ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("aroundItem"));                                                      // 12
  }, function() {                                                                                          // 13
    return [ "\n                    ", Spacebars.include(view.lookupTemplate("bzAroundYouItem")), "\n                " ];
  }), "\n            "), "\n        "), "\n        \n    ");                                               // 15
}));                                                                                                       // 16
                                                                                                           // 17
Template.__checkName("bzAroundYouItem");                                                                   // 18
Template["bzAroundYouItem"] = new Template("Template.bzAroundYouItem", (function() {                       // 19
  var view = this;                                                                                         // 20
  return HTML.DIV({                                                                                        // 21
    "class": "small-12 medium-6 large-4 columns left"                                                      // 22
  }, "\n        ", HTML.DIV({                                                                              // 23
    "class": "bz-item"                                                                                     // 24
  }, "\n            ", HTML.DIV({                                                                          // 25
    "class": "bz-side-a"                                                                                   // 26
  }, "\n                ", HTML.Raw('<div class="bz-avatar"></div>'), "\n                ", HTML.Raw('<div class="bz-rating"></div>'), "\n                ", HTML.DIV({
    "class": "bz-username"                                                                                 // 28
  }, Blaze.View("lookup:getUserName", function() {                                                         // 29
    return Spacebars.mustache(view.lookup("getUserName"));                                                 // 30
  })), "\n            "), "\n            ", HTML.DIV({                                                     // 31
    "class": "bz-side-b"                                                                                   // 32
  }, "\n                ", HTML.Raw('<div class="arrow"></div>'), "\n                ", HTML.DIV({         // 33
    "class": "bz-photo bz-overlay-hover"                                                                   // 34
  }, "\n                    ", HTML.IMG({                                                                  // 35
    width: "400",                                                                                          // 36
    height: "300",                                                                                         // 37
    "class": "bz-overlay-scale",                                                                           // 38
    src: function() {                                                                                      // 39
      return Spacebars.mustache(view.lookup("getImgSrc"));                                                 // 40
    },                                                                                                     // 41
    alt: ""                                                                                                // 42
  }), "\n                    ", HTML.Raw('<!--<img width="400" height="300" class="bz-overlay-scale" src="http://lorempixel.com/400/300/?{{getTimeStamp}}" alt=""/>-->'), "\n                    ", HTML.Raw('<a class="bz-position-cover" href="#"></a>'), "\n                    ", HTML.Raw('<div class="bz-distance"><i class="fa fa-location-arrow"></i> 30 km</div>'), "\n                "), "\n                ", HTML.H4({
    "class": "bz-title"                                                                                    // 44
  }, Blaze.View("lookup:details.title", function() {                                                       // 45
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "title"));                             // 46
  })), "\n                ", HTML.DIV({                                                                    // 47
    "class": "bz-content"                                                                                  // 48
  }, "\n                    ", HTML.P("\n                        ", Blaze.View("lookup:details.description", function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "description"));                       // 50
  }), "\n                    "), "\n                "), "\n                ", HTML.DIV({                   // 51
    "class": "bz-item-footer"                                                                              // 52
  }, "\n                    ", HTML.DIV({                                                                  // 53
    "class": "bz-price"                                                                                    // 54
  }, Blaze.View("lookup:details.price", function() {                                                       // 55
    return Spacebars.mustache(Spacebars.dot(view.lookup("details"), "price"));                             // 56
  }), " ", HTML.Raw('<span class="bz-prefix">$</span>')), "\n                    ", HTML.DIV({             // 57
    "class": "bz-category"                                                                                 // 58
  }, "\n                        ", HTML.DIV({                                                              // 59
    "class": function() {                                                                                  // 60
      return [ "button bz-btn-category type-category-", Spacebars.mustache(view.lookup("categoryType")) ]; // 61
    }                                                                                                      // 62
  }, "\n                            ", Blaze.View("lookup:categoryType", function() {                      // 63
    return Spacebars.mustache(view.lookup("categoryType"));                                                // 64
  }), "\n                        "), "\n                    "), "\n                "), "\n            "), "\n        "), "\n    ");
}));                                                                                                       // 66
                                                                                                           // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/arutune:bz-page-home/client/cordova/around-you.js                                              //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
/**                                                                                                        // 1
 * Created by root on 9/15/15.                                                                             // 2
 */                                                                                                        // 3
                                                                                                           // 4
Template.bzAroundYouItem.rendered = function() {                                                           // 5
                                                                                                           // 6
  /*init Rate*/                                                                                            // 7
  $('.bz-rating').raty({                                                                                   // 8
    starType: 'i'                                                                                          // 9
  });                                                                                                      // 10
};                                                                                                         // 11
                                                                                                           // 12
Template.aroundYou.helpers({                                                                               // 13
  aroundItem: function() {                                                                                 // 14
    var searchSelector = Session.get('bz.control.search-selector');                                        // 15
    var ret = bz.cols.posts.find(searchSelector, {limit:3}).fetch();                                       // 16
                                                                                                           // 17
    return ret;                                                                                            // 18
  }                                                                                                        // 19
});                                                                                                        // 20
                                                                                                           // 21
Template.bzAroundYouItem.helpers({                                                                         // 22
                                                                                                           // 23
  categoryType: function() {                                                                               // 24
    /*debugger;                                                                                            // 25
                                                                                                           // 26
    var postsId = bz.cols.posts.find({_id: this._id}).fetch()[0].type;                                     // 27
                                                                                                           // 28
    if(postsId) {                                                                                          // 29
      var ret = bz.cols.siteTypes.find({_id: postsId}).fetch()[0].name;                                    // 30
    }*/                                                                                                    // 31
    return bz.cols.posts.find({_id: this._id}).fetch()[0].type;                                            // 32
                                                                                                           // 33
                                                                                                           // 34
  },                                                                                                       // 35
  getAvatarImg: function () {},                                                                            // 36
  getRank: function() {},                                                                                  // 37
  getTimeStamp: function(){                                                                                // 38
    return Date.now();                                                                                     // 39
  },                                                                                                       // 40
  getUserName: function() {                                                                                // 41
    return Meteor.users.findOne(this.userId).username.toCapitalCase();                                     // 42
  },                                                                                                       // 43
  getImgSrc: function(){                                                                                   // 44
    var ret, phId = this.details.photos[0];                                                                // 45
    if(phId){                                                                                              // 46
      ret = bz.cols.images.findOne(phId);                                                                  // 47
      ret = ret && ret.data;                                                                               // 48
    }                                                                                                      // 49
    return ret;                                                                                            // 50
  }                                                                                                        // 51
});                                                                                                        // 52
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/arutune:bz-page-home/client/cordova/template.page-home.js                                      //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
                                                                                                           // 1
Template.__checkName("pageHome");                                                                          // 2
Template["pageHome"] = new Template("Template.pageHome", (function() {                                     // 3
  var view = this;                                                                                         // 4
  return [ Blaze._TemplateWith(function() {                                                                // 5
    return "headerButtonLeft";                                                                             // 6
  }, function() {                                                                                          // 7
    return Spacebars.include(view.lookupTemplate("contentFor"), function() {                               // 8
      return [ "\n        ", HTML.BUTTON({                                                                 // 9
        "class": "button button-clear pull-left",                                                          // 10
        "data-ion-menu-toggle": "left"                                                                     // 11
      }, "\n            ", Blaze.If(function() {                                                           // 12
        return Spacebars.call(view.lookup("isAndroid"));                                                   // 13
      }, function() {                                                                                      // 14
        return [ "\n                ", Blaze._TemplateWith(function() {                                    // 15
          return {                                                                                         // 16
            icon: Spacebars.call("android-more-vertical")                                                  // 17
          };                                                                                               // 18
        }, function() {                                                                                    // 19
          return Spacebars.include(view.lookupTemplate("ionIcon"));                                        // 20
        }), "\n            " ];                                                                            // 21
      }, function() {                                                                                      // 22
        return [ "\n                ", Blaze._TemplateWith(function() {                                    // 23
          return {                                                                                         // 24
            icon: Spacebars.call("navicon")                                                                // 25
          };                                                                                               // 26
        }, function() {                                                                                    // 27
          return Spacebars.include(view.lookupTemplate("ionIcon"));                                        // 28
        }), "\n            " ];                                                                            // 29
      }), "\n        "), "\n    " ];                                                                       // 30
    });                                                                                                    // 31
  }), "\n\n    ", Blaze._TemplateWith(function() {                                                         // 32
    return "headerTitle";                                                                                  // 33
  }, function() {                                                                                          // 34
    return Spacebars.include(view.lookupTemplate("contentFor"), function() {                               // 35
      return [ "\n        ", HTML.H1({                                                                     // 36
        "class": "title"                                                                                   // 37
      }, "HOME PAGE"), "\n\n        ", HTML.BUTTON({                                                       // 38
        "class": "button button-clear pull-right",                                                         // 39
        "data-ion-menu-toggle": "right"                                                                    // 40
      }, "\n            ", Blaze.If(function() {                                                           // 41
        return Spacebars.call(view.lookup("isAndroid"));                                                   // 42
      }, function() {                                                                                      // 43
        return [ "\n                ", Blaze._TemplateWith(function() {                                    // 44
          return {                                                                                         // 45
            icon: Spacebars.call("android-more-vertical")                                                  // 46
          };                                                                                               // 47
        }, function() {                                                                                    // 48
          return Spacebars.include(view.lookupTemplate("ionIcon"));                                        // 49
        }), "\n            " ];                                                                            // 50
      }, function() {                                                                                      // 51
        return [ "\n                ", Blaze._TemplateWith(function() {                                    // 52
          return {                                                                                         // 53
            icon: Spacebars.call("navicon")                                                                // 54
          };                                                                                               // 55
        }, function() {                                                                                    // 56
          return Spacebars.include(view.lookupTemplate("ionIcon"));                                        // 57
        }), "\n            " ];                                                                            // 58
      }), "\n        "), "\n\n    " ];                                                                     // 59
    });                                                                                                    // 60
  }), "\n\n\n    ", Spacebars.include(view.lookupTemplate("ionView"), function() {                         // 61
    return [ "\n        ", Spacebars.include(view.lookupTemplate("ionContent"), function() {               // 62
      return [ "\n            ", HTML.DIV({                                                                // 63
        "class": "wrapper-message padding-left padding-right"                                              // 64
      }, "\n\n                ", HTML.DIV({                                                                // 65
        "class": "fake-box"                                                                                // 66
      }, "\n                    ", HTML.H1({                                                               // 67
        "class": "font-smoothing uppercase padding-bottom"                                                 // 68
      }, "Buzzar"), "\n                    ", HTML.Comment('<h3 class="capitalize">karm\n                    a has no deadline</h3>'), "\n                    ", HTML.Comment('<h5 class="padding-bottom" style="text-align: center;">Online Crowd-finding (TM)</h5>'), "\n                    ", HTML.H5({
        "class": "padding-bottom",                                                                         // 70
        style: "text-align: center;"                                                                       // 71
      }, Blaze.View("lookup:t9n", function() {                                                             // 72
        return Spacebars.mustache(view.lookup("t9n"), "headliner");                                        // 73
      })), "\n                    ", HTML.A({                                                              // 74
        "class": "button button-block button-assertive capitalize",                                        // 75
        href: "/posts/new"                                                                                 // 76
      }, "\n                        Create instant post\n                        ", HTML.I({               // 77
        "class": "icon ion-coffee",                                                                        // 78
        style: "position: absolute; right: 20px; top: -3px;"                                               // 79
      }), "\n                    "), "\n                    ", Blaze.View("lookup:username", function() {  // 80
        return Spacebars.mustache(view.lookup("username"));                                                // 81
      }), "\n                "), "\n              ", Spacebars.include(view.lookupTemplate("categoryListButtons")), "\n\n              ", HTML.LABEL({
        "class": "item item-input"                                                                         // 83
      }, "\n                    ", HTML.I({                                                                // 84
        "class": "icon ion-search placeholder-icon"                                                        // 85
      }), "\n                    ", HTML.INPUT({                                                           // 86
        type: "text",                                                                                      // 87
        "class": "capitalize js-search-text",                                                              // 88
        placeholder: "find anything around you"                                                            // 89
      }), "\n                "), "\n                ", HTML.A({                                            // 90
        name: "original-post-details",                                                                     // 91
        "class": "button button-small disabled hidden js-search-posts-link",                               // 92
        "data-ion-modal": "searchPostsModal"                                                               // 93
      }, "Check >>"), "\n                ", HTML.DIV({                                                     // 94
        style: "padding-top: 50px;"                                                                        // 95
      }, "\n\n                    ", HTML.DIV({                                                            // 96
        "class": "js-about-us hidden"                                                                      // 97
      }, "\n                        ", Spacebars.include(view.lookupTemplate("aboutUs")), "\n                    "), "\n                    ", HTML.BUTTON({
        "class": "button button-calm capitalize js-read-more"                                              // 99
      }, "\n                        ", HTML.SPAN("read more"), "\n                        ", HTML.SPAN({   // 100
        "class": "hidden"                                                                                  // 101
      }, "show less"), "\n                    "), "\n                    ", HTML.Comment('<a class="button button-calm capitalize" href="/">\n                        <span>search page >></span>\n                    </a>'), "\n                    ", Spacebars.include(view.lookupTemplate("checkInBtn")), "\n                "), "\n            "), "\n        " ];
    }), "\n    " ];                                                                                        // 103
  }) ];                                                                                                    // 104
}));                                                                                                       // 105
                                                                                                           // 106
Template.__checkName("searchPostsModal");                                                                  // 107
Template["searchPostsModal"] = new Template("Template.searchPostsModal", (function() {                     // 108
  var view = this;                                                                                         // 109
  return Blaze._TemplateWith(function() {                                                                  // 110
    return {                                                                                               // 111
      title: Spacebars.call("Url Post Details")                                                            // 112
    };                                                                                                     // 113
  }, function() {                                                                                          // 114
    return Spacebars.include(view.lookupTemplate("ionModal"), function() {                                 // 115
      return [ "\n        ", HTML.DIV({                                                                    // 116
        "class": "padding"                                                                                 // 117
      }, "\n            ", HTML.LABEL({                                                                    // 118
        "class": "item item-input"                                                                         // 119
      }, "\n                ", HTML.I({                                                                    // 120
        "class": "icon ion-search placeholder-icon"                                                        // 121
      }), "\n                ", HTML.INPUT({                                                               // 122
        type: "text",                                                                                      // 123
        "class": "capitalize js-search-text-modal",                                                        // 124
        placeholder: "find anything around you"                                                            // 125
      }), "\n            "), "\n\n            ", HTML.Comment("Title: <span>{{ getTitle }}</span>"), "\n\n            ", Spacebars.include(view.lookupTemplate("globalSearch")), "\n        "), "\n    " ];
    });                                                                                                    // 127
  });                                                                                                      // 128
}));                                                                                                       // 129
                                                                                                           // 130
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/arutune:bz-page-home/client/cordova/page-home.js                                               //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
/**                                                                                                        // 1
 * Created by ashot on 8/20/15.                                                                            // 2
 */                                                                                                        // 3
var isOn = false;                                                                                          // 4
                                                                                                           // 5
Template.pageHome.events({                                                                                 // 6
  'click .js-read-more': function (e,v){                                                                   // 7
    v.$('.js-about-us').toggleClass('hidden');                                                             // 8
    v.$('.js-read-more span').toggleClass('hidden');                                                       // 9
  },                                                                                                       // 10
  'keydown .js-search-text': function(e,v){                                                                // 11
    if(!isOn) {                                                                                            // 12
      v.$('.js-search-posts-link').click();                                                                // 13
      $('.js-search-text-modal').val($('.js-search-text').val())                                           // 14
      $('.js-search-text-modal').focus();                                                                  // 15
    }                                                                                                      // 16
  }                                                                                                        // 17
})                                                                                                         // 18
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
