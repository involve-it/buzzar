(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/arutune:bz-page-map/client/router.js                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Created by douson on 03.07.15.                                                                                 // 2
 */                                                                                                               // 3
var requireLoginController = bz.router.requireLoginController;                                                    // 4
// POSTS:                                                                                                         // 5
Router.map(function () {                                                                                          // 6
  this.route('bz.map', {                                                                                          // 7
    path: '/map',                                                                                                 // 8
    template: 'bzPageMap',                                                                                        // 9
    waitOn: function () {                                                                                         // 10
      return [                                                                                                    // 11
        bz.help.maps.googleMapsLoad()                                                                             // 12
        //GoogleMaps.load({libraries: 'geometry,places', v: '3'})                                                 // 13
        //GoogleMaps.load({key: bz.config.mapsKey, libraries: 'geometry,places', v: '3'})                         // 14
        //GoogleMaps.load({key: 'AIzaSyCE5a0IeEGQLptVSSW-5swNFNaRUXKEWss', libraries: 'geometry,places', v: '3'}) // 15
      ];                                                                                                          // 16
    }                                                                                                             // 17
  });                                                                                                             // 18
});                                                                                                               // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/arutune:bz-page-map/client/controller.js                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Created by Ashot on 9/19/15.                                                                                   // 2
 */                                                                                                               // 3
//bz.help.makeNamespace('bz.runtime.newPost.location');                                                           // 4
                                                                                                                  // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
