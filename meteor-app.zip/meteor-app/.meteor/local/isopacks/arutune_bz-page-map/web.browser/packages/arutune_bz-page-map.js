(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-map/client/router.js                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by douson on 03.07.15.                                                                                    // 2
 */                                                                                                                  // 3
var requireLoginController = bz.router.requireLoginController;                                                       // 4
// POSTS:                                                                                                            // 5
Router.map(function () {                                                                                             // 6
  this.route('bz.map', {                                                                                             // 7
    path: '/map',                                                                                                    // 8
    template: 'bzPageMap',                                                                                           // 9
    waitOn: function () {                                                                                            // 10
      return [                                                                                                       // 11
        bz.help.maps.googleMapsLoad()                                                                                // 12
        //GoogleMaps.load({libraries: 'geometry,places', v: '3'})                                                    // 13
        //GoogleMaps.load({key: bz.config.mapsKey, libraries: 'geometry,places', v: '3'})                            // 14
        //GoogleMaps.load({key: 'AIzaSyCE5a0IeEGQLptVSSW-5swNFNaRUXKEWss', libraries: 'geometry,places', v: '3'})    // 15
      ];                                                                                                             // 16
    }                                                                                                                // 17
  });                                                                                                                // 18
});                                                                                                                  // 19
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-map/client/controller.js                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by Ashot on 9/19/15.                                                                                      // 2
 */                                                                                                                  // 3
//bz.help.makeNamespace('bz.runtime.newPost.location');                                                              // 4
                                                                                                                     // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-map/client/browser/template.google-map.js                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("googleMapControl");                                                                            // 2
Template["googleMapControl"] = new Template("Template.googleMapControl", (function() {                               // 3
  var view = this;                                                                                                   // 4
  return HTML.DIV({                                                                                                  // 5
    "class": "control--google-map"                                                                                   // 6
  }, "\n        ", HTML.DIV({                                                                                        // 7
    "class": "map-container",                                                                                        // 8
    style: "width: 100%; height: 100%;"                                                                              // 9
  }, "\n            ", Blaze._TemplateWith(function() {                                                              // 10
    return {                                                                                                         // 11
      name: Spacebars.call("map"),                                                                                   // 12
      options: Spacebars.call(view.lookup("mapOptions"))                                                             // 13
    };                                                                                                               // 14
  }, function() {                                                                                                    // 15
    return Spacebars.include(view.lookupTemplate("googleMap"));                                                      // 16
  }), "\n        "), "\n    ");                                                                                      // 17
}));                                                                                                                 // 18
                                                                                                                     // 19
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-map/client/browser/google-map.js                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by syurdor on 7/27/2015.                                                                                  // 2
 */                                                                                                                  // 3
                                                                                                                     // 4
    /**                                                                                                              // 5
     * collection : [{                                                                                               // 6
     *    coords: {                                                                                                  // 7
     *      lat: 0,                                                                                                  // 8
     *      lng: 0                                                                                                   // 9
     *    },                                                                                                         // 10
     *    type: 0,                                                                                                   // 11
     *    title: '',                                                                                                 // 12
     *    data: {}                                                                                                   // 13
     * }, ...]                                                                                                       // 14
    * */                                                                                                             // 15
                                                                                                                     // 16
var module = {                                                                                                       // 17
  markers: [],                                                                                                       // 18
  map: null,                                                                                                         // 19
  load: function(collection){                                                                                        // 20
    //Tracker.autorun(function () {                                                                                  // 21
    // use this for reactivity, todo: change for finding only posts around user:                                     // 22
    //bz.cols.posts.find().count();                                                                                  // 23
                                                                                                                     // 24
    //bz.bus.search.doSearch(function(err, res){                                                                     // 25
    // safely delete existing:                                                                                       // 26
    module.deleteMarkers();                                                                                          // 27
                                                                                                                     // 28
    // create markers:                                                                                               // 29
    module.createMarkersFromCollection(collection);                                                                  // 30
                                                                                                                     // 31
    //module.setMapOnAll(markersArr, googleMap);                                                                     // 32
                                                                                                                     // 33
    module.reposition();                                                                                             // 34
    //});                                                                                                            // 35
    //});                                                                                                            // 36
  },                                                                                                                 // 37
  random: function(min, max){                                                                                        // 38
    return (max - min) * Math.random() + min;                                                                        // 39
  },                                                                                                                 // 40
  reposition: function(){                                                                                            // 41
    var bounds = new google.maps.LatLngBounds();                                                                     // 42
    //for (var i in module.markers) {                                                                                // 43
    //  bounds.extend(module.markers[i].position);                                                                   // 44
    //}                                                                                                              // 45
    var location = Session.get('bz.control.search.location') && Session.get('bz.control.search.location').coords,    // 46
        radius = Session.get('bz.control.search.distance') || bz.const.locations.defaultDistance;                    // 47
                                                                                                                     // 48
    if (location) {                                                                                                  // 49
      var dLat = (radius / bz.const.locations.earthRadius) / Math.PI * 180,                                          // 50
          dLng = (radius / bz.const.locations.earthRadius / Math.cos(location.lat * Math.PI / 180)) / Math.PI * 180; // 51
      var box = {                                                                                                    // 52
        lng1: location.lng - dLng,                                                                                   // 53
        lng2: location.lng + dLng,                                                                                   // 54
        lat1: location.lat - dLat,                                                                                   // 55
        lat2: location.lat + dLat                                                                                    // 56
      };                                                                                                             // 57
                                                                                                                     // 58
      bounds.extend(new google.maps.LatLng(box.lat1, box.lng1));                                                     // 59
      bounds.extend(new google.maps.LatLng(box.lat2, box.lng2));                                                     // 60
    }                                                                                                                // 61
                                                                                                                     // 62
    module.map.fitBounds(bounds);                                                                                    // 63
  },                                                                                                                 // 64
  createMarkersFromCollection: function(collection){                                                                 // 65
    var defColor = 'FE7569';                                                                                         // 66
    _.each(collection, function (item) {                                                                             // 67
      if (item && item.coords) {                                                                                     // 68
        var latitude = item.coords.lat,                                                                              // 69
            longitude = item.coords.lng,                                                                             // 70
            infoWindow = new google.maps.InfoWindow({                                                                // 71
              content: '<h4>' + item.title + '</h4>'                                                                 // 72
            }),                                                                                                      // 73
            marker = new google.maps.Marker({                                                                        // 74
              position: new google.maps.LatLng(latitude, longitude),                                                 // 75
              title: item.title,                                                                                     // 76
              icon: 'http://chart.apis.google.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|' + (module.getRgb(item.type) || defColor),
              data: item.data,  // our field,                                                                        // 78
              map: module.map,                                                                                       // 79
              infoWindow: infoWindow                                                                                 // 80
            });                                                                                                      // 81
                                                                                                                     // 82
        marker.addListener('click', module.markerClickHandler);                                                      // 83
                                                                                                                     // 84
        module.markers.push(marker);                                                                                 // 85
      } else {                                                                                                       // 86
      }                                                                                                              // 87
    });                                                                                                              // 88
  },                                                                                                                 // 89
  getRgb: function(str){                                                                                             // 90
    var hash = 0;                                                                                                    // 91
    for (var i = 0; i < str.length; i++) {                                                                           // 92
      hash = str.charCodeAt(i) + ((hash << 5) - hash);                                                               // 93
    }                                                                                                                // 94
                                                                                                                     // 95
    var c = (hash & 0x00FFFFFF)                                                                                      // 96
        .toString(16)                                                                                                // 97
        .toUpperCase();                                                                                              // 98
                                                                                                                     // 99
    return "00000".substring(0, 6 - c.length) + c;                                                                   // 100
  },                                                                                                                 // 101
  markerClickHandler: function(){                                                                                    // 102
    for(var i = 0; i<module.markers.length; i++){                                                                    // 103
      if (module.markers[i] && module.markers[i].infoWindow){                                                        // 104
        module.markers[i].infoWindow.close();                                                                        // 105
      }                                                                                                              // 106
    }                                                                                                                // 107
    if (this.infoWindow){                                                                                            // 108
      this.infoWindow.open(module.map, this);                                                                        // 109
    }                                                                                                                // 110
    Session.set('search.selectedPost', this.data);                                                                   // 111
  },                                                                                                                 // 112
  deleteMarkers: function(){                                                                                         // 113
    for (var i = 0; i < module.markers.length; i++) {                                                                // 114
      if (module.markers[i]) {                                                                                       // 115
        if (module.markers[i].infoWindow){                                                                           // 116
          module.markers[i].infoWindow.close();                                                                      // 117
        }                                                                                                            // 118
        module.markers[i].marker.setMap(null);                                                                       // 119
      }                                                                                                              // 120
                                                                                                                     // 121
    }                                                                                                                // 122
    module.markers = [];                                                                                             // 123
  }                                                                                                                  // 124
};                                                                                                                   // 125
                                                                                                                     // 126
bz.help.makeNamespace('bz.runtime.googleMap', module);                                                               // 127
                                                                                                                     // 128
Template.googleMapControl.helpers({                                                                                  // 129
  mapOptions: function () {                                                                                          // 130
    if (GoogleMaps.loaded()) {                                                                                       // 131
      // Map initialization options                                                                                  // 132
      var coords = new google.maps.LatLng(37.3, -121.8);                                                             // 133
      if (bz.runtime.maps.loc) {                                                                                     // 134
        coords = bz.runtime.maps.loc;                                                                                // 135
      }                                                                                                              // 136
      return {                                                                                                       // 137
        center: coords,                                                                                              // 138
        zoom: 12                                                                                                     // 139
      };                                                                                                             // 140
    }                                                                                                                // 141
  }                                                                                                                  // 142
});                                                                                                                  // 143
                                                                                                                     // 144
Template.googleMapControl.onCreated(function () {                                                                    // 145
  // We can use the `ready` callback to interact with the map API once the map is ready.                             // 146
  GoogleMaps.ready('map', function (map) {                                                                           // 147
    // Add a marker to the map once it's ready                                                                       // 148
    /*markers.push(new google.maps.Marker({                                                                          // 149
     position: map.options.center,                                                                                   // 150
     map: map.instance                                                                                               // 151
     }));*/                                                                                                          // 152
                                                                                                                     // 153
                                                                                                                     // 154
    //instead of doing this - call bz.runtime.googleMap.load(collection) to show markers on the map.                 // 155
    module.map = map.instance;                                                                                       // 156
    var searchSelector = Session.get('bz.control.search-selector');                                                  // 157
    var posts = bz.cols.posts.find(searchSelector).fetch();                                                          // 158
                                                                                                                     // 159
    var col = [];                                                                                                    // 160
    _.each(posts, function(post){                                                                                    // 161
      if (post && post.details && post.details.locations && Array.isArray(post.details.locations) && post.details.locations.length > 0){
        col.push({                                                                                                   // 163
          coords: post.details.locations[0].coords,                                                                  // 164
          type: post.type,                                                                                           // 165
          title: post.details.title,                                                                                 // 166
          data: post                                                                                                 // 167
        });                                                                                                          // 168
      }                                                                                                              // 169
    });                                                                                                              // 170
                                                                                                                     // 171
    module.load(col);                                                                                                // 172
  });                                                                                                                // 173
});                                                                                                                  // 174
Template.googleMapControl.onDestroyed(function () {                                                                  // 175
  console.log('googleMapControl.onDestroyed');                                                                       // 176
});                                                                                                                  // 177
                                                                                                                     // 178
// HELPERS:                                                                                                          // 179
                                                                                                                     // 180
                                                                                                                     // 181
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-map/client/browser/template.page-map.js                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     // 1
Template.__checkName("bzPageMap");                                                                                   // 2
Template["bzPageMap"] = new Template("Template.bzPageMap", (function() {                                             // 3
  var view = this;                                                                                                   // 4
  return Blaze.If(function() {                                                                                       // 5
    return Spacebars.call(view.lookup("searchHistory"));                                                             // 6
  }, function() {                                                                                                    // 7
    return [ "\n\n        ", HTML.Comment("If search history is true"), "\n        ", HTML.DIV("Есть стория поиска"), "\n\n      " ];
  }, function() {                                                                                                    // 9
    return [ "\n        ", HTML.Comment("{{#if searchResult}}"), "\n\n          ", HTML.Comment("Search result, if sth found"), "\n          ", HTML.Comment("Code here"), "\n\n          ", HTML.Comment("Load google map control"), "\n        ", HTML.Comment(" height - temp "), "\n        ", HTML.DIV({
      style: "height:600px;"                                                                                         // 11
    }, "\n          ", Spacebars.include(view.lookupTemplate("googleMapControl")), "\n        "), "\n\n          ", HTML.Comment("Panel (search result)"), "\n          ", Spacebars.include(view.lookupTemplate("panelSearchResult")), "\n\n        ", HTML.Comment("{{else}}"), "\n\n          ", HTML.Comment("Empty blank"), "\n          ", HTML.Comment("{{> noSearch}}"), "\n\n        ", HTML.Comment("{{/if}}"), "\n      " ];
  });                                                                                                                // 13
}));                                                                                                                 // 14
                                                                                                                     // 15
Template.__checkName("panelSearchResult");                                                                           // 16
Template["panelSearchResult"] = new Template("Template.panelSearchResult", (function() {                             // 17
  var view = this;                                                                                                   // 18
  return Blaze.If(function() {                                                                                       // 19
    return Spacebars.call(view.lookup("activeTemplate"));                                                            // 20
  }, function() {                                                                                                    // 21
    return [ "\n    ", Blaze._TemplateWith(function() {                                                              // 22
      return {                                                                                                       // 23
        template: Spacebars.call(view.lookup("activeTemplate"))                                                      // 24
      };                                                                                                             // 25
    }, function() {                                                                                                  // 26
      return Spacebars.include(function() {                                                                          // 27
        return Spacebars.call(Template.__dynamic);                                                                   // 28
      });                                                                                                            // 29
    }), "\n    ", Blaze._TemplateWith(function() {                                                                   // 30
      return {                                                                                                       // 31
        template: Spacebars.call(view.lookup("activeTemplate")),                                                     // 32
        data: Spacebars.call(view.lookup("getData"))                                                                 // 33
      };                                                                                                             // 34
    }, function() {                                                                                                  // 35
      return Spacebars.include(function() {                                                                          // 36
        return Spacebars.call(Template.__dynamic);                                                                   // 37
      });                                                                                                            // 38
    }), "\n  " ];                                                                                                    // 39
  });                                                                                                                // 40
}));                                                                                                                 // 41
                                                                                                                     // 42
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/arutune:bz-page-map/client/browser/page-map.js                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/**                                                                                                                  // 1
 * Created by douson on 27.08.15.                                                                                    // 2
 */                                                                                                                  // 3
                                                                                                                     // 4
Template.bzPageMap.onCreated(function () {                                                                           // 5
  // keep track of the selected post, if it has value, set active template to single:                                // 6
  setActiveTemplateSessionToSingleIfSelectedPostHasValue();                                                          // 7
});                                                                                                                  // 8
                                                                                                                     // 9
Template.bzPageMap.rendered = function () {                                                                          // 10
};                                                                                                                   // 11
                                                                                                                     // 12
/* Dynamic template */                                                                                               // 13
Template.panelSearchResult.helpers({                                                                                 // 14
  activeTemplate: function () {                                                                                      // 15
    //debugger;                                                                                                      // 16
                                                                                                                     // 17
    return Session.get('activeTemplate');                                                                            // 18
  },                                                                                                                 // 19
  getData: function () {                                                                                             // 20
    var ret = {};                                                                                                    // 21
    Session.get('search.selectedPost');                                                                              // 22
                                                                                                                     // 23
    if (Session.get('activeTemplate') === 'singleSearchTemplate') {                                                  // 24
      ret = Session.get('search.selectedPost');                                                                      // 25
    }                                                                                                                // 26
    return ret;                                                                                                      // 27
  }                                                                                                                  // 28
});                                                                                                                  // 29
                                                                                                                     // 30
//HELPERS:                                                                                                           // 31
                                                                                                                     // 32
function setActiveTemplateSessionToSingleIfSelectedPostHasValue() {                                                  // 33
  Tracker.autorun(function () {                                                                                      // 34
    var selPost = Session.get('search.selectedPost');                                                                // 35
    if (Session.get('search.selectedPost') && typeof Session.get('search.selectedPost') === 'object' && Session.get('activeTemplate') !== 'singleSearchTemplate') {
      Session.set('activeTemplate', 'singleSearchTemplate');                                                         // 37
    }                                                                                                                // 38
  });                                                                                                                // 39
}                                                                                                                    // 40
                                                                                                                     // 41
                                                                                                                     // 42
                                                                                                                     // 43
                                                                                                                     // 44
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
