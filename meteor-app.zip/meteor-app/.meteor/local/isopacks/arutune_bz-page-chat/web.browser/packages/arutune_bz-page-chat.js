(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/router.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by douson on 03.07.15.                                                                                      // 2
 */                                                                                                                    // 3
Router.map(function () {                                                                                               // 4
  this.route('chats', {                                                                                                // 5
    path: '/chats',                                                                                                    // 6
    controller: 'requireLoginController',                                                                              // 7
    onBeforeAction: function () {                                                                                      // 8
      Router.go('/chats/my');                                                                                          // 9
    }                                                                                                                  // 10
  });                                                                                                                  // 11
  this.route('chats.id', {                                                                                             // 12
    path: '/chat/:chatId',                                                                                             // 13
    template: 'bzChatId',                                                                                              // 14
    controller: 'requireLoginController',                                                                              // 15
                                                                                                                       // 16
    waitOn: function () {                                                                                              // 17
      var chatId = this.params.chatId;                                                                                 // 18
      return [                                                                                                         // 19
        //Meteor.subscribe('bz.users.byId', this.params.userId)                                                        // 20
        Meteor.subscribe('bz.users.all'),                                                                              // 21
        Meteor.subscribe('bz.chats.id', chatId),                                                                       // 22
        Meteor.subscribe('bz.messages.chatId', chatId)                                                                 // 23
      ]                                                                                                                // 24
    },                                                                                                                 // 25
    data: function () {                                                                                                // 26
      var chatId = this.params.chatId,                                                                                 // 27
        chat = bz.cols.chats.findOne(chatId),                                                                          // 28
        user = chat && chat.users && _.without(chat.users, Meteor.userId())[0];                                        // 29
      if (user && chat) {                                                                                              // 30
        var ret = {                                                                                                    // 31
          chat: chat,                                                                                                  // 32
          user: Meteor.users.findOne(user),                                                                            // 33
          messages: bz.cols.messages.find({chatId: chatId})                                                            // 34
        }                                                                                                              // 35
      }                                                                                                                // 36
      return ret;                                                                                                      // 37
    },                                                                                                                 // 38
                                                                                                                       // 39
    onBeforeAction: function () {                                                                                      // 40
      if (!this.data() || !this.data().user || !this.data().messages) {                                                // 41
        Router.go('/page-not-found');                                                                                  // 42
      } else {                                                                                                         // 43
        this.next();                                                                                                   // 44
      }                                                                                                                // 45
    }                                                                                                                  // 46
  });                                                                                                                  // 47
                                                                                                                       // 48
  this.route('chats.my', {                                                                                             // 49
    path: '/chats/my',                                                                                                 // 50
    template: 'bzPageChats',                                                                                           // 51
    controller: 'requireLoginController',                                                                              // 52
    waitOn: function () {                                                                                              // 53
      return [                                                                                                         // 54
        Meteor.subscribe('bz.users.all'),                                                                              // 55
        Meteor.subscribe('bz.chats.my', Meteor.userId())                                                               // 56
      ]                                                                                                                // 57
    },                                                                                                                 // 58
    data: function () {                                                                                                // 59
      return bz.cols.chats.find({                                                                                      // 60
        userId: Meteor.userId()                                                                                        // 61
      });                                                                                                              // 62
    }                                                                                                                  // 63
  });                                                                                                                  // 64
                                                                                                                       // 65
  // create post flow:                                                                                                 // 66
  this.route('chats.new', {                                                                                            // 67
    path: '/chats/new',                                                                                                // 68
    controller: 'requireLoginController'                                                                               // 69
  });                                                                                                                  // 70
});                                                                                                                    // 71
/*                                                                                                                     // 72
                                                                                                                       // 73
 this.route('chats.id', {                                                                                              // 74
 path: '/chat/:userId',                                                                                                // 75
 template: 'bzChatId',                                                                                                 // 76
 controller: 'requireLoginController',                                                                                 // 77
                                                                                                                       // 78
 waitOn: function(){                                                                                                   // 79
 var usersArr = [],                                                                                                    // 80
 currentUser = Meteor.user(),                                                                                          // 81
 friendUserId = this.params.userId;                                                                                    // 82
 currentUser && usersArr.push(currentUser._id);                                                                        // 83
 friendUserId && usersArr.push(friendUserId);                                                                          // 84
 return [                                                                                                              // 85
 //Meteor.subscribe('bz.users.byId', this.params.userId)                                                               // 86
 Meteor.subscribe('bz.users.all'),                                                                                     // 87
 Meteor.subscribe('bz.messages.users', usersArr)                                                                       // 88
 ]                                                                                                                     // 89
 },                                                                                                                    // 90
 data: function () {                                                                                                   // 91
 var usersArr = [],                                                                                                    // 92
 currentUser = Meteor.user(),                                                                                          // 93
 friendUserId = this.params.userId;                                                                                    // 94
 currentUser && usersArr.push(currentUser._id);                                                                        // 95
 friendUserId && usersArr.push(friendUserId);                                                                          // 96
 var ret = {                                                                                                           // 97
 user : Meteor.users.findOne({ _id: this.params.userId }),                                                             // 98
 messages: bz.cols.messages.find({userId: {$in: usersArr}, toUserId: {$in: usersArr}})                                 // 99
 }                                                                                                                     // 100
 return ret;                                                                                                           // 101
 },                                                                                                                    // 102
                                                                                                                       // 103
 onBeforeAction: function () {                                                                                         // 104
 if (!this.data() || !this.data().user || !this.data().messages) {                                                     // 105
 debugger;                                                                                                             // 106
 Router.go('/page-not-found');                                                                                         // 107
 } else {                                                                                                              // 108
 this.next();                                                                                                          // 109
 }                                                                                                                     // 110
 }                                                                                                                     // 111
 });*/                                                                                                                 // 112
                                                                                                                       // 113
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/controller.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by Ashot on 9/19/15.                                                                                        // 2
 */                                                                                                                    // 3
bz.help.makeNamespace('bz.buz.chats');                                                                                 // 4
                                                                                                                       // 5
sendMessage = function (messageText, chat, friendUserId) {                                                             // 6
  var  msgTs = Date.now();                                                                                             // 7
                                                                                                                       // 8
  createChatIfFirstMessage(currentUser._id, friendUserId),                                                             // 9
  makeChatActive(chat);                                                                                                // 10
                                                                                                                       // 11
  bz.cols.messages.insert({                                                                                            // 12
    userId: currentUser._id,                                                                                           // 13
    toUserId: friendUserId,                                                                                            // 14
    chatId: chat._id,                                                                                                  // 15
    text: messageText,                                                                                                 // 16
    timestamp: msgTs,                                                                                                  // 17
    keyMessage: 'own-message',                                                                                         // 18
    seen: false                                                                                                        // 19
  });                                                                                                                  // 20
                                                                                                                       // 21
  chat.lastMessageTs = msgTs; // assign timestamp of the last message to the chat                                      // 22
                                                                                                                       // 23
  scrollMessages();                                                                                                    // 24
                                                                                                                       // 25
}                                                                                                                      // 26
scrollMessages = function () {                                                                                         // 27
  var elem = document.getElementsByClassName("bz-messages-container");                                                 // 28
  elem[0].scrollTop = elem[0].scrollHeight;                                                                            // 29
  //$('.messages-container').animate({"scrollTop": $('.messages-container')[0].scrollHeight}, "100");                  // 30
  //this.$messages[0].scrollTop = this.$messages[0].scrollHeight;                                                      // 31
}                                                                                                                      // 32
makeChatActive = function (chat) {                                                                                     // 33
  //var chat = bz.cols.chats.findOne(chatId);                                                                          // 34
  if (chat && !chat.active) {                                                                                          // 35
    //chat && (chat.active = true);                                                                                    // 36
    bz.cols.chats.update(chat._id, {$set: {activated: true}});                                                         // 37
  }                                                                                                                    // 38
}                                                                                                                      // 39
createChatIfFirstMessage = function (userFrom, userTo) {                                                               // 40
  //var usersArr = [userFrom, userTo];                                                                                 // 41
  /*bz.cols.chats.remove({                                                                                             // 42
   userId: userTo                                                                                                      // 43
   });                                                                                                                 // 44
   bz.cols.chats.remove({                                                                                              // 45
   userId: userFrom                                                                                                    // 46
   });*/                                                                                                               // 47
  var chatId, chats1, chats2, chatsAll;                                                                                // 48
  chats1 = bz.cols.chats.find({                                                                                        // 49
    userId: userFrom,                                                                                                  // 50
    users: {$in: [userTo]}                                                                                             // 51
  }).fetch();                                                                                                          // 52
  chats2 = bz.cols.chats.find({                                                                                        // 53
    userId: userTo,                                                                                                    // 54
    users: {$in: [userFrom]}                                                                                           // 55
  }).fetch();                                                                                                          // 56
  chatsAll = _.union(chats1, chats2);                                                                                  // 57
  _.each(chatsAll, function (item) {                                                                                   // 58
    //bz.cols.chats.remove(item._id);                                                                                  // 59
  });                                                                                                                  // 60
  /*bz.cols.chats.remove({                                                                                             // 61
   userId: userFrom                                                                                                    // 62
   });*/                                                                                                               // 63
  if (chatsAll.length === 0) {                                                                                         // 64
    /*bz.cols.chats.insert({                                                                                           // 65
     userId: userFrom,                                                                                                 // 66
     users: [userTo],                                                                                                  // 67
     timeBegin: Date.now()                                                                                             // 68
     });*/                                                                                                             // 69
    chatId = bz.cols.chats.insert({                                                                                    // 70
      userId: userFrom,                                                                                                // 71
      users: [userTo, userFrom],                                                                                       // 72
      timeBegin: Date.now(),                                                                                           // 73
      lastMessageTs: Date.now(),                                                                                       // 74
      activated: false // we just create record in DB, but we don't wanna show this conv-n to the other user           // 75
    });                                                                                                                // 76
  } else {                                                                                                             // 77
    chatId = chatsAll[0]._id                                                                                           // 78
  }                                                                                                                    // 79
  return chatId;                                                                                                       // 80
}                                                                                                                      // 81
                                                                                                                       // 82
getUniqueChatsForUser = function (userId, all) {                                                                       // 83
  var chatsArr = [];                                                                                                   // 84
  //var chats = _.union(bz.cols.chats.find({userId: userId}).fetch(), bz.cols.chats.find({users: {$in: [userId]}}).fetch());
  /*var chats = bz.cols.chats.find({                                                                                   // 86
   $or: [                                                                                                              // 87
                                                                                                                       // 88
   {                                                                                                                   // 89
   userId: userId                                                                                                      // 90
   },                                                                                                                  // 91
   {                                                                                                                   // 92
   users: {$in: [userId]}                                                                                              // 93
   }                                                                                                                   // 94
   ]                                                                                                                   // 95
   }).fetch();*/                                                                                                       // 96
  /*var chats = bz.cols.chats.find({                                                                                   // 97
   users: {$in: [userId]}                                                                                              // 98
   }).fetch();                                                                                                         // 99
   var users1 = _.unique(_.map(chats, function(item) {                                                                 // 100
   return item.users[0]                                                                                                // 101
   }));                                                                                                                // 102
   _.each(users1, function(usr){                                                                                       // 103
   var chats1 = bz.cols.chats.findOne({                                                                                // 104
   userId: Meteor.userId(), users: {$in: [usr]}},                                                                      // 105
   {sort: {timeBegin: -1}});                                                                                           // 106
   //chats.tsFormatted = moment(chats1.timeBegin).fromNow();                                                           // 107
   chatsArr.push(chats1);                                                                                              // 108
   });                                                                                                                 // 109
   return chatsArr;                                                                                                    // 110
                                                                                                                       // 111
   */                                                                                                                  // 112
  var chats;                                                                                                           // 113
  if (all) {                                                                                                           // 114
    var chats = bz.cols.chats.find({                                                                                   // 115
      users: {$in: [userId]}                                                                                           // 116
    }).fetch();                                                                                                        // 117
  } else {                                                                                                             // 118
    var chats = bz.cols.chats.find({                                                                                   // 119
      users: {$in: [userId]},                                                                                          // 120
      activated: true                                                                                                  // 121
    }).fetch();                                                                                                        // 122
  }                                                                                                                    // 123
                                                                                                                       // 124
  return chats;                                                                                                        // 125
};                                                                                                                     // 126
                                                                                                                       // 127
messageModals = {};                                                                                                    // 128
showMessageModal = function (msgObj, userObj, id) {                                                                    // 129
  var data = {                                                                                                         // 130
      messageText: msgObj.text,                                                                                        // 131
      chatId: msgObj.chatId,                                                                                           // 132
      user: userObj                                                                                                    // 133
    },                                                                                                                 // 134
    parentNode = $('.js-message-popup-placeholder')[0];                                                                // 135
    messageModals[id] = Blaze.renderWithData(Template.bzChatMessagePopup, data, parentNode);                           // 136
                                                                                                                       // 137
  /*$('.js-chat-message-modal').foundation('reveal', 'open');*/                                                        // 138
                                                                                                                       // 139
  /*setTimeout(function () {                                                                                           // 140
    a = id;                                                                                                            // 141
    hideMessageModal(id);                                                                                              // 142
  }, 50000);*/                                                                                                         // 143
};                                                                                                                     // 144
                                                                                                                       // 145
bzAlerMessage = {};                                                                                                    // 146
showbzAlerMessage = function(msgObj, userObj, id) {                                                                    // 147
  var text = msgObj.text,                                                                                              // 148
      cutMessage = text.slice(0, 70) + '...';                                                                          // 149
                                                                                                                       // 150
  var data = {                                                                                                         // 151
    messageText: cutMessage,                                                                                           // 152
    chatId: msgObj.chatId,                                                                                             // 153
    user: userObj                                                                                                      // 154
  };                                                                                                                   // 155
                                                                                                                       // 156
  /*var parentNode = $('.message-loader')[0];                                                                          // 157
  bzAlerMessage[id] = Blaze.renderWithData(Template.sAlertCustom, data, parentNode);*/                                 // 158
                                                                                                                       // 159
  sAlert.success(data, {timeout: 5000});                                                                               // 160
};                                                                                                                     // 161
                                                                                                                       // 162
                                                                                                                       // 163
hideMessageModal = function(msgId){                                                                                    // 164
  $('.js-chat-message-modal').foundation('reveal', 'close');                                                           // 165
  if(msgId) {                                                                                                          // 166
    var view = messageModals[msgId];                                                                                   // 167
    view && Blaze.remove(view);                                                                                        // 168
  }                                                                                                                    // 169
};                                                                                                                     // 170
                                                                                                                       // 171
Template.registerHelper("timestampToTime", function (timestamp) {                                                      // 172
  var date = new Date(timestamp);                                                                                      // 173
  //return '';                                                                                                         // 174
  return moment(date).fromNow();                                                                                       // 175
});                                                                                                                    // 176
Meteor.startup(function () {                                                                                           // 177
  /*bz.cols.messages.find().observeChanges({                                                                           // 178
   added: function(a, b){                                                                                              // 179
   console.log(a);                                                                                                     // 180
   console.log(b);                                                                                                     // 181
   }                                                                                                                   // 182
   });*/                                                                                                               // 183
});                                                                                                                    // 184
                                                                                                                       // 185
// EXPOSE EXTERNAL API:                                                                                                // 186
bz.buz.chats.createChatIfFirstMessage = createChatIfFirstMessage;                                                      // 187
bz.buz.chats.showMessageModal = showMessageModal;                                                                      // 188
                                                                                                                       // 189
bz.buz.chats.showbzAlerMessage = showbzAlerMessage;                                                                    // 190
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/template.chat-id.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("bzChatId");                                                                                      // 2
Template["bzChatId"] = new Template("Template.bzChatId", (function() {                                                 // 3
  var view = this;                                                                                                     // 4
  return HTML.DIV({                                                                                                    // 5
    "class": "main-content"                                                                                            // 6
  }, "\n    ", HTML.DIV({                                                                                              // 7
    "class": "bz-page-chat"                                                                                            // 8
  }, "\n\n        ", Spacebars.include(view.lookupTemplate("bzMessageToolbar")), "\n        \n\n        ", HTML.DIV({  // 9
    "class": "bz-messages-container"                                                                                   // 10
  }, "\n\n            ", Blaze.Each(function() {                                                                       // 11
    return Spacebars.call(view.lookup("getMessages"));                                                                 // 12
  }, function() {                                                                                                      // 13
    return [ "\n                ", Spacebars.include(view.lookupTemplate("chatMessage")), "\n            " ];          // 14
  }), "\n\n        "), "\n        ", HTML.DIV({                                                                        // 15
    "class": "bz-user-inputs-messages"                                                                                 // 16
  }, "\n            ", HTML.DIV({                                                                                      // 17
    "class": "bz-user-inputs-messages-wrapper"                                                                         // 18
  }, "\n                ", HTML.DIV({                                                                                  // 19
    "class": "bz-user-inputs"                                                                                          // 20
  }, "\n                    ", HTML.DIV({                                                                              // 21
    "class": "bz-user-inputs-message"                                                                                  // 22
  }, "\n                        ", HTML.TEXTAREA({                                                                     // 23
    "class": "btn--input-message",                                                                                     // 24
    id: "message-input",                                                                                               // 25
    placeholder: "Type your message ...",                                                                              // 26
    name: "textMessage",                                                                                               // 27
    "data-autoresize": "",                                                                                             // 28
    rows: "1"                                                                                                          // 29
  }), "\n                    "), "\n                    ", HTML.Raw('<div class="bz-user-inputs-btn-send">\n                        <button id="send-btn" type="button" class="button bz-small btn-default btn--send">Send</button>\n                    </div>'), "\n                "), "\n            "), "\n        "), "\n    "), "\n  ");
}));                                                                                                                   // 31
                                                                                                                       // 32
Template.__checkName("bzMessageToolbar");                                                                              // 33
Template["bzMessageToolbar"] = new Template("Template.bzMessageToolbar", (function() {                                 // 34
  var view = this;                                                                                                     // 35
  return HTML.DIV({                                                                                                    // 36
    "class": "bz-toolbar bz-user-owner-toolbar"                                                                        // 37
  }, "\n        ", HTML.DIV({                                                                                          // 38
    "class": "bz-user-owner-toolbar-wrapper"                                                                           // 39
  }, "\n            ", HTML.DIV({                                                                                      // 40
    "class": "bz-user-wrap-inner"                                                                                      // 41
  }, "\n                ", HTML.Raw('<div class="bz-user-avatar">\n                    <img src="/img/content/avatars/avatar-no.png" style="height:50px; width:50px;">\n                </div>'), "\n                ", HTML.DIV({
    "class": "bz-user-info"                                                                                            // 43
  }, "\n                    ", HTML.DIV({                                                                              // 44
    "class": "bz-username"                                                                                             // 45
  }, "\n                        ", HTML.A({                                                                            // 46
    href: "/profile/#"                                                                                                 // 47
  }, Blaze.View("lookup:getFriendUserName", function() {                                                               // 48
    return Spacebars.mustache(view.lookup("getFriendUserName"));                                                       // 49
  })), "\n                    "), "\n                    ", HTML.Raw('<div class="bz-user-status"><span>online or offline</span></div>'), "\n                "), "\n            "), "\n            ", HTML.Raw('<div class="bz-user-service-menu">Will be service menu</div>'), "\n        "), "\n    ");
}));                                                                                                                   // 51
                                                                                                                       // 52
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/chat-id.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by ashot on 5/20/15.                                                                                        // 2
 */                                                                                                                    // 3
                                                                                                                       // 4
Template.bzChatId.onRendered(function() {                                                                              // 5
                                                                                                                       // 6
    $.each($('textarea[data-autoresize]'), function() {                                                                // 7
        var offset = this.offsetHeight - this.clientHeight;                                                            // 8
        var resizeTextarea = function(el) {                                                                            // 9
            $(el).css('height', 'auto').css('height', el.scrollHeight + offset);                                       // 10
        };                                                                                                             // 11
                                                                                                                       // 12
        $(this).on('keyup input', function() {                                                                         // 13
            if(this.scrollHeight > 44) {                                                                               // 14
                resizeTextarea(this);                                                                                  // 15
            }                                                                                                          // 16
        }).removeAttr('data-autoresize');                                                                              // 17
    });                                                                                                                // 18
                                                                                                                       // 19
});                                                                                                                    // 20
                                                                                                                       // 21
Template.bzChatId.created = function () {                                                                              // 22
  currentUser = Meteor.user();                                                                                         // 23
  //friendUserId = Router.current().params.userId;                                                                     // 24
};                                                                                                                     // 25
                                                                                                                       // 26
Template.bzChatId.rendered = function () {                                                                             // 27
//todo: Don't forget turn on:                                                                                          // 28
// Trail();                                                                                                            // 29
    var that = this;                                                                                                   // 30
    scrollMessages();                                                                                                  // 31
    var lastCount = this.data.messages.count();                                                                        // 32
    Deps.autorun(function() {                                                                                          // 33
        /*var newCount = that.data.messages.count();                                                                   // 34
        if(newCount > lastCount) {                                                                                     // 35
            scrollMessages();                                                                                          // 36
        }*/                                                                                                            // 37
    });                                                                                                                // 38
};                                                                                                                     // 39
                                                                                                                       // 40
Template.bzChatId.events({                                                                                             // 41
  'click #send-btn': function (e, v) {                                                                                 // 42
    if(!currentUser){                                                                                                  // 43
      alert('please login');                                                                                           // 44
    } else {                                                                                                           // 45
      var messageText = v.$('#message-input').val();                                                                   // 46
        if($.trim(messageText) === "") {                                                                               // 47
            return false;                                                                                              // 48
        }                                                                                                              // 49
        if(messageText != '') {                                                                                        // 50
          sendMessage.call(this, messageText, this.chat, this.user._id);                                               // 51
          v.$('#message-input').val('');                                                                               // 52
        }//end if                                                                                                      // 53
    }                                                                                                                  // 54
  },                                                                                                                   // 55
  'keydown #message-input': function(e, v) {                                                                           // 56
                                                                                                                       // 57
      if(e.which === 13) {                                                                                             // 58
          e.preventDefault();                                                                                          // 59
          //console.log("you pressed enter");                                                                          // 60
          var messageText = v.$('#message-input').val();                                                               // 61
          if($.trim(messageText) === "") {                                                                             // 62
              return false;                                                                                            // 63
          }                                                                                                            // 64
          if(messageText != '') {                                                                                      // 65
            sendMessage.call(this, messageText, this.chat, this.user._id);                                             // 66
            v.$('#message-input').val('');                                                                             // 67
          }                                                                                                            // 68
      }                                                                                                                // 69
  }                                                                                                                    // 70
});                                                                                                                    // 71
                                                                                                                       // 72
Template.bzChatId.helpers({                                                                                            // 73
  getMessages: function (a, b) {                                                                                       // 74
    var messages = this.messages                                                                                       // 75
    return messages;                                                                                                   // 76
  }                                                                                                                    // 77
});                                                                                                                    // 78
                                                                                                                       // 79
                                                                                                                       // 80
                                                                                                                       // 81
Template.bzMessageToolbar.helpers({                                                                                    // 82
  getFriendUserName: function() {                                                                                      // 83
    var friendUserName = this.user.username,                                                                           // 84
        partEmail;                                                                                                     // 85
    if(friendUserName) {                                                                                               // 86
      return friendUserName;                                                                                           // 87
    } else {                                                                                                           // 88
      partEmail = this.user.emails[0].address;                                                                         // 89
      return partEmail.split('@')[0];                                                                                  // 90
    }                                                                                                                  // 91
  }                                                                                                                    // 92
});                                                                                                                    // 93
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/template.chats-all.js                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("bzChatsMy");                                                                                     // 2
Template["bzChatsMy"] = new Template("Template.bzChatsMy", (function() {                                               // 3
  var view = this;                                                                                                     // 4
  return Blaze.If(function() {                                                                                         // 5
    return Spacebars.call(view.lookup("getChats"));                                                                    // 6
  }, function() {                                                                                                      // 7
    return [ "\n\n    ", Spacebars.include(view.lookupTemplate("bzChatsToolbar")), "\n\n    ", Blaze.Each(function() { // 8
      return Spacebars.call(view.lookup("getChats"));                                                                  // 9
    }, function() {                                                                                                    // 10
      return [ "\n      ", Spacebars.include(view.lookupTemplate("bzChatItem")), "\n    " ];                           // 11
    }), "\n\n  " ];                                                                                                    // 12
  }, function() {                                                                                                      // 13
    return [ "\n\n    ", Spacebars.include(view.lookupTemplate("noChats")), "\n\n  " ];                                // 14
  });                                                                                                                  // 15
}));                                                                                                                   // 16
                                                                                                                       // 17
Template.__checkName("bzChatItem");                                                                                    // 18
Template["bzChatItem"] = new Template("Template.bzChatItem", (function() {                                             // 19
  var view = this;                                                                                                     // 20
  return HTML.DIV({                                                                                                    // 21
    "class": "bz-chat-item"                                                                                            // 22
  }, "\n    ", HTML.A({                                                                                                // 23
    href: function() {                                                                                                 // 24
      return [ "/chat/", Spacebars.mustache(view.lookup("_id")) ];                                                     // 25
    }                                                                                                                  // 26
  }, "\n      ", HTML.DIV({                                                                                            // 27
    "class": "bz-meta"                                                                                                 // 28
  }, "\n\n        ", Blaze.Each(function() {                                                                           // 29
    return Spacebars.call(view.lookup("getUsers"));                                                                    // 30
  }, function() {                                                                                                      // 31
    return [ "\n\n          ", Blaze.If(function() {                                                                   // 32
      return Spacebars.call(Spacebars.dot(view.lookup("profile"), "image", "data"));                                   // 33
    }, function() {                                                                                                    // 34
      return [ "\n            ", HTML.DIV({                                                                            // 35
        "class": "bz-user-avatar"                                                                                      // 36
      }, "\n                ", HTML.DIV({                                                                              // 37
        "class": "bz-avatar",                                                                                          // 38
        style: function() {                                                                                            // 39
          return [ "background-image: url(", Spacebars.mustache(Spacebars.dot(view.lookup("profile"), "image", "data")), ")" ];
        }                                                                                                              // 41
      }), "\n            "), "\n          " ];                                                                         // 42
    }, function() {                                                                                                    // 43
      return [ "\n            ", HTML.DIV({                                                                            // 44
        "class": "bz-user-avatar"                                                                                      // 45
      }, "\n              ", HTML.IMG({                                                                                // 46
        src: "/img/content/avatars/avatar-no.png",                                                                     // 47
        alt: "null"                                                                                                    // 48
      }), "\n            "), "\n          " ];                                                                         // 49
    }), "\n\n          ", HTML.DIV({                                                                                   // 50
      "class": "bz-username"                                                                                           // 51
    }, "\n            ", Blaze.View("lookup:getUserName", function() {                                                 // 52
      return Spacebars.mustache(view.lookup("getUserName"), view.lookup("."));                                         // 53
    }), "\n          "), "\n\n        " ];                                                                             // 54
  }), "\n\n        ", HTML.DIV({                                                                                       // 55
    "class": "bz-last-timestamp"                                                                                       // 56
  }, " Last message: ", Blaze.View("lookup:getFormattedTs", function() {                                               // 57
    return Spacebars.mustache(view.lookup("getFormattedTs"), view.lookup("timeBegin"));                                // 58
  }), " "), "\n        ", HTML.DIV({                                                                                   // 59
    "class": ""                                                                                                        // 60
  }, "Chat id: ", Blaze.View("lookup:_id", function() {                                                                // 61
    return Spacebars.mustache(view.lookup("_id"));                                                                     // 62
  }), " "), "\n\n      "), "\n    "), "\n  ");                                                                         // 63
}));                                                                                                                   // 64
                                                                                                                       // 65
Template.__checkName("chatMessage");                                                                                   // 66
Template["chatMessage"] = new Template("Template.chatMessage", (function() {                                           // 67
  var view = this;                                                                                                     // 68
  return HTML.DIV({                                                                                                    // 69
    "class": "bz-conversations-message-wrapper"                                                                        // 70
  }, "\n    ", HTML.DIV({                                                                                              // 71
    "class": function() {                                                                                              // 72
      return [ "bz-message ", Spacebars.mustache(view.lookup("getMessageClass")) ];                                    // 73
    }                                                                                                                  // 74
  }, "\n      ", HTML.DIV({                                                                                            // 75
    "class": "bz-box-message"                                                                                          // 76
  }, "\n        ", HTML.Raw('<div class="bz-message-user-avatar">\n            <img src="/img/content/avatars/avatar-no.png" style="height:40px; width:40px;">\n        </div>'), "\n        ", HTML.DIV({
    "class": "bz-message-body"                                                                                         // 78
  }, "\n            ", HTML.DIV({                                                                                      // 79
    "class": "bz-message-text"                                                                                         // 80
  }, Blaze.View("lookup:text", function() {                                                                            // 81
    return Spacebars.mustache(view.lookup("text"));                                                                    // 82
  })), "\n            ", HTML.SPAN({                                                                                   // 83
    "class": "timeStamp"                                                                                               // 84
  }, Blaze.View("lookup:timestampToTime", function() {                                                                 // 85
    return Spacebars.mustache(view.lookup("timestampToTime"), view.lookup("timestamp"));                               // 86
  })), "\n        "), "\n      "), "\n      \n    "), "\n\n  ");                                                       // 87
}));                                                                                                                   // 88
                                                                                                                       // 89
Template.__checkName("replyArea");                                                                                     // 90
Template["replyArea"] = new Template("Template.replyArea", (function() {                                               // 91
  var view = this;                                                                                                     // 92
  return HTML.DIV({                                                                                                    // 93
    id: "replyArea"                                                                                                    // 94
  }, "\n    ", HTML.DIV({                                                                                              // 95
    "class": "user-inputs-messages"                                                                                    // 96
  }, "\n\n      ", HTML.DIV({                                                                                          // 97
    "class": "user-inputs"                                                                                             // 98
  }, "\n        ", HTML.FORM("\n          ", HTML.TEXTAREA({                                                           // 99
    "class": "btn--input-message",                                                                                     // 100
    id: "message-input",                                                                                               // 101
    name: "textMessage",                                                                                               // 102
    placeholder: [ "Send Message ", HTML.CharRef({                                                                     // 103
      html: "&crarr;",                                                                                                 // 104
      str: "↵"                                                                                                         // 105
    }) ],                                                                                                              // 106
    "data-autoresize": "",                                                                                             // 107
    rows: "1"                                                                                                          // 108
  }), "\n          ", HTML.Raw('<!--<input id="message-input" type="text" name="textMessage" value="" placeholder="Your message" class="btn-input-message"> - -->'), "\n          ", HTML.Raw('<input id="send-btn" type="button" value="send" class="btn--send">'), "\n        "), "\n      "), "\n\n    "), "\n  ");
}));                                                                                                                   // 110
                                                                                                                       // 111
Template.__checkName("noChats");                                                                                       // 112
Template["noChats"] = new Template("Template.noChats", (function() {                                                   // 113
  var view = this;                                                                                                     // 114
  return HTML.Raw('<div class="bz-wrapper-no-message">\n    <div class="bz-flex-box">\n\n      <div class="bz-img-conversation">\n        <i class="fa fa-comments"></i>\n      </div>\n\n      <div class="title-message">You have<br>no conversations yet</div>\n      <div class="subtitle-message">Start messaging by pressing the pencil button in the top right corner or press\n        button\n        below.\n      </div>\n\n      <div class="bz-padding-top-x2">\n        <button class="button button-outline btn-default goContacts">go to the Contacts</button>\n      </div>\n    </div>\n  </div>');
}));                                                                                                                   // 116
                                                                                                                       // 117
Template.__checkName("bzChatsToolbar");                                                                                // 118
Template["bzChatsToolbar"] = new Template("Template.bzChatsToolbar", (function() {                                     // 119
  var view = this;                                                                                                     // 120
  return HTML.Raw('<div class="bz-toolbar bz-chats-toolbar">\n    <div class="bz-search-header">\n      <label class="bz-item-input-wrapper">\n        <i class="fa fa-search placeholder-icon"></i>\n        <input type="search" placeholder="Search for messages or username" class="bz-input-search">\n      </label>\n    </div>\n\n    <div style="height: 62px; line-height: 62px; padding: 0 15px;">Filter</div>\n\n  </div>');
}));                                                                                                                   // 122
                                                                                                                       // 123
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/chats-all.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by douson on 24.08.15.                                                                                      // 2
 */                                                                                                                    // 3
                                                                                                                       // 4
Template.bzChatsMy.onCreated(function () {                                                                             // 5
  //return Meteor.subscribe('posts-images');                                                                           // 6
});                                                                                                                    // 7
                                                                                                                       // 8
Template.bzChatsMy.helpers({                                                                                           // 9
  getChats: function () {                                                                                              // 10
    var ret = getUniqueChatsForUser(Meteor.userId());                                                                  // 11
    return ret;                                                                                                        // 12
    /*var lastChat = _.uniq(bz.cols.chats.find({userId: Meteor.userId()}, {                                            // 13
      sort: {myField: 1}, fields: {myField: true}                                                                      // 14
    }).fetch().map(function(x) {                                                                                       // 15
      return x.myField;                                                                                                // 16
    }), true);*/                                                                                                       // 17
    //var lastChat = chats.sort                                                                                        // 18
    //db.user.find( {"id" : {$in : user.friends }})                                                                    // 19
    //return chats;                                                                                                    // 20
  }                                                                                                                    // 21
});                                                                                                                    // 22
Template.bzChatItem.onRendered(function(){                                                                             // 23
});                                                                                                                    // 24
Template.bzChatItem.helpers({                                                                                          // 25
  getUserName: function(){                                                                                             // 26
    /*var user = Meteor.users.findOne({                                                                                // 27
      _id: this.toString()                                                                                             // 28
    });*/                                                                                                              // 29
    //var user = Meteor.users.findOne(Meteor.userId());                                                                // 30
    var user = this;                                                                                                   // 31
    return user.username;                                                                                              // 32
  },                                                                                                                   // 33
  getUsers: function(){                                                                                                // 34
    return Meteor.users.find({                                                                                         // 35
      _id: {$in: _.without(this.users, Meteor.userId())}                                                               // 36
    });                                                                                                                // 37
  }                                                                                                                    // 38
})                                                                                                                     // 39
Template.onePostRowItem.helpers({                                                                                      // 40
  getPhotoUrl: function () {                                                                                           // 41
    var photo = bz.cols.posts.findOne({_id: this._id}),                                                                // 42
      photoId = photo.details.photos && photo.details.photos[0] || undefined;                                          // 43
                                                                                                                       // 44
    if (photoId) {                                                                                                     // 45
      var image = bz.cols.images.findOne({_id: photoId});                                                              // 46
    }                                                                                                                  // 47
                                                                                                                       // 48
    return image;                                                                                                      // 49
                                                                                                                       // 50
  },                                                                                                                   // 51
  getPrice: function () {                                                                                              // 52
  }                                                                                                                    // 53
});                                                                                                                    // 54
// reply area                                                                                                          // 55
Template.replyArea.events({                                                                                            // 56
  'click ': function(e, tmpl) {                                                                                        // 57
    e.preventDefault();                                                                                                // 58
                                                                                                                       // 59
    var textArea = tmpl.$('...');                                                                                      // 60
    var val = textArea.val();                                                                                          // 61
                                                                                                                       // 62
    textArea.attr('disable', 'disable');                                                                               // 63
                                                                                                                       // 64
    /* ... */                                                                                                          // 65
  },                                                                                                                   // 66
  'keypress textarea': function(e, tmpl) {                                                                             // 67
    if(e.keyCode === 13) {                                                                                             // 68
      e.preventDefault();                                                                                              // 69
      tmpl.$('...').submit();                                                                                          // 70
    }                                                                                                                  // 71
  }                                                                                                                    // 72
});                                                                                                                    // 73
                                                                                                                       // 74
                                                                                                                       // 75
Template.chatMessage.onRendered(function(){                                                                            // 76
  bz.cols.messages.update(this.data._id, {$set: {seen: true}});                                                        // 77
});                                                                                                                    // 78
Template.chatMessage.helpers({                                                                                         // 79
  getMessageClass: function () {                                                                                       // 80
    var className = '';                                                                                                // 81
    if (this.userId === currentUser._id) {                                                                             // 82
      // my message                                                                                                    // 83
      className = 'my-message';                                                                                        // 84
    } else {                                                                                                           // 85
      className = 'friends-message';                                                                                   // 86
    }                                                                                                                  // 87
    return className;                                                                                                  // 88
  },                                                                                                                   // 89
  isOwnMessage: function () {                                                                                          // 90
  }                                                                                                                    // 91
});                                                                                                                    // 92
                                                                                                                       // 93
                                                                                                                       // 94
                                                                                                                       // 95
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/template.controls.js                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("bzChatMessagePopup");                                                                            // 2
Template["bzChatMessagePopup"] = new Template("Template.bzChatMessagePopup", (function() {                             // 3
  var view = this;                                                                                                     // 4
  return HTML.DIV({                                                                                                    // 5
    id: "bzChatMessageModal",                                                                                          // 6
    "class": "reveal-modal js-chat-message-modal",                                                                     // 7
    "data-reveal": "",                                                                                                 // 8
    "aria-labelledby": "firstModalTitle",                                                                              // 9
    "aria-hidden": "true",                                                                                             // 10
    role: "dialog"                                                                                                     // 11
  }, HTML.Raw("\n    <h4>New incoming message.</h4>\n\n    "), HTML.P(HTML.A({                                         // 12
    href: function() {                                                                                                 // 13
      return [ "/chat/", Spacebars.mustache(view.lookup("chatId")) ];                                                  // 14
    },                                                                                                                 // 15
    "class": "js-go-to-msg-link",                                                                                      // 16
    "data-id": function() {                                                                                            // 17
      return Spacebars.mustache(view.lookup("_id"));                                                                   // 18
    }                                                                                                                  // 19
  }, Blaze.View("lookup:messageText", function() {                                                                     // 20
    return Spacebars.mustache(view.lookup("messageText"));                                                             // 21
  }))), "\n    ", Blaze.If(function() {                                                                                // 22
    return Spacebars.call(view.lookup("user"));                                                                        // 23
  }, function() {                                                                                                      // 24
    return [ "\n    ", HTML.P("From:"), "\n    ", Blaze._TemplateWith(function() {                                     // 25
      return Spacebars.call(view.lookup("user"));                                                                      // 26
    }, function() {                                                                                                    // 27
      return Spacebars.include(view.lookupTemplate("bzUserProfileBasic"));                                             // 28
    }), "\n    " ];                                                                                                    // 29
  }), HTML.Raw('\n    <a class="close-reveal-modal" aria-label="Close">&#215;</a>\n  '));                              // 30
}));                                                                                                                   // 31
                                                                                                                       // 32
Template.__checkName("sAlertCustom");                                                                                  // 33
Template["sAlertCustom"] = new Template("Template.sAlertCustom", (function() {                                         // 34
  var view = this;                                                                                                     // 35
  return HTML.DIV({                                                                                                    // 36
    "class": function() {                                                                                              // 37
      return [ "custom-alert-class s-alert-box s-alert-", Spacebars.mustache(view.lookup("condition")), " s-alert-", Spacebars.mustache(view.lookup("position")), " s-alert-effect-scale s-alert-show" ];
    },                                                                                                                 // 39
    id: function() {                                                                                                   // 40
      return Spacebars.mustache(view.lookup("_id"));                                                                   // 41
    },                                                                                                                 // 42
    style: function() {                                                                                                // 43
      return Spacebars.mustache(view.lookup("boxPosition"));                                                           // 44
    }                                                                                                                  // 45
  }, "\n        ", HTML.DIV({                                                                                          // 46
    "class": "s-alert-box-inner"                                                                                       // 47
  }, "\n            ", Blaze.If(function() {                                                                           // 48
    return Spacebars.call(view.lookup("user"));                                                                        // 49
  }, function() {                                                                                                      // 50
    return [ "\n                ", HTML.DIV({                                                                          // 51
      "class": "bz-alert-message"                                                                                      // 52
    }, "\n                    ", HTML.DIV({                                                                            // 53
      "class": "bz-alert-message-wrapper"                                                                              // 54
    }, "\n                        ", HTML.DIV({                                                                        // 55
      "class": "bz-user-avatar"                                                                                        // 56
    }, "\n                            ", Blaze.If(function() {                                                         // 57
      return Spacebars.call(Spacebars.dot(view.lookup("user"), "profile", "image", "data"));                           // 58
    }, function() {                                                                                                    // 59
      return [ "\n                            ", HTML.DIV({                                                            // 60
        "class": "bz-avatar",                                                                                          // 61
        style: function() {                                                                                            // 62
          return [ "background-image: url(", Spacebars.mustache(Spacebars.dot(view.lookup("user"), "profile", "image", "data")), ")" ];
        }                                                                                                              // 64
      }), "\n                            " ];                                                                          // 65
    }, function() {                                                                                                    // 66
      return [ "\n                            ", HTML.DIV({                                                            // 67
        "class": "bz-avatar",                                                                                          // 68
        style: "background-image: url('/img/content/avatars/avatar-no.png')"                                           // 69
      }), "\n                            " ];                                                                          // 70
    }), "\n                        "), "\n                        ", HTML.DIV({                                        // 71
      "class": "bz-alert-message-content"                                                                              // 72
    }, "\n                            ", HTML.DIV({                                                                    // 73
      "class": "bz-alert-message-username"                                                                             // 74
    }, " ", Blaze.View("lookup:user.username", function() {                                                            // 75
      return Spacebars.mustache(Spacebars.dot(view.lookup("user"), "username"));                                       // 76
    }), " "), "\n                            ", HTML.A({                                                               // 77
      href: function() {                                                                                               // 78
        return [ "/chat/", Spacebars.mustache(view.lookup("chatId")) ];                                                // 79
      },                                                                                                               // 80
      "class": "js-go-to-msg-link",                                                                                    // 81
      "data-id": function() {                                                                                          // 82
        return Spacebars.mustache(view.lookup("_id"));                                                                 // 83
      }                                                                                                                // 84
    }, "\n                                ", HTML.DIV({                                                                // 85
      "class": "bz-alert-message-text"                                                                                 // 86
    }, "\n                                    ", HTML.SPAN(" ", Blaze.View("lookup:messageText", function() {          // 87
      return Spacebars.mustache(view.lookup("messageText"));                                                           // 88
    }), " "), "\n                                "), "\n                            "), "\n                        "), "\n                    "), "\n                "), "\n            " ];
  }), "            \n        "), HTML.Raw('\n        <span class="s-alert-close"></span>\n    '));                     // 90
}));                                                                                                                   // 91
                                                                                                                       // 92
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/controls.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by arutu_000 on 10/6/2015.                                                                                  // 2
 */                                                                                                                    // 3
Template.bzChatMessagePopup.onRendered(function(){                                                                     // 4
  //js-message-text                                                                                                    // 5
  if(this.data) {                                                                                                      // 6
    var id = this.data._id;                                                                                            // 7
    $(document).on('closed.fndtn.reveal', '[data-reveal].js-chat-message-modal', function () {                         // 8
      hideMessageModal(id);                                                                                            // 9
    });                                                                                                                // 10
  }                                                                                                                    // 11
});                                                                                                                    // 12
Template.bzChatMessagePopup.onDestroyed(function(){                                                                    // 13
  $(document).off('closed.fndtn.reveal', '[data-reveal].js-chat-message-modal');                                       // 14
})                                                                                                                     // 15
Template.bzChatMessagePopup.events({                                                                                   // 16
  'click .js-go-to-msg-link': function(){                                                                              // 17
    debugger;                                                                                                          // 18
    hideMessageModal()                                                                                                 // 19
    // need to close the modal with the message:                                                                       // 20
  }                                                                                                                    // 21
});                                                                                                                    // 22
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/template.page-chats.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("bzPageChats");                                                                                   // 2
Template["bzPageChats"] = new Template("Template.bzPageChats", (function() {                                           // 3
  var view = this;                                                                                                     // 4
  return HTML.DIV({                                                                                                    // 5
    "class": "main-content"                                                                                            // 6
  }, "\n      ", HTML.DIV({                                                                                            // 7
    "class": "bz-wrapper-messages"                                                                                     // 8
  }, "\n        ", Spacebars.include(view.lookupTemplate("bzChatsMy")), "\n      "), "\n    ");                        // 9
}));                                                                                                                   // 10
                                                                                                                       // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/arutune:bz-page-chat/client/browser/page-chats.js                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by ashot on 8/20/15.                                                                                        // 2
 */                                                                                                                    // 3
var isOn = false;                                                                                                      // 4
Template.bzPageChats.events({                                                                                          // 5
                                                                                                                       // 6
});                                                                                                                    // 7
                                                                                                                       // 8
Template.bzPageChats.rendered = function () {                                                                          // 9
                                                                                                                       // 10
  //$('select').foundationSelect();                                                                                    // 11
  //$(document).foundation();                                                                                          // 12
                                                                                                                       // 13
};                                                                                                                     // 14
                                                                                                                       // 15
                                                                                                                       // 16
                                                                                                                       // 17
                                                                                                                       // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
