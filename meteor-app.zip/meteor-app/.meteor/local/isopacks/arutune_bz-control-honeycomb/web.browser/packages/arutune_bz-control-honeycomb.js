(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/client/lib/honeycomb.js                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by Serge on 10/13/2015.                                                                                  // 2
 */                                                                                                                 // 3
honeycomb = (function(){                                                                                            // 4
                                                                                                                    // 5
    /*interface*/                                                                                                   // 6
    honeycomb = {                                                                                                   // 7
        createHoneycomb: createHoneycomb,                                                                           // 8
        augmentData: augmentData,                                                                                   // 9
        removeHoneycomb: removeHoneycomb                                                                            // 10
    };                                                                                                              // 11
                                                                                                                    // 12
    /*almost privates:*/                                                                                            // 13
                                                                                                                    // 14
    var honeycombContainer = null;                                                                                  // 15
    var honeycombData = null;                                                                                       // 16
    var cellCentersOffsetsFromTop = [35, 150, 265];                                                                 // 17
    var cellCentersOffsetsFromLeftOddRows = [10, 143, 276, 409, 542, 675, 808];                                     // 18
    var cellCentersOffsetsFromLeftEvenRows = [76, 209, 342, 475, 608, 741];                                         // 19
    var displayedPageNumber = 0;                                                                                    // 20
    var totalPages = 0;                                                                                             // 21
    var cells = [];                                                                                                 // 22
                                                                                                                    // 23
                                                                                                                    // 24
    function createHoneycomb(honeycombPlaceHolder, data){                                                           // 25
        console.log("createHoneycomb launched!");                                                                   // 26
        honeycombContainer = document.createElement("div");                                                         // 27
        honeycombContainer.className = "hc-unselectable hc-honeycomb-container"                                     // 28
        honeycombData = data;                                                                                       // 29
                                                                                                                    // 30
        totalPages = Math.floor(honeycombData.length/20);                                                           // 31
        honeycombContainer.innerHTML = "";                                                                          // 32
        createRoundPaginationControls();                                                                            // 33
        var pageData = cutSlice(displayedPageNumber);                                                               // 34
        appendCells(pageData);                                                                                      // 35
        renderCells();                                                                                              // 36
                                                                                                                    // 37
        /*need to check if honeycombPlaceHolder is dom element before continue*/                                    // 38
        honeycombPlaceHolder.appendChild(honeycombContainer);                                                       // 39
    };/*end createHoneycomb*/                                                                                       // 40
                                                                                                                    // 41
    function augmentData(){                                                                                         // 42
        console.log("augmentData is launched");                                                                     // 43
    };                                                                                                              // 44
                                                                                                                    // 45
    function removeHoneycomb(){                                                                                     // 46
        console.log("removeHoneycomb is launched");                                                                 // 47
    }                                                                                                               // 48
                                                                                                                    // 49
    function createRoundPaginationControls(){                                                                       // 50
                                                                                                                    // 51
        var paginationPrevious = document.createElement("div");                                                     // 52
                                                                                                                    // 53
        if(displayedPageNumber > 0){                                                                                // 54
            paginationPrevious.className = "hc-pagination hc-pagination-previous";                                  // 55
            paginationPrevious.addEventListener("click", decrementPage);                                            // 56
        }                                                                                                           // 57
        else{                                                                                                       // 58
            paginationPrevious.className = "hc-pagination hc-pagination-disabled hc-pagination-previous";           // 59
        }                                                                                                           // 60
                                                                                                                    // 61
        var paginationNext = document.createElement("div");                                                         // 62
        if(displayedPageNumber < totalPages - 1){                                                                   // 63
            paginationNext.className = "hc-pagination hc-pagination-next";                                          // 64
            paginationNext.addEventListener("click", incrementPage);                                                // 65
        }                                                                                                           // 66
        else{                                                                                                       // 67
            paginationNext.className = "hc-pagination hc-pagination-disabled hc-pagination-next";                   // 68
        }                                                                                                           // 69
                                                                                                                    // 70
        honeycombContainer.appendChild(paginationPrevious);                                                         // 71
        honeycombContainer.appendChild(paginationNext);                                                             // 72
    };                                                                                                              // 73
                                                                                                                    // 74
    function createPaginationControls(){                                                                            // 75
                                                                                                                    // 76
                                                                                                                    // 77
        var paginationPrevious = createPaginationControl();// document.createElement("div");                        // 78
                                                                                                                    // 79
        if(displayedPageNumber > 0){                                                                                // 80
            //paginationPrevious.className = "hc-pagination hc-pagination-previous";                                // 81
            paginationPrevious.addEventListener("click", decrementPage);                                            // 82
        }                                                                                                           // 83
        else{                                                                                                       // 84
            //paginationPrevious.className = "hc-pagination hc-pagination-disabled hc-pagination-previous";         // 85
        }                                                                                                           // 86
                                                                                                                    // 87
        var paginationNext = createNextPaginationControl();// document.createElement("div");                        // 88
        if(displayedPageNumber < totalPages - 1){                                                                   // 89
            /*paginationNext.className = "hc-pagination hc-pagination-next";*/                                      // 90
            paginationNext.addEventListener("click", incrementPage);                                                // 91
        }                                                                                                           // 92
        else{                                                                                                       // 93
            /*paginationNext.className = "hc-pagination hc-pagination-disabled hc-pagination-next";*/               // 94
        }                                                                                                           // 95
                                                                                                                    // 96
        honeycombContainer.appendChild(paginationPrevious);                                                         // 97
        honeycombContainer.appendChild(paginationNext);                                                             // 98
    };                                                                                                              // 99
                                                                                                                    // 100
    function createPaginationControl(){                                                                             // 101
        var cellContentHolder = document.createElement("div");                                                      // 102
        cellContentHolder.className = "hc-pagination-previous-content";                                             // 103
        //cellContentHolder.style.backgroundImage = "url('" + cellData.backgroundImageUrl + "')";                   // 104
                                                                                                                    // 105
        var innerBounder = document.createElement("div");                                                           // 106
        innerBounder.className = "hc-pagination-previous-inner-bounder";                                            // 107
        innerBounder.appendChild(cellContentHolder);                                                                // 108
                                                                                                                    // 109
        var middleBounder = document.createElement("div");                                                          // 110
        middleBounder.className = "hc-pagination-previous-middle-bounder";                                          // 111
        middleBounder.appendChild(innerBounder);                                                                    // 112
                                                                                                                    // 113
                                                                                                                    // 114
        var outerBounder = document.createElement("div");                                                           // 115
        outerBounder.className = "hc-pagination-previous-outer-bounder";                                            // 116
        outerBounder.appendChild(middleBounder);                                                                    // 117
                                                                                                                    // 118
        var cell = document.createElement("div");                                                                   // 119
        cell.className = "hc-pagination-previous-wrap";                                                             // 120
        cell.appendChild(outerBounder);                                                                             // 121
        cell.style.top = "142px";                                                                                   // 122
        cell.style.left = "20px";                                                                                   // 123
                                                                                                                    // 124
        return cell;                                                                                                // 125
                                                                                                                    // 126
    }                                                                                                               // 127
                                                                                                                    // 128
    function createNextPaginationControl(){                                                                         // 129
        var cellContentHolder = document.createElement("div");                                                      // 130
        cellContentHolder.className = "hc-pagination-next-content";                                                 // 131
        //cellContentHolder.style.backgroundImage = "url('" + cellData.backgroundImageUrl + "')";                   // 132
                                                                                                                    // 133
        var innerBounder = document.createElement("div");                                                           // 134
        innerBounder.className = "hc-pagination-next-inner-bounder";                                                // 135
        innerBounder.appendChild(cellContentHolder);                                                                // 136
                                                                                                                    // 137
        var middleBounder = document.createElement("div");                                                          // 138
        middleBounder.className = "hc-pagination-next-middle-bounder";                                              // 139
        middleBounder.appendChild(innerBounder);                                                                    // 140
                                                                                                                    // 141
                                                                                                                    // 142
        var outerBounder = document.createElement("div");                                                           // 143
        outerBounder.className = "hc-pagination-next-outer-bounder";                                                // 144
        outerBounder.appendChild(middleBounder);                                                                    // 145
                                                                                                                    // 146
        var cell = document.createElement("div");                                                                   // 147
        cell.className = "hc-pagination-next-wrap";                                                                 // 148
        cell.appendChild(outerBounder);                                                                             // 149
        cell.style.top = "142px";                                                                                   // 150
        cell.style.left = "886px";                                                                                  // 151
                                                                                                                    // 152
        return cell;                                                                                                // 153
                                                                                                                    // 154
    }                                                                                                               // 155
                                                                                                                    // 156
                                                                                                                    // 157
    function cutSlice(num){                                                                                         // 158
        pageData = honeycombData.slice(20*num, 20*num + 20);                                                        // 159
        return pageData;                                                                                            // 160
    }/*end of cutSlice...*/                                                                                         // 161
                                                                                                                    // 162
    function incrementPage(){                                                                                       // 163
        honeycombContainer.innerHTML = "";                                                                          // 164
        cells = [];                                                                                                 // 165
        /*add checking here prior incrementing*/                                                                    // 166
        displayedPageNumber ++;                                                                                     // 167
        createRoundPaginationControls();                                                                            // 168
        var pageData = cutSlice(displayedPageNumber);                                                               // 169
        appendCells(pageData);                                                                                      // 170
        renderCells();                                                                                              // 171
    };/*end of incrementPage...*/                                                                                   // 172
                                                                                                                    // 173
    function decrementPage(){                                                                                       // 174
        honeycombContainer.innerHTML = "";                                                                          // 175
        /*add checking here prior incrementing*/                                                                    // 176
        displayedPageNumber --;                                                                                     // 177
        createRoundPaginationControls();                                                                            // 178
        var pageData = cutSlice(displayedPageNumber);                                                               // 179
        appendCells(pageData);                                                                                      // 180
        renderCells();                                                                                              // 181
    }/*end of decrementPage*/                                                                                       // 182
                                                                                                                    // 183
    function createCell(top, left, cellData){                                                                       // 184
        var cellTopNav = document.createElement("div");                                                             // 185
        cellTopNav.className = "hc-cell-top-nav";                                                                   // 186
        var cellTopNavText = document.createTextNode(cellData.topText);                                             // 187
        cellTopNav.appendChild(cellTopNavText);                                                                     // 188
                                                                                                                    // 189
        var cellTextHeader = document.createElement("div");                                                         // 190
        cellTextHeader.className = "hc-cell-text-header";                                                           // 191
        var cellTextHeaderText = document.createTextNode(cellData.headerText);                                      // 192
        cellTextHeader.appendChild(cellTextHeaderText);                                                             // 193
                                                                                                                    // 194
        var cellTextBody = document.createElement("div");                                                           // 195
        cellTextBody.className = "hc-cell-text-body";                                                               // 196
        var cellTextBodyText = document.createTextNode(cellData.bodyText);                                          // 197
        cellTextBody.appendChild(cellTextBodyText);                                                                 // 198
                                                                                                                    // 199
        var cellBottomButton = document.createElement("div");                                                       // 200
        cellBottomButton.className = "hc-cell-bottom-button";                                                       // 201
        var cellBottomButtonText = document.createTextNode(cellData.buttonText);                                    // 202
        cellBottomButton.appendChild(cellBottomButtonText);                                                         // 203
                                                                                                                    // 204
        var cellContentHolder = document.createElement("div");                                                      // 205
        cellContentHolder.className = "hc-cell-content";                                                            // 206
        cellContentHolder.style.backgroundImage = "url('" + cellData.backgroundImageUrl + "')";                     // 207
        cellContentHolder.appendChild(cellTopNav);                                                                  // 208
        cellContentHolder.appendChild(cellTextHeader);                                                              // 209
        cellContentHolder.appendChild(cellTextBody);                                                                // 210
        cellContentHolder.appendChild(cellBottomButton);                                                            // 211
                                                                                                                    // 212
        var innerBounder = document.createElement("div");                                                           // 213
        innerBounder.className = "hc-cell-inner-bounder";                                                           // 214
        innerBounder.appendChild(cellContentHolder);                                                                // 215
                                                                                                                    // 216
        var middleBounder = document.createElement("div");                                                          // 217
        middleBounder.className = "hc-cell-middle-bounder";                                                         // 218
        middleBounder.appendChild(innerBounder);                                                                    // 219
                                                                                                                    // 220
                                                                                                                    // 221
        var outerBounder = document.createElement("div");                                                           // 222
        outerBounder.className = "hc-cell-outer-bounder";                                                           // 223
        outerBounder.appendChild(middleBounder);                                                                    // 224
                                                                                                                    // 225
        var cell = document.createElement("div");                                                                   // 226
        cell.className = "hc-cell-wrap";                                                                            // 227
        cell.appendChild(outerBounder);                                                                             // 228
        cell.style.top = top+"px";                                                                                  // 229
        cell.style.left = left+"px";                                                                                // 230
                                                                                                                    // 231
        cell.isMagnified = false;                                                                                   // 232
                                                                                                                    // 233
        cell.cellIndex = -1;                                                                                        // 234
                                                                                                                    // 235
        cell.magnify = function(){                                                                                  // 236
            cell.isMagnified = true;                                                                                // 237
            cell.classList.add("hc-cell-wrap-magnified");                                                           // 238
        };                                                                                                          // 239
                                                                                                                    // 240
        cell.demagnify = function(){                                                                                // 241
            cell.isMagnified = false;                                                                               // 242
            cell.classList.remove("hc-cell-wrap-magnified");                                                        // 243
        };                                                                                                          // 244
                                                                                                                    // 245
        cellContentHolder.addEventListener("click", function(){                                                     // 246
            if (cell.isMagnified){                                                                                  // 247
                cell.demagnify();                                                                                   // 248
                                                                                                                    // 249
            }                                                                                                       // 250
            else{                                                                                                   // 251
                demagnifyAllCellsBut(cell.cellIndex);                                                               // 252
                cell.magnify();                                                                                     // 253
            }                                                                                                       // 254
        });                                                                                                         // 255
                                                                                                                    // 256
        cellBottomButton.addEventListener("click", function(e){cellData.cellBottomButtonFunction(); e.stopPropagation()});
        /*cellBottomButton.onclick=function(){alert("clicked button"); return null;}*/                              // 258
        return cell;                                                                                                // 259
    }/*end createCell*/                                                                                             // 260
                                                                                                                    // 261
    function appendCells(pageData){                                                                                 // 262
        cells=[];                                                                                                   // 263
        var cell;                                                                                                   // 264
        for(var i = 0; i<pageData.length; i++){                                                                     // 265
            if(0 <= i && i<7){                                                                                      // 266
                cell = createCell(cellCentersOffsetsFromTop[0], cellCentersOffsetsFromLeftOddRows[i], pageData[i]); // 267
                cell.cellIndex = i;                                                                                 // 268
                cells.push(cell);                                                                                   // 269
                /*honeycombContainer.appendChild(cell);*/                                                           // 270
            }                                                                                                       // 271
            if(7 <= i && i < 13){                                                                                   // 272
                cell = createCell(cellCentersOffsetsFromTop[1], cellCentersOffsetsFromLeftEvenRows[i - 7], pageData[i]);
                cell.cellIndex = i;                                                                                 // 274
                cells.push(cell);                                                                                   // 275
                /*honeycombContainer.appendChild(cell);*/                                                           // 276
            }                                                                                                       // 277
            if(13 <= i && i<20){                                                                                    // 278
                cell = createCell(cellCentersOffsetsFromTop[2], cellCentersOffsetsFromLeftOddRows[i - 13], pageData[i]);
                cell.cellIndex = i;                                                                                 // 280
                cells.push(cell);                                                                                   // 281
                /*honeycombContainer.appendChild(cell);	*/                                                          // 282
            }                                                                                                       // 283
        }                                                                                                           // 284
    }/*end appendCells*/                                                                                            // 285
                                                                                                                    // 286
    function renderCells(){                                                                                         // 287
        for (var i = 0; i<cells.length; i++){                                                                       // 288
            honeycombContainer.appendChild(cells[i]);                                                               // 289
        }                                                                                                           // 290
    };	/*end renderCells*/                                                                                          // 291
                                                                                                                    // 292
    function demagnifyAllCellsBut(cellIndex){                                                                       // 293
        for (var i = 0; i<cells.length; i++){                                                                       // 294
            if(i == cellIndex){                                                                                     // 295
                                                                                                                    // 296
            }                                                                                                       // 297
            else{                                                                                                   // 298
                cells[i].demagnify();                                                                               // 299
            }                                                                                                       // 300
        }                                                                                                           // 301
    }/*end demagnifyAllCellsBut*/                                                                                   // 302
                                                                                                                    // 303
                                                                                                                    // 304
    return honeycomb;                                                                                               // 305
                                                                                                                    // 306
})();                                                                                                               // 307
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/client/router.js                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by Serge on 10/13/2015.                                                                                  // 2
 */                                                                                                                 // 3
                                                                                                                    // 4
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/client/controller.js                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by Serge on 10/13/2015.                                                                                  // 2
 */                                                                                                                 // 3
var a = 5; var b = 6;                                                                                               // 4
function generateDataSample(){                                                                                      // 5
    var result =[];                                                                                                 // 6
    var imgIndex = 0;                                                                                               // 7
    for (var i = 0; i < 120; i++){                                                                                  // 8
                                                                                                                    // 9
        var item = {};                                                                                              // 10
        item.topText = i + "ft";                                                                                    // 11
        item.headerText = "I want to ride my bycicle i want to ride my bike, I want to ride my bycicle I want to ride it where i like" + i;
        item.bodyText = "I want to ride my bycicle i want to ride my bike, I want to ride my bycicle I want to ride it where i like" + i;
        item.buttonText = "Button " + i;                                                                            // 14
                                                                                                                    // 15
        item.backgroundImageUrl = "img/" + imgIndex + ".jpg";                                                       // 16
        imgIndex++; if (imgIndex>2){imgIndex = 0};                                                                  // 17
                                                                                                                    // 18
        item.cellBottomButtonFunction = function(){alert("meow!")}                                                  // 19
        result.push(item);                                                                                          // 20
    }                                                                                                               // 21
    return result;                                                                                                  // 22
}                                                                                                                   // 23
initHoneyComb = function(){                                                                                         // 24
    var insertHoneycombHere = document.getElementById("honeycomb-placeholder");                                     // 25
    var sampleData = generateDataSample();                                                                          // 26
    honeycomb.createHoneycomb(insertHoneycombHere, sampleData);                                                     // 27
}                                                                                                                   // 28
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/client/models.js                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by Serge on 10/13/2015.                                                                                  // 2
 */                                                                                                                 // 3
                                                                                                                    // 4
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/client/browser/app.js                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by Ashot on 9/8/15.                                                                                      // 2
 */                                                                                                                 // 3
if (Meteor.isClient) {                                                                                              // 4
  //angular.module('socially',['angular-meteor']);                                                                  // 5
}                                                                                                                   // 6
Meteor.startup(function () {                                                                                        // 7
  angular.module('myModule', ['angular-meteor'])                                                                    // 8
});                                                                                                                 // 9
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/user.ng.html.js                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
angular.module('angular-meteor').run(['$templateCache', function($templateCache) {$templateCache.put("arutune_bz-control-honeycomb_user.ng.html", "<div> <label>Name:</label> <input type=\"text\" ng-model=\"yourName\" placeholder=\"Enter a name here\"> <h1>Hello {{yourName}}!</h1> </div>");}]);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/client/browser/template.honeycomb.js                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
                                                                                                                    // 1
Template.__checkName("bzControlHoneycomb");                                                                         // 2
Template["bzControlHoneycomb"] = new Template("Template.bzControlHoneycomb", (function() {                          // 3
  var view = this;                                                                                                  // 4
  return HTML.Raw('<div id="honeycomb-placeholder"></div>');                                                        // 5
}));                                                                                                                // 6
                                                                                                                    // 7
Template.__checkName("bzControlHoneycombOld");                                                                      // 8
Template["bzControlHoneycombOld"] = new Template("Template.bzControlHoneycombOld", (function() {                    // 9
  var view = this;                                                                                                  // 10
  return [ HTML.Raw('<!--<div id="myModule">\n    &lt;!&ndash;<label>Name:</label>\n    <input type="text" ng-model="yourName" placeholder="Enter a name here">\n\n    <h1>Hello {{yourName}}!</h1>&ndash;&gt;\n\n    <ng-include src="\'user.ng.html\'"></ng-include>\n  </div>-->\n\n\n  '), HTML.DIV({
    "class": "honeycomb-container"                                                                                  // 12
  }, "\n\n    ", HTML.DIV({                                                                                         // 13
    "class": "cell-wrap",                                                                                           // 14
    style: "top:35px; left:10px;"                                                                                   // 15
  }, "\n      ", HTML.DIV({                                                                                         // 16
    "class": "red-rect"                                                                                             // 17
  }, "\n        ", HTML.DIV({                                                                                       // 18
    "class": "green-rect"                                                                                           // 19
  }, "\n          ", HTML.DIV({                                                                                     // 20
    "class": "blue-rect"                                                                                            // 21
  }, "\n            ", HTML.DIV({                                                                                   // 22
    "class": "pink-rect",                                                                                           // 23
    style: function() {                                                                                             // 24
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 25
    }                                                                                                               // 26
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 28
    style: "top:35px; left:143px;"                                                                                  // 29
  }, "\n      ", HTML.DIV({                                                                                         // 30
    "class": "red-rect"                                                                                             // 31
  }, "\n        ", HTML.DIV({                                                                                       // 32
    "class": "green-rect"                                                                                           // 33
  }, "\n          ", HTML.DIV({                                                                                     // 34
    "class": "blue-rect"                                                                                            // 35
  }, "\n            ", HTML.DIV({                                                                                   // 36
    "class": "pink-rect",                                                                                           // 37
    style: function() {                                                                                             // 38
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 39
    }                                                                                                               // 40
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 42
    style: "top:35px; left:276px;"                                                                                  // 43
  }, "\n      ", HTML.DIV({                                                                                         // 44
    "class": "red-rect"                                                                                             // 45
  }, "\n        ", HTML.DIV({                                                                                       // 46
    "class": "green-rect"                                                                                           // 47
  }, "\n          ", HTML.DIV({                                                                                     // 48
    "class": "blue-rect"                                                                                            // 49
  }, "\n            ", HTML.DIV({                                                                                   // 50
    "class": "pink-rect",                                                                                           // 51
    style: function() {                                                                                             // 52
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 53
    }                                                                                                               // 54
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 56
    style: "top:35px; left:409px;"                                                                                  // 57
  }, "\n      ", HTML.DIV({                                                                                         // 58
    "class": "red-rect"                                                                                             // 59
  }, "\n        ", HTML.DIV({                                                                                       // 60
    "class": "green-rect"                                                                                           // 61
  }, "\n          ", HTML.DIV({                                                                                     // 62
    "class": "blue-rect"                                                                                            // 63
  }, "\n            ", HTML.DIV({                                                                                   // 64
    "class": "pink-rect",                                                                                           // 65
    style: function() {                                                                                             // 66
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 67
    }                                                                                                               // 68
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 70
    style: "top:35px; left:542px;"                                                                                  // 71
  }, "\n      ", HTML.DIV({                                                                                         // 72
    "class": "red-rect"                                                                                             // 73
  }, "\n        ", HTML.DIV({                                                                                       // 74
    "class": "green-rect"                                                                                           // 75
  }, "\n          ", HTML.DIV({                                                                                     // 76
    "class": "blue-rect"                                                                                            // 77
  }, "\n            ", HTML.DIV({                                                                                   // 78
    "class": "pink-rect",                                                                                           // 79
    style: function() {                                                                                             // 80
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 81
    }                                                                                                               // 82
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 84
    style: "top:35px; left:675px;"                                                                                  // 85
  }, "\n      ", HTML.DIV({                                                                                         // 86
    "class": "red-rect"                                                                                             // 87
  }, "\n        ", HTML.DIV({                                                                                       // 88
    "class": "green-rect"                                                                                           // 89
  }, "\n          ", HTML.DIV({                                                                                     // 90
    "class": "blue-rect"                                                                                            // 91
  }, "\n            ", HTML.DIV({                                                                                   // 92
    "class": "pink-rect",                                                                                           // 93
    style: function() {                                                                                             // 94
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 95
    }                                                                                                               // 96
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 98
    style: "top:35px; left:808px;"                                                                                  // 99
  }, "\n      ", HTML.DIV({                                                                                         // 100
    "class": "red-rect"                                                                                             // 101
  }, "\n        ", HTML.DIV({                                                                                       // 102
    "class": "green-rect"                                                                                           // 103
  }, "\n          ", HTML.DIV({                                                                                     // 104
    "class": "blue-rect"                                                                                            // 105
  }, "\n            ", HTML.DIV({                                                                                   // 106
    "class": "pink-rect",                                                                                           // 107
    style: function() {                                                                                             // 108
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 109
    }                                                                                                               // 110
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n    ", HTML.Raw("<!--end first line-->"), "\n\n\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 112
    style: "top:150px; left:76px;"                                                                                  // 113
  }, "\n      ", HTML.DIV({                                                                                         // 114
    "class": "red-rect"                                                                                             // 115
  }, "\n        ", HTML.DIV({                                                                                       // 116
    "class": "green-rect"                                                                                           // 117
  }, "\n          ", HTML.DIV({                                                                                     // 118
    "class": "blue-rect"                                                                                            // 119
  }, "\n            ", HTML.DIV({                                                                                   // 120
    "class": "pink-rect",                                                                                           // 121
    style: function() {                                                                                             // 122
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 123
    }                                                                                                               // 124
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 126
    style: "top:150px; left:209px;"                                                                                 // 127
  }, "\n      ", HTML.DIV({                                                                                         // 128
    "class": "red-rect"                                                                                             // 129
  }, "\n        ", HTML.DIV({                                                                                       // 130
    "class": "green-rect"                                                                                           // 131
  }, "\n          ", HTML.DIV({                                                                                     // 132
    "class": "blue-rect"                                                                                            // 133
  }, "\n            ", HTML.DIV({                                                                                   // 134
    "class": "pink-rect",                                                                                           // 135
    style: function() {                                                                                             // 136
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 137
    }                                                                                                               // 138
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 140
    style: "top:150px; left:342px;"                                                                                 // 141
  }, "\n      ", HTML.DIV({                                                                                         // 142
    "class": "red-rect"                                                                                             // 143
  }, "\n        ", HTML.DIV({                                                                                       // 144
    "class": "green-rect"                                                                                           // 145
  }, "\n          ", HTML.DIV({                                                                                     // 146
    "class": "blue-rect"                                                                                            // 147
  }, "\n            ", HTML.DIV({                                                                                   // 148
    "class": "pink-rect",                                                                                           // 149
    style: function() {                                                                                             // 150
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 151
    }                                                                                                               // 152
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 154
    style: "top:150px; left:475px;"                                                                                 // 155
  }, "\n      ", HTML.DIV({                                                                                         // 156
    "class": "red-rect"                                                                                             // 157
  }, "\n        ", HTML.DIV({                                                                                       // 158
    "class": "green-rect"                                                                                           // 159
  }, "\n          ", HTML.DIV({                                                                                     // 160
    "class": "blue-rect"                                                                                            // 161
  }, "\n            ", HTML.DIV({                                                                                   // 162
    "class": "pink-rect",                                                                                           // 163
    style: function() {                                                                                             // 164
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 165
    }                                                                                                               // 166
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 168
    style: "top:150px; left:608px;"                                                                                 // 169
  }, "\n      ", HTML.DIV({                                                                                         // 170
    "class": "red-rect"                                                                                             // 171
  }, "\n        ", HTML.DIV({                                                                                       // 172
    "class": "green-rect"                                                                                           // 173
  }, "\n          ", HTML.DIV({                                                                                     // 174
    "class": "blue-rect"                                                                                            // 175
  }, "\n            ", HTML.DIV({                                                                                   // 176
    "class": "pink-rect",                                                                                           // 177
    style: function() {                                                                                             // 178
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 179
    }                                                                                                               // 180
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 182
    style: "top:150px; left:741px;"                                                                                 // 183
  }, "\n      ", HTML.DIV({                                                                                         // 184
    "class": "red-rect"                                                                                             // 185
  }, "\n        ", HTML.DIV({                                                                                       // 186
    "class": "green-rect"                                                                                           // 187
  }, "\n          ", HTML.DIV({                                                                                     // 188
    "class": "blue-rect"                                                                                            // 189
  }, "\n            ", HTML.DIV({                                                                                   // 190
    "class": "pink-rect",                                                                                           // 191
    style: function() {                                                                                             // 192
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 193
    }                                                                                                               // 194
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n    ", HTML.Raw("<!--end second line-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 196
    style: "top:265px; left:10px;"                                                                                  // 197
  }, "\n      ", HTML.DIV({                                                                                         // 198
    "class": "red-rect"                                                                                             // 199
  }, "\n        ", HTML.DIV({                                                                                       // 200
    "class": "green-rect"                                                                                           // 201
  }, "\n          ", HTML.DIV({                                                                                     // 202
    "class": "blue-rect"                                                                                            // 203
  }, "\n            ", HTML.DIV({                                                                                   // 204
    "class": "pink-rect",                                                                                           // 205
    style: function() {                                                                                             // 206
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 207
    }                                                                                                               // 208
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 210
    style: "top:265px; left:143px;"                                                                                 // 211
  }, "\n      ", HTML.DIV({                                                                                         // 212
    "class": "red-rect"                                                                                             // 213
  }, "\n        ", HTML.DIV({                                                                                       // 214
    "class": "green-rect"                                                                                           // 215
  }, "\n          ", HTML.DIV({                                                                                     // 216
    "class": "blue-rect"                                                                                            // 217
  }, "\n            ", HTML.DIV({                                                                                   // 218
    "class": "pink-rect",                                                                                           // 219
    style: function() {                                                                                             // 220
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 221
    }                                                                                                               // 222
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 224
    style: "top:265px; left:276px;"                                                                                 // 225
  }, "\n      ", HTML.DIV({                                                                                         // 226
    "class": "red-rect"                                                                                             // 227
  }, "\n        ", HTML.DIV({                                                                                       // 228
    "class": "green-rect"                                                                                           // 229
  }, "\n          ", HTML.DIV({                                                                                     // 230
    "class": "blue-rect"                                                                                            // 231
  }, "\n            ", HTML.DIV({                                                                                   // 232
    "class": "pink-rect",                                                                                           // 233
    style: function() {                                                                                             // 234
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 235
    }                                                                                                               // 236
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 238
    style: "top:265px; left:409px;"                                                                                 // 239
  }, "\n      ", HTML.DIV({                                                                                         // 240
    "class": "red-rect"                                                                                             // 241
  }, "\n        ", HTML.DIV({                                                                                       // 242
    "class": "green-rect"                                                                                           // 243
  }, "\n          ", HTML.DIV({                                                                                     // 244
    "class": "blue-rect"                                                                                            // 245
  }, "\n            ", HTML.DIV({                                                                                   // 246
    "class": "pink-rect",                                                                                           // 247
    style: function() {                                                                                             // 248
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 249
    }                                                                                                               // 250
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 252
    style: "top:265px; left:542px;"                                                                                 // 253
  }, "\n      ", HTML.DIV({                                                                                         // 254
    "class": "red-rect"                                                                                             // 255
  }, "\n        ", HTML.DIV({                                                                                       // 256
    "class": "green-rect"                                                                                           // 257
  }, "\n          ", HTML.DIV({                                                                                     // 258
    "class": "blue-rect"                                                                                            // 259
  }, "\n            ", HTML.DIV({                                                                                   // 260
    "class": "pink-rect",                                                                                           // 261
    style: function() {                                                                                             // 262
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 263
    }                                                                                                               // 264
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 266
    style: "top:265px; left:675px;"                                                                                 // 267
  }, "\n      ", HTML.DIV({                                                                                         // 268
    "class": "red-rect"                                                                                             // 269
  }, "\n        ", HTML.DIV({                                                                                       // 270
    "class": "green-rect"                                                                                           // 271
  }, "\n          ", HTML.DIV({                                                                                     // 272
    "class": "blue-rect"                                                                                            // 273
  }, "\n            ", HTML.DIV({                                                                                   // 274
    "class": "pink-rect",                                                                                           // 275
    style: function() {                                                                                             // 276
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 277
    }                                                                                                               // 278
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n    ", HTML.DIV({
    "class": "cell-wrap",                                                                                           // 280
    style: "top:265px; left:808px;"                                                                                 // 281
  }, "\n      ", HTML.DIV({                                                                                         // 282
    "class": "red-rect"                                                                                             // 283
  }, "\n        ", HTML.DIV({                                                                                       // 284
    "class": "green-rect"                                                                                           // 285
  }, "\n          ", HTML.DIV({                                                                                     // 286
    "class": "blue-rect"                                                                                            // 287
  }, "\n            ", HTML.DIV({                                                                                   // 288
    "class": "pink-rect",                                                                                           // 289
    style: function() {                                                                                             // 290
      return [ "background-image: url('", Spacebars.mustache(view.lookup("getPostImg")), "');" ];                   // 291
    }                                                                                                               // 292
  }, "\n              ", HTML.Raw('<div class="cell-top-nav">200ft</div>'), "\n              ", HTML.Raw('<div class="cell-text-header">Header</div>'), "\n              ", HTML.Raw('<div class="cell-text-body">Hello Hello Hello! Check Check Chek Check! Hello Hello Hello Hello! Check Check Check!</div>'), "\n              ", HTML.Raw('<div class="cell-bottom-button">Button</div>'), "\n            "), "\n          "), "\n        "), "\n      "), "\n    "), HTML.Raw("<!--end cell-->"), "\n\n  ") ];
}));                                                                                                                // 294
                                                                                                                    // 295
Template.__checkName("bzControlHoneycombItem");                                                                     // 296
Template["bzControlHoneycombItem"] = new Template("Template.bzControlHoneycombItem", (function() {                  // 297
  var view = this;                                                                                                  // 298
  return "";                                                                                                        // 299
}));                                                                                                                // 300
                                                                                                                    // 301
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arutune:bz-control-honeycomb/client/browser/honeycomb.js                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Created by Ashot on 9/8/15.                                                                                      // 2
 */                                                                                                                 // 3
Template.bzControlHoneycomb.onRendered(function(){                                                                  // 4
   initHoneyComb();                                                                                                 // 5
});                                                                                                                 // 6
Template.bzControlHoneycombOld.helpers({                                                                            // 7
  getPostImg: function(){                                                                                           // 8
                                                                                                                    // 9
    return bz.const.randomImageSite + '?ts=' + Date.now();                                                          // 10
  }                                                                                                                 // 11
})                                                                                                                  // 12
Template.bzControlHoneycombOld.rendered = function () {                                                             // 13
  //ng-app="socially"                                                                                               // 14
  //angular.module('socially',['angular-meteor']);                                                                  // 15
  var element  = $('#myModule');                                                                                    // 16
  //if(!element.hasClass('ng-scope')) {                                                                             // 17
    angular.module('myModule', ['angular-meteor']);                                                                 // 18
    angular.bootstrap(element[0], ['myModule']);                                                                    // 19
  //}                                                                                                               // 20
}                                                                                                                   // 21
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
