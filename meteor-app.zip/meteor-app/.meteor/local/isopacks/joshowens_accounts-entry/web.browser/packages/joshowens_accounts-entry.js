(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signIn/template.signIn.js                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySignIn");                                                                                  // 2
Template["entrySignIn"] = new Template("Template.entrySignIn", (function() {                                          // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "page-wrapper-auth tmpl-background"                                                                      // 6
  }, "\n    ", HTML.DIV({                                                                                             // 7
    "class": ""                                                                                                       // 8
  }, "\n      ", HTML.DIV({                                                                                           // 9
    "class": "wrapper-auth"                                                                                           // 10
  }, "\n        ", Blaze.If(function() {                                                                              // 11
    return Spacebars.call(view.lookup("logo"));                                                                       // 12
  }, function() {                                                                                                     // 13
    return [ "\n          ", HTML.DIV({                                                                               // 14
      "class": "entry-logo"                                                                                           // 15
    }, "\n            ", HTML.A({                                                                                     // 16
      href: "/"                                                                                                       // 17
    }, HTML.IMG({                                                                                                     // 18
      src: function() {                                                                                               // 19
        return Spacebars.mustache(view.lookup("logo"));                                                               // 20
      },                                                                                                              // 21
      alt: "logo"                                                                                                     // 22
    })), "\n          "), "\n        " ];                                                                             // 23
  }, function() {                                                                                                     // 24
    return [ "\n          ", HTML.H1({                                                                                // 25
      "class": "title-auth"                                                                                           // 26
    }, "Fantasia"), "\n\n          ", HTML.P({                                                                        // 27
      "class": "subtitle-auth"                                                                                        // 28
    }, "emotional chat"), "\n        " ];                                                                             // 29
  }), "\n\n        ", HTML.DIV({                                                                                      // 30
    "class": ""                                                                                                       // 31
  }, "\n          ", Blaze.If(function() {                                                                            // 32
    return Spacebars.call(view.lookup("otherLoginServices"));                                                         // 33
  }, function() {                                                                                                     // 34
    return [ "\n            ", HTML.DIV({                                                                             // 35
      "class": "entry-social"                                                                                         // 36
    }, "\n              ", Blaze.Each(function() {                                                                    // 37
      return Spacebars.call(view.lookup("loginServices"));                                                            // 38
    }, function() {                                                                                                   // 39
      return [ "\n                ", Spacebars.include(view.lookupTemplate("entrySocial")), "\n              " ];     // 40
    }), "\n              ", Blaze.If(function() {                                                                     // 41
      return Spacebars.call(view.lookup("passwordLoginService"));                                                     // 42
    }, function() {                                                                                                   // 43
      return [ "\n                ", HTML.DIV({                                                                       // 44
        "class": "email-option"                                                                                       // 45
      }, "\n                  ", HTML.STRONG({                                                                        // 46
        "class": "line-thru or-sign-in"                                                                               // 47
      }, Blaze.View("lookup:t9n", function() {                                                                        // 48
        return Spacebars.mustache(view.lookup("t9n"), "OR");                                                          // 49
      })), "\n                "), "\n              " ];                                                               // 50
    }), "\n            "), "\n          " ];                                                                          // 51
  }), "\n          ", Spacebars.include(view.lookupTemplate("entryError")), "\n          ", Blaze.Unless(function() { // 52
    return Spacebars.call(view.lookup("otherLoginServices"));                                                         // 53
  }, function() {                                                                                                     // 54
    return [ "\n            ", HTML.DIV({                                                                             // 55
      "class": "email-option"                                                                                         // 56
    }, "\n              ", HTML.H3(Blaze.View("lookup:t9n", function() {                                              // 57
      return Spacebars.mustache(view.lookup("t9n"), "signIn");                                                        // 58
    })), "\n            "), "\n          " ];                                                                         // 59
  }), "\n\n          ", Blaze.If(function() {                                                                         // 60
    return Spacebars.call(view.lookup("passwordLoginService"));                                                       // 61
  }, function() {                                                                                                     // 62
    return [ "\n              \n            ", HTML.FORM({                                                            // 63
      "class": "entry-form",                                                                                          // 64
      id: "signIn",                                                                                                   // 65
      "data-abide": ""                                                                                                // 66
    }, "\n\n              ", HTML.DIV({                                                                               // 67
      "class": "form-group"                                                                                           // 68
    }, "\n                ", HTML.DIV({                                                                               // 69
      "class": "input-symbol"                                                                                         // 70
    }, "\n                  ", HTML.INPUT({                                                                           // 71
      autofocus: "",                                                                                                  // 72
      name: "email",                                                                                                  // 73
      type: function() {                                                                                              // 74
        return Spacebars.mustache(view.lookup("emailInputType"));                                                     // 75
      },                                                                                                              // 76
      "class": "form-control",                                                                                        // 77
      value: function() {                                                                                             // 78
        return Spacebars.mustache(view.lookup("email"));                                                              // 79
      },                                                                                                              // 80
      placeholder: function() {                                                                                       // 81
        return Spacebars.mustache(view.lookup("emailPlaceholder"));                                                   // 82
      },                                                                                                              // 83
      autocapitalize: "none",                                                                                         // 84
      autocomplete: "off",                                                                                            // 85
      autocorrect: "off",                                                                                             // 86
      required: ""                                                                                                    // 87
    }), "\n                    ", HTML.SMALL({                                                                        // 88
      "class": "error"                                                                                                // 89
    }, "A valid email address or username is required"), "\n                    \n                "), "\n              "), "\n\n              ", HTML.DIV({
      "class": "form-group"                                                                                           // 91
    }, "\n                ", HTML.DIV({                                                                               // 92
      "class": "input-symbol"                                                                                         // 93
    }, "\n                  ", HTML.INPUT({                                                                           // 94
      name: "password",                                                                                               // 95
      type: "password",                                                                                               // 96
      "class": "form-control",                                                                                        // 97
      value: function() {                                                                                             // 98
        return Spacebars.mustache(view.lookup("password"));                                                           // 99
      },                                                                                                              // 100
      placeholder: function() {                                                                                       // 101
        return Spacebars.mustache(view.lookup("t9n"), "password");                                                    // 102
      },                                                                                                              // 103
      required: ""                                                                                                    // 104
    }), "\n                    ", HTML.SMALL({                                                                        // 105
      "class": "error"                                                                                                // 106
    }, "Your password must match the requirements"), "\n                "), "\n              "), "\n\n              ", Blaze.Unless(function() {
      return Spacebars.call(view.lookup("isUsernameOnly"));                                                           // 108
    }, function() {                                                                                                   // 109
      return [ "\n                ", HTML.P(HTML.A({                                                                  // 110
        href: function() {                                                                                            // 111
          return Spacebars.mustache(view.lookup("pathFor"), "entryForgotPassword");                                   // 112
        }                                                                                                             // 113
      }, Blaze.View("lookup:t9n", function() {                                                                        // 114
        return Spacebars.mustache(view.lookup("t9n"), "forgotPassword");                                              // 115
      }))), "\n                ", HTML.BUTTON({                                                                       // 116
        type: "submit",                                                                                               // 117
        "class": "submit btn btn-primary"                                                                             // 118
      }, Blaze.View("lookup:t9n", function() {                                                                        // 119
        return Spacebars.mustache(view.lookup("t9n"), "signIn");                                                      // 120
      })), "\n              " ];                                                                                      // 121
    }), "\n\n            "), "\n          " ];                                                                        // 122
  }), "\n\n          ", Blaze.If(function() {                                                                         // 123
    return Spacebars.call(view.lookup("showCreateAccountLink"));                                                      // 124
  }, function() {                                                                                                     // 125
    return [ "\n            ", HTML.P({                                                                               // 126
      "class": "entry-signup-cta"                                                                                     // 127
    }, Blaze.View("lookup:t9n", function() {                                                                          // 128
      return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                             // 129
    }), " ", HTML.A({                                                                                                 // 130
      href: function() {                                                                                              // 131
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignUp");                                             // 132
      }                                                                                                               // 133
    }, Blaze.View("lookup:t9n", function() {                                                                          // 134
      return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                        // 135
    }))), "\n          " ];                                                                                           // 136
  }), "\n            \n          ", HTML.Raw("<!--{{> socialButtons}}-->"), "\n            \n          ", Blaze.If(function() {
    return Spacebars.call(view.lookup("talkingToServer"));                                                            // 138
  }, function() {                                                                                                     // 139
    return [ "\n            ", Spacebars.include(view.lookupTemplate("spinner")), "\n          " ];                   // 140
  }), "\n            \n        "), "\n      "), "\n    "), "\n  ");                                                   // 141
}));                                                                                                                  // 142
                                                                                                                      // 143
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/template.signUp.js                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySignUp");                                                                                  // 2
Template["entrySignUp"] = new Template("Template.entrySignUp", (function() {                                          // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "page-wrapper-auth tmpl-background"                                                                      // 6
  }, "\n                    ", HTML.DIV({                                                                             // 7
    "class": ""                                                                                                       // 8
  }, "\n                        ", HTML.DIV({                                                                         // 9
    "class": "wrapper-auth"                                                                                           // 10
  }, "\n                            ", Blaze.If(function() {                                                          // 11
    return Spacebars.call(view.lookup("logo"));                                                                       // 12
  }, function() {                                                                                                     // 13
    return [ "\n                                ", HTML.DIV({                                                         // 14
      "class": "entry-logo"                                                                                           // 15
    }, "\n                                    ", HTML.A({                                                             // 16
      href: "/"                                                                                                       // 17
    }, HTML.IMG({                                                                                                     // 18
      src: function() {                                                                                               // 19
        return Spacebars.mustache(view.lookup("logo"));                                                               // 20
      },                                                                                                              // 21
      alt: "logo"                                                                                                     // 22
    })), "\n                                "), "\n                            " ];                                   // 23
  }, function() {                                                                                                     // 24
    return [ "\n                                ", HTML.H1({                                                          // 25
      "class": "title-auth"                                                                                           // 26
    }, "Fantasia"), "\n                                ", HTML.P({                                                    // 27
      "class": "subtitle-auth"                                                                                        // 28
    }, "emotional chat"), "\n                            " ];                                                         // 29
  }), "\n\n                                ", HTML.DIV({                                                              // 30
    "class": "create-account-option"                                                                                  // 31
  }, "\n                                    ", HTML.H3(Blaze.View("lookup:t9n", function() {                          // 32
    return Spacebars.mustache(view.lookup("t9n"), "createAccount");                                                   // 33
  })), "\n                                ", Blaze.If(function() {                                                    // 34
    return Spacebars.call(view.lookup("otherLoginServices"));                                                         // 35
  }, function() {                                                                                                     // 36
    return [ "\n                                  ", HTML.P({                                                         // 37
      "class": "entry-signin-cta"                                                                                     // 38
    }, Blaze.View("lookup:t9n", function() {                                                                          // 39
      return Spacebars.mustache(view.lookup("t9n"), "ifYouAlreadyHaveAnAccount");                                     // 40
    }), " ", HTML.A({                                                                                                 // 41
      href: function() {                                                                                              // 42
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignIn");                                             // 43
      }                                                                                                               // 44
    }, Blaze.View("lookup:t9n", function() {                                                                          // 45
      return Spacebars.mustache(view.lookup("t9n"), "signin");                                                        // 46
    })), "."), "\n                                  ", HTML.DIV({                                                     // 47
      "class": "entry-social"                                                                                         // 48
    }, "\n                                    ", Blaze.Each(function() {                                              // 49
      return Spacebars.call(view.lookup("loginServices"));                                                            // 50
    }, function() {                                                                                                   // 51
      return [ "\n                                      ", Spacebars.include(view.lookupTemplate("entrySocial")), "\n                                    " ];
    }), "\n                                    ", Blaze.If(function() {                                               // 53
      return Spacebars.call(view.lookup("passwordLoginService"));                                                     // 54
    }, function() {                                                                                                   // 55
      return [ "\n                                      ", HTML.DIV({                                                 // 56
        "class": "email-option"                                                                                       // 57
      }, "\n                                        ", HTML.STRONG({                                                  // 58
        "class": "line-thru"                                                                                          // 59
      }, Blaze.View("lookup:t9n", function() {                                                                        // 60
        return Spacebars.mustache(view.lookup("t9n"), "OR");                                                          // 61
      })), "\n                                        ", HTML.A({                                                     // 62
        "data-toggle": "collapse",                                                                                    // 63
        href: "#signUp"                                                                                               // 64
      }, "\n                                          ", Blaze.View("lookup:t9n", function() {                        // 65
        return Spacebars.mustache(view.lookup("t9n"), "signUpWithYourEmailAddress");                                  // 66
      }), "\n                                        "), "\n                                      "), "\n                                    " ];
    }), "\n                                  "), "\n                                " ];                              // 68
  }, function() {                                                                                                     // 69
    return [ "\n                                    ", HTML.P({                                                       // 70
      "class": "entry-signin-cta"                                                                                     // 71
    }, Blaze.View("lookup:t9n", function() {                                                                          // 72
      return Spacebars.mustache(view.lookup("t9n"), "ifYouAlreadyHaveAnAccount");                                     // 73
    }), " ", HTML.A({                                                                                                 // 74
      href: function() {                                                                                              // 75
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignIn");                                             // 76
      }                                                                                                               // 77
    }, Blaze.View("lookup:t9n", function() {                                                                          // 78
      return Spacebars.mustache(view.lookup("t9n"), "signin");                                                        // 79
    })), "."), "\n                                " ];                                                                // 80
  }), "\n                                ", Spacebars.include(view.lookupTemplate("entryError")), "\n                                ", Blaze.If(function() {
    return Spacebars.call(view.lookup("passwordLoginService"));                                                       // 82
  }, function() {                                                                                                     // 83
    return [ "\n                                  ", HTML.FORM({                                                      // 84
      "class": function() {                                                                                           // 85
        return [ "entry-form ", Spacebars.mustache(view.lookup("signupClass")) ];                                     // 86
      },                                                                                                              // 87
      id: "signUp",                                                                                                   // 88
      "data-abide": ""                                                                                                // 89
    }, "\n                                    ", Blaze.If(function() {                                                // 90
      return Spacebars.call(view.lookup("showUsername"));                                                             // 91
    }, function() {                                                                                                   // 92
      return [ "\n                                        \n                                      ", HTML.DIV({       // 93
        "class": "form-group"                                                                                         // 94
      }, "\n                                        ", HTML.DIV({                                                     // 95
        "class": "input-symbol"                                                                                       // 96
      }, "\n                                         ", HTML.INPUT({                                                  // 97
        autofocus: "",                                                                                                // 98
        name: "username",                                                                                             // 99
        placeholder: function() {                                                                                     // 100
          return Spacebars.mustache(view.lookup("t9n"), "username");                                                  // 101
        },                                                                                                            // 102
        type: "string",                                                                                               // 103
        "class": "form-control",                                                                                      // 104
        value: "",                                                                                                    // 105
        autocapitalize: "none",                                                                                       // 106
        autocomplete: "off",                                                                                          // 107
        autocorrect: "off",                                                                                           // 108
        required: ""                                                                                                  // 109
      }), "\n                                         ", HTML.SMALL({                                                 // 110
        "class": "error"                                                                                              // 111
      }, "A valid username is required"), "\n                                        "), "\n                                      "), "\n                                        \n                                    " ];
    }), "\n                        \n                                    ", Blaze.If(function() {                     // 113
      return Spacebars.call(view.lookup("showEmail"));                                                                // 114
    }, function() {                                                                                                   // 115
      return [ "\n                                        \n                                      ", HTML.DIV({       // 116
        "class": "form-group"                                                                                         // 117
      }, "\n                                        ", Blaze.If(function() {                                          // 118
        return Spacebars.call(view.lookup("showUsername"));                                                           // 119
      }, function() {                                                                                                 // 120
        return [ "\n                                            ", HTML.DIV({                                         // 121
          "class": "input-symbol"                                                                                     // 122
        }, "\n                                              ", HTML.INPUT({                                           // 123
          type: "email",                                                                                              // 124
          placeholder: function() {                                                                                   // 125
            return Spacebars.mustache(view.lookup("t9n"), "emailAddress");                                            // 126
          },                                                                                                          // 127
          "class": "form-control",                                                                                    // 128
          value: function() {                                                                                         // 129
            return Spacebars.mustache(view.lookup("emailAddress"));                                                   // 130
          },                                                                                                          // 131
          autocapitalize: "none",                                                                                     // 132
          autocomplete: "off",                                                                                        // 133
          autocorrect: "off",                                                                                         // 134
          required: ""                                                                                                // 135
        }), "\n                                                ", HTML.SMALL({                                        // 136
          "class": "error"                                                                                            // 137
        }, "A valid email address is required"), "\n                                            "), "\n                                        " ];
      }, function() {                                                                                                 // 139
        return [ "\n                                          ", HTML.INPUT({                                         // 140
          autofocus: "",                                                                                              // 141
          type: "email",                                                                                              // 142
          placeholder: function() {                                                                                   // 143
            return Spacebars.mustache(view.lookup("t9n"), "emailAddress");                                            // 144
          },                                                                                                          // 145
          "class": "form-control",                                                                                    // 146
          value: function() {                                                                                         // 147
            return Spacebars.mustache(view.lookup("emailAddress"));                                                   // 148
          },                                                                                                          // 149
          autocapitalize: "none",                                                                                     // 150
          autocomplete: "off",                                                                                        // 151
          autocorrect: "off",                                                                                         // 152
          required: ""                                                                                                // 153
        }), "\n                                            ", HTML.SMALL({                                            // 154
          "class": "error"                                                                                            // 155
        }, "A valid email address is required"), "\n                                        " ];                      // 156
      }), "\n                                      "), "\n                                    " ];                    // 157
    }), "\n                        \n                                    ", HTML.DIV({                                // 158
      "class": "form-group"                                                                                           // 159
    }, "\n                                       ", HTML.DIV({                                                        // 160
      "class": "input-symbol"                                                                                         // 161
    }, "\n                                           ", HTML.INPUT({                                                  // 162
      type: "password",                                                                                               // 163
      placeholder: function() {                                                                                       // 164
        return Spacebars.mustache(view.lookup("t9n"), "password");                                                    // 165
      },                                                                                                              // 166
      "class": "form-control",                                                                                        // 167
      value: "",                                                                                                      // 168
      required: ""                                                                                                    // 169
    }), "\n                                           ", HTML.SMALL({                                                 // 170
      "class": "error"                                                                                                // 171
    }, "Your password must match the requirements"), "\n                                        "), "\n                                    "), "\n                        \n                                    ", Blaze.If(function() {
      return Spacebars.call(view.lookup("showSignupCode"));                                                           // 173
    }, function() {                                                                                                   // 174
      return [ "\n                                      ", HTML.DIV({                                                 // 175
        "class": "form-group"                                                                                         // 176
      }, "\n                                          ", HTML.DIV({                                                   // 177
        "class": "input-symbol"                                                                                       // 178
      }, "\n                                            ", HTML.INPUT({                                               // 179
        name: "signupCode",                                                                                           // 180
        placeholder: function() {                                                                                     // 181
          return Spacebars.mustache(view.lookup("t9n"), "signupCode");                                                // 182
        },                                                                                                            // 183
        type: "string",                                                                                               // 184
        "class": "form-control",                                                                                      // 185
        value: "",                                                                                                    // 186
        autocapitalize: "none",                                                                                       // 187
        autocomplete: "off",                                                                                          // 188
        autocorrect: "off",                                                                                           // 189
        required: ""                                                                                                  // 190
      }), "\n                                              ", HTML.SMALL({                                            // 191
        "class": "error"                                                                                              // 192
      }, "Your Sign up code must match the requirements"), "\n                                          "), "    \n                                      "), "\n                                    " ];
    }), "\n                        \n                                    ", Spacebars.include(view.lookupTemplate("entryExtraSignUpFields")), "\n                                    ", HTML.BUTTON({
      type: "submit",                                                                                                 // 195
      "class": "submit btn btn-primary"                                                                               // 196
    }, Blaze.View("lookup:t9n", function() {                                                                          // 197
      return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                        // 198
    })), "\n                                  "), "\n                                " ];                             // 199
  }), "\n\n                                    ", Spacebars.include(view.lookupTemplate("socialButtons")), "\n                                    \n                                ", Blaze.If(function() {
    return Spacebars.call(view.lookup("both"));                                                                       // 201
  }, function() {                                                                                                     // 202
    return [ "\n                                  ", HTML.P({                                                         // 203
      "class": "entry-agreement"                                                                                      // 204
    }, Blaze.View("lookup:t9n", function() {                                                                          // 205
      return Spacebars.mustache(view.lookup("t9n"), "clickAgree");                                                    // 206
    }), "\n                                    ", HTML.A({                                                            // 207
      href: function() {                                                                                              // 208
        return Spacebars.mustache(view.lookup("privacyUrl"));                                                         // 209
      }                                                                                                               // 210
    }, Blaze.View("lookup:t9n", function() {                                                                          // 211
      return Spacebars.mustache(view.lookup("t9n"), "privacyPolicy");                                                 // 212
    })), " ", Blaze.View("lookup:t9n", function() {                                                                   // 213
      return Spacebars.mustache(view.lookup("t9n"), "and");                                                           // 214
    }), "\n                                    ", HTML.A({                                                            // 215
      href: function() {                                                                                              // 216
        return Spacebars.mustache(view.lookup("termsUrl"));                                                           // 217
      }                                                                                                               // 218
    }, Blaze.View("lookup:t9n", function() {                                                                          // 219
      return Spacebars.mustache(view.lookup("t9n"), "terms");                                                         // 220
    })), ".\n                                  "), "\n                                " ];                            // 221
  }, function() {                                                                                                     // 222
    return [ "\n                                  ", Blaze.Unless(function() {                                        // 223
      return Spacebars.call(view.lookup("neither"));                                                                  // 224
    }, function() {                                                                                                   // 225
      return [ "\n                                    ", HTML.P({                                                     // 226
        "class": "entry-agreement"                                                                                    // 227
      }, Blaze.View("lookup:t9n", function() {                                                                        // 228
        return Spacebars.mustache(view.lookup("t9n"), "clickAgree");                                                  // 229
      }), "\n                                      ", Blaze.If(function() {                                           // 230
        return Spacebars.call(view.lookup("privacyUrl"));                                                             // 231
      }, function() {                                                                                                 // 232
        return [ HTML.A({                                                                                             // 233
          href: function() {                                                                                          // 234
            return Spacebars.mustache(view.lookup("privacyUrl"));                                                     // 235
          }                                                                                                           // 236
        }, Blaze.View("lookup:t9n", function() {                                                                      // 237
          return Spacebars.mustache(view.lookup("t9n"), "privacyPolicy");                                             // 238
        })), "." ];                                                                                                   // 239
      }), "\n                                      ", Blaze.If(function() {                                           // 240
        return Spacebars.call(view.lookup("termsUrl"));                                                               // 241
      }, function() {                                                                                                 // 242
        return [ HTML.A({                                                                                             // 243
          href: function() {                                                                                          // 244
            return Spacebars.mustache(view.lookup("termsUrl"));                                                       // 245
          }                                                                                                           // 246
        }, Blaze.View("lookup:t9n", function() {                                                                      // 247
          return Spacebars.mustache(view.lookup("t9n"), "terms");                                                     // 248
        })), "." ];                                                                                                   // 249
      }), "\n                                    "), "\n                                  " ];                        // 250
    }), "\n                                " ];                                                                       // 251
  }), "\n                                ", Blaze.If(function() {                                                     // 252
    return Spacebars.call(view.lookup("talkingToServer"));                                                            // 253
  }, function() {                                                                                                     // 254
    return [ "\n                                  ", Spacebars.include(view.lookupTemplate("spinner")), "\n                                " ];
  }), "\n                              "), "\n                            "), "\n                          "), "\n                    ");
}));                                                                                                                  // 257
                                                                                                                      // 258
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/template.extraSignUpFields.js                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryExtraSignUpFields");                                                                       // 2
Template["entryExtraSignUpFields"] = new Template("Template.entryExtraSignUpFields", (function() {                    // 3
  var view = this;                                                                                                    // 4
  return Blaze.Each(function() {                                                                                      // 5
    return Spacebars.call(view.lookup("extraSignUpFields"));                                                          // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("_entryExtraSignUpField")), "\n    " ];                  // 8
  });                                                                                                                 // 9
}));                                                                                                                  // 10
                                                                                                                      // 11
Template.__checkName("_entryExtraSignUpField");                                                                       // 12
Template["_entryExtraSignUpField"] = new Template("Template._entryExtraSignUpField", (function() {                    // 13
  var view = this;                                                                                                    // 14
  return [ Blaze.If(function() {                                                                                      // 15
    return Spacebars.call(view.lookup("isTextField"));                                                                // 16
  }, function() {                                                                                                     // 17
    return [ "\n    ", HTML.DIV({                                                                                     // 18
      "class": "form-group"                                                                                           // 19
    }, "\n        ", Blaze.View("lookup:text_field", function() {                                                     // 20
      return Spacebars.mustache(view.lookup("text_field"), view.lookup("field"), Spacebars.kw({                       // 21
        type: view.lookup("type"),                                                                                    // 22
        required: view.lookup("required"),                                                                            // 23
        label: view.lookup("label"),                                                                                  // 24
        placeholder: view.lookup("placeholder")                                                                       // 25
      }));                                                                                                            // 26
    }), "\n    "), "\n    " ];                                                                                        // 27
  }), "\n\n    ", Blaze.If(function() {                                                                               // 28
    return Spacebars.call(view.lookup("isCheckbox"));                                                                 // 29
  }, function() {                                                                                                     // 30
    return [ "\n    ", HTML.DIV({                                                                                     // 31
      "class": "checkbox"                                                                                             // 32
    }, "\n        ", Blaze.View("lookup:check_box", function() {                                                      // 33
      return Spacebars.mustache(view.lookup("check_box"), view.lookup("name"), Spacebars.kw({                         // 34
        label: view.lookup("label"),                                                                                  // 35
        required: view.lookup("required")                                                                             // 36
      }));                                                                                                            // 37
    }), "\n    "), "\n    " ];                                                                                        // 38
  }) ];                                                                                                               // 39
}));                                                                                                                  // 40
                                                                                                                      // 41
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/forgotPassword/template.forgotPassword.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryForgotPassword");                                                                          // 2
Template["entryForgotPassword"] = new Template("Template.entryForgotPassword", (function() {                          // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "page-wrapper-auth tmpl-background"                                                                      // 6
  }, "\n    ", HTML.DIV({                                                                                             // 7
    "class": ""                                                                                                       // 8
  }, "\n      ", HTML.DIV({                                                                                           // 9
    "class": "wrapper-auth"                                                                                           // 10
  }, "\n\n        ", Blaze.If(function() {                                                                            // 11
    return Spacebars.call(view.lookup("logo"));                                                                       // 12
  }, function() {                                                                                                     // 13
    return [ "\n          ", HTML.DIV({                                                                               // 14
      "class": "entry-logo"                                                                                           // 15
    }, "\n            ", HTML.A({                                                                                     // 16
      href: "/"                                                                                                       // 17
    }, HTML.IMG({                                                                                                     // 18
      src: function() {                                                                                               // 19
        return Spacebars.mustache(view.lookup("logo"));                                                               // 20
      },                                                                                                              // 21
      alt: "logo"                                                                                                     // 22
    })), "\n          "), "\n        " ];                                                                             // 23
  }, function() {                                                                                                     // 24
    return [ "\n          ", HTML.H1({                                                                                // 25
      "class": "title-auth"                                                                                           // 26
    }, "Fantasia"), "\n\n          ", HTML.P({                                                                        // 27
      "class": "subtitle-auth"                                                                                        // 28
    }, "emotional chat"), "\n        " ];                                                                             // 29
  }), "\n\n        ", HTML.DIV({                                                                                      // 30
    "class": "forgot-account-password"                                                                                // 31
  }, "\n            \n          ", HTML.Raw("<!--{{#if error}}\n            <div class='alert alert-danger'>{{error}}</div>\n          {{/if}}-->"), "\n            \n          ", HTML.H3(Blaze.View("lookup:t9n", function() {
    return Spacebars.mustache(view.lookup("t9n"), "forgotPassword");                                                  // 33
  })), "\n\n          ", HTML.FORM({                                                                                  // 34
    id: "forgotPassword",                                                                                             // 35
    "data-abide": ""                                                                                                  // 36
  }, "\n            ", HTML.DIV({                                                                                     // 37
    "class": "form-group"                                                                                             // 38
  }, "\n              ", HTML.DIV({                                                                                   // 39
    "class": "input-symbol"                                                                                           // 40
  }, "\n                ", HTML.INPUT({                                                                               // 41
    type: "email",                                                                                                    // 42
    name: "forgottenEmail",                                                                                           // 43
    "class": "form-control",                                                                                          // 44
    placeholder: function() {                                                                                         // 45
      return Spacebars.mustache(view.lookup("t9n"), "emailAddress");                                                  // 46
    },                                                                                                                // 47
    value: "",                                                                                                        // 48
    required: ""                                                                                                      // 49
  }), "\n                  ", HTML.Raw('<small class="error">A valid email address is required</small>'), "\n              "), "\n            "), "\n            ", HTML.BUTTON({
    type: "submit",                                                                                                   // 51
    "class": "submit btn btn-primary"                                                                                 // 52
  }, Blaze.View("lookup:t9n", function() {                                                                            // 53
    return Spacebars.mustache(view.lookup("t9n"), "emailResetLink");                                                  // 54
  })), "\n          "), "\n          ", Blaze.If(function() {                                                         // 55
    return Spacebars.call(view.lookup("showSignupCode"));                                                             // 56
  }, function() {                                                                                                     // 57
    return [ "\n            ", HTML.P({                                                                               // 58
      "class": "entry-signup-cta"                                                                                     // 59
    }, Blaze.View("lookup:t9n", function() {                                                                          // 60
      return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                             // 61
    }), " ", HTML.A({                                                                                                 // 62
      href: function() {                                                                                              // 63
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignUp");                                             // 64
      }                                                                                                               // 65
    }, Blaze.View("lookup:t9n", function() {                                                                          // 66
      return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                        // 67
    }))), "\n          " ];                                                                                           // 68
  }), "\n          ", Blaze.If(function() {                                                                           // 69
    return Spacebars.call(view.lookup("talkingToServer"));                                                            // 70
  }, function() {                                                                                                     // 71
    return [ "\n            ", Spacebars.include(view.lookupTemplate("spinner")), "\n          " ];                   // 72
  }), "\n        "), "\n\n      "), "\n\n    "), "\n  ");                                                             // 73
}));                                                                                                                  // 74
                                                                                                                      // 75
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/resetPassword/template.resetPassword.js                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryResetPassword");                                                                           // 2
Template["entryResetPassword"] = new Template("Template.entryResetPassword", (function() {                            // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": function() {                                                                                             // 6
      return Spacebars.mustache(view.lookup("containerCSSClass"));                                                    // 7
    }                                                                                                                 // 8
  }, "\n    ", HTML.DIV({                                                                                             // 9
    "class": function() {                                                                                             // 10
      return Spacebars.mustache(view.lookup("rowCSSClass"));                                                          // 11
    }                                                                                                                 // 12
  }, "\n      ", Blaze.If(function() {                                                                                // 13
    return Spacebars.call(view.lookup("logo"));                                                                       // 14
  }, function() {                                                                                                     // 15
    return [ "\n        ", HTML.DIV({                                                                                 // 16
      "class": "entry-logo"                                                                                           // 17
    }, "\n            ", HTML.A({                                                                                     // 18
      href: "/"                                                                                                       // 19
    }, HTML.IMG({                                                                                                     // 20
      src: function() {                                                                                               // 21
        return Spacebars.mustache(view.lookup("logo"));                                                               // 22
      },                                                                                                              // 23
      alt: "logo"                                                                                                     // 24
    })), "\n        "), "\n      " ];                                                                                 // 25
  }), "\n      ", HTML.DIV({                                                                                          // 26
    "class": "entry col-md-4 col-md-offset-4"                                                                         // 27
  }, "\n        ", Blaze.If(function() {                                                                              // 28
    return Spacebars.call(view.lookup("error"));                                                                      // 29
  }, function() {                                                                                                     // 30
    return [ "\n          ", HTML.DIV({                                                                               // 31
      "class": "alert alert-danger"                                                                                   // 32
    }, Blaze.View("lookup:error", function() {                                                                        // 33
      return Spacebars.mustache(view.lookup("error"));                                                                // 34
    })), "\n        " ];                                                                                              // 35
  }), "\n        ", HTML.H3(Blaze.View("lookup:t9n", function() {                                                     // 36
    return Spacebars.mustache(view.lookup("t9n"), "resetYourPassword");                                               // 37
  })), "\n        ", HTML.FORM({                                                                                      // 38
    id: "resetPassword"                                                                                               // 39
  }, "\n          ", HTML.Raw('<div class="form-group">\n            <input type="password" name="new-password" class="form-control" value="">\n          </div>'), "\n          ", HTML.BUTTON({
    type: "submit",                                                                                                   // 41
    "class": "btn btn-default"                                                                                        // 42
  }, Blaze.View("lookup:t9n", function() {                                                                            // 43
    return Spacebars.mustache(view.lookup("t9n"), "updateYourPassword");                                              // 44
  })), "\n        "), "\n        ", Blaze.If(function() {                                                             // 45
    return Spacebars.call(view.lookup("showSignupCode"));                                                             // 46
  }, function() {                                                                                                     // 47
    return [ "\n          ", HTML.P({                                                                                 // 48
      "class": "entry-signup-cta"                                                                                     // 49
    }, Blaze.View("lookup:t9n", function() {                                                                          // 50
      return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                             // 51
    }), " ", HTML.A({                                                                                                 // 52
      href: function() {                                                                                              // 53
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignUp");                                             // 54
      }                                                                                                               // 55
    }, Blaze.View("lookup:t9n", function() {                                                                          // 56
      return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                        // 57
    }))), "\n        " ];                                                                                             // 58
  }), "\n        ", Blaze.If(function() {                                                                             // 59
    return Spacebars.call(view.lookup("talkingToServer"));                                                            // 60
  }, function() {                                                                                                     // 61
    return [ "\n          ", Spacebars.include(view.lookupTemplate("spinner")), "\n        " ];                       // 62
  }), "\n      "), "\n    "), "\n  ");                                                                                // 63
}));                                                                                                                  // 64
                                                                                                                      // 65
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/enrollAccount/template.enrollAccount.js                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryEnrollAccount");                                                                           // 2
Template["entryEnrollAccount"] = new Template("Template.entryEnrollAccount", (function() {                            // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "container"                                                                                              // 6
  }, "\n    ", HTML.DIV({                                                                                             // 7
    "class": "row"                                                                                                    // 8
  }, "\n      ", Blaze.If(function() {                                                                                // 9
    return Spacebars.call(view.lookup("logo"));                                                                       // 10
  }, function() {                                                                                                     // 11
    return [ "\n        ", HTML.DIV({                                                                                 // 12
      "class": "entry-logo"                                                                                           // 13
    }, "\n            ", HTML.A({                                                                                     // 14
      href: "/"                                                                                                       // 15
    }, HTML.IMG({                                                                                                     // 16
      src: function() {                                                                                               // 17
        return Spacebars.mustache(view.lookup("logo"));                                                               // 18
      },                                                                                                              // 19
      alt: "logo"                                                                                                     // 20
    })), "\n        "), "\n      " ];                                                                                 // 21
  }), "\n      ", HTML.DIV({                                                                                          // 22
    "class": "entry col-md-4 col-md-offset-4"                                                                         // 23
  }, "\n        ", Blaze.If(function() {                                                                              // 24
    return Spacebars.call(view.lookup("error"));                                                                      // 25
  }, function() {                                                                                                     // 26
    return [ "\n          ", HTML.DIV({                                                                               // 27
      "class": "alert alert-danger"                                                                                   // 28
    }, Blaze.View("lookup:error", function() {                                                                        // 29
      return Spacebars.mustache(view.lookup("error"));                                                                // 30
    })), "\n        " ];                                                                                              // 31
  }), "\n        ", HTML.H3(Blaze.View("lookup:t9n", function() {                                                     // 32
    return Spacebars.mustache(view.lookup("t9n"), "choosePassword");                                                  // 33
  })), "\n        ", HTML.FORM({                                                                                      // 34
    id: "setPassword"                                                                                                 // 35
  }, "\n          ", HTML.Raw('<div class="form-group">\n            <input type="password" name="new-password" class="form-control" value="">\n          </div>'), "\n          ", HTML.BUTTON({
    type: "submit",                                                                                                   // 37
    "class": "btn btn-default"                                                                                        // 38
  }, Blaze.View("lookup:t9n", function() {                                                                            // 39
    return Spacebars.mustache(view.lookup("t9n"), "setPassword");                                                     // 40
  })), "\n        "), "\n        ", Blaze.If(function() {                                                             // 41
    return Spacebars.call(view.lookup("showSignupCode"));                                                             // 42
  }, function() {                                                                                                     // 43
    return [ "\n          ", HTML.P({                                                                                 // 44
      "class": "entry-signup-cta"                                                                                     // 45
    }, Blaze.View("lookup:t9n", function() {                                                                          // 46
      return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                             // 47
    }), " ", HTML.A({                                                                                                 // 48
      href: "/sign-up"                                                                                                // 49
    }, Blaze.View("lookup:t9n", function() {                                                                          // 50
      return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                        // 51
    }))), "\n        " ];                                                                                             // 52
  }), "\n      "), "\n    "), "\n  ");                                                                                // 53
}));                                                                                                                  // 54
                                                                                                                      // 55
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/socialButtons/template.social-buttons.js                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("socialButtons");                                                                                // 2
Template["socialButtons"] = new Template("Template.socialButtons", (function() {                                      // 3
  var view = this;                                                                                                    // 4
  return HTML.Raw('<div class="social-auth">\n        <!--<a class="button js-login-with-fb-btn"><i class="fa fa-facebook"></i> Login with Facebook</a>-->\n    </div>');
}));                                                                                                                  // 6
                                                                                                                      // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/socialButtons/social-buttons.js                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Created by root on 9/28/15.                                                                                        // 2
 */                                                                                                                   // 3
                                                                                                                      // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/social/template.social.js                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySocial");                                                                                  // 2
Template["entrySocial"] = new Template("Template.entrySocial", (function() {                                          // 3
  var view = this;                                                                                                    // 4
  return HTML.BUTTON({                                                                                                // 5
    "class": "btn",                                                                                                   // 6
    id: function() {                                                                                                  // 7
      return [ "entry-", Spacebars.mustache(view.lookup(".")) ];                                                      // 8
    },                                                                                                                // 9
    name: function() {                                                                                                // 10
      return Spacebars.mustache(view.lookup("."));                                                                    // 11
    }                                                                                                                 // 12
  }, "\n    ", Blaze.If(function() {                                                                                  // 13
    return Spacebars.call(view.lookup("unconfigured"));                                                               // 14
  }, function() {                                                                                                     // 15
    return [ "\n      ", HTML.I({                                                                                     // 16
      "class": function() {                                                                                           // 17
        return [ "fa fa-", Spacebars.mustache(view.lookup("icon")) ];                                                 // 18
      }                                                                                                               // 19
    }), " ", Blaze.View("lookup:t9n", function() {                                                                    // 20
      return Spacebars.mustache(view.lookup("t9n"), "configure");                                                     // 21
    }), " ", Blaze.View("lookup:capitalize", function() {                                                             // 22
      return Spacebars.mustache(view.lookup("capitalize"), view.lookup("."));                                         // 23
    }), "\n    " ];                                                                                                   // 24
  }, function() {                                                                                                     // 25
    return [ "\n      ", HTML.I({                                                                                     // 26
      "class": function() {                                                                                           // 27
        return [ "fa fa-", Spacebars.mustache(view.lookup("icon")) ];                                                 // 28
      }                                                                                                               // 29
    }), " ", Blaze.View("lookup:buttonText", function() {                                                             // 30
      return Spacebars.mustache(view.lookup("buttonText"));                                                           // 31
    }), " ", Blaze.View("lookup:t9n", function() {                                                                    // 32
      return Spacebars.mustache(view.lookup("t9n"), "with");                                                          // 33
    }), " ", Blaze.View("lookup:capitalize", function() {                                                             // 34
      return Spacebars.mustache(view.lookup("capitalize"), view.lookup("."));                                         // 35
    }), "\n    " ];                                                                                                   // 36
  }), "\n  ");                                                                                                        // 37
}));                                                                                                                  // 38
                                                                                                                      // 39
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/error/template.error.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryError");                                                                                   // 2
Template["entryError"] = new Template("Template.entryError", (function() {                                            // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("error"));                                                                      // 6
  }, function() {                                                                                                     // 7
    return [ "\n  ", HTML.DIV({                                                                                       // 8
      "class": "alert alert-danger label",                                                                            // 9
      style: "width: 100%;    position: fixed; font-size: 1.2em; bottom: 0; left: 0;"                                 // 10
    }, Blaze.View("lookup:error", function() {                                                                        // 11
      return Spacebars.mustache(view.lookup("error"));                                                                // 12
    })), "\n  " ];                                                                                                    // 13
  });                                                                                                                 // 14
}));                                                                                                                  // 15
                                                                                                                      // 16
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/template.accountButtons.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryAccountButtons");                                                                          // 2
Template["entryAccountButtons"] = new Template("Template.entryAccountButtons", (function() {                          // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("currentUser"));                                                                // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("signedInTemplate")), "\n  " ];                          // 8
  }, function() {                                                                                                     // 9
    return [ "\n\n    ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                           // 10
      return [ "\n      ", HTML.A({                                                                                   // 11
        href: function() {                                                                                            // 12
          return Spacebars.mustache(view.lookup("pathFor"), "entrySignIn");                                           // 13
        }                                                                                                             // 14
      }, Blaze.View("lookup:beforeSignIn", function() {                                                               // 15
        return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignIn")));                                    // 16
      }), Blaze.View("lookup:t9n", function() {                                                                       // 17
        return Spacebars.mustache(view.lookup("t9n"), "signIn");                                                      // 18
      })), "\n    " ];                                                                                                // 19
    }), "\n\n    ", Blaze.Unless(function() {                                                                         // 20
      return Spacebars.call(view.lookup("wrapLinks"));                                                                // 21
    }, function() {                                                                                                   // 22
      return [ "\n      ", HTML.SPAN("or"), "\n    " ];                                                               // 23
    }), "\n\n    ", Blaze.If(function() {                                                                             // 24
      return Spacebars.call(view.lookup("showCreateAccountLink"));                                                    // 25
    }, function() {                                                                                                   // 26
      return [ "\n      ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                         // 27
        return [ "\n        ", HTML.A({                                                                               // 28
          href: function() {                                                                                          // 29
            return Spacebars.mustache(view.lookup("entrySignUp"));                                                    // 30
          }                                                                                                           // 31
        }, Blaze.View("lookup:beforeSignUp", function() {                                                             // 32
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignUp")));                                  // 33
        }), Blaze.View("lookup:t9n", function() {                                                                     // 34
          return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                    // 35
        })), "\n      " ];                                                                                            // 36
      }), "\n    " ];                                                                                                 // 37
    }), "\n  " ];                                                                                                     // 38
  });                                                                                                                 // 39
}));                                                                                                                  // 40
                                                                                                                      // 41
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/template._wrapLinks.js                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("wrapLinks");                                                                                    // 2
Template["wrapLinks"] = new Template("Template.wrapLinks", (function() {                                              // 3
  var view = this;                                                                                                    // 4
  return HTML.LI("\n  ", Blaze._InOuterTemplateScope(view, function() {                                               // 5
    return Spacebars.include(function() {                                                                             // 6
      return Spacebars.call(view.templateContentBlock);                                                               // 7
    });                                                                                                               // 8
  }), "\n");                                                                                                          // 9
}));                                                                                                                  // 10
                                                                                                                      // 11
Template.__checkName("noWrapLinks");                                                                                  // 12
Template["noWrapLinks"] = new Template("Template.noWrapLinks", (function() {                                          // 13
  var view = this;                                                                                                    // 14
  return Blaze._InOuterTemplateScope(view, function() {                                                               // 15
    return Spacebars.include(function() {                                                                             // 16
      return Spacebars.call(view.templateContentBlock);                                                               // 17
    });                                                                                                               // 18
  });                                                                                                                 // 19
}));                                                                                                                  // 20
                                                                                                                      // 21
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/template.signedIn.js                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySignedIn");                                                                                // 2
Template["entrySignedIn"] = new Template("Template.entrySignedIn", (function() {                                      // 3
  var view = this;                                                                                                    // 4
  return [ Blaze.If(function() {                                                                                      // 5
    return Spacebars.call(view.lookup("profileUrl"));                                                                 // 6
  }, function() {                                                                                                     // 7
    return [ "\n  ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                               // 8
      return [ "\n    ", HTML.A({                                                                                     // 9
        "class": "profileLink",                                                                                       // 10
        href: function() {                                                                                            // 11
          return Spacebars.mustache(view.lookup("profileUrl"));                                                       // 12
        }                                                                                                             // 13
      }, Blaze.View("lookup:beforeSignedInAs", function() {                                                           // 14
        return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignedInAs")));                                // 15
      }), Blaze.View("lookup:signedInAs", function() {                                                                // 16
        return Spacebars.mustache(view.lookup("signedInAs"));                                                         // 17
      })), "\n  " ];                                                                                                  // 18
    }), "\n" ];                                                                                                       // 19
  }, function() {                                                                                                     // 20
    return [ "\n  ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                               // 21
      return [ "\n    ", HTML.P({                                                                                     // 22
        "class": "navbar-text"                                                                                        // 23
      }, Blaze.View("lookup:beforeSignedInAs", function() {                                                           // 24
        return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignedInAs")));                                // 25
      }), Blaze.View("lookup:signedInAs", function() {                                                                // 26
        return Spacebars.mustache(view.lookup("signedInAs"));                                                         // 27
      })), "\n  " ];                                                                                                  // 28
    }), "\n" ];                                                                                                       // 29
  }), "\n\n", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                                      // 30
    return [ "\n  ", HTML.A({                                                                                         // 31
      href: function() {                                                                                              // 32
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignOut");                                            // 33
      }                                                                                                               // 34
    }, Blaze.View("lookup:beforeSignOut", function() {                                                                // 35
      return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignOut")));                                     // 36
    }), Blaze.View("lookup:t9n", function() {                                                                         // 37
      return Spacebars.mustache(view.lookup("t9n"), "signOut");                                                       // 38
    })), "\n" ];                                                                                                      // 39
  }) ];                                                                                                               // 40
}));                                                                                                                  // 41
                                                                                                                      // 42
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/verificationPending/template.verificationPending.js                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryVerificationPending");                                                                     // 2
Template["entryVerificationPending"] = new Template("Template.entryVerificationPending", (function() {                // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": function() {                                                                                             // 6
      return Spacebars.mustache(view.lookup("containerCSSClass"));                                                    // 7
    }                                                                                                                 // 8
  }, "\n    ", HTML.DIV({                                                                                             // 9
    "class": function() {                                                                                             // 10
      return Spacebars.mustache(view.lookup("rowCSSClass"));                                                          // 11
    }                                                                                                                 // 12
  }, "\n      ", Blaze.If(function() {                                                                                // 13
    return Spacebars.call(view.lookup("logo"));                                                                       // 14
  }, function() {                                                                                                     // 15
    return [ "\n        ", HTML.DIV({                                                                                 // 16
      "class": "entry-logo"                                                                                           // 17
    }, "\n            ", HTML.A({                                                                                     // 18
      href: "/"                                                                                                       // 19
    }, HTML.IMG({                                                                                                     // 20
      src: function() {                                                                                               // 21
        return Spacebars.mustache(view.lookup("logo"));                                                               // 22
      },                                                                                                              // 23
      alt: "logo"                                                                                                     // 24
    })), "\n        "), "\n      " ];                                                                                 // 25
  }), "\n      ", HTML.DIV({                                                                                          // 26
    "class": "entry col-md-4 col-md-offset-4"                                                                         // 27
  }, "\n        ", Blaze.If(function() {                                                                              // 28
    return Spacebars.call(view.lookup("error"));                                                                      // 29
  }, function() {                                                                                                     // 30
    return [ "\n          ", HTML.DIV({                                                                               // 31
      "class": "alert alert-danger"                                                                                   // 32
    }, Blaze.View("lookup:error", function() {                                                                        // 33
      return Spacebars.mustache(view.lookup("error"));                                                                // 34
    })), "\n        " ];                                                                                              // 35
  }), "\n        ", HTML.DIV({                                                                                        // 36
    "class": "panel panel-info"                                                                                       // 37
  }, "\n          ", HTML.DIV({                                                                                       // 38
    "class": "panel-heading"                                                                                          // 39
  }, "\n            ", HTML.H3({                                                                                      // 40
    "class": "panel-title"                                                                                            // 41
  }, Blaze.View("lookup:t9n", function() {                                                                            // 42
    return Spacebars.mustache(view.lookup("t9n"), "verificationPending");                                             // 43
  })), "\n          "), "\n          ", HTML.DIV({                                                                    // 44
    "class": "panel-body"                                                                                             // 45
  }, "\n            ", Blaze.View("lookup:t9n", function() {                                                          // 46
    return Spacebars.mustache(view.lookup("t9n"), "verificationPendingDetails");                                      // 47
  }), "\n          "), "\n          \n        "), "\n      "), "\n    "), "\n  ");                                    // 48
}));                                                                                                                  // 49
                                                                                                                      // 50
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/entry.coffee.js                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                  

AccountsEntry = {
  settings: {
    wrapLinks: true,
    homeRoute: '/',
    dashboardRoute: '/dashboard',
    passwordSignupFields: 'EMAIL_ONLY',
    emailToLower: true,
    usernameToLower: false,
    entrySignUp: '/sign-up',
    extraSignUpFields: [],
    showOtherLoginServices: true,
    fluidLayout: false,
    useContainer: true,
    signInAfterRegistration: true,
    emailVerificationPendingRoute: '/verification-pending',
    showSpinner: true,
    spinnerOptions: {
      color: "#000",
      top: "80%"
    }
  },
  isStringEmail: function(email) {
    var emailPattern;
    emailPattern = /^([\w.-]+)@([\w.-]+)\.([a-zA-Z.]{2,6})$/i;
    if (email.match(emailPattern)) {
      return true;
    } else {
      return false;
    }
  },
  config: function(appConfig) {
    var signUpRoute;
    this.settings = _.extend(this.settings, appConfig);
    T9n.defaultLanguage = "en";
    if (appConfig.language) {
      T9n.language = appConfig.language;
    }
    if (appConfig.signUpTemplate) {
      signUpRoute = Router.routes['entrySignUp'];
      return signUpRoute.options.template = appConfig.signUpTemplate;
    }
  },
  signInRequired: function(router, extraCondition) {
    if (extraCondition == null) {
      extraCondition = true;
    }
    if (!Meteor.loggingIn()) {
      if (Meteor.user() && extraCondition) {
        return router.next();
      } else {
        Session.set('fromWhere', router.url);
        Router.go('/sign-in');
        Session.set('entryError', t9n('error.signInRequired'));
        return router.next();
      }
    }
  }
};

this.AccountsEntry = AccountsEntry;

this.T9NHelper = (function() {
  function T9NHelper() {}

  T9NHelper.translate = function(code) {
    return T9n.get(code, "error.accounts");
  };

  T9NHelper.accountsError = function(err) {
    return Session.set('entryError', this.translate(err.reason));
  };

  return T9NHelper;

})();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/helpers.coffee.js                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
if (typeof Handlebars !== "undefined") {
  UI.registerHelper("signedInAs", function(date) {
    if (Meteor.user().username) {
      return Meteor.user().username;
    } else if (Meteor.user().profile && Meteor.user().profile.name) {
      return Meteor.user().profile.name;
    } else if (Meteor.user().emails && Meteor.user().emails[0]) {
      return Meteor.user().emails[0].address;
    } else {
      return "Signed In";
    }
  });
}

UI.registerHelper('accountButtons', function() {
  return Template.entryAccountButtons;
});

UI.registerHelper('capitalize', function(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
});

UI.registerHelper('signupClass', function() {
  if (AccountsEntry.settings.showOtherLoginServices && Accounts.oauth && Accounts.oauth.serviceNames().length > 0) {
    return "collapse";
  }
});

UI.registerHelper('signedIn', function() {
  if (Meteor.user()) {
    return true;
  }
});

UI.registerHelper('otherLoginServices', function() {
  return AccountsEntry.settings.showOtherLoginServices && Accounts.oauth && Accounts.oauth.serviceNames().length > 0;
});

UI.registerHelper('loginServices', function() {
  return Accounts.oauth.serviceNames();
});

UI.registerHelper('showSignupCode', function() {
  return AccountsEntry.settings.showSignupCode === true;
});

UI.registerHelper('passwordLoginService', function() {
  return !!Package['accounts-password'];
});

UI.registerHelper('showCreateAccountLink', function() {
  return !Accounts._options.forbidClientAccountCreation;
});

UI.registerHelper('fluidLayout', function() {
  return AccountsEntry.settings.fluidLayout === true;
});

UI.registerHelper('talkingToServer', function() {
  if (AccountsEntry.settings.showSpinner === true) {
    Meteor.Spinner.options = AccountsEntry.settings.spinnerOptions;
    return Session.get('talkingToServer') === true;
  } else {
    return false;
  }
});

UI.registerHelper('containerCSSClass', function() {
  if (AccountsEntry.settings.useContainer === false) {
    return "accounts-entry-container";
  } else {
    if (AccountsEntry.settings.fluidLayout === true) {
      return "container-fluid";
    } else {
      return "container";
    }
  }
});

UI.registerHelper('rowCSSClass', function() {
  if (AccountsEntry.settings.fluidLayout === true) {
    return "row-fluid";
  } else {
    return "row";
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signIn/signIn.coffee.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
AccountsEntry.entrySignInHelpers = {
  emailInputType: function() {
    if (AccountsEntry.settings.passwordSignupFields === 'EMAIL_ONLY') {
      return 'email';
    } else {
      return 'string';
    }
  },
  emailPlaceholder: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    if (_.contains(['USERNAME_AND_EMAIL', 'USERNAME_AND_OPTIONAL_EMAIL'], fields)) {
      return t9n("usernameOrEmail");
    } else if (fields === "USERNAME_ONLY") {
      return t9n("username");
    }
    return t9n("email");
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  },
  isUsernameOnly: function() {
    return AccountsEntry.settings.passwordSignupFields === 'USERNAME_ONLY';
  }
};

AccountsEntry.entrySignInEvents = {
  'submit #signIn': function(event) {
    var email;
    event.preventDefault();
    email = $('input[name="email"]').val();
    if ((AccountsEntry.isStringEmail(email) && AccountsEntry.settings.emailToLower) || (!AccountsEntry.isStringEmail(email) && AccountsEntry.settings.usernameToLower)) {
      email = email.toLowerCase();
    }
    Session.set('email', email);
    Session.set('password', $('input[name="password"]').val());
    Session.set('talkingToServer', true);
    return Meteor.loginWithPassword(Session.get('email'), Session.get('password'), function(error) {
      Session.set('password', void 0);
      Session.set('talkingToServer', false);
      if (!error) {
        bz.help.location.processCurrentLocation();
      }
      if (error) {
        return T9NHelper.accountsError(error);
      } else if (Session.get('fromWhere')) {
        Router.go(Session.get('fromWhere'));
        return Session.set('fromWhere', void 0);
      } else {
        return Router.go(AccountsEntry.settings.dashboardRoute);
      }
    });
  },
  'click .js-login-with-fb-btn': function(e, v) {
    debugger;
    return Meteor.signInWithFacebook({}, function() {
      debugger;
    });
  }
};

Template.entrySignIn.helpers(AccountsEntry.entrySignInHelpers);

Template.entrySignIn.events(AccountsEntry.entrySignInEvents);

Template.entrySignIn.rendered = function() {
  $(document).foundation({
    abide: {
      live_validate: true,
      validate_on_blur: true,
      focus_on_invalid: true,
      error_labels: true,
      timeout: 1000,
      patterns: {
        email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
      }
    }
  });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/signUp.coffee.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
AccountsEntry.hashPassword = function(password) {
  return {
    digest: SHA256(password),
    algorithm: "sha-256"
  };
};

AccountsEntry.entrySignUpHelpers = {
  showEmail: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    return _.contains(['USERNAME_AND_EMAIL', 'USERNAME_AND_OPTIONAL_EMAIL', 'EMAIL_ONLY'], fields);
  },
  showUsername: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    return _.contains(['USERNAME_AND_EMAIL', 'USERNAME_AND_OPTIONAL_EMAIL', 'USERNAME_ONLY'], fields);
  },
  showSignupCode: function() {
    return AccountsEntry.settings.showSignupCode;
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  },
  privacyUrl: function() {
    return AccountsEntry.settings.privacyUrl;
  },
  termsUrl: function() {
    return AccountsEntry.settings.termsUrl;
  },
  both: function() {
    return AccountsEntry.settings.privacyUrl && AccountsEntry.settings.termsUrl;
  },
  neither: function() {
    return !AccountsEntry.settings.privacyUrl && !AccountsEntry.settings.termsUrl;
  },
  emailIsOptional: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    return _.contains(['USERNAME_AND_OPTIONAL_EMAIL'], fields);
  },
  emailAddress: function() {
    return Session.get('email');
  }
};

AccountsEntry.entrySignUpEvents = {
  'submit #signUp': function(event, t) {
    var email, emailRequired, extraFields, fields, filteredExtraFields, formValues, password, passwordErrors, signupCode, trimInput, username, usernameRequired;
    event.preventDefault();
    username = t.find('input[name="username"]') ? t.find('input[name="username"]').value.toLowerCase() : void 0;
    if (username && AccountsEntry.settings.usernameToLower) {
      username = username.toLowerCase();
    }
    signupCode = t.find('input[name="signupCode"]') ? t.find('input[name="signupCode"]').value : void 0;
    trimInput = function(val) {
      return val.replace(/^\s*|\s*$/g, "");
    };
    email = t.find('input[type="email"]') ? trimInput(t.find('input[type="email"]').value) : void 0;
    if (AccountsEntry.settings.emailToLower && email) {
      email = email.toLowerCase();
    }
    formValues = SimpleForm.processForm(event.target);
    extraFields = _.pluck(AccountsEntry.settings.extraSignUpFields, 'field');
    filteredExtraFields = _.pick(formValues, extraFields);
    password = t.find('input[type="password"]').value;
    fields = AccountsEntry.settings.passwordSignupFields;
    passwordErrors = (function(password) {
      var errMsg, msg;
      errMsg = [];
      msg = false;
      if (password.length < 7) {
        errMsg.push(t9n("error.minChar"));
      }
      if (password.search(/[a-z]/i) < 0) {
        errMsg.push(t9n("error.pwOneLetter"));
      }
      if (password.search(/[0-9]/) < 0) {
        errMsg.push(t9n("error.pwOneDigit"));
      }
      if (errMsg.length > 0) {
        msg = "";
        errMsg.forEach(function(e) {
          return msg = msg.concat("" + e + "\r\n");
        });
        Session.set('entryError', msg);
        return true;
      }
      return false;
    })(password);
    if (passwordErrors) {
      return;
    }
    emailRequired = _.contains(['USERNAME_AND_EMAIL', 'EMAIL_ONLY'], fields);
    usernameRequired = _.contains(['USERNAME_AND_EMAIL', 'USERNAME_ONLY'], fields);
    if (usernameRequired && username.length === 0) {
      Session.set('entryError', t9n("error.usernameRequired"));
      return;
    }
    if (username && AccountsEntry.isStringEmail(username)) {
      Session.set('entryError', t9n("error.usernameIsEmail"));
      return;
    }
    if (emailRequired && email.length === 0) {
      Session.set('entryError', t9n("error.emailRequired"));
      return;
    }
    if (AccountsEntry.settings.showSignupCode && signupCode.length === 0) {
      Session.set('entryError', t9n("error.signupCodeRequired"));
      return;
    }
    return Meteor.call('entryValidateSignupCode', signupCode, function(err, valid) {
      var newUserData;
      if (valid) {
        newUserData = {
          username: username,
          email: email,
          password: AccountsEntry.hashPassword(password),
          profile: filteredExtraFields
        };
        Session.set('talkingToServer', true);
        return Meteor.call('entryCreateUser', newUserData, function(err, data) {
          var isEmailSignUp, userCredential;
          Session.set('talkingToServer', false);
          if (err) {
            console.log(err);
            T9NHelper.accountsError(err);
            return;
          }
          isEmailSignUp = _.contains(['USERNAME_AND_EMAIL', 'EMAIL_ONLY'], AccountsEntry.settings.passwordSignupFields);
          if (isEmailSignUp) {
            userCredential = email;
          } else {
            userCredential = username;
          }
          if (AccountsEntry.settings.signInAfterRegistration === true) {
            Session.set('talkingToServer', true);
            return Meteor.loginWithPassword(userCredential, password, function(error) {
              Session.set('talkingToServer', false);
              if (error) {
                console.log(error);
                return T9NHelper.accountsError(error);
              } else if (Session.get('fromWhere')) {
                Router.go(Session.get('fromWhere'));
                return Session.set('fromWhere', void 0);
              } else {
                return Router.go(AccountsEntry.settings.dashboardRoute);
              }
            });
          } else {
            if (AccountsEntry.settings.emailVerificationPendingRoute) {
              return Router.go(AccountsEntry.settings.emailVerificationPendingRoute);
            }
          }
        });
      } else {
        console.log(err);
        Session.set('entryError', t9n("error.signupCodeIncorrect"));
      }
    });
  },
  'click .js-login-with-fb-btn': function(e, v) {
    debugger;
    return Meteor.signInWithFacebook({}, function() {
      debugger;
    });
  }
};

Template.entrySignUp.helpers(AccountsEntry.entrySignUpHelpers);

Template.entrySignUp.events(AccountsEntry.entrySignUpEvents);

Template.entrySignUp.rendered = function() {
  $(document).foundation({
    abide: {
      live_validate: true,
      validate_on_blur: true,
      focus_on_invalid: true,
      error_labels: true,
      timeout: 1000,
      patterns: {
        email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
      }
    }
  });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/extraSignUpFields.coffee.js                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryExtraSignUpFields.helpers({
  extraSignUpFields: function() {
    return AccountsEntry.settings.extraSignUpFields;
  }
});

Template._entryExtraSignUpField.helpers({
  isTextField: function() {
    return this.type !== "check_box";
  },
  isCheckbox: function() {
    return this.type === "check_box";
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/forgotPassword/forgotPassword.coffee.js                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryForgotPassword.helpers({
  error: function() {
    return t9n(Session.get('entryError'));
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});

Template.entryForgotPassword.events({
  'submit #forgotPassword': function(event) {
    event.preventDefault();
    Session.set('email', $('input[name="forgottenEmail"]').val());
    if (Session.get('email').length === 0) {
      Session.set('entryError', 'Email is required');
      return;
    }
    Session.set('talkingToServer', true);
    return Accounts.forgotPassword({
      email: Session.get('email')
    }, function(error) {
      Session.set('talkingToServer', false);
      if (error) {
        return Session.set('entryError', error.reason);
      } else {
        return Router.go(AccountsEntry.settings.homeRoute);
      }
    });
  }
});

Template.entryForgotPassword.rendered = function() {
  $(document).foundation({
    abide: {
      live_validate: true,
      validate_on_blur: true,
      focus_on_invalid: true,
      error_labels: true,
      timeout: 1000,
      patterns: {
        email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
      }
    }
  });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/resetPassword/resetPassword.coffee.js                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryResetPassword.helpers({
  error: function() {
    return Session.get('entryError');
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});

Template.entryResetPassword.events({
  'submit #resetPassword': function(event) {
    var password, passwordErrors;
    event.preventDefault();
    password = $('input[type="password"]').val();
    passwordErrors = (function(password) {
      var errMsg, msg;
      errMsg = [];
      msg = false;
      if (password.length < 7) {
        errMsg.push(t9n("error.minChar"));
      }
      if (password.search(/[a-z]/i) < 0) {
        errMsg.push(t9n("error.pwOneLetter"));
      }
      if (password.search(/[0-9]/) < 0) {
        errMsg.push(t9n("error.pwOneDigit"));
      }
      if (errMsg.length > 0) {
        msg = "";
        errMsg.forEach(function(e) {
          return msg = msg.concat("" + e + "\r\n");
        });
        Session.set('entryError', msg);
        return true;
      }
      return false;
    })(password);
    if (passwordErrors) {
      return;
    }
    Session.set('talkingToServer', true);
    return Accounts.resetPassword(Session.get('resetToken'), password, function(error) {
      Session.set('talkingToServer', false);
      if (error) {
        return Session.set('entryError', error.reason || "Unknown error");
      } else {
        Session.set('resetToken', null);
        return Router.go(AccountsEntry.settings.dashboardRoute);
      }
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/enrollAccount/enrollAccount.coffee.js                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryEnrollAccount.helpers({
  error: function() {
    return Session.get('entryError');
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});

Template.entryEnrollAccount.events({
  'submit #setPassword': function(event) {
    var password, passwordErrors;
    event.preventDefault();
    password = $('input[type="password"]').val();
    passwordErrors = (function(password) {
      var errMsg, msg;
      errMsg = [];
      msg = false;
      if (password.length < 7) {
        errMsg.push(t9n("error.minChar"));
      }
      if (password.search(/[a-z]/i) < 0) {
        errMsg.push(t9n("error.pwOneLetter"));
      }
      if (password.search(/[0-9]/) < 0) {
        errMsg.push(t9n("error.pwOneDigit"));
      }
      if (errMsg.length > 0) {
        msg = "";
        errMsg.forEach(function(e) {
          return msg = msg.concat("" + e + "\r\n");
        });
        Session.set('entryError', msg);
        return true;
      }
      return false;
    })(password);
    if (passwordErrors) {
      return;
    }
    return Accounts.resetPassword(Session.get('resetToken'), password, function(error) {
      if (error) {
        return Session.set('entryError', error.reason || "Unknown error");
      } else {
        Session.set('resetToken', null);
        return Router.go(AccountsEntry.settings.dashboardRoute);
      }
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/social/social.coffee.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var capitalize;

Template.entrySocial.helpers({
  buttonText: function() {
    var buttonText;
    buttonText = Session.get('buttonText');
    if (buttonText === 'up') {
      return t9n('signUp');
    } else {
      return t9n('signIn');
    }
  },
  unconfigured: function() {
    return ServiceConfiguration.configurations.find({
      service: this.toString()
    }).fetch().length === 0;
  },
  google: function() {
    if (this[0] === 'g' && this[1] === 'o') {
      return true;
    }
  },
  icon: function() {
    switch (this.toString()) {
      case 'google':
        return 'google-plus';
      case 'meteor-developer':
        return 'rocket';
      default:
        return this;
    }
  }
});

Template.entrySocial.events({
  'click .btn': function(event) {
    var callback, loginWithService, options, serviceName;
    event.preventDefault();
    serviceName = $(event.target).attr('id').replace('entry-', '');
    callback = function(err) {
      Session.set('talkingToServer', false);
      if (!err) {
        if (Session.get('fromWhere')) {
          Router.go(Session.get('fromWhere'));
          return Session.set('fromWhere', void 0);
        } else {
          return Router.go(AccountsEntry.settings.dashboardRoute);
        }
      } else if (err instanceof Accounts.LoginCancelledError) {

      } else if (err instanceof ServiceConfiguration.ConfigError) {
        return Accounts._loginButtonsSession.configureService(serviceName);
      } else {
        return Accounts._loginButtonsSession.errorMessage(err.reason || t9n("error.unknown"));
      }
    };
    if (serviceName === 'meteor-developer') {
      loginWithService = Meteor["loginWithMeteorDeveloperAccount"];
    } else {
      loginWithService = Meteor["loginWith" + capitalize(serviceName)];
    }
    options = {};
    if (Accounts.ui._options.requestPermissions[serviceName]) {
      options.requestPermissions = Accounts.ui._options.requestPermissions[serviceName];
    }
    if (Accounts.ui._options.requestOfflineToken && Accounts.ui._options.requestOfflineToken[serviceName]) {
      options.requestOfflineToken = Accounts.ui._options.requestOfflineToken[serviceName];
    }
    Session.set('talkingToServer', true);
    return loginWithService(options, callback);
  }
});

capitalize = function(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/error/error.coffee.js                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryError.helpers({
  error: function() {
    return Session.get('entryError');
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/accountButtons.coffee.js                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var entryAccountButtonsHelpers;

entryAccountButtonsHelpers = {
  profileUrl: function() {
    if (!AccountsEntry.settings.profileRoute) {
      return false;
    }
    return AccountsEntry.settings.profileRoute;
  },
  wrapLinksLi: function() {
    if (AccountsEntry.settings.wrapLinks) {
      return Template.wrapLinks;
    } else {
      return Template.noWrapLinks;
    }
  },
  wrapLinks: function() {
    return AccountsEntry.settings.wrapLinks;
  },
  beforeSignIn: function() {
    return AccountsEntry.settings.beforeSignIn;
  },
  beforeSignUp: function() {
    return AccountsEntry.settings.beforeSignUp;
  },
  beforeSignOut: function() {
    return AccountsEntry.settings.beforeSignOut;
  },
  beforeSignedInAs: function() {
    return AccountsEntry.settings.beforeSignedInAs;
  },
  entrySignUp: function() {
    return AccountsEntry.settings.entrySignUp;
  },
  profile: function() {
    return Meteor.user().profile;
  }
};

Template.entryAccountButtons.helpers(entryAccountButtonsHelpers);

Template.entryAccountButtons.helpers({
  signedInTemplate: function() {
    if (AccountsEntry.settings.signedInTemplate) {
      Template[AccountsEntry.settings.signedInTemplate].helpers(entryAccountButtonsHelpers);
      return Template[AccountsEntry.settings.signedInTemplate];
    } else {
      return Template.entrySignedIn;
    }
  }
});

Template.entrySignedIn.helpers(entryAccountButtonsHelpers);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/verificationPending/verificationPending.coffee.js                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryVerificationPending.helpers({
  error: function() {
    return t9n(Session.get('entryError'));
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/t9n/english.coffee.js                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var en;

en = {
  signIn: "Sign In",
  signin: "sign in",
  signOut: "Sign Out",
  signUp: "Register",
  OR: "OR",
  forgotPassword: "Forgot your password?",
  emailAddress: "Email Address",
  emailResetLink: "Email Reset Link",
  dontHaveAnAccount: "Don't have an account?",
  resetYourPassword: "Reset your password",
  updateYourPassword: "Update your password",
  password: "Password",
  usernameOrEmail: "Username or email",
  email: "Email",
  ifYouAlreadyHaveAnAccount: "If you already have an account",
  signUpWithYourEmailAddress: "Register with your email address",
  username: "Username",
  optional: "Optional",
  signupCode: "Registration Code",
  clickAgree: "By clicking Register, you agree to our",
  privacyPolicy: "Privacy Policy",
  terms: "Terms of Use",
  sign: "Sign",
  configure: "Configure",
  "with": "with",
  createAccount: "Create an Account",
  verificationPending: "Confirm your email address",
  verificationPendingDetails: "A confirmation email has been sent to the email address you provided. Click on the confirmation link in the email to activate your account.",
  and: "and",
  "Match failed": "Match failed",
  "User not found": "User not found",
  error: {
    minChar: "7 character minimum password.",
    pwOneLetter: "Password requires 1 letter.",
    pwOneDigit: "Password must have at least one digit.",
    usernameRequired: "Username is required.",
    emailRequired: "Email is required.",
    signupCodeRequired: "Registration code is required.",
    signupCodeIncorrect: "Registration code is incorrect.",
    signInRequired: "You must be signed in to do that.",
    usernameIsEmail: "Username cannot be an email address."
  }
};

T9n.map("en", en);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/shared/router.coffee.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var exclusions;

Router.map(function() {
  this.route("entrySignIn", {
    path: "/sign-in",
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      Session.set('buttonText', 'in');
      return this.next();
    },
    onRun: function() {
      var pkgRendered, userRendered;
      if (Meteor.userId()) {
        Router.go(AccountsEntry.settings.dashboardRoute);
      }
      if (AccountsEntry.settings.signInTemplate) {
        this.template = AccountsEntry.settings.signInTemplate;
        pkgRendered = Template.entrySignIn.rendered;
        userRendered = Template[this.template].rendered;
        if (userRendered) {
          Template[this.template].rendered = function() {
            pkgRendered.call(this);
            return userRendered.call(this);
          };
        } else {
          Template[this.template].rendered = pkgRendered;
        }
        Template[this.template].events(AccountsEntry.entrySignInEvents);
        Template[this.template].helpers(AccountsEntry.entrySignInHelpers);
      }
      return this.next();
    }
  });
  this.route("entrySignUp", {
    path: "/sign-up",
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      Session.set('buttonText', 'up');
      return this.next();
    },
    onRun: function() {
      var pkgRendered, userRendered;
      if (AccountsEntry.settings.signUpTemplate) {
        this.template = AccountsEntry.settings.signUpTemplate;
        pkgRendered = Template.entrySignUp.rendered;
        userRendered = Template[this.template].rendered;
        if (userRendered) {
          Template[this.template].rendered = function() {
            pkgRendered.call(this);
            return userRendered.call(this);
          };
        } else {
          Template[this.template].rendered = pkgRendered;
        }
        Template[this.template].events(AccountsEntry.entrySignUpEvents);
        Template[this.template].helpers(AccountsEntry.entrySignUpHelpers);
      }
      return this.next();
    }
  });
  this.route("entryForgotPassword", {
    path: "/forgot-password",
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      return this.next();
    }
  });
  this.route('entrySignOut', {
    path: '/sign-out',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      if (!AccountsEntry.settings.homeRoute) {
        return this.next();
      } else {
        Meteor.call('logOut', Meteor.userId());
        return Meteor.logout(function() {
          return Router.go(AccountsEntry.settings.homeRoute);
        });
      }
    }
  });
  this.route('entryVerificationPending', {
    path: '/verification-pending',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      return this.next();
    }
  });
  this.route('entryResetPassword', {
    path: 'reset-password/:resetToken',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      Session.set('resetToken', this.params.resetToken);
      return this.next();
    }
  });
  return this.route('entryEnrollAccount', {
    path: 'enroll-account/:resetToken',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      return Session.set('resetToken', this.params.resetToken);
    }
  });
});

exclusions = [];

_.each(Router.routes, function(route) {
  return exclusions.push(route.getName());
});

Router.onStop(function() {
  var _ref;
  if (!_.contains(exclusions, (_ref = Router.current().route) != null ? _ref.getName() : void 0)) {
    return Session.set('fromWhere', window.location.pathname);
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
