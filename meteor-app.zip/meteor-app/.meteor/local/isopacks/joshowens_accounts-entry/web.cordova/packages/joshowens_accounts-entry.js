(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signIn/template.signIn.app.js                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySignIn");                                                                                  // 2
Template["entrySignIn"] = new Template("Template.entrySignIn", (function() {                                          // 3
  var view = this;                                                                                                    // 4
  return Spacebars.include(view.lookupTemplate("ionBody"), function() {                                               // 5
    return [ "\n        ", Spacebars.include(view.lookupTemplate("ionView"), function() {                             // 6
      return [ "\n            ", Blaze._TemplateWith(function() {                                                     // 7
        return {                                                                                                      // 8
          "class": Spacebars.call("body-texture")                                                                     // 9
        };                                                                                                            // 10
      }, function() {                                                                                                 // 11
        return Spacebars.include(view.lookupTemplate("ionContent"), function() {                                      // 12
          return [ "\n                ", Spacebars.include(view.lookupTemplate("ionList"), function() {               // 13
            return [ "\n                    ", HTML.DIV({                                                             // 14
              "class": "page-wrapper-auth"                                                                            // 15
            }, "\n\n\n\n                        ", HTML.DIV({                                                         // 16
              "class": ""                                                                                             // 17
            }, "\n                            ", HTML.DIV({                                                           // 18
              "class": "wrapper-auth"                                                                                 // 19
            }, "\n                                ", Blaze.If(function() {                                            // 20
              return Spacebars.call(view.lookup("logo"));                                                             // 21
            }, function() {                                                                                           // 22
              return [ "\n                                    ", HTML.DIV({                                           // 23
                "class": "entry-logo"                                                                                 // 24
              }, "\n                                        ", HTML.A({                                               // 25
                href: "/"                                                                                             // 26
              }, HTML.IMG({                                                                                           // 27
                src: function() {                                                                                     // 28
                  return Spacebars.mustache(view.lookup("logo"));                                                     // 29
                },                                                                                                    // 30
                alt: "logo"                                                                                           // 31
              })), "\n                                    "), "\n                                " ];                 // 32
            }, function() {                                                                                           // 33
              return [ "\n                                    ", HTML.H1({                                            // 34
                "class": "title-auth"                                                                                 // 35
              }, "Fantasia"), "\n                                    ", HTML.P({                                      // 36
                "class": "subtitle-auth"                                                                              // 37
              }, "emotional chat"), "\n                                " ];                                           // 38
            }), "\n\n                              ", HTML.DIV({                                                      // 39
              "class": ""                                                                                             // 40
            }, "\n                                ", Blaze.If(function() {                                            // 41
              return Spacebars.call(view.lookup("otherLoginServices"));                                               // 42
            }, function() {                                                                                           // 43
              return [ "\n                                ", HTML.DIV({                                               // 44
                "class": "entry-social"                                                                               // 45
              }, "\n                                  ", Blaze.Each(function() {                                      // 46
                return Spacebars.call(view.lookup("loginServices"));                                                  // 47
              }, function() {                                                                                         // 48
                return [ "\n                                    ", Spacebars.include(view.lookupTemplate("entrySocial")), "\n                                  " ];
              }), "\n                                  ", Blaze.If(function() {                                       // 50
                return Spacebars.call(view.lookup("passwordLoginService"));                                           // 51
              }, function() {                                                                                         // 52
                return [ "\n                                  ", HTML.DIV({                                           // 53
                  "class": "email-option"                                                                             // 54
                }, "\n                                    ", HTML.STRONG({                                            // 55
                  "class": "line-thru or-sign-in"                                                                     // 56
                }, Blaze.View("lookup:t9n", function() {                                                              // 57
                  return Spacebars.mustache(view.lookup("t9n"), "OR");                                                // 58
                })), "\n                                  "), "\n                                  " ];               // 59
              }), "\n                                "), "\n                                " ];                      // 60
            }), "\n                                ", Spacebars.include(view.lookupTemplate("entryError")), "\n                                ", Blaze.Unless(function() {
              return Spacebars.call(view.lookup("otherLoginServices"));                                               // 62
            }, function() {                                                                                           // 63
              return [ "\n                                  ", HTML.DIV({                                             // 64
                "class": "email-option"                                                                               // 65
              }, "\n                                    ", HTML.H3(Blaze.View("lookup:t9n", function() {              // 66
                return Spacebars.mustache(view.lookup("t9n"), "signIn");                                              // 67
              })), "\n                                  "), "\n                                " ];                   // 68
            }), "\n\n                                  ", Blaze.If(function() {                                       // 69
              return Spacebars.call(view.lookup("passwordLoginService"));                                             // 70
            }, function() {                                                                                           // 71
              return [ "\n                                      ", HTML.FORM({                                        // 72
                "class": "entry-form",                                                                                // 73
                id: "signIn"                                                                                          // 74
              }, "\n\n                                            ", HTML.DIV({                                       // 75
                "class": "form-group"                                                                                 // 76
              }, "\n                                                ", HTML.DIV({                                     // 77
                "class": "input-symbol"                                                                               // 78
              }, "\n                                                    ", HTML.INPUT({                               // 79
                autofocus: "",                                                                                        // 80
                name: "email",                                                                                        // 81
                type: function() {                                                                                    // 82
                  return Spacebars.mustache(view.lookup("emailInputType"));                                           // 83
                },                                                                                                    // 84
                "class": "form-control",                                                                              // 85
                value: function() {                                                                                   // 86
                  return Spacebars.mustache(view.lookup("email"));                                                    // 87
                },                                                                                                    // 88
                placeholder: function() {                                                                             // 89
                  return Spacebars.mustache(view.lookup("emailPlaceholder"));                                         // 90
                },                                                                                                    // 91
                autocapitalize: "none",                                                                               // 92
                autocomplete: "off",                                                                                  // 93
                autocorrect: "off"                                                                                    // 94
              }), "\n                                                "), "\n                                            "), "\n\n                                            ", HTML.DIV({
                "class": "form-group"                                                                                 // 96
              }, "\n                                                ", HTML.DIV({                                     // 97
                "class": "input-symbol"                                                                               // 98
              }, "\n                                                    ", HTML.INPUT({                               // 99
                name: "password",                                                                                     // 100
                type: "password",                                                                                     // 101
                "class": "form-control",                                                                              // 102
                value: function() {                                                                                   // 103
                  return Spacebars.mustache(view.lookup("password"));                                                 // 104
                },                                                                                                    // 105
                placeholder: function() {                                                                             // 106
                  return Spacebars.mustache(view.lookup("t9n"), "password");                                          // 107
                }                                                                                                     // 108
              }), "\n                                                "), "\n                                            "), "\n\n                                            ", Blaze.Unless(function() {
                return Spacebars.call(view.lookup("isUsernameOnly"));                                                 // 110
              }, function() {                                                                                         // 111
                return [ "\n                                              ", HTML.P(HTML.A({                          // 112
                  href: function() {                                                                                  // 113
                    return Spacebars.mustache(view.lookup("pathFor"), "entryForgotPassword");                         // 114
                  }                                                                                                   // 115
                }, Blaze.View("lookup:t9n", function() {                                                              // 116
                  return Spacebars.mustache(view.lookup("t9n"), "forgotPassword");                                    // 117
                }))), "\n                                              ", HTML.BUTTON({                               // 118
                  type: "submit",                                                                                     // 119
                  "class": "submit btn btn-primary"                                                                   // 120
                }, Blaze.View("lookup:t9n", function() {                                                              // 121
                  return Spacebars.mustache(view.lookup("t9n"), "signIn");                                            // 122
                })), "\n                                            " ];                                              // 123
              }), "\n\n                                      "), "\n                                " ];              // 124
            }), "\n\n                                ", Blaze.If(function() {                                         // 125
              return Spacebars.call(view.lookup("showCreateAccountLink"));                                            // 126
            }, function() {                                                                                           // 127
              return [ "\n                                ", HTML.P({                                                 // 128
                "class": "entry-signup-cta"                                                                           // 129
              }, Blaze.View("lookup:t9n", function() {                                                                // 130
                return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                   // 131
              }), " ", HTML.A({                                                                                       // 132
                href: function() {                                                                                    // 133
                  return Spacebars.mustache(view.lookup("pathFor"), "entrySignUp");                                   // 134
                }                                                                                                     // 135
              }, Blaze.View("lookup:t9n", function() {                                                                // 136
                return Spacebars.mustache(view.lookup("t9n"), "signUp");                                              // 137
              }))), "\n                                " ];                                                           // 138
            }), "\n                                ", HTML.Comment('<p class=""><a class="button js-login-with-fb-btn">Login with Facebook</a></p>'), "\n                                ", Blaze.If(function() {
              return Spacebars.call(view.lookup("talkingToServer"));                                                  // 140
            }, function() {                                                                                           // 141
              return [ "\n                                  ", Spacebars.include(view.lookupTemplate("spinner")), "\n                                " ];
            }), "\n                              "), "\n                            "), "\n                        "), "\n\n\n                    "), "\n                " ];
          }), "\n            " ];                                                                                     // 144
        });                                                                                                           // 145
      }), "\n        " ];                                                                                             // 146
    }), "\n    " ];                                                                                                   // 147
  });                                                                                                                 // 148
}));                                                                                                                  // 149
                                                                                                                      // 150
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/template.signUp.app.js                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySignUp");                                                                                  // 2
Template["entrySignUp"] = new Template("Template.entrySignUp", (function() {                                          // 3
  var view = this;                                                                                                    // 4
  return Spacebars.include(view.lookupTemplate("ionBody"), function() {                                               // 5
    return [ "\n    ", Spacebars.include(view.lookupTemplate("ionView"), function() {                                 // 6
      return [ "\n        ", Blaze._TemplateWith(function() {                                                         // 7
        return {                                                                                                      // 8
          "class": Spacebars.call("body-texture")                                                                     // 9
        };                                                                                                            // 10
      }, function() {                                                                                                 // 11
        return Spacebars.include(view.lookupTemplate("ionContent"), function() {                                      // 12
          return [ "\n            ", Spacebars.include(view.lookupTemplate("ionList"), function() {                   // 13
            return [ "\n                ", HTML.DIV({                                                                 // 14
              "class": "page-wrapper-auth"                                                                            // 15
            }, "\n                    ", HTML.DIV({                                                                   // 16
              "class": ""                                                                                             // 17
            }, "\n                        ", HTML.DIV({                                                               // 18
              "class": "wrapper-auth"                                                                                 // 19
            }, "\n                            ", Blaze.If(function() {                                                // 20
              return Spacebars.call(view.lookup("logo"));                                                             // 21
            }, function() {                                                                                           // 22
              return [ "\n                                ", HTML.DIV({                                               // 23
                "class": "entry-logo"                                                                                 // 24
              }, "\n                                    ", HTML.A({                                                   // 25
                href: "/"                                                                                             // 26
              }, HTML.IMG({                                                                                           // 27
                src: function() {                                                                                     // 28
                  return Spacebars.mustache(view.lookup("logo"));                                                     // 29
                },                                                                                                    // 30
                alt: "logo"                                                                                           // 31
              })), "\n                                "), "\n                            " ];                         // 32
            }, function() {                                                                                           // 33
              return [ "\n                                ", HTML.H1({                                                // 34
                "class": "title-auth"                                                                                 // 35
              }, "Fantasia"), "\n                                ", HTML.P({                                          // 36
                "class": "subtitle-auth"                                                                              // 37
              }, "emotional chat"), "\n                            " ];                                               // 38
            }), "\n\n                                ", HTML.DIV({                                                    // 39
              "class": "create-account-option"                                                                        // 40
            }, "\n                                    ", HTML.H3(Blaze.View("lookup:t9n", function() {                // 41
              return Spacebars.mustache(view.lookup("t9n"), "createAccount");                                         // 42
            })), "\n                                ", Blaze.If(function() {                                          // 43
              return Spacebars.call(view.lookup("otherLoginServices"));                                               // 44
            }, function() {                                                                                           // 45
              return [ "\n                                  ", HTML.P({                                               // 46
                "class": "entry-signin-cta"                                                                           // 47
              }, Blaze.View("lookup:t9n", function() {                                                                // 48
                return Spacebars.mustache(view.lookup("t9n"), "ifYouAlreadyHaveAnAccount");                           // 49
              }), " ", HTML.A({                                                                                       // 50
                href: function() {                                                                                    // 51
                  return Spacebars.mustache(view.lookup("pathFor"), "entrySignIn");                                   // 52
                }                                                                                                     // 53
              }, Blaze.View("lookup:t9n", function() {                                                                // 54
                return Spacebars.mustache(view.lookup("t9n"), "signin");                                              // 55
              })), "."), "\n                                  ", HTML.DIV({                                           // 56
                "class": "entry-social"                                                                               // 57
              }, "\n                                    ", Blaze.Each(function() {                                    // 58
                return Spacebars.call(view.lookup("loginServices"));                                                  // 59
              }, function() {                                                                                         // 60
                return [ "\n                                      ", Spacebars.include(view.lookupTemplate("entrySocial")), "\n                                    " ];
              }), "\n                                    ", Blaze.If(function() {                                     // 62
                return Spacebars.call(view.lookup("passwordLoginService"));                                           // 63
              }, function() {                                                                                         // 64
                return [ "\n                                      ", HTML.DIV({                                       // 65
                  "class": "email-option"                                                                             // 66
                }, "\n                                        ", HTML.STRONG({                                        // 67
                  "class": "line-thru"                                                                                // 68
                }, Blaze.View("lookup:t9n", function() {                                                              // 69
                  return Spacebars.mustache(view.lookup("t9n"), "OR");                                                // 70
                })), "\n                                        ", HTML.A({                                           // 71
                  "data-toggle": "collapse",                                                                          // 72
                  href: "#signUp"                                                                                     // 73
                }, "\n                                          ", Blaze.View("lookup:t9n", function() {              // 74
                  return Spacebars.mustache(view.lookup("t9n"), "signUpWithYourEmailAddress");                        // 75
                }), "\n                                        "), "\n                                      "), "\n                                    " ];
              }), "\n                                  "), "\n                                " ];                    // 77
            }, function() {                                                                                           // 78
              return [ "\n                                    ", HTML.P({                                             // 79
                "class": "entry-signin-cta"                                                                           // 80
              }, Blaze.View("lookup:t9n", function() {                                                                // 81
                return Spacebars.mustache(view.lookup("t9n"), "ifYouAlreadyHaveAnAccount");                           // 82
              }), " ", HTML.A({                                                                                       // 83
                href: function() {                                                                                    // 84
                  return Spacebars.mustache(view.lookup("pathFor"), "entrySignIn");                                   // 85
                }                                                                                                     // 86
              }, Blaze.View("lookup:t9n", function() {                                                                // 87
                return Spacebars.mustache(view.lookup("t9n"), "signin");                                              // 88
              })), "."), "\n                                " ];                                                      // 89
            }), "\n                                ", Spacebars.include(view.lookupTemplate("entryError")), "\n                                ", Blaze.If(function() {
              return Spacebars.call(view.lookup("passwordLoginService"));                                             // 91
            }, function() {                                                                                           // 92
              return [ "\n                                  ", HTML.FORM({                                            // 93
                "class": function() {                                                                                 // 94
                  return [ "entry-form ", Spacebars.mustache(view.lookup("signupClass")) ];                           // 95
                },                                                                                                    // 96
                id: "signUp"                                                                                          // 97
              }, "\n                                    ", Blaze.If(function() {                                      // 98
                return Spacebars.call(view.lookup("showUsername"));                                                   // 99
              }, function() {                                                                                         // 100
                return [ "\n                                        \n                                      ", HTML.DIV({
                  "class": "form-group"                                                                               // 102
                }, "\n                                        ", HTML.DIV({                                           // 103
                  "class": "input-symbol"                                                                             // 104
                }, "\n                                         ", HTML.INPUT({                                        // 105
                  autofocus: "",                                                                                      // 106
                  name: "username",                                                                                   // 107
                  placeholder: function() {                                                                           // 108
                    return Spacebars.mustache(view.lookup("t9n"), "username");                                        // 109
                  },                                                                                                  // 110
                  type: "string",                                                                                     // 111
                  "class": "form-control",                                                                            // 112
                  value: "",                                                                                          // 113
                  autocapitalize: "none",                                                                             // 114
                  autocomplete: "off",                                                                                // 115
                  autocorrect: "off"                                                                                  // 116
                }), "\n                                        "), "\n                                      "), "\n                                        \n                                    " ];
              }), "\n                        \n                                    ", Blaze.If(function() {           // 118
                return Spacebars.call(view.lookup("showEmail"));                                                      // 119
              }, function() {                                                                                         // 120
                return [ "\n                                        \n                                      ", HTML.DIV({
                  "class": "form-group"                                                                               // 122
                }, "\n                                        ", Blaze.If(function() {                                // 123
                  return Spacebars.call(view.lookup("showUsername"));                                                 // 124
                }, function() {                                                                                       // 125
                  return [ "\n                                            ", HTML.DIV({                               // 126
                    "class": "input-symbol"                                                                           // 127
                  }, "\n                                              ", HTML.INPUT({                                 // 128
                    type: "email",                                                                                    // 129
                    placeholder: function() {                                                                         // 130
                      return Spacebars.mustache(view.lookup("t9n"), "emailAddress");                                  // 131
                    },                                                                                                // 132
                    "class": "form-control",                                                                          // 133
                    value: function() {                                                                               // 134
                      return Spacebars.mustache(view.lookup("emailAddress"));                                         // 135
                    },                                                                                                // 136
                    autocapitalize: "none",                                                                           // 137
                    autocomplete: "off",                                                                              // 138
                    autocorrect: "off"                                                                                // 139
                  }), "\n                                            "), "\n                                        " ];
                }, function() {                                                                                       // 141
                  return [ "\n                                          ", HTML.INPUT({                               // 142
                    autofocus: "",                                                                                    // 143
                    type: "email",                                                                                    // 144
                    placeholder: function() {                                                                         // 145
                      return Spacebars.mustache(view.lookup("t9n"), "emailAddress");                                  // 146
                    },                                                                                                // 147
                    "class": "form-control",                                                                          // 148
                    value: function() {                                                                               // 149
                      return Spacebars.mustache(view.lookup("emailAddress"));                                         // 150
                    },                                                                                                // 151
                    autocapitalize: "none",                                                                           // 152
                    autocomplete: "off",                                                                              // 153
                    autocorrect: "off"                                                                                // 154
                  }), "\n                                        " ];                                                 // 155
                }), "\n                                      "), "\n                                    " ];          // 156
              }), "\n                        \n                                    ", HTML.DIV({                      // 157
                "class": "form-group"                                                                                 // 158
              }, "\n                                       ", HTML.DIV({                                              // 159
                "class": "input-symbol"                                                                               // 160
              }, "\n                                           ", HTML.INPUT({                                        // 161
                type: "password",                                                                                     // 162
                placeholder: function() {                                                                             // 163
                  return Spacebars.mustache(view.lookup("t9n"), "password");                                          // 164
                },                                                                                                    // 165
                "class": "form-control",                                                                              // 166
                value: ""                                                                                             // 167
              }), "\n                                        "), "\n                                    "), "\n                        \n                                    ", Blaze.If(function() {
                return Spacebars.call(view.lookup("showSignupCode"));                                                 // 169
              }, function() {                                                                                         // 170
                return [ "\n                                      ", HTML.DIV({                                       // 171
                  "class": "form-group"                                                                               // 172
                }, "\n                                          ", HTML.DIV({                                         // 173
                  "class": "input-symbol"                                                                             // 174
                }, "\n                                            ", HTML.INPUT({                                     // 175
                  name: "signupCode",                                                                                 // 176
                  placeholder: function() {                                                                           // 177
                    return Spacebars.mustache(view.lookup("t9n"), "signupCode");                                      // 178
                  },                                                                                                  // 179
                  type: "string",                                                                                     // 180
                  "class": "form-control",                                                                            // 181
                  value: "",                                                                                          // 182
                  autocapitalize: "none",                                                                             // 183
                  autocomplete: "off",                                                                                // 184
                  autocorrect: "off"                                                                                  // 185
                }), "\n                                          "), "    \n                                      "), "\n                                    " ];
              }), "\n                        \n                                    ", Spacebars.include(view.lookupTemplate("entryExtraSignUpFields")), "\n                                    ", HTML.BUTTON({
                type: "submit",                                                                                       // 188
                "class": "submit btn btn-primary"                                                                     // 189
              }, Blaze.View("lookup:t9n", function() {                                                                // 190
                return Spacebars.mustache(view.lookup("t9n"), "signUp");                                              // 191
              })), "\n                                  "), "\n                                " ];                   // 192
            }), "\n                                ", Blaze.If(function() {                                           // 193
              return Spacebars.call(view.lookup("both"));                                                             // 194
            }, function() {                                                                                           // 195
              return [ "\n                                  ", HTML.P({                                               // 196
                "class": "entry-agreement"                                                                            // 197
              }, Blaze.View("lookup:t9n", function() {                                                                // 198
                return Spacebars.mustache(view.lookup("t9n"), "clickAgree");                                          // 199
              }), "\n                                    ", HTML.A({                                                  // 200
                href: function() {                                                                                    // 201
                  return Spacebars.mustache(view.lookup("privacyUrl"));                                               // 202
                }                                                                                                     // 203
              }, Blaze.View("lookup:t9n", function() {                                                                // 204
                return Spacebars.mustache(view.lookup("t9n"), "privacyPolicy");                                       // 205
              })), " ", Blaze.View("lookup:t9n", function() {                                                         // 206
                return Spacebars.mustache(view.lookup("t9n"), "and");                                                 // 207
              }), "\n                                    ", HTML.A({                                                  // 208
                href: function() {                                                                                    // 209
                  return Spacebars.mustache(view.lookup("termsUrl"));                                                 // 210
                }                                                                                                     // 211
              }, Blaze.View("lookup:t9n", function() {                                                                // 212
                return Spacebars.mustache(view.lookup("t9n"), "terms");                                               // 213
              })), ".\n                                  "), "\n                                " ];                  // 214
            }, function() {                                                                                           // 215
              return [ "\n                                  ", Blaze.Unless(function() {                              // 216
                return Spacebars.call(view.lookup("neither"));                                                        // 217
              }, function() {                                                                                         // 218
                return [ "\n                                    ", HTML.P({                                           // 219
                  "class": "entry-agreement"                                                                          // 220
                }, Blaze.View("lookup:t9n", function() {                                                              // 221
                  return Spacebars.mustache(view.lookup("t9n"), "clickAgree");                                        // 222
                }), "\n                                      ", Blaze.If(function() {                                 // 223
                  return Spacebars.call(view.lookup("privacyUrl"));                                                   // 224
                }, function() {                                                                                       // 225
                  return [ HTML.A({                                                                                   // 226
                    href: function() {                                                                                // 227
                      return Spacebars.mustache(view.lookup("privacyUrl"));                                           // 228
                    }                                                                                                 // 229
                  }, Blaze.View("lookup:t9n", function() {                                                            // 230
                    return Spacebars.mustache(view.lookup("t9n"), "privacyPolicy");                                   // 231
                  })), "." ];                                                                                         // 232
                }), "\n                                      ", Blaze.If(function() {                                 // 233
                  return Spacebars.call(view.lookup("termsUrl"));                                                     // 234
                }, function() {                                                                                       // 235
                  return [ HTML.A({                                                                                   // 236
                    href: function() {                                                                                // 237
                      return Spacebars.mustache(view.lookup("termsUrl"));                                             // 238
                    }                                                                                                 // 239
                  }, Blaze.View("lookup:t9n", function() {                                                            // 240
                    return Spacebars.mustache(view.lookup("t9n"), "terms");                                           // 241
                  })), "." ];                                                                                         // 242
                }), "\n                                    "), "\n                                  " ];              // 243
              }), "\n                                " ];                                                             // 244
            }), "\n                                ", Blaze.If(function() {                                           // 245
              return Spacebars.call(view.lookup("talkingToServer"));                                                  // 246
            }, function() {                                                                                           // 247
              return [ "\n                                  ", Spacebars.include(view.lookupTemplate("spinner")), "\n                                " ];
            }), "\n                              "), "\n                            "), "\n                          "), "\n                    "), "\n            " ];
          }), "\n        " ];                                                                                         // 250
        });                                                                                                           // 251
      }), "\n    " ];                                                                                                 // 252
    }), "\n" ];                                                                                                       // 253
  });                                                                                                                 // 254
}));                                                                                                                  // 255
                                                                                                                      // 256
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/template.extraSignUpFields.app.js                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryExtraSignUpFields");                                                                       // 2
Template["entryExtraSignUpFields"] = new Template("Template.entryExtraSignUpFields", (function() {                    // 3
  var view = this;                                                                                                    // 4
  return Blaze.Each(function() {                                                                                      // 5
    return Spacebars.call(view.lookup("extraSignUpFields"));                                                          // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("_entryExtraSignUpField")), "\n    " ];                  // 8
  });                                                                                                                 // 9
}));                                                                                                                  // 10
                                                                                                                      // 11
Template.__checkName("_entryExtraSignUpField");                                                                       // 12
Template["_entryExtraSignUpField"] = new Template("Template._entryExtraSignUpField", (function() {                    // 13
  var view = this;                                                                                                    // 14
  return [ Blaze.If(function() {                                                                                      // 15
    return Spacebars.call(view.lookup("isTextField"));                                                                // 16
  }, function() {                                                                                                     // 17
    return [ "\n    ", HTML.DIV({                                                                                     // 18
      "class": "form-group"                                                                                           // 19
    }, "\n        ", Blaze.View("lookup:text_field", function() {                                                     // 20
      return Spacebars.mustache(view.lookup("text_field"), view.lookup("field"), Spacebars.kw({                       // 21
        type: view.lookup("type"),                                                                                    // 22
        required: view.lookup("required"),                                                                            // 23
        label: view.lookup("label"),                                                                                  // 24
        placeholder: view.lookup("placeholder")                                                                       // 25
      }));                                                                                                            // 26
    }), "\n    "), "\n    " ];                                                                                        // 27
  }), "\n\n    ", Blaze.If(function() {                                                                               // 28
    return Spacebars.call(view.lookup("isCheckbox"));                                                                 // 29
  }, function() {                                                                                                     // 30
    return [ "\n    ", HTML.DIV({                                                                                     // 31
      "class": "checkbox"                                                                                             // 32
    }, "\n        ", Blaze.View("lookup:check_box", function() {                                                      // 33
      return Spacebars.mustache(view.lookup("check_box"), view.lookup("name"), Spacebars.kw({                         // 34
        label: view.lookup("label"),                                                                                  // 35
        required: view.lookup("required")                                                                             // 36
      }));                                                                                                            // 37
    }), "\n    "), "\n    " ];                                                                                        // 38
  }) ];                                                                                                               // 39
}));                                                                                                                  // 40
                                                                                                                      // 41
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/forgotPassword/template.forgotPassword.app.js                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryForgotPassword");                                                                          // 2
Template["entryForgotPassword"] = new Template("Template.entryForgotPassword", (function() {                          // 3
  var view = this;                                                                                                    // 4
  return Spacebars.include(view.lookupTemplate("ionBody"), function() {                                               // 5
    return [ "\n    ", Spacebars.include(view.lookupTemplate("ionView"), function() {                                 // 6
      return [ "\n        ", Blaze._TemplateWith(function() {                                                         // 7
        return {                                                                                                      // 8
          "class": Spacebars.call("body-texture")                                                                     // 9
        };                                                                                                            // 10
      }, function() {                                                                                                 // 11
        return Spacebars.include(view.lookupTemplate("ionContent"), function() {                                      // 12
          return [ "\n            ", Spacebars.include(view.lookupTemplate("ionList"), function() {                   // 13
            return [ "\n                ", HTML.DIV({                                                                 // 14
              "class": "page-wrapper-auth"                                                                            // 15
            }, "\n                    ", HTML.DIV({                                                                   // 16
              "class": ""                                                                                             // 17
            }, "\n                        ", HTML.DIV({                                                               // 18
              "class": "wrapper-auth"                                                                                 // 19
            }, "\n                            \n                            ", Blaze.If(function() {                  // 20
              return Spacebars.call(view.lookup("logo"));                                                             // 21
            }, function() {                                                                                           // 22
              return [ "\n                                ", HTML.DIV({                                               // 23
                "class": "entry-logo"                                                                                 // 24
              }, "\n                                    ", HTML.A({                                                   // 25
                href: "/"                                                                                             // 26
              }, HTML.IMG({                                                                                           // 27
                src: function() {                                                                                     // 28
                  return Spacebars.mustache(view.lookup("logo"));                                                     // 29
                },                                                                                                    // 30
                alt: "logo"                                                                                           // 31
              })), "\n                                "), "\n                            " ];                         // 32
            }, function() {                                                                                           // 33
              return [ "\n                                ", HTML.H1({                                                // 34
                "class": "title-auth"                                                                                 // 35
              }, "Fantasia"), "\n                                ", HTML.P({                                          // 36
                "class": "subtitle-auth"                                                                              // 37
              }, "emotional chat"), "\n                            " ];                                               // 38
            }), "\n                            \n                            ", HTML.DIV({                            // 39
              "class": "forgot-account-password"                                                                      // 40
            }, "\n                            ", Blaze.If(function() {                                                // 41
              return Spacebars.call(view.lookup("error"));                                                            // 42
            }, function() {                                                                                           // 43
              return [ "\n                              ", HTML.DIV({                                                 // 44
                "class": "alert alert-danger"                                                                         // 45
              }, Blaze.View("lookup:error", function() {                                                              // 46
                return Spacebars.mustache(view.lookup("error"));                                                      // 47
              })), "\n                            " ];                                                                // 48
            }), "\n                            ", HTML.H3(Blaze.View("lookup:t9n", function() {                       // 49
              return Spacebars.mustache(view.lookup("t9n"), "forgotPassword");                                        // 50
            })), "\n                            ", HTML.FORM({                                                        // 51
              id: "forgotPassword"                                                                                    // 52
            }, "\n                              ", HTML.DIV({                                                         // 53
              "class": "form-group"                                                                                   // 54
            }, "\n                                  ", HTML.DIV({                                                     // 55
              "class": "input-symbol"                                                                                 // 56
            }, "\n                                    ", HTML.INPUT({                                                 // 57
              type: "email",                                                                                          // 58
              name: "forgottenEmail",                                                                                 // 59
              "class": "form-control",                                                                                // 60
              placeholder: function() {                                                                               // 61
                return Spacebars.mustache(view.lookup("t9n"), "emailAddress");                                        // 62
              },                                                                                                      // 63
              value: ""                                                                                               // 64
            }), "\n                                  "), "\n                              "), "\n                              ", HTML.BUTTON({
              type: "submit",                                                                                         // 66
              "class": "submit btn btn-primary"                                                                       // 67
            }, Blaze.View("lookup:t9n", function() {                                                                  // 68
              return Spacebars.mustache(view.lookup("t9n"), "emailResetLink");                                        // 69
            })), "\n                            "), "\n                            ", Blaze.If(function() {           // 70
              return Spacebars.call(view.lookup("showSignupCode"));                                                   // 71
            }, function() {                                                                                           // 72
              return [ "\n                              ", HTML.P({                                                   // 73
                "class": "entry-signup-cta"                                                                           // 74
              }, Blaze.View("lookup:t9n", function() {                                                                // 75
                return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                   // 76
              }), " ", HTML.A({                                                                                       // 77
                href: function() {                                                                                    // 78
                  return Spacebars.mustache(view.lookup("pathFor"), "entrySignUp");                                   // 79
                }                                                                                                     // 80
              }, Blaze.View("lookup:t9n", function() {                                                                // 81
                return Spacebars.mustache(view.lookup("t9n"), "signUp");                                              // 82
              }))), "\n                            " ];                                                               // 83
            }), "\n                            ", Blaze.If(function() {                                               // 84
              return Spacebars.call(view.lookup("talkingToServer"));                                                  // 85
            }, function() {                                                                                           // 86
              return [ "\n                              ", Spacebars.include(view.lookupTemplate("spinner")), "\n                            " ];
            }), "\n                            "), "\n                            \n                        "), "\n                        \n                      "), "\n                "), "\n            " ];
          }), "\n        " ];                                                                                         // 89
        });                                                                                                           // 90
      }), "\n    " ];                                                                                                 // 91
    }), "\n" ];                                                                                                       // 92
  });                                                                                                                 // 93
}));                                                                                                                  // 94
                                                                                                                      // 95
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/resetPassword/template.resetPassword.app.js                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryResetPassword");                                                                           // 2
Template["entryResetPassword"] = new Template("Template.entryResetPassword", (function() {                            // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": function() {                                                                                             // 6
      return Spacebars.mustache(view.lookup("containerCSSClass"));                                                    // 7
    }                                                                                                                 // 8
  }, "\n    ", HTML.DIV({                                                                                             // 9
    "class": function() {                                                                                             // 10
      return Spacebars.mustache(view.lookup("rowCSSClass"));                                                          // 11
    }                                                                                                                 // 12
  }, "\n      ", Blaze.If(function() {                                                                                // 13
    return Spacebars.call(view.lookup("logo"));                                                                       // 14
  }, function() {                                                                                                     // 15
    return [ "\n        ", HTML.DIV({                                                                                 // 16
      "class": "entry-logo"                                                                                           // 17
    }, "\n            ", HTML.A({                                                                                     // 18
      href: "/"                                                                                                       // 19
    }, HTML.IMG({                                                                                                     // 20
      src: function() {                                                                                               // 21
        return Spacebars.mustache(view.lookup("logo"));                                                               // 22
      },                                                                                                              // 23
      alt: "logo"                                                                                                     // 24
    })), "\n        "), "\n      " ];                                                                                 // 25
  }), "\n      ", HTML.DIV({                                                                                          // 26
    "class": "entry col-md-4 col-md-offset-4"                                                                         // 27
  }, "\n        ", Blaze.If(function() {                                                                              // 28
    return Spacebars.call(view.lookup("error"));                                                                      // 29
  }, function() {                                                                                                     // 30
    return [ "\n          ", HTML.DIV({                                                                               // 31
      "class": "alert alert-danger"                                                                                   // 32
    }, Blaze.View("lookup:error", function() {                                                                        // 33
      return Spacebars.mustache(view.lookup("error"));                                                                // 34
    })), "\n        " ];                                                                                              // 35
  }), "\n        ", HTML.H3(Blaze.View("lookup:t9n", function() {                                                     // 36
    return Spacebars.mustache(view.lookup("t9n"), "resetYourPassword");                                               // 37
  })), "\n        ", HTML.FORM({                                                                                      // 38
    id: "resetPassword"                                                                                               // 39
  }, "\n          ", HTML.Raw('<div class="form-group">\n            <input type="password" name="new-password" class="form-control" value="">\n          </div>'), "\n          ", HTML.BUTTON({
    type: "submit",                                                                                                   // 41
    "class": "btn btn-default"                                                                                        // 42
  }, Blaze.View("lookup:t9n", function() {                                                                            // 43
    return Spacebars.mustache(view.lookup("t9n"), "updateYourPassword");                                              // 44
  })), "\n        "), "\n        ", Blaze.If(function() {                                                             // 45
    return Spacebars.call(view.lookup("showSignupCode"));                                                             // 46
  }, function() {                                                                                                     // 47
    return [ "\n          ", HTML.P({                                                                                 // 48
      "class": "entry-signup-cta"                                                                                     // 49
    }, Blaze.View("lookup:t9n", function() {                                                                          // 50
      return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                             // 51
    }), " ", HTML.A({                                                                                                 // 52
      href: function() {                                                                                              // 53
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignUp");                                             // 54
      }                                                                                                               // 55
    }, Blaze.View("lookup:t9n", function() {                                                                          // 56
      return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                        // 57
    }))), "\n        " ];                                                                                             // 58
  }), "\n        ", Blaze.If(function() {                                                                             // 59
    return Spacebars.call(view.lookup("talkingToServer"));                                                            // 60
  }, function() {                                                                                                     // 61
    return [ "\n          ", Spacebars.include(view.lookupTemplate("spinner")), "\n        " ];                       // 62
  }), "\n      "), "\n    "), "\n  ");                                                                                // 63
}));                                                                                                                  // 64
                                                                                                                      // 65
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/enrollAccount/template.enrollAccount.app.js                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryEnrollAccount");                                                                           // 2
Template["entryEnrollAccount"] = new Template("Template.entryEnrollAccount", (function() {                            // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": "container"                                                                                              // 6
  }, "\n    ", HTML.DIV({                                                                                             // 7
    "class": "row"                                                                                                    // 8
  }, "\n      ", Blaze.If(function() {                                                                                // 9
    return Spacebars.call(view.lookup("logo"));                                                                       // 10
  }, function() {                                                                                                     // 11
    return [ "\n        ", HTML.DIV({                                                                                 // 12
      "class": "entry-logo"                                                                                           // 13
    }, "\n            ", HTML.A({                                                                                     // 14
      href: "/"                                                                                                       // 15
    }, HTML.IMG({                                                                                                     // 16
      src: function() {                                                                                               // 17
        return Spacebars.mustache(view.lookup("logo"));                                                               // 18
      },                                                                                                              // 19
      alt: "logo"                                                                                                     // 20
    })), "\n        "), "\n      " ];                                                                                 // 21
  }), "\n      ", HTML.DIV({                                                                                          // 22
    "class": "entry col-md-4 col-md-offset-4"                                                                         // 23
  }, "\n        ", Blaze.If(function() {                                                                              // 24
    return Spacebars.call(view.lookup("error"));                                                                      // 25
  }, function() {                                                                                                     // 26
    return [ "\n          ", HTML.DIV({                                                                               // 27
      "class": "alert alert-danger"                                                                                   // 28
    }, Blaze.View("lookup:error", function() {                                                                        // 29
      return Spacebars.mustache(view.lookup("error"));                                                                // 30
    })), "\n        " ];                                                                                              // 31
  }), "\n        ", HTML.H3(Blaze.View("lookup:t9n", function() {                                                     // 32
    return Spacebars.mustache(view.lookup("t9n"), "choosePassword");                                                  // 33
  })), "\n        ", HTML.FORM({                                                                                      // 34
    id: "setPassword"                                                                                                 // 35
  }, "\n          ", HTML.Raw('<div class="form-group">\n            <input type="password" name="new-password" class="form-control" value="">\n          </div>'), "\n          ", HTML.BUTTON({
    type: "submit",                                                                                                   // 37
    "class": "btn btn-default"                                                                                        // 38
  }, Blaze.View("lookup:t9n", function() {                                                                            // 39
    return Spacebars.mustache(view.lookup("t9n"), "setPassword");                                                     // 40
  })), "\n        "), "\n        ", Blaze.If(function() {                                                             // 41
    return Spacebars.call(view.lookup("showSignupCode"));                                                             // 42
  }, function() {                                                                                                     // 43
    return [ "\n          ", HTML.P({                                                                                 // 44
      "class": "entry-signup-cta"                                                                                     // 45
    }, Blaze.View("lookup:t9n", function() {                                                                          // 46
      return Spacebars.mustache(view.lookup("t9n"), "dontHaveAnAccount");                                             // 47
    }), " ", HTML.A({                                                                                                 // 48
      href: "/sign-up"                                                                                                // 49
    }, Blaze.View("lookup:t9n", function() {                                                                          // 50
      return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                        // 51
    }))), "\n        " ];                                                                                             // 52
  }), "\n      "), "\n    "), "\n  ");                                                                                // 53
}));                                                                                                                  // 54
                                                                                                                      // 55
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/social/template.social.js                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySocial");                                                                                  // 2
Template["entrySocial"] = new Template("Template.entrySocial", (function() {                                          // 3
  var view = this;                                                                                                    // 4
  return HTML.BUTTON({                                                                                                // 5
    "class": "btn",                                                                                                   // 6
    id: function() {                                                                                                  // 7
      return [ "entry-", Spacebars.mustache(view.lookup(".")) ];                                                      // 8
    },                                                                                                                // 9
    name: function() {                                                                                                // 10
      return Spacebars.mustache(view.lookup("."));                                                                    // 11
    }                                                                                                                 // 12
  }, "\n    ", Blaze.If(function() {                                                                                  // 13
    return Spacebars.call(view.lookup("unconfigured"));                                                               // 14
  }, function() {                                                                                                     // 15
    return [ "\n      ", HTML.I({                                                                                     // 16
      "class": function() {                                                                                           // 17
        return [ "fa fa-", Spacebars.mustache(view.lookup("icon")) ];                                                 // 18
      }                                                                                                               // 19
    }), " ", Blaze.View("lookup:t9n", function() {                                                                    // 20
      return Spacebars.mustache(view.lookup("t9n"), "configure");                                                     // 21
    }), " ", Blaze.View("lookup:capitalize", function() {                                                             // 22
      return Spacebars.mustache(view.lookup("capitalize"), view.lookup("."));                                         // 23
    }), "\n    " ];                                                                                                   // 24
  }, function() {                                                                                                     // 25
    return [ "\n      ", HTML.I({                                                                                     // 26
      "class": function() {                                                                                           // 27
        return [ "fa fa-", Spacebars.mustache(view.lookup("icon")) ];                                                 // 28
      }                                                                                                               // 29
    }), " ", Blaze.View("lookup:buttonText", function() {                                                             // 30
      return Spacebars.mustache(view.lookup("buttonText"));                                                           // 31
    }), " ", Blaze.View("lookup:t9n", function() {                                                                    // 32
      return Spacebars.mustache(view.lookup("t9n"), "with");                                                          // 33
    }), " ", Blaze.View("lookup:capitalize", function() {                                                             // 34
      return Spacebars.mustache(view.lookup("capitalize"), view.lookup("."));                                         // 35
    }), "\n    " ];                                                                                                   // 36
  }), "\n  ");                                                                                                        // 37
}));                                                                                                                  // 38
                                                                                                                      // 39
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/error/template.error.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryError");                                                                                   // 2
Template["entryError"] = new Template("Template.entryError", (function() {                                            // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("error"));                                                                      // 6
  }, function() {                                                                                                     // 7
    return [ "\n  ", HTML.DIV({                                                                                       // 8
      "class": "alert alert-danger label",                                                                            // 9
      style: "width: 100%;    position: fixed; font-size: 1.2em; bottom: 0; left: 0;"                                 // 10
    }, Blaze.View("lookup:error", function() {                                                                        // 11
      return Spacebars.mustache(view.lookup("error"));                                                                // 12
    })), "\n  " ];                                                                                                    // 13
  });                                                                                                                 // 14
}));                                                                                                                  // 15
                                                                                                                      // 16
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/template.accountButtons.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryAccountButtons");                                                                          // 2
Template["entryAccountButtons"] = new Template("Template.entryAccountButtons", (function() {                          // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("currentUser"));                                                                // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("signedInTemplate")), "\n  " ];                          // 8
  }, function() {                                                                                                     // 9
    return [ "\n\n    ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                           // 10
      return [ "\n      ", HTML.A({                                                                                   // 11
        href: function() {                                                                                            // 12
          return Spacebars.mustache(view.lookup("pathFor"), "entrySignIn");                                           // 13
        }                                                                                                             // 14
      }, Blaze.View("lookup:beforeSignIn", function() {                                                               // 15
        return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignIn")));                                    // 16
      }), Blaze.View("lookup:t9n", function() {                                                                       // 17
        return Spacebars.mustache(view.lookup("t9n"), "signIn");                                                      // 18
      })), "\n    " ];                                                                                                // 19
    }), "\n\n    ", Blaze.Unless(function() {                                                                         // 20
      return Spacebars.call(view.lookup("wrapLinks"));                                                                // 21
    }, function() {                                                                                                   // 22
      return [ "\n      ", HTML.SPAN("or"), "\n    " ];                                                               // 23
    }), "\n\n    ", Blaze.If(function() {                                                                             // 24
      return Spacebars.call(view.lookup("showCreateAccountLink"));                                                    // 25
    }, function() {                                                                                                   // 26
      return [ "\n      ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                         // 27
        return [ "\n        ", HTML.A({                                                                               // 28
          href: function() {                                                                                          // 29
            return Spacebars.mustache(view.lookup("entrySignUp"));                                                    // 30
          }                                                                                                           // 31
        }, Blaze.View("lookup:beforeSignUp", function() {                                                             // 32
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignUp")));                                  // 33
        }), Blaze.View("lookup:t9n", function() {                                                                     // 34
          return Spacebars.mustache(view.lookup("t9n"), "signUp");                                                    // 35
        })), "\n      " ];                                                                                            // 36
      }), "\n    " ];                                                                                                 // 37
    }), "\n  " ];                                                                                                     // 38
  });                                                                                                                 // 39
}));                                                                                                                  // 40
                                                                                                                      // 41
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/template._wrapLinks.js                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("wrapLinks");                                                                                    // 2
Template["wrapLinks"] = new Template("Template.wrapLinks", (function() {                                              // 3
  var view = this;                                                                                                    // 4
  return HTML.LI("\n  ", Blaze._InOuterTemplateScope(view, function() {                                               // 5
    return Spacebars.include(function() {                                                                             // 6
      return Spacebars.call(view.templateContentBlock);                                                               // 7
    });                                                                                                               // 8
  }), "\n");                                                                                                          // 9
}));                                                                                                                  // 10
                                                                                                                      // 11
Template.__checkName("noWrapLinks");                                                                                  // 12
Template["noWrapLinks"] = new Template("Template.noWrapLinks", (function() {                                          // 13
  var view = this;                                                                                                    // 14
  return Blaze._InOuterTemplateScope(view, function() {                                                               // 15
    return Spacebars.include(function() {                                                                             // 16
      return Spacebars.call(view.templateContentBlock);                                                               // 17
    });                                                                                                               // 18
  });                                                                                                                 // 19
}));                                                                                                                  // 20
                                                                                                                      // 21
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/template.signedIn.js                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entrySignedIn");                                                                                // 2
Template["entrySignedIn"] = new Template("Template.entrySignedIn", (function() {                                      // 3
  var view = this;                                                                                                    // 4
  return [ Blaze.If(function() {                                                                                      // 5
    return Spacebars.call(view.lookup("profileUrl"));                                                                 // 6
  }, function() {                                                                                                     // 7
    return [ "\n  ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                               // 8
      return [ "\n    ", HTML.A({                                                                                     // 9
        "class": "profileLink",                                                                                       // 10
        href: function() {                                                                                            // 11
          return Spacebars.mustache(view.lookup("profileUrl"));                                                       // 12
        }                                                                                                             // 13
      }, Blaze.View("lookup:beforeSignedInAs", function() {                                                           // 14
        return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignedInAs")));                                // 15
      }), Blaze.View("lookup:signedInAs", function() {                                                                // 16
        return Spacebars.mustache(view.lookup("signedInAs"));                                                         // 17
      })), "\n  " ];                                                                                                  // 18
    }), "\n" ];                                                                                                       // 19
  }, function() {                                                                                                     // 20
    return [ "\n  ", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                               // 21
      return [ "\n    ", HTML.P({                                                                                     // 22
        "class": "navbar-text"                                                                                        // 23
      }, Blaze.View("lookup:beforeSignedInAs", function() {                                                           // 24
        return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignedInAs")));                                // 25
      }), Blaze.View("lookup:signedInAs", function() {                                                                // 26
        return Spacebars.mustache(view.lookup("signedInAs"));                                                         // 27
      })), "\n  " ];                                                                                                  // 28
    }), "\n" ];                                                                                                       // 29
  }), "\n\n", Spacebars.include(view.lookupTemplate("wrapLinksLi"), function() {                                      // 30
    return [ "\n  ", HTML.A({                                                                                         // 31
      href: function() {                                                                                              // 32
        return Spacebars.mustache(view.lookup("pathFor"), "entrySignOut");                                            // 33
      }                                                                                                               // 34
    }, Blaze.View("lookup:beforeSignOut", function() {                                                                // 35
      return Spacebars.makeRaw(Spacebars.mustache(view.lookup("beforeSignOut")));                                     // 36
    }), Blaze.View("lookup:t9n", function() {                                                                         // 37
      return Spacebars.mustache(view.lookup("t9n"), "signOut");                                                       // 38
    })), "\n" ];                                                                                                      // 39
  }) ];                                                                                                               // 40
}));                                                                                                                  // 41
                                                                                                                      // 42
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/verificationPending/template.verificationPending.js                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("entryVerificationPending");                                                                     // 2
Template["entryVerificationPending"] = new Template("Template.entryVerificationPending", (function() {                // 3
  var view = this;                                                                                                    // 4
  return HTML.DIV({                                                                                                   // 5
    "class": function() {                                                                                             // 6
      return Spacebars.mustache(view.lookup("containerCSSClass"));                                                    // 7
    }                                                                                                                 // 8
  }, "\n    ", HTML.DIV({                                                                                             // 9
    "class": function() {                                                                                             // 10
      return Spacebars.mustache(view.lookup("rowCSSClass"));                                                          // 11
    }                                                                                                                 // 12
  }, "\n      ", Blaze.If(function() {                                                                                // 13
    return Spacebars.call(view.lookup("logo"));                                                                       // 14
  }, function() {                                                                                                     // 15
    return [ "\n        ", HTML.DIV({                                                                                 // 16
      "class": "entry-logo"                                                                                           // 17
    }, "\n            ", HTML.A({                                                                                     // 18
      href: "/"                                                                                                       // 19
    }, HTML.IMG({                                                                                                     // 20
      src: function() {                                                                                               // 21
        return Spacebars.mustache(view.lookup("logo"));                                                               // 22
      },                                                                                                              // 23
      alt: "logo"                                                                                                     // 24
    })), "\n        "), "\n      " ];                                                                                 // 25
  }), "\n      ", HTML.DIV({                                                                                          // 26
    "class": "entry col-md-4 col-md-offset-4"                                                                         // 27
  }, "\n        ", Blaze.If(function() {                                                                              // 28
    return Spacebars.call(view.lookup("error"));                                                                      // 29
  }, function() {                                                                                                     // 30
    return [ "\n          ", HTML.DIV({                                                                               // 31
      "class": "alert alert-danger"                                                                                   // 32
    }, Blaze.View("lookup:error", function() {                                                                        // 33
      return Spacebars.mustache(view.lookup("error"));                                                                // 34
    })), "\n        " ];                                                                                              // 35
  }), "\n        ", HTML.DIV({                                                                                        // 36
    "class": "panel panel-info"                                                                                       // 37
  }, "\n          ", HTML.DIV({                                                                                       // 38
    "class": "panel-heading"                                                                                          // 39
  }, "\n            ", HTML.H3({                                                                                      // 40
    "class": "panel-title"                                                                                            // 41
  }, Blaze.View("lookup:t9n", function() {                                                                            // 42
    return Spacebars.mustache(view.lookup("t9n"), "verificationPending");                                             // 43
  })), "\n          "), "\n          ", HTML.DIV({                                                                    // 44
    "class": "panel-body"                                                                                             // 45
  }, "\n            ", Blaze.View("lookup:t9n", function() {                                                          // 46
    return Spacebars.mustache(view.lookup("t9n"), "verificationPendingDetails");                                      // 47
  }), "\n          "), "\n          \n        "), "\n      "), "\n    "), "\n  ");                                    // 48
}));                                                                                                                  // 49
                                                                                                                      // 50
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/entry.coffee.js                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                  

AccountsEntry = {
  settings: {
    wrapLinks: true,
    homeRoute: '/',
    dashboardRoute: '/dashboard',
    passwordSignupFields: 'EMAIL_ONLY',
    emailToLower: true,
    usernameToLower: false,
    entrySignUp: '/sign-up',
    extraSignUpFields: [],
    showOtherLoginServices: true,
    fluidLayout: false,
    useContainer: true,
    signInAfterRegistration: true,
    emailVerificationPendingRoute: '/verification-pending',
    showSpinner: true,
    spinnerOptions: {
      color: "#000",
      top: "80%"
    }
  },
  isStringEmail: function(email) {
    var emailPattern;
    emailPattern = /^([\w.-]+)@([\w.-]+)\.([a-zA-Z.]{2,6})$/i;
    if (email.match(emailPattern)) {
      return true;
    } else {
      return false;
    }
  },
  config: function(appConfig) {
    var signUpRoute;
    this.settings = _.extend(this.settings, appConfig);
    T9n.defaultLanguage = "en";
    if (appConfig.language) {
      T9n.language = appConfig.language;
    }
    if (appConfig.signUpTemplate) {
      signUpRoute = Router.routes['entrySignUp'];
      return signUpRoute.options.template = appConfig.signUpTemplate;
    }
  },
  signInRequired: function(router, extraCondition) {
    if (extraCondition == null) {
      extraCondition = true;
    }
    if (!Meteor.loggingIn()) {
      if (Meteor.user() && extraCondition) {
        return router.next();
      } else {
        Session.set('fromWhere', router.url);
        Router.go('/sign-in');
        Session.set('entryError', t9n('error.signInRequired'));
        return router.next();
      }
    }
  }
};

this.AccountsEntry = AccountsEntry;

this.T9NHelper = (function() {
  function T9NHelper() {}

  T9NHelper.translate = function(code) {
    return T9n.get(code, "error.accounts");
  };

  T9NHelper.accountsError = function(err) {
    return Session.set('entryError', this.translate(err.reason));
  };

  return T9NHelper;

})();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/helpers.coffee.js                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
if (typeof Handlebars !== "undefined") {
  UI.registerHelper("signedInAs", function(date) {
    if (Meteor.user().username) {
      return Meteor.user().username;
    } else if (Meteor.user().profile && Meteor.user().profile.name) {
      return Meteor.user().profile.name;
    } else if (Meteor.user().emails && Meteor.user().emails[0]) {
      return Meteor.user().emails[0].address;
    } else {
      return "Signed In";
    }
  });
}

UI.registerHelper('accountButtons', function() {
  return Template.entryAccountButtons;
});

UI.registerHelper('capitalize', function(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
});

UI.registerHelper('signupClass', function() {
  if (AccountsEntry.settings.showOtherLoginServices && Accounts.oauth && Accounts.oauth.serviceNames().length > 0) {
    return "collapse";
  }
});

UI.registerHelper('signedIn', function() {
  if (Meteor.user()) {
    return true;
  }
});

UI.registerHelper('otherLoginServices', function() {
  return AccountsEntry.settings.showOtherLoginServices && Accounts.oauth && Accounts.oauth.serviceNames().length > 0;
});

UI.registerHelper('loginServices', function() {
  return Accounts.oauth.serviceNames();
});

UI.registerHelper('showSignupCode', function() {
  return AccountsEntry.settings.showSignupCode === true;
});

UI.registerHelper('passwordLoginService', function() {
  return !!Package['accounts-password'];
});

UI.registerHelper('showCreateAccountLink', function() {
  return !Accounts._options.forbidClientAccountCreation;
});

UI.registerHelper('fluidLayout', function() {
  return AccountsEntry.settings.fluidLayout === true;
});

UI.registerHelper('talkingToServer', function() {
  if (AccountsEntry.settings.showSpinner === true) {
    Meteor.Spinner.options = AccountsEntry.settings.spinnerOptions;
    return Session.get('talkingToServer') === true;
  } else {
    return false;
  }
});

UI.registerHelper('containerCSSClass', function() {
  if (AccountsEntry.settings.useContainer === false) {
    return "accounts-entry-container";
  } else {
    if (AccountsEntry.settings.fluidLayout === true) {
      return "container-fluid";
    } else {
      return "container";
    }
  }
});

UI.registerHelper('rowCSSClass', function() {
  if (AccountsEntry.settings.fluidLayout === true) {
    return "row-fluid";
  } else {
    return "row";
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signIn/signIn.coffee.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
AccountsEntry.entrySignInHelpers = {
  emailInputType: function() {
    if (AccountsEntry.settings.passwordSignupFields === 'EMAIL_ONLY') {
      return 'email';
    } else {
      return 'string';
    }
  },
  emailPlaceholder: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    if (_.contains(['USERNAME_AND_EMAIL', 'USERNAME_AND_OPTIONAL_EMAIL'], fields)) {
      return t9n("usernameOrEmail");
    } else if (fields === "USERNAME_ONLY") {
      return t9n("username");
    }
    return t9n("email");
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  },
  isUsernameOnly: function() {
    return AccountsEntry.settings.passwordSignupFields === 'USERNAME_ONLY';
  }
};

AccountsEntry.entrySignInEvents = {
  'submit #signIn': function(event) {
    var email;
    event.preventDefault();
    email = $('input[name="email"]').val();
    if ((AccountsEntry.isStringEmail(email) && AccountsEntry.settings.emailToLower) || (!AccountsEntry.isStringEmail(email) && AccountsEntry.settings.usernameToLower)) {
      email = email.toLowerCase();
    }
    Session.set('email', email);
    Session.set('password', $('input[name="password"]').val());
    Session.set('talkingToServer', true);
    return Meteor.loginWithPassword(Session.get('email'), Session.get('password'), function(error) {
      Session.set('password', void 0);
      Session.set('talkingToServer', false);
      if (!error) {
        bz.help.location.processCurrentLocation();
      }
      if (error) {
        return T9NHelper.accountsError(error);
      } else if (Session.get('fromWhere')) {
        Router.go(Session.get('fromWhere'));
        return Session.set('fromWhere', void 0);
      } else {
        return Router.go(AccountsEntry.settings.dashboardRoute);
      }
    });
  },
  'click .js-login-with-fb-btn': function(e, v) {
    debugger;
    return Meteor.signInWithFacebook({}, function() {
      debugger;
    });
  }
};

Template.entrySignIn.helpers(AccountsEntry.entrySignInHelpers);

Template.entrySignIn.events(AccountsEntry.entrySignInEvents);

Template.entrySignIn.rendered = function() {
  $(document).foundation({
    abide: {
      live_validate: true,
      validate_on_blur: true,
      focus_on_invalid: true,
      error_labels: true,
      timeout: 1000,
      patterns: {
        email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
      }
    }
  });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/signUp.coffee.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
AccountsEntry.hashPassword = function(password) {
  return {
    digest: SHA256(password),
    algorithm: "sha-256"
  };
};

AccountsEntry.entrySignUpHelpers = {
  showEmail: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    return _.contains(['USERNAME_AND_EMAIL', 'USERNAME_AND_OPTIONAL_EMAIL', 'EMAIL_ONLY'], fields);
  },
  showUsername: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    return _.contains(['USERNAME_AND_EMAIL', 'USERNAME_AND_OPTIONAL_EMAIL', 'USERNAME_ONLY'], fields);
  },
  showSignupCode: function() {
    return AccountsEntry.settings.showSignupCode;
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  },
  privacyUrl: function() {
    return AccountsEntry.settings.privacyUrl;
  },
  termsUrl: function() {
    return AccountsEntry.settings.termsUrl;
  },
  both: function() {
    return AccountsEntry.settings.privacyUrl && AccountsEntry.settings.termsUrl;
  },
  neither: function() {
    return !AccountsEntry.settings.privacyUrl && !AccountsEntry.settings.termsUrl;
  },
  emailIsOptional: function() {
    var fields;
    fields = AccountsEntry.settings.passwordSignupFields;
    return _.contains(['USERNAME_AND_OPTIONAL_EMAIL'], fields);
  },
  emailAddress: function() {
    return Session.get('email');
  }
};

AccountsEntry.entrySignUpEvents = {
  'submit #signUp': function(event, t) {
    var email, emailRequired, extraFields, fields, filteredExtraFields, formValues, password, passwordErrors, signupCode, trimInput, username, usernameRequired;
    event.preventDefault();
    username = t.find('input[name="username"]') ? t.find('input[name="username"]').value.toLowerCase() : void 0;
    if (username && AccountsEntry.settings.usernameToLower) {
      username = username.toLowerCase();
    }
    signupCode = t.find('input[name="signupCode"]') ? t.find('input[name="signupCode"]').value : void 0;
    trimInput = function(val) {
      return val.replace(/^\s*|\s*$/g, "");
    };
    email = t.find('input[type="email"]') ? trimInput(t.find('input[type="email"]').value) : void 0;
    if (AccountsEntry.settings.emailToLower && email) {
      email = email.toLowerCase();
    }
    formValues = SimpleForm.processForm(event.target);
    extraFields = _.pluck(AccountsEntry.settings.extraSignUpFields, 'field');
    filteredExtraFields = _.pick(formValues, extraFields);
    password = t.find('input[type="password"]').value;
    fields = AccountsEntry.settings.passwordSignupFields;
    passwordErrors = (function(password) {
      var errMsg, msg;
      errMsg = [];
      msg = false;
      if (password.length < 7) {
        errMsg.push(t9n("error.minChar"));
      }
      if (password.search(/[a-z]/i) < 0) {
        errMsg.push(t9n("error.pwOneLetter"));
      }
      if (password.search(/[0-9]/) < 0) {
        errMsg.push(t9n("error.pwOneDigit"));
      }
      if (errMsg.length > 0) {
        msg = "";
        errMsg.forEach(function(e) {
          return msg = msg.concat("" + e + "\r\n");
        });
        Session.set('entryError', msg);
        return true;
      }
      return false;
    })(password);
    if (passwordErrors) {
      return;
    }
    emailRequired = _.contains(['USERNAME_AND_EMAIL', 'EMAIL_ONLY'], fields);
    usernameRequired = _.contains(['USERNAME_AND_EMAIL', 'USERNAME_ONLY'], fields);
    if (usernameRequired && username.length === 0) {
      Session.set('entryError', t9n("error.usernameRequired"));
      return;
    }
    if (username && AccountsEntry.isStringEmail(username)) {
      Session.set('entryError', t9n("error.usernameIsEmail"));
      return;
    }
    if (emailRequired && email.length === 0) {
      Session.set('entryError', t9n("error.emailRequired"));
      return;
    }
    if (AccountsEntry.settings.showSignupCode && signupCode.length === 0) {
      Session.set('entryError', t9n("error.signupCodeRequired"));
      return;
    }
    return Meteor.call('entryValidateSignupCode', signupCode, function(err, valid) {
      var newUserData;
      if (valid) {
        newUserData = {
          username: username,
          email: email,
          password: AccountsEntry.hashPassword(password),
          profile: filteredExtraFields
        };
        Session.set('talkingToServer', true);
        return Meteor.call('entryCreateUser', newUserData, function(err, data) {
          var isEmailSignUp, userCredential;
          Session.set('talkingToServer', false);
          if (err) {
            console.log(err);
            T9NHelper.accountsError(err);
            return;
          }
          isEmailSignUp = _.contains(['USERNAME_AND_EMAIL', 'EMAIL_ONLY'], AccountsEntry.settings.passwordSignupFields);
          if (isEmailSignUp) {
            userCredential = email;
          } else {
            userCredential = username;
          }
          if (AccountsEntry.settings.signInAfterRegistration === true) {
            Session.set('talkingToServer', true);
            return Meteor.loginWithPassword(userCredential, password, function(error) {
              Session.set('talkingToServer', false);
              if (error) {
                console.log(error);
                return T9NHelper.accountsError(error);
              } else if (Session.get('fromWhere')) {
                Router.go(Session.get('fromWhere'));
                return Session.set('fromWhere', void 0);
              } else {
                return Router.go(AccountsEntry.settings.dashboardRoute);
              }
            });
          } else {
            if (AccountsEntry.settings.emailVerificationPendingRoute) {
              return Router.go(AccountsEntry.settings.emailVerificationPendingRoute);
            }
          }
        });
      } else {
        console.log(err);
        Session.set('entryError', t9n("error.signupCodeIncorrect"));
      }
    });
  },
  'click .js-login-with-fb-btn': function(e, v) {
    debugger;
    return Meteor.signInWithFacebook({}, function() {
      debugger;
    });
  }
};

Template.entrySignUp.helpers(AccountsEntry.entrySignUpHelpers);

Template.entrySignUp.events(AccountsEntry.entrySignUpEvents);

Template.entrySignUp.rendered = function() {
  $(document).foundation({
    abide: {
      live_validate: true,
      validate_on_blur: true,
      focus_on_invalid: true,
      error_labels: true,
      timeout: 1000,
      patterns: {
        email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
      }
    }
  });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/signUp/extraSignUpFields.coffee.js                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryExtraSignUpFields.helpers({
  extraSignUpFields: function() {
    return AccountsEntry.settings.extraSignUpFields;
  }
});

Template._entryExtraSignUpField.helpers({
  isTextField: function() {
    return this.type !== "check_box";
  },
  isCheckbox: function() {
    return this.type === "check_box";
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/forgotPassword/forgotPassword.coffee.js                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryForgotPassword.helpers({
  error: function() {
    return t9n(Session.get('entryError'));
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});

Template.entryForgotPassword.events({
  'submit #forgotPassword': function(event) {
    event.preventDefault();
    Session.set('email', $('input[name="forgottenEmail"]').val());
    if (Session.get('email').length === 0) {
      Session.set('entryError', 'Email is required');
      return;
    }
    Session.set('talkingToServer', true);
    return Accounts.forgotPassword({
      email: Session.get('email')
    }, function(error) {
      Session.set('talkingToServer', false);
      if (error) {
        return Session.set('entryError', error.reason);
      } else {
        return Router.go(AccountsEntry.settings.homeRoute);
      }
    });
  }
});

Template.entryForgotPassword.rendered = function() {
  $(document).foundation({
    abide: {
      live_validate: true,
      validate_on_blur: true,
      focus_on_invalid: true,
      error_labels: true,
      timeout: 1000,
      patterns: {
        email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
      }
    }
  });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/resetPassword/resetPassword.coffee.js                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryResetPassword.helpers({
  error: function() {
    return Session.get('entryError');
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});

Template.entryResetPassword.events({
  'submit #resetPassword': function(event) {
    var password, passwordErrors;
    event.preventDefault();
    password = $('input[type="password"]').val();
    passwordErrors = (function(password) {
      var errMsg, msg;
      errMsg = [];
      msg = false;
      if (password.length < 7) {
        errMsg.push(t9n("error.minChar"));
      }
      if (password.search(/[a-z]/i) < 0) {
        errMsg.push(t9n("error.pwOneLetter"));
      }
      if (password.search(/[0-9]/) < 0) {
        errMsg.push(t9n("error.pwOneDigit"));
      }
      if (errMsg.length > 0) {
        msg = "";
        errMsg.forEach(function(e) {
          return msg = msg.concat("" + e + "\r\n");
        });
        Session.set('entryError', msg);
        return true;
      }
      return false;
    })(password);
    if (passwordErrors) {
      return;
    }
    Session.set('talkingToServer', true);
    return Accounts.resetPassword(Session.get('resetToken'), password, function(error) {
      Session.set('talkingToServer', false);
      if (error) {
        return Session.set('entryError', error.reason || "Unknown error");
      } else {
        Session.set('resetToken', null);
        return Router.go(AccountsEntry.settings.dashboardRoute);
      }
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/enrollAccount/enrollAccount.coffee.js                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryEnrollAccount.helpers({
  error: function() {
    return Session.get('entryError');
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});

Template.entryEnrollAccount.events({
  'submit #setPassword': function(event) {
    var password, passwordErrors;
    event.preventDefault();
    password = $('input[type="password"]').val();
    passwordErrors = (function(password) {
      var errMsg, msg;
      errMsg = [];
      msg = false;
      if (password.length < 7) {
        errMsg.push(t9n("error.minChar"));
      }
      if (password.search(/[a-z]/i) < 0) {
        errMsg.push(t9n("error.pwOneLetter"));
      }
      if (password.search(/[0-9]/) < 0) {
        errMsg.push(t9n("error.pwOneDigit"));
      }
      if (errMsg.length > 0) {
        msg = "";
        errMsg.forEach(function(e) {
          return msg = msg.concat("" + e + "\r\n");
        });
        Session.set('entryError', msg);
        return true;
      }
      return false;
    })(password);
    if (passwordErrors) {
      return;
    }
    return Accounts.resetPassword(Session.get('resetToken'), password, function(error) {
      if (error) {
        return Session.set('entryError', error.reason || "Unknown error");
      } else {
        Session.set('resetToken', null);
        return Router.go(AccountsEntry.settings.dashboardRoute);
      }
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/social/social.coffee.js                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var capitalize;

Template.entrySocial.helpers({
  buttonText: function() {
    var buttonText;
    buttonText = Session.get('buttonText');
    if (buttonText === 'up') {
      return t9n('signUp');
    } else {
      return t9n('signIn');
    }
  },
  unconfigured: function() {
    return ServiceConfiguration.configurations.find({
      service: this.toString()
    }).fetch().length === 0;
  },
  google: function() {
    if (this[0] === 'g' && this[1] === 'o') {
      return true;
    }
  },
  icon: function() {
    switch (this.toString()) {
      case 'google':
        return 'google-plus';
      case 'meteor-developer':
        return 'rocket';
      default:
        return this;
    }
  }
});

Template.entrySocial.events({
  'click .btn': function(event) {
    var callback, loginWithService, options, serviceName;
    event.preventDefault();
    serviceName = $(event.target).attr('id').replace('entry-', '');
    callback = function(err) {
      Session.set('talkingToServer', false);
      if (!err) {
        if (Session.get('fromWhere')) {
          Router.go(Session.get('fromWhere'));
          return Session.set('fromWhere', void 0);
        } else {
          return Router.go(AccountsEntry.settings.dashboardRoute);
        }
      } else if (err instanceof Accounts.LoginCancelledError) {

      } else if (err instanceof ServiceConfiguration.ConfigError) {
        return Accounts._loginButtonsSession.configureService(serviceName);
      } else {
        return Accounts._loginButtonsSession.errorMessage(err.reason || t9n("error.unknown"));
      }
    };
    if (serviceName === 'meteor-developer') {
      loginWithService = Meteor["loginWithMeteorDeveloperAccount"];
    } else {
      loginWithService = Meteor["loginWith" + capitalize(serviceName)];
    }
    options = {};
    if (Accounts.ui._options.requestPermissions[serviceName]) {
      options.requestPermissions = Accounts.ui._options.requestPermissions[serviceName];
    }
    if (Accounts.ui._options.requestOfflineToken && Accounts.ui._options.requestOfflineToken[serviceName]) {
      options.requestOfflineToken = Accounts.ui._options.requestOfflineToken[serviceName];
    }
    Session.set('talkingToServer', true);
    return loginWithService(options, callback);
  }
});

capitalize = function(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/error/error.coffee.js                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryError.helpers({
  error: function() {
    return Session.get('entryError');
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/accountButtons/accountButtons.coffee.js                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var entryAccountButtonsHelpers;

entryAccountButtonsHelpers = {
  profileUrl: function() {
    if (!AccountsEntry.settings.profileRoute) {
      return false;
    }
    return AccountsEntry.settings.profileRoute;
  },
  wrapLinksLi: function() {
    if (AccountsEntry.settings.wrapLinks) {
      return Template.wrapLinks;
    } else {
      return Template.noWrapLinks;
    }
  },
  wrapLinks: function() {
    return AccountsEntry.settings.wrapLinks;
  },
  beforeSignIn: function() {
    return AccountsEntry.settings.beforeSignIn;
  },
  beforeSignUp: function() {
    return AccountsEntry.settings.beforeSignUp;
  },
  beforeSignOut: function() {
    return AccountsEntry.settings.beforeSignOut;
  },
  beforeSignedInAs: function() {
    return AccountsEntry.settings.beforeSignedInAs;
  },
  entrySignUp: function() {
    return AccountsEntry.settings.entrySignUp;
  },
  profile: function() {
    return Meteor.user().profile;
  }
};

Template.entryAccountButtons.helpers(entryAccountButtonsHelpers);

Template.entryAccountButtons.helpers({
  signedInTemplate: function() {
    if (AccountsEntry.settings.signedInTemplate) {
      Template[AccountsEntry.settings.signedInTemplate].helpers(entryAccountButtonsHelpers);
      return Template[AccountsEntry.settings.signedInTemplate];
    } else {
      return Template.entrySignedIn;
    }
  }
});

Template.entrySignedIn.helpers(entryAccountButtonsHelpers);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/views/verificationPending/verificationPending.coffee.js                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.entryVerificationPending.helpers({
  error: function() {
    return t9n(Session.get('entryError'));
  },
  logo: function() {
    return AccountsEntry.settings.logo;
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/client/t9n/english.coffee.js                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var en;

en = {
  signIn: "Sign In",
  signin: "sign in",
  signOut: "Sign Out",
  signUp: "Register",
  OR: "OR",
  forgotPassword: "Forgot your password?",
  emailAddress: "Email Address",
  emailResetLink: "Email Reset Link",
  dontHaveAnAccount: "Don't have an account?",
  resetYourPassword: "Reset your password",
  updateYourPassword: "Update your password",
  password: "Password",
  usernameOrEmail: "Username or email",
  email: "Email",
  ifYouAlreadyHaveAnAccount: "If you already have an account",
  signUpWithYourEmailAddress: "Register with your email address",
  username: "Username",
  optional: "Optional",
  signupCode: "Registration Code",
  clickAgree: "By clicking Register, you agree to our",
  privacyPolicy: "Privacy Policy",
  terms: "Terms of Use",
  sign: "Sign",
  configure: "Configure",
  "with": "with",
  createAccount: "Create an Account",
  verificationPending: "Confirm your email address",
  verificationPendingDetails: "A confirmation email has been sent to the email address you provided. Click on the confirmation link in the email to activate your account.",
  and: "and",
  "Match failed": "Match failed",
  "User not found": "User not found",
  error: {
    minChar: "7 character minimum password.",
    pwOneLetter: "Password requires 1 letter.",
    pwOneDigit: "Password must have at least one digit.",
    usernameRequired: "Username is required.",
    emailRequired: "Email is required.",
    signupCodeRequired: "Registration code is required.",
    signupCodeIncorrect: "Registration code is incorrect.",
    signInRequired: "You must be signed in to do that.",
    usernameIsEmail: "Username cannot be an email address."
  }
};

T9n.map("en", en);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/joshowens:accounts-entry/shared/router.coffee.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var exclusions;

Router.map(function() {
  this.route("entrySignIn", {
    path: "/sign-in",
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      Session.set('buttonText', 'in');
      return this.next();
    },
    onRun: function() {
      var pkgRendered, userRendered;
      if (Meteor.userId()) {
        Router.go(AccountsEntry.settings.dashboardRoute);
      }
      if (AccountsEntry.settings.signInTemplate) {
        this.template = AccountsEntry.settings.signInTemplate;
        pkgRendered = Template.entrySignIn.rendered;
        userRendered = Template[this.template].rendered;
        if (userRendered) {
          Template[this.template].rendered = function() {
            pkgRendered.call(this);
            return userRendered.call(this);
          };
        } else {
          Template[this.template].rendered = pkgRendered;
        }
        Template[this.template].events(AccountsEntry.entrySignInEvents);
        Template[this.template].helpers(AccountsEntry.entrySignInHelpers);
      }
      return this.next();
    }
  });
  this.route("entrySignUp", {
    path: "/sign-up",
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      Session.set('buttonText', 'up');
      return this.next();
    },
    onRun: function() {
      var pkgRendered, userRendered;
      if (AccountsEntry.settings.signUpTemplate) {
        this.template = AccountsEntry.settings.signUpTemplate;
        pkgRendered = Template.entrySignUp.rendered;
        userRendered = Template[this.template].rendered;
        if (userRendered) {
          Template[this.template].rendered = function() {
            pkgRendered.call(this);
            return userRendered.call(this);
          };
        } else {
          Template[this.template].rendered = pkgRendered;
        }
        Template[this.template].events(AccountsEntry.entrySignUpEvents);
        Template[this.template].helpers(AccountsEntry.entrySignUpHelpers);
      }
      return this.next();
    }
  });
  this.route("entryForgotPassword", {
    path: "/forgot-password",
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      return this.next();
    }
  });
  this.route('entrySignOut', {
    path: '/sign-out',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      if (!AccountsEntry.settings.homeRoute) {
        return this.next();
      } else {
        Meteor.call('logOut', Meteor.userId());
        return Meteor.logout(function() {
          return Router.go(AccountsEntry.settings.homeRoute);
        });
      }
    }
  });
  this.route('entryVerificationPending', {
    path: '/verification-pending',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      return this.next();
    }
  });
  this.route('entryResetPassword', {
    path: 'reset-password/:resetToken',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      Session.set('resetToken', this.params.resetToken);
      return this.next();
    }
  });
  return this.route('entryEnrollAccount', {
    path: 'enroll-account/:resetToken',
    layoutTemplate: 'basicLayout',
    onBeforeAction: function() {
      Session.set('entryError', void 0);
      return Session.set('resetToken', this.params.resetToken);
    }
  });
});

exclusions = [];

_.each(Router.routes, function(route) {
  return exclusions.push(route.getName());
});

Router.onStop(function() {
  var _ref;
  if (!_.contains(exclusions, (_ref = Router.current().route) != null ? _ref.getName() : void 0)) {
    return Session.set('fromWhere', window.location.pathname);
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
